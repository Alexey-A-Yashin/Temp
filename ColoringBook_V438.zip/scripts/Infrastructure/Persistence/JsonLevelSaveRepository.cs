using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using ColoringBook.Domain.Level;
using ColoringBook.Domain.Level.Season;
using Godot;

namespace ColoringBook.Infrastructure.Persistence;

/// <summary>
/// Простое JSON-хранилище дескрипторов.
/// Файлы кладутся в user://levels/
/// </summary>
public sealed class JsonLevelSaveRepository : ILevelSaveRepository
{
    private readonly string _directory;
    private readonly JsonSerializerOptions _options;

    public JsonLevelSaveRepository()
    {
        _directory = ProjectSettings.GlobalizePath("user://levels");
        Directory.CreateDirectory(_directory);

        _options = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            Converters = { new JsonStringEnumConverter() }
        };
    }

    public void Save(LevelDescriptor descriptor)
    {
        var path = GetPath(descriptor.Id);
        var dto = LevelDescriptorDto.FromDomain(descriptor);
        var json = JsonSerializer.Serialize(dto, _options);
        File.WriteAllText(path, json);
        GD.Print($"[Save] LevelDescriptor saved: {path}");
    }

    public LevelDescriptor? Load(Guid id)
    {
        var path = GetPath(id);
        if (!File.Exists(path))
            return null;

        var json = File.ReadAllText(path);
        var dto = JsonSerializer.Deserialize<LevelDescriptorDto>(json, _options);
        return dto?.ToDomain();
    }

    public IReadOnlyList<LevelDescriptor> LoadAll()
    {
        var result = new List<LevelDescriptor>();
        if (!Directory.Exists(_directory))
            return result;

        foreach (var file in Directory.GetFiles(_directory, "*.json"))
        {
            try
            {
                var json = File.ReadAllText(file);
                var dto = JsonSerializer.Deserialize<LevelDescriptorDto>(json, _options);
                if (dto != null)
                    result.Add(dto.ToDomain());
            }
            catch (Exception ex)
            {
                GD.PrintErr($"[Save] Failed to load {file}: {ex.Message}");
            }
        }

        return result;
    }

    public bool Exists(Guid id) => File.Exists(GetPath(id));

    public void Delete(Guid id)
    {
        var path = GetPath(id);
        if (File.Exists(path))
            File.Delete(path);
    }

    private string GetPath(Guid id) => Path.Combine(_directory, $"{id}.json");

    private sealed class LevelDescriptorDto
    {
        public Guid Id { get; set; }
        public int Seed { get; set; }
        public SeasonMode SeasonMode { get; set; }
        public SeasonType FixedSeason { get; set; }
        public DateTime CreatedUtc { get; set; }

        public static LevelDescriptorDto FromDomain(LevelDescriptor d) => new()
        {
            Id = d.Id,
            Seed = d.Seed,
            SeasonMode = d.SeasonMode,
            FixedSeason = d.FixedSeason,
            CreatedUtc = d.CreatedUtc
        };

        public LevelDescriptor ToDomain() => new(
            Id, Seed, SeasonMode, FixedSeason, CreatedUtc);
    }
}
