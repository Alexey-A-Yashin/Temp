using System;
using System.Text.Json;
using ColoringBook.Domain.Level.Settings;

namespace ColoringBook.Infrastructure.Settings;

/// <summary>
/// ЗАГРУЗКА НАСТРОЕК ИЗ JSON.
///
/// ---- ПОРЯДОК ЗНАЧЕНИЙ ----
///
/// По иерархии из книги (раздел «Конфигурация как инструмент управления
/// окружениями»): базовые умолчания, затем файл, затем правка на ходу.
///
///   1. УМОЛЧАНИЯ   в записях домена. Станок работает без пульта.
///   2. ФАЙЛ        settings/terrain.json и прочие. Нет файла — умолчания.
///   3. НА ХОДУ     присвоение FarBackground.Water и прочих.
///
/// НИЖНИЙ УРОВЕНЬ НЕ ОБЯЗАТЕЛЕН. Уровень собирается и без файлов — это правило,
/// а не удобство: иначе поломка файла роняет игру.
///
/// ---- ЧАСТИЧНЫЕ ФАЙЛЫ ----
///
/// В json можно указать одну величину, а не весь список: остальные останутся
/// умолчаниями. Так проще править то, что подбирается, не переписывая всё.
///
/// ---- ПОЧЕМУ НЕ GODOT RESOURCE ----
///
/// Настройки правятся не вручную в инспекторе, а приходят файлом. Resource с
/// [Export] тут лишний слой: он привязал бы записи домена к Godot без нужды.
/// </summary>
public static class SettingsLoader
{
    private static readonly JsonSerializerOptions Options = new()
    {
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
    };

    /// <summary>
    /// Читает настройки из файла. Нет файла или он повреждён — возвращает
    /// умолчания и сообщает причину.
    /// </summary>
    /// <param name="readText">Чтение файла. Отдельным доводом, чтобы домен и
    /// стенд не зависели от способа: в игре это Godot FileAccess, на стенде
    /// обычный File.</param>
    public static T Load<T>(string path, T fallback, Func<string, string?> readText,
                            Action<string>? report = null) where T : class
    {
        try
        {
            string? text = readText(path);
            if (string.IsNullOrWhiteSpace(text))
            {
                report?.Invoke($"[настройки] {path} не найден — берутся умолчания");
                return fallback;
            }

            var loaded = JsonSerializer.Deserialize<T>(text, Options);
            if (loaded is null)
            {
                report?.Invoke($"[настройки] {path} пуст — берутся умолчания");
                return fallback;
            }

            report?.Invoke($"[настройки] {path} загружен");
            return loaded;
        }
        catch (Exception e)
        {
            // Поломка файла НЕ должна ронять игру: берутся умолчания, причина
            // пишется в журнал.
            report?.Invoke($"[настройки] {path} не разобран ({e.Message}) — умолчания");
            return fallback;
        }
    }

    /// <summary>Записывает настройки в json — чтобы получить образец файла со
    /// всеми величинами и нынешними значениями.</summary>
    public static string ToJson<T>(T settings)
        => JsonSerializer.Serialize(settings, new JsonSerializerOptions
        {
            WriteIndented = true,
        });
}
