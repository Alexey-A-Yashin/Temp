using System;
using System.Collections.Generic;
using System.Text.Json;
using Godot;
using ColoringBook.Domain.Sketching;

namespace ColoringBook.Infrastructure.Sketching;

/// <summary>
/// Хранилище снимков в пользовательском каталоге.
///
/// Раскладка: user://sketches/{id}/{source|outline|painted}.png + meta.json.
/// Отдельная папка на снимок, а не один общий файл, потому что изображения крупные
/// и галерее нужно читать только meta.json — иначе её открытие упиралось бы в диск.
///
/// Единственное место в подсистеме, знающее о файлах. Домен о нём не подозревает:
/// он видит только ISketchRepository (см. книгу, 4.5 — инверсия зависимостей).
/// </summary>
public sealed class FileSketchRepository : ISketchRepository
{
    /// <summary>
    /// Каталог снимков — В ПРОЕКТЕ, рядом с исходниками.
    ///
    /// user:// удобен для готовой игры, но неудобен при разработке: это виртуальный
    /// префикс, и реальная папка лежит глубоко в системном каталоге. Пока идёт
    /// отладка механики, снимки нужны под рукой.
    ///
    /// ОГРАНИЧЕНИЕ: res:// доступен на запись ТОЛЬКО из редактора. В собранной игре
    /// ресурсы упакованы и запись невозможна, поэтому там нужен user://. Выбор
    /// делается один раз при создании: если запись в res:// не удалась — работаем
    /// с user://, и это честно пишется в лог.
    /// </summary>
    private const string ProjectRoot = "res://sketches";
    private const string UserRoot = "user://sketches";

    private readonly string _root;

    /// <summary>Каталог снимков — нужен снаружи, чтобы класть туда отладочные проходы.</summary>
    public static string RootPath { get; private set; } = UserRoot;
    private const string MetaFile = "meta.json";

    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        WriteIndented = true,
    };

    public FileSketchRepository()
    {
        _root = ChooseRoot();
        RootPath = _root;
        DirAccess.MakeDirRecursiveAbsolute(_root);
        // Печатаем АБСОЛЮТНЫЙ путь: user:// — это виртуальный префикс Godot, и найти
        // по нему файлы в проводнике нельзя. Реальный каталог зависит от системы:
        //   Windows: %APPDATA%\Godot\app_userdata\<имя проекта>\sketches
        //   Linux:   ~/.local/share/godot/app_userdata/<имя проекта>/sketches
        //   macOS:   ~/Library/Application Support/Godot/app_userdata/<имя>/sketches
        GD.Print($"[sketch] каталог снимков: {ProjectSettings.GlobalizePath(_root)}");
    }

    /// <summary>
    /// Проверка записи в проектный каталог. В экспортированной сборке res:// только
    /// для чтения, и попытка создать там папку провалится — тогда уходим в user://.
    /// </summary>
    private static string ChooseRoot()
    {
        if (OS.HasFeature("editor"))
        {
            var err = DirAccess.MakeDirRecursiveAbsolute(ProjectRoot);
            if (err == Error.Ok || DirAccess.DirExistsAbsolute(ProjectRoot))
                return ProjectRoot;
            GD.Print("[sketch] res://sketches недоступен на запись, использую user://");
        }
        return UserRoot;
    }


    private string DirOf(SketchId id) => $"{_root}/{id.Value}";

    private static string LayerFile(SketchLayer layer) => layer switch
    {
        SketchLayer.Source => "source.png",
        SketchLayer.Outline => "outline.png",
        _ => "painted.png",
    };

    public void Create(Sketch sketch, byte[] sourcePng, byte[] outlinePng)
    {
        string dir = DirOf(sketch.Id);
        DirAccess.MakeDirRecursiveAbsolute(dir);
        WriteBytes($"{dir}/{LayerFile(SketchLayer.Source)}", sourcePng);
        WriteBytes($"{dir}/{LayerFile(SketchLayer.Outline)}", outlinePng);
        WriteMeta(sketch);
    }

    public void SavePainting(Sketch sketch, byte[] paintedPng)
    {
        string dir = DirOf(sketch.Id);
        if (!DirAccess.DirExistsAbsolute(dir)) return;
        WriteBytes($"{dir}/{LayerFile(SketchLayer.Painted)}", paintedPng);
        WriteMeta(sketch);
    }

    public IReadOnlyList<Sketch> List()
    {
        var result = new List<Sketch>();
        using var dir = DirAccess.Open(_root);
        if (dir == null) return result;

        dir.ListDirBegin();
        for (string name = dir.GetNext(); name != ""; name = dir.GetNext())
        {
            if (!dir.CurrentIsDir()) continue;
            if (name is "." or "..") continue;
            if (TryLoad(new SketchId(name), out var s)) result.Add(s);
        }
        dir.ListDirEnd();

        // Новые первыми: галерея — лента, а не архив.
        result.Sort((a, b) => b.CreatedUtc.CompareTo(a.CreatedUtc));
        return result;
    }

    public bool TryLoad(SketchId id, out Sketch sketch)
    {
        sketch = null!;
        if (!id.IsValid()) return false;
        string path = $"{DirOf(id)}/{MetaFile}";
        if (!FileAccess.FileExists(path)) return false;

        try
        {
            using var f = FileAccess.Open(path, FileAccess.ModeFlags.Read);
            if (f == null) return false;
            string json = f.GetAsText();
            var rec = JsonSerializer.Deserialize<SketchRecord>(json);
            if (rec == null) return false;
            return rec.TryToDomain(out sketch);
        }
        catch (Exception ex)
        {
            // Битый или чужой файл не должен ронять галерею: пропускаем запись.
            GD.PrintErr($"[sketch] не удалось прочитать {path}: {ex.Message}");
            return false;
        }
    }

    public byte[]? ReadLayer(SketchId id, SketchLayer layer)
    {
        if (!id.IsValid()) return null;
        string path = $"{DirOf(id)}/{LayerFile(layer)}";
        if (!FileAccess.FileExists(path)) return null;
        using var f = FileAccess.Open(path, FileAccess.ModeFlags.Read);
        return f?.GetBuffer((long)f.GetLength());
    }

    public void Delete(SketchId id)
    {
        if (!id.IsValid()) return;
        string dir = DirOf(id);
        if (!DirAccess.DirExistsAbsolute(dir)) return;
        foreach (var layer in new[] { SketchLayer.Source, SketchLayer.Outline, SketchLayer.Painted })
            DirAccess.RemoveAbsolute($"{dir}/{LayerFile(layer)}");
        DirAccess.RemoveAbsolute($"{dir}/{MetaFile}");
        DirAccess.RemoveAbsolute(dir);
    }

    private void WriteMeta(Sketch sketch)
    {
        string path = $"{DirOf(sketch.Id)}/{MetaFile}";
        string json = JsonSerializer.Serialize(SketchRecord.From(sketch), JsonOpts);
        using var f = FileAccess.Open(path, FileAccess.ModeFlags.Write);
        f?.StoreString(json);
    }

    private static void WriteBytes(string path, byte[] data)
    {
        if (data == null || data.Length == 0) return;
        using var f = FileAccess.Open(path, FileAccess.ModeFlags.Write);
        f?.StoreBuffer(data);
    }
}
