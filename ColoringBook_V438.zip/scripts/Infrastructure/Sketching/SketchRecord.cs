using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using ColoringBook.Domain.Sketching;

namespace ColoringBook.Infrastructure.Sketching;

/// <summary>
/// МОДЕЛЬ ХРАНЕНИЯ снимка — отдельная от доменной.
///
/// Книга, 10.1: «модель хранения и модель исполнения — разные сущности, живущие по
/// разным законам… любое сохранение пересекает границу времени». Игрок начнёт
/// раскрашивать сегодня и вернётся через месяц, когда код уже изменится, поэтому
/// сериализуется НЕ доменный Sketch, а этот DTO с номером схемы. Переименование поля
/// в домене не ломает старые файлы: их читает конвертер по версии.
/// </summary>
internal sealed class SketchRecord
{
    /// <summary>Версия схемы. Увеличивается при любом несовместимом изменении.</summary>
    [JsonPropertyName("schema")] public int Schema { get; set; } = CurrentSchema;

    public const int CurrentSchema = 1;

    [JsonPropertyName("id")] public string Id { get; set; } = "";
    [JsonPropertyName("createdUtc")] public string CreatedUtc { get; set; } = "";
    [JsonPropertyName("title")] public string Title { get; set; } = "";
    [JsonPropertyName("progress")] public int Progress { get; set; }
    [JsonPropertyName("completion")] public float Completion { get; set; }

    [JsonPropertyName("worldSeed")] public int WorldSeed { get; set; }
    [JsonPropertyName("chunkIndex")] public int ChunkIndex { get; set; }
    [JsonPropertyName("camX")] public float CamX { get; set; }
    [JsonPropertyName("camY")] public float CamY { get; set; }
    [JsonPropertyName("camZ")] public float CamZ { get; set; }
    [JsonPropertyName("yaw")] public float Yaw { get; set; }
    [JsonPropertyName("pitch")] public float Pitch { get; set; }
    [JsonPropertyName("season")] public string Season { get; set; } = "";

    public static SketchRecord From(Sketch s) => new()
    {
        Schema = CurrentSchema,
        Id = s.Id.Value,
        CreatedUtc = s.CreatedUtc.ToString("O"),
        Title = s.Title,
        Progress = (int)s.Progress,
        Completion = s.Completion,
        WorldSeed = s.Origin.WorldSeed,
        ChunkIndex = s.Origin.ChunkIndex,
        CamX = s.Origin.CameraX,
        CamY = s.Origin.CameraY,
        CamZ = s.Origin.CameraZ,
        Yaw = s.Origin.Yaw,
        Pitch = s.Origin.Pitch,
        Season = s.Origin.SeasonName,
    };

    /// <summary>
    /// Восстановление доменной сущности. Здесь же живёт МИГРАЦИЯ старых версий:
    /// при появлении схемы 2 сюда добавится ветка, дополняющая недостающие поля
    /// значениями по умолчанию, — и файлы схемы 1 продолжат открываться.
    /// </summary>
    public bool TryToDomain(out Sketch sketch)
    {
        sketch = null!;
        var id = new SketchId(Id);
        if (!id.IsValid()) return false;
        if (Schema > CurrentSchema) return false;   // файл из будущей версии игры

        if (!DateTime.TryParse(CreatedUtc, null,
                System.Globalization.DateTimeStyles.RoundtripKind, out var created))
            created = DateTime.UtcNow;

        var origin = new SketchOrigin(
            WorldSeed, ChunkIndex, CamX, CamY, CamZ, Yaw, Pitch, Season);

        var progress = Enum.IsDefined(typeof(SketchProgress), Progress)
            ? (SketchProgress)Progress
            : SketchProgress.NotStarted;

        sketch = new Sketch(id, created, origin, progress, Title);
        if (Completion > 0f) sketch.MarkPainted(Completion);
        return true;
    }
}
