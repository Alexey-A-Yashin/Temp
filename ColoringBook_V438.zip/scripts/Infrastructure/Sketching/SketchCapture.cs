using System;
using System.Collections.Generic;
using Godot;
using ColoringBook.Presentation.Diagnostics;

namespace ColoringBook.Infrastructure.Sketching;

/// <summary>
/// ЗАХВАТ СНИМКА: цветной исходник плюс контурная заготовка.
///
/// ПОЧЕМУ НЕ ПОСТЭФФЕКТ КАМЕРЫ. Ходовые схемы контуров читают буфер нормалей через
/// hint_normal_roughness_texture, но он доступен ТОЛЬКО в Forward+. В проекте стоит
/// renderer/rendering_method="mobile", где такой шейдер не компилируется
/// (godotengine/godot#78411) и способен подвесить редактор. Чтение depth-буфера в
/// Mobile возможно, но ломает sub-passes, ради которых мобильный рендерер и сделан.
///
/// ПОЭТОМУ схема такая: сцена рендерится ДВАЖДЫ в SubViewport с материалами-
/// переопределениями (глубина, затем нормали), а границы ищутся на CPU. Это не зависит
/// от рендерера и стоит два кадра — снимок делается по нажатию, а не каждый кадр,
/// так что дорогой путь здесь допустим.
///
/// ПОРОГИ ПОДОБРАНЫ ЗАМЕРОМ, а не на глаз. На синтетической сцене (небо, уходящий
/// вдаль склон, три «дерева» на разной глубине, грань) без поправки на наклон
/// поверхности контуром помечалось 50% кадра: пологая поверхность, уходящая вдаль,
/// даёт постоянный градиент глубины. После деления на косинус наклона и на саму
/// глубину появилась устойчивая полка:
///     порог 0.05 -> 49.9% кадра
///     порог 0.12 -> 14.0%
///     порог 0.18 ->  2.6%, обводка дерева 83%, грань 76%
///     порог 0.50 ->  2.4%, обводка дерева 80%
/// Взято 0.18 — начало полки.
/// </summary>
public sealed partial class SketchCapture : Node
{
    /// <summary>Разрешение снимка. Меньше кадра: заготовка под раскраску, а не обои.</summary>
    public int Width { get; set; } = 1024;
    public int Height { get; set; } = 576;






    /// <summary>Шаг квантования цвета. 3 даёт 3.84% чернил и 49 областей заливки;
    /// 6 — 7.79% и 103 области. Взято 3: для страницы раскраски крупные области
    /// удобнее мелких.</summary>
    public float ColorQuantSteps { get; set; } = 3f;

    /// <summary>Радиус размытия цвета — ДОЛЯ размера кадра, а не пиксели.
    /// Игра мобильная, разрешения разные; фиксированный радиус давал бы разную
    /// детализацию наброска на разных устройствах.</summary>
    public float ColorBlurFraction { get; set; } = 0.006f;


    /// <summary>Область считается КРУПНОЙ ФОРМОЙ, если занимает такую долю кадра.
    /// Границы двух крупных форм обводятся жирнее.</summary>
    public float BigRegionFraction { get; set; } = 0.010f;

    /// <summary>На сколько точек утолщать линии крупных форм.</summary>
    public int ThickExtra { get; set; } = 1;

    /// <summary>Радиус смыкания маски растительности (см. BuildOutline).</summary>
    public int VegetationCloseRadius { get; set; } = 2;


    /// <summary>
    /// Сохранять ли служебные проходы рядом со снимком (id.png, depth.png).
    ///
    /// Без них диагностика превращается в угадывание: по одному лишь outline.png
    /// нельзя понять, сработал ли проход идентификаторов, каким значением очищается
    /// фон и совпали ли размеры буферов. Замер по последнему наброску показал, что
    /// покрытие горизонта (57%) в точности совпадает с результатом БЕЗ участия ID —
    /// то есть проход не вносил вклада, и понять это можно было только косвенно.
    /// </summary>
    public bool DumpDebugPasses { get; set; } = true;

    /// <summary>Куда сложить служебные проходы. Задаётся снаружи вместе с папкой снимка.</summary>
    public string DebugDir { get; set; } = "";

    /// <summary>Дальность, на которую нормируется глубина в шейдере прохода.</summary>
    public float FarPlane { get; set; } = 400f;

    /// <summary>
    /// Запас дальней плоскости для ОБЫЧНОГО вида: прибавляется к удалению
    /// камеры от середины. Должен покрывать диагональ области, иначе дальний
    /// угол уйдёт за плоскость отсечения.
    ///
    /// Это НЕ то же, что FarPlane: там нормировка глубины эскиза на четырёх
    /// километрах, здесь видимость всей территории. Пока они были одним полем,
    /// все кадры обхода снимались с отсечением на 4 км.
    /// </summary>
    public float RenderFarMargin { get; set; } = 400f;

    /// <summary>Диапазон высот рельефа для разбиения на планы в проходе ID.
    /// По умолчанию совпадает с LevelView3D.HeightScale.</summary>
    public float TerrainZoneYMin { get; set; } = 0f;
    public float TerrainZoneYMax { get; set; } = 48f;

    /// <summary>Сколько высотных полос у рельефа. Каждая лишняя превращается в
    /// горизонталь поперёк склона, а не в форму, поэтому их немного.</summary>
    public int TerrainZoneBands { get; set; } = 4;

    /// <summary>
    /// МИНИМАЛЬНЫЙ ВПИСАННЫЙ РАДИУС ЗАКРАШИВАЕМОЙ ОБЛАСТИ, в точках кадра.
    ///
    /// Главная величина всего конвейера, и до V148 её не существовало. Прежняя схема
    /// работала с ЧЕРНИЛАМИ: находила границы, чистила короткие обрывки, утолщала.
    /// Область при этом нигде не была объектом — она получалась как побочный результат
    /// того, что линии где-то замкнулись, и её пригодность никто не проверял. Замер по
    /// реальному шаблону: 2482 замкнутых области, из них 1905 мельче двух точек,
    /// и только 20 таких, во что можно попасть пальцем.
    ///
    /// Порог задаётся зумом раскраски. Палец на экране — около 40 точек; при
    /// двукратном увеличении это 20 точек кадра, то есть радиус 10. Но детали,
    /// рассчитанные ИМЕННО на зум, должны выживать, поэтому режется по меньшему
    /// порогу: 4 точки радиуса — это 8 точек в поперечнике, при 2× как раз кончик
    /// пальца. Всё, что тоньше, не закрасить ни при каком увеличении, и оно только
    /// засоряет рисунок.
    /// </summary>
    public float MinRegionRadius { get; set; } = 4f;

    /// <summary>Радиус, начиная с которого область закрашивается без увеличения.
    /// Используется только для отчёта: это мера качества шаблона, а не порог резки.</summary>
    public float ComfortRegionRadius { get; set; } = 10f;

    /// <summary>Порог относительного скачка глубины для силуэтного ребра.
    /// Делится на саму глубину: без этого уходящая вдаль пологая поверхность даёт
    /// постоянный градиент и метится целиком (та же ловушка, что была у порогов
    /// Собеля — 50% кадра под контуром).</summary>
    public float SilhouetteRelativeStep { get; set; } = 0.06f;

    private const string DepthShaderPath = "res://assets/shaders/sketch_depth.gdshader";
    // NormalShaderPath убран вместе со штриховкой (V148): проход больше не строится.
    private const string IdShaderPath = "res://assets/shaders/sketch_id.gdshader";

    /// <summary>
    /// КАТЕГОРИИ ОБЪЕКТОВ для прохода идентификаторов.
    ///
    /// ---- V148: ЧЕТЫРЁХ КАТЕГОРИЙ БЫЛО МАЛО ----
    ///
    /// Прежний список знал ровно четыре значения: рельеф, растительность, вода, небо.
    /// Гора и луг были одним цветом, дерево и куст — одним, две соседние кроны — тоже,
    /// а значит линии «склон / дно долины», «опушка / поляна», «крона / крона» в
    /// шаблон попасть не могли. Недостающее добиралось квантованием цвета исходника,
    /// и оно давало полосы вместо форм: границы кванта покрывали 5.85% кадра против
    /// 2.65% у границ ID.
    ///
    /// Теперь класс лежит в канале R, подкласс — в G и B, всё на сетке 1/5
    /// (см. заголовок sketch_id.gdshader). Рельеф и растительность считают подкласс
    /// в шейдере: у первого это высотная полоса и уклон, у второй — вид и номер
    /// экземпляра.
    /// </summary>
    private enum IdMode { Flat = 0, TerrainZones = 1, VegetationInstances = 2 }

    /// <summary>Значение канала на сетке 1/5: 0, 0.2 … 1.0.</summary>
    private static float Grid5(int step) => Math.Clamp(step, 0, 5) / 5f;

    private static readonly (string namePart, Color color, IdMode mode)[] IdCategories =
    {
        // Вода и русло: класс 2, подкласс в G.
        ("WaterSurface",   new Color(Grid5(2), Grid5(0), 0f), IdMode.Flat),
        ("RiverMesh",      new Color(Grid5(2), Grid5(1), 0f), IdMode.Flat),
        ("MainStem",       new Color(Grid5(2), Grid5(2), 0f), IdMode.Flat),
        // Тропа: класс 3. Отдельный класс, а не подкласс рельефа: на раскраске это
        // самостоятельная форма, и её граница нужна всегда.
        ("WalkPath",       new Color(Grid5(3), 0f, 0f), IdMode.Flat),
        // Растительность: класс 4, вид в G, экземпляр в B (считает шейдер).
        ("VegetationRoot", new Color(Grid5(4), Grid5(0), 0f), IdMode.VegetationInstances),
        // ВИТРИНА — ПЛОСКИЙ ЦВЕТ, а не режим экземпляров.
        //
        // Хеш в шейдере берётся от INSTANCE_ID, а витрина ставит растения отдельными
        // MeshInstance3D, где он всегда ноль. Все растения ряда получили бы один цвет
        // и на шаблоне слились бы в одну область, стоит им соприкоснуться в кадре —
        // то есть именно на близкой дистанции, ради которой витрина и снимается.
        // Поэтому здесь номер считается по имени узла на стороне C#.
        ("PlantGallery",   new Color(Grid5(4), Grid5(0), 0f), IdMode.Flat),
        // Рельеф: класс 1, полоса высоты и уклон считает шейдер.
        ("TerrainMesh",    new Color(Grid5(1), 0f, 0f), IdMode.TerrainZones),
    };

    /// <summary>
    /// Вид растения по имени узла. Узлы растительности называются
    /// Veg_{cx}_{cz}_{Kind}_{variant}_{lod}, поэтому вид читается из имени и
    /// отдельная разметка не нужна.
    ///
    /// Хвойные сведены вместе, лиственные вместе: на раскраске важен силуэт кроны,
    /// а сосна от кедра в контуре не отличается. Дёрн и камыш разделены — у них
    /// разная форма пятна.
    /// </summary>
    private static int VegetationSubclass(string name)
    {
        if (name.Contains("_Pine_", StringComparison.Ordinal)
            || name.Contains("_Fir_", StringComparison.Ordinal)) return 1;
        if (name.Contains("_Deciduous_", StringComparison.Ordinal)) return 2;
        if (name.Contains("_Bush_", StringComparison.Ordinal)) return 3;
        if (name.Contains("_GrassTuft_", StringComparison.Ordinal)
            || name.Contains("_Moss_", StringComparison.Ordinal)) return 4;
        if (name.Contains("_Reed_", StringComparison.Ordinal)) return 5;
        return 0;   // камни и всё прочее
    }

    // Номер растения витрины — ПОРЯДКОВЫЙ НОМЕР УЗЛА среди соседей, а не хеш имени.
    //
    // Первая версия хешировала путь узла. Имена в ряду отличаются одним символом
    // (Plant_Pine, Plant_Pine2, Plant_Pine3), и FNV по модулю шести на таких строках
    // кластеризуется: прогон дал пять совпадений подряд из одиннадцати пар, то есть
    // почти половина соседей слилась бы в одну область. Порядковый номер по кругу
    // 0..5 гарантирует, что СОСЕДНИЕ растения не совпадут никогда, а витрина ставит
    // их в ряд именно в порядке добавления.

    /// <summary>Вид растения витрины по имени узла Plant_{kind}.</summary>
    private static int GalleryKindIndex(string name) => VegetationSubclass("_" + name.Replace("Plant_", "") + "_");

    /// <summary>Служебная надпись витрины: в шаблон попадать не должна.
    /// Она рисуется поверх сцены и давала на шаблоне прямоугольники, которые
    /// считались областями наравне с растениями.</summary>
    private static bool IsGalleryLabel(Node node)
    {
        for (Node? n = node; n != null; n = n.GetParent())
            if (n.Name.ToString().StartsWith("GalleryLabel_", StringComparison.Ordinal)) return true;
        return false;
    }

    private static (Color color, IdMode mode) IdColorFor(Node node)
    {
        // Подпись красится в цвет неба: класс 0 — то, что конвейер считает бумагой,
        // а не закрашиваемой областью.
        if (IsGalleryLabel(node)) return (new Color(0f, 0f, 0f), IdMode.Flat);
        // Ищем категорию у самого узла и у его предков: растительность лежит
        // внутри VegetationRoot и своих имён категории не несёт.
        for (Node? n = node; n != null; n = n.GetParent())
        {
            string name = n.Name;
            foreach (var (part, col, mode) in IdCategories)
                if (name.Contains(part, StringComparison.Ordinal))
                {
                    if (mode == IdMode.VegetationInstances)
                        return (new Color(col.R, Grid5(VegetationSubclass(node.Name)), 0f), mode);
                    if (part == "PlantGallery")
                        return (new Color(col.R, Grid5(GalleryKindIndex(node.Name)),
                                          Grid5(node.GetIndex() % 6)), mode);
                    return (col, mode);
                }
        }
        return (new Color(0f, Grid5(5), Grid5(5)), IdMode.Flat);   // прочее
    }

    /// <summary>
    /// БЫСТРЫЙ СНИМОК — только цветной кадр, без служебных проходов.
    ///
    /// Контуры здесь НЕ строятся намеренно: снимок игрок может тут же удалить, и
    /// считать для него два прохода рендера плюс Собеля по 590 тысячам точек — работа
    /// впустую. Контур появляется позже, по кнопке «Редактировать» (см. BuildOutlineAsync).
    /// </summary>
    public byte[]? CaptureSource(Viewport sourceViewport)
    {
        if (sourceViewport == null) return null;
        var img = sourceViewport.GetTexture()?.GetImage();
        if (img == null) return null;
        var size = OutputSize(sourceViewport);
        img.Resize(size.X, size.Y, Image.Interpolation.Lanczos);
        _lastSize = size;
        _lastSource = img;   // нужен для дробления областей по цвету
        return img.SavePngToBuffer();
    }

    /// <summary>
    /// Размер снимка, СОХРАНЯЮЩИЙ СООТНОШЕНИЕ СТОРОН окна.
    ///
    /// Раньше и кадр, и служебные проходы жёстко приводились к 1024x576. Но окно
    /// 1400x900 имеет соотношение 1.556, а 1024x576 — 1.778: исходник ужимался по
    /// горизонтали на 14%, а контуры рендерились в СВОЁМ соотношении, то есть
    /// охватывали другой сектор сцены. Замер по присланным снимкам это подтвердил:
    /// линия горизонта на контуре совпадала с исходником лишь на 48-64%, а часть
    /// линий оказывалась выше горизонта — там, где в кадре небо.
    ///
    /// Теперь оба изображения строятся в соотношении окна и вписываются в
    /// Width x Height, поэтому совпадают точка в точку.
    /// </summary>
    public Vector2I OutputSize(Viewport vp)
    {
        var s = vp.GetVisibleRect().Size;
        float aspect = s.Y > 1f ? s.X / s.Y : 16f / 9f;
        int w = Width, h = (int)MathF.Round(Width / aspect);
        if (h > Height) { h = Height; w = (int)MathF.Round(Height * aspect); }
        return new Vector2I(Math.Max(w, 16), Math.Max(h, 16));
    }

    /// <summary>Размер последнего снимка — служебные проходы должны совпасть с ним.</summary>
    private Vector2I _lastSize = new(1024, 576);

    /// <summary>Последний снятый кадр — источник цвета для дробления областей.</summary>
    private Image? _lastSource;

    /// <summary>
    /// Построить контуры для уже сделанного снимка: два служебных прохода плюс поиск
    /// границ. Вызывается только когда игрок решил рисовать.
    /// </summary>
    /// <summary>
    /// СНЯТЬ КАДР И ПОСТРОИТЬ КОНТУРЫ ЗА ОДИН ЗАХОД.
    ///
    /// Раньше контуры строились отложенно, при первом открытии на раскраску, и это
    /// вносило ошибку, которую не исправить порогами: орбитальная камера задаётся
    /// ЧЕТЫРЬМЯ величинами (цель, дистанция, поворот, наклон), а в снимке сохранялись
    /// только поворот и наклон. Ни цель, ни дистанция, ни режим камеры не сохранялись
    /// вовсе, поэтому восстановить ракурс точно было невозможно — контуры строились
    /// с другой точки, чем сделан кадр.
    ///
    /// Одновременное построение снимает весь этот класс ошибок: камера та же самая,
    /// восстанавливать нечего. Цена — два служебных прохода в момент съёмки вместо
    /// возможной экономии на удалённых снимках; это доли секунды один раз.
    /// </summary>
    public async System.Threading.Tasks.Task<(byte[] source, byte[] outline)?> CaptureBothAsync(
        Node3D sceneRoot, Viewport sourceViewport, Camera3D camera)
    {
        if (sceneRoot == null || sourceViewport == null || camera == null) return null;
        byte[]? src = CaptureSource(sourceViewport);
        if (src == null) return null;
        byte[]? outline = await BuildOutlineAsync(sceneRoot, camera);
        if (outline == null) return null;
        return (src, outline);
    }

    public async System.Threading.Tasks.Task<byte[]?> BuildOutlineAsync(
        Node3D sceneRoot, Camera3D camera, Vector2I? size = null)
    {
        if (sceneRoot == null || camera == null) return null;
        if (size.HasValue) _lastSize = size.Value;
        var depthImg = await RenderPassAsync(sceneRoot, camera, DepthShaderPath, packDepth: true);
        var idImg = await RenderIdPassAsync(sceneRoot, camera);
        if (depthImg == null) return null;

        // ---- V148: ПРОХОДА НОРМАЛЕЙ БОЛЬШЕ НЕТ ----
        //
        // Он остался единственным потребителем штриховки, а штриховка убрана: под ней
        // лежало 29% кадра, и это ровно те области — горы и кроны, — которые на
        // раскраске самые крупные и самые желанные. Форму теперь передают высотные
        // полосы и класс уклона в проходе ID (они дают ЗАКРАШИВАЕМЫЕ области вместо
        // серого поля) и силуэтные рёбра по глубине.
        //
        // Заодно снимок стал на два кадра ожидания дешевле. Шейдер оставлен в assets:
        // понадобится, если решим передавать объём иначе.

        if (DumpDebugPasses && !string.IsNullOrEmpty(DebugDir))
        {
            DirAccess.MakeDirRecursiveAbsolute(DebugDir);
            depthImg.SavePng($"{DebugDir}/debug_depth.png");
            idImg?.SavePng($"{DebugDir}/debug_id.png");
        }

        return BuildOutline(depthImg, idImg, _lastSource);
    }

    /// <summary>
    /// Один служебный проход: временный SubViewport со своей камерой и
    /// материалом-переопределением на всей сцене.
    /// </summary>
    /// <summary>
    /// ШАБЛОН С ПРОИЗВОЛЬНОЙ ПОЗЫ — для витрины растений.
    ///
    /// Все проходы строятся от Camera3D, потому что снимок игрока делается его
    /// камерой. Витрине же нужны фиксированные позы: породы стоят в ряд, камера
    /// обходит их по трём дистанциям. Искать нужное дерево на уровне ради одного
    /// шаблона — работа, которую делать не следует: витрина для того и заведена.
    ///
    /// Временная камера живёт только на время построения и в основную сцену не
    /// попадает, поэтому вид игрока не сбивается.
    /// </summary>
    public async System.Threading.Tasks.Task<byte[]?> BuildOutlineFromPoseAsync(
        Node3D sceneRoot, Vector3 pos, Vector3 fwd, float fov, Vector2I size)
    {
        _lastSize = size;
        var cam = new Camera3D { Fov = fov, Near = 0.05f, Far = FarPlane, Current = false };
        AddChild(cam);
        cam.LookAtFromPosition(pos, pos + fwd, Vector3.Up);
        try
        {
            return await BuildOutlineAsync(sceneRoot, cam, size);
        }
        finally
        {
            cam.QueueFree();
        }
    }

    private async System.Threading.Tasks.Task<Image?> RenderPassAsync(
        Node3D sceneRoot, Camera3D camera, string shaderPath, bool packDepth)
    {
        var shader = GD.Load<Shader>(shaderPath);
        if (shader == null)
        {
            GD.PrintErr($"[sketch] шейдер не найден: {shaderPath}");
            return null;
        }

        var mat = new ShaderMaterial { Shader = shader };
        if (packDepth) mat.SetShaderParameter("far_plane", FarPlane);

        var vp = new SubViewport
        {
            // Тот же размер, что у снимка: иначе соотношение сторон разойдётся и
            // контур будет охватывать другой сектор сцены.
            Size = _lastSize,
            RenderTargetUpdateMode = SubViewport.UpdateMode.Once,
            TransparentBg = false,
            // Сглаживание выключено намеренно: полутона на границе размывают скачок
            // глубины, и контур получается рыхлым.
            Msaa3D = Viewport.Msaa.Disabled,
        };
        AddChild(vp);

        // Камера-двойник: копируем параметры, чтобы кадр совпал с тем, что видит игрок.
        var cam = new Camera3D
        {
            Fov = camera.Fov,
            Near = camera.Near,
            Far = camera.Far,
            Projection = camera.Projection,
            GlobalTransform = camera.GlobalTransform,
        };
        vp.AddChild(cam);
        cam.Current = true;

        // Сцена переиспользуется, а не копируется: дубль тысяч MultiMesh-узлов
        // занял бы больше памяти, чем весь снимок. Поэтому вьюпорт получает
        // ССЫЛКУ на мир основной сцены.
        vp.World3D = sceneRoot.GetWorld3D();

        var saved = new List<(GeometryInstance3D gi, Material? prev)>();
        ApplyOverride(sceneRoot, mat, saved);

        // Ждём два кадра: один на отрисовку, второй на готовность текстуры.
        await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
        await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);

        Image? img = vp.GetTexture()?.GetImage();

        RestoreOverride(saved);
        vp.QueueFree();
        return img;
    }

    /// <summary>
    /// СНИМОК СЦЕНЫ ИЗ ПРОИЗВОЛЬНОЙ ТОЧКИ — для обхода уровня.
    ///
    /// ЗАЧЕМ. Телеметрия отвечает, сколько чего попало в кадр и какого оно экранного
    /// размера. Чего она не даёт — как это выглядит: ни теней, ни шейдера рельефа, ни
    /// настоящего атласа импосторов в числах нет. Механика снимков умеет ровно то,
    /// что нужно, и уже отлажена: временный SubViewport со ССЫЛКОЙ на мир основной
    /// сцены, камера-двойник, два кадра ожидания.
    ///
    /// Отличие от снимка игрока: материалы НЕ подменяются — нужен обычный вид сцены,
    /// а не проход глубины или идентификаторов.
    /// </summary>
    public async System.Threading.Tasks.Task<Image?> RenderViewAsync(
        Node3D sceneRoot, Vector3 pos, Vector3 fwd, float fov, Vector2I size)
    {
        var vp = new SubViewport
        {
            Size = size,
            RenderTargetUpdateMode = SubViewport.UpdateMode.Once,
            TransparentBg = false,
            Msaa3D = Viewport.Msaa.Disabled,
        };
        AddChild(vp);

        // ---- V303: ДАЛЬНЯЯ ПЛОСКОСТЬ ОТДЕЛЕНА ОТ НОРМИРОВКИ ГЛУБИНЫ ----
        //
        // Здесь стояло `Far = FarPlane`, а FarPlane — это 400 единиц, то есть
        // 4 км, и заведено оно СОВСЕМ ДЛЯ ДРУГОГО: на эту дальность шейдер
        // прохода нормирует глубину при построении эскиза. Два разных понятия
        // жили в одном поле.
        //
        // Цена ошибки. ВСЕ кадры обхода за всю историю снимались с отсечением на
        // четырёх километрах. Это значит, что мера «слои глубины не менее
        // четырёх» и вообще весь дальний план в снимках — измерялись на кадре,
        // где дали нет по построению. Девять новых кадров всего уровня вышли
        // пустыми на 100%: камера стоит в тридцати километрах, всё за плоскостью.
        //
        // Живая камера игры пользуется своей дальностью — MaxOrbitDistance плюс
        // полудиагональ области, около 80 км, — то есть снимок и игра показывали
        // РАЗНОЕ.
        //
        // Берётся расстояние до цели плюс полная диагональ области: так в кадр
        // попадает и дальний угол, откуда бы ни снимали.
        float far = pos.Length() + RenderFarMargin;
        var cam = new Camera3D { Fov = fov, Near = 0.05f, Far = far };
        vp.AddChild(cam);
        cam.Current = true;
        vp.World3D = sceneRoot.GetWorld3D();
        // LookAtFromPosition, а не сборка базиса вручную: у Godot своё соглашение
        // об осях камеры, и повторять его здесь значило бы завести второй источник
        // правды. Вертикальный взгляд не используется, вырождения базиса не будет.
        cam.LookAtFromPosition(pos, pos + fwd, Vector3.Up);

        await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
        await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);

        Image? img = vp.GetTexture()?.GetImage();
        vp.QueueFree();
        return img;
    }

    /// <summary>
    /// Подменить материалы на служебный, ЗАПОМНИВ прежние.
    ///
    /// Прежняя версия по окончании прохода просто ставила MaterialOverride = null.
    /// Это уничтожало материалы проекта НАВСЕГДА: рельеф, вода, русло, тропы и вся
    /// растительность хранят свои материалы именно в MaterialOverride
    /// (LevelView3D: terrainMat, waterMat, riverMat, walkMat, CreateFoliageMaterial).
    /// После одного снимка мир оставался чёрно-белым — это и было видно на скриншоте.
    /// </summary>
    /// <summary>
    /// Проход идентификаторов: каждому узлу — материал со своим плоским цветом.
    /// Один шейдер, но отдельный экземпляр материала на категорию, иначе цвет был бы
    /// общим для всей сцены.
    /// </summary>
    private async System.Threading.Tasks.Task<Image?> RenderIdPassAsync(
        Node3D sceneRoot, Camera3D camera)
    {
        var shader = GD.Load<Shader>(IdShaderPath);
        if (shader == null) return null;

        // Ключ кеша — цвет И режим: у рельефа и растительности цвет один на всю
        // категорию, а подкласс считает шейдер, поэтому один материал на пару.
        var byKey = new Dictionary<(Color, IdMode), ShaderMaterial>();
        ShaderMaterial MatFor(Color c, IdMode mode)
        {
            if (byKey.TryGetValue((c, mode), out var m)) return m;
            m = new ShaderMaterial { Shader = shader };
            m.SetShaderParameter("id_color", new Vector3(c.R, c.G, c.B));
            m.SetShaderParameter("id_mode", (int)mode);
            m.SetShaderParameter("zone_y_min", TerrainZoneYMin);
            m.SetShaderParameter("zone_y_max", TerrainZoneYMax);
            m.SetShaderParameter("zone_bands", TerrainZoneBands);
            byKey[(c, mode)] = m;
            return m;
        }

        var vp = new SubViewport
        {
            Size = _lastSize,
            RenderTargetUpdateMode = SubViewport.UpdateMode.Once,
            TransparentBg = false,
            Msaa3D = Viewport.Msaa.Disabled,
        };
        AddChild(vp);
        var cam = new Camera3D
        {
            Fov = camera.Fov, Near = camera.Near, Far = camera.Far,
            Projection = camera.Projection, GlobalTransform = camera.GlobalTransform,
        };
        vp.AddChild(cam);
        cam.Current = true;
        vp.World3D = sceneRoot.GetWorld3D();

        var saved = new List<(GeometryInstance3D gi, Material? prev)>();
        ApplyIdOverride(sceneRoot, MatFor, saved);

        await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
        await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);

        Image? img = vp.GetTexture()?.GetImage();
        RestoreOverride(saved);
        vp.QueueFree();
        return img;
    }

    private static void ApplyIdOverride(
        Node node, Func<Color, IdMode, ShaderMaterial> matFor,
        List<(GeometryInstance3D gi, Material? prev)> saved)
    {
        if (node is GeometryInstance3D gi)
        {
            var prev = gi.MaterialOverride;
            saved.Add((gi, prev));

            // ИМПОСТОР РИСУЕТ СЕБЯ САМ.
            //
            // Плоский материал прохода не выполняет отсечения по альфе — это его смысл,
            // крона должна стать одним пятном. Но силуэт карточки импостора задан
            // ИСКЛЮЧИТЕЛЬНО альфой атласа, и под плоским материалом каждое дальнее
            // дерево превратилось бы в прямоугольник. Поэтому для таких узлов берётся
            // копия их же материала с включённым режимом id: отсечение сохраняется,
            // цвет становится цветом категории.
            //
            // Прежнее решение — временно переводить дальние чанки на настоящую
            // геометрию — давало на снимке деревья, которых не было на экране.
            if (prev is ShaderMaterial sm && sm.Shader != null
                && sm.Shader.ResourcePath.EndsWith("impostor.gdshader", StringComparison.Ordinal))
            {
                var idMat = (ShaderMaterial)sm.Duplicate();
                var (c, _) = IdColorFor(gi);
                idMat.SetShaderParameter("id_mode", true);
                idMat.SetShaderParameter("id_color", new Vector3(c.R, c.G, c.B));
                gi.MaterialOverride = idMat;
            }
            else
            {
                var (c, mode) = IdColorFor(gi);
                gi.MaterialOverride = matFor(c, mode);
            }
        }
        foreach (Node c in node.GetChildren()) ApplyIdOverride(c, matFor, saved);
    }

    private static void ApplyOverride(
        Node node, Material mat, List<(GeometryInstance3D gi, Material? prev)> saved)
    {
        if (node is GeometryInstance3D gi)
        {
            saved.Add((gi, gi.MaterialOverride));
            gi.MaterialOverride = mat;
        }
        foreach (Node c in node.GetChildren()) ApplyOverride(c, mat, saved);
    }

    private static void RestoreOverride(List<(GeometryInstance3D gi, Material? prev)> saved)
    {
        foreach (var (gi, prev) in saved)
            if (GodotObject.IsInstanceValid(gi)) gi.MaterialOverride = prev;
        saved.Clear();
    }

    /// <summary>
    /// Поиск границ оператором Собеля по глубине и по нормалям.
    ///
    /// Считается на CPU: изображение 1024x576 — это 590 тысяч точек, доли секунды,
    /// и это одноразовая операция. Зато алгоритм не зависит от рендерера и его можно
    /// проверить численно, что и было сделано при подборе порогов.
    /// </summary>
    /// <summary>
    /// ПОСТРОЕНИЕ КОНТУРОВ: границы ОБЛАСТЕЙ, а не геометрических микрорёбер.
    ///
    /// ПОЧЕМУ ПЕРЕДЕЛАНО. Прежняя схема (Собель по глубине и нормалям) на реальном
    /// кадре давала 13.94% чернил при покрытии линии горизонта всего 26% — то есть
    /// заливала кадр линиями, пропуская самую очевидную границу картинки. Причина
    /// не в порогах: детектор отвечает на вопрос «где резко меняется расстояние или
    /// наклон», а раскраске нужен другой — «где кончается одна закрашиваемая область».
    ///
    /// Замеры на том же кадре:
    ///     глубина + нормали      13.94% чернил, небо  26%, вода 57%
    ///     XDoG по яркости         7.52% чернил, 1143 обрывка, областей 8
    ///     сегментация по цвету    5.61% чернил, небо  87%, вода 66%
    ///     ГРАНИЦЫ ID              2.09% чернил, небо 100%, вода 100%
    ///
    /// Границы идентификаторов точны ПО ПОСТРОЕНИЮ: мы сами рендерим сцену и знаем,
    /// где вода, где рельеф, где крона, где небо. Угадывать это по цвету — терять
    /// информацию, которая уже есть.
    ///
    /// Итоговая схема:
    ///   1) границы ID — основа, всегда сохраняются;
    ///   2) внутри каждой области — дробление по КВАНТОВАННОМУ цвету исходника
    ///      (снег и скала на одном меше рельефа должны разделиться);
    ///   3) толщина линии по площади соседних областей: крупные формы жирнее;
    ///   4) зачистка коротких обрывков.
    ///
    /// Квантование вместо k-means выбрано намеренно: k-means зависит от начального
    /// приближения, и замер показал разброс покрытия неба 60-81% между зёрнами.
    /// Квантование детерминировано и даёт вчетверо лучшую связность линий
    /// (39 связных компонент против 290).
    /// </summary>
    private byte[] BuildOutline(Image depthImg, Image? idImg, Image? sourceImg, Image? normalImg = null)
    {
        int w = depthImg.GetWidth(), h = depthImg.GetHeight();
        int n = w * h;

        // ---- 1. ГЛУБИНА ТЕПЕРЬ В ДЕЛЕ ----
        //
        // До V148 этот массив заполнялся и не использовался ни разу: проход глубины
        // рендерился, распаковывался и выбрасывался. Теперь по нему берутся СИЛУЭТНЫЕ
        // рёбра — там, где расстояние скачком меняется, одна форма закрывает другую.
        // Это единственная линия, которую нельзя получить из идентификаторов: два
        // дальних хребта на разном удалении относятся к одной категории рельефа и
        // одной высотной полосе, а на рисунке должны разделяться.
        var depth = new float[n];
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            var dc = depthImg.GetPixel(x, y);
            depth[y * w + x] = dc.R + dc.G / 255f + dc.B / 65025f;
        }

        // ---- 2. ИДЕНТИФИКАТОР ТОЧКИ ----
        //
        // Цвета прохода лежат на сетке 1/5 и читаются из вьюпорта без искажения
        // (проверено: в снятом проходе ровные 0 и 255). Поэтому округление к ближайшему
        // узлу сетки восстанавливает класс и подкласс точно, и можно позволить себе
        // 216 значений вместо прежних четырёх.
        var idKey = new int[n];
        if (idImg != null && idImg.GetWidth() == w && idImg.GetHeight() == h)
        {
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                var c = idImg.GetPixel(x, y);
                idKey[y * w + x] = Grid5Index(c.R) * 36 + Grid5Index(c.G) * 6 + Grid5Index(c.B);
            }
        }

        // Смыкание маски растительности: крона — облако плоских карточек, и без
        // смыкания её граница возникает на кромке КАЖДОЙ карточки. Замер прошлых
        // сессий: без смыкания 151 компонента границы при медиане 7 точек, с радиусом 2
        // — 16 компонент при медиане 33, площадь маски при этом не меняется.
        // Класс растительности — старший разряд ключа (R = 4 → key / 36 == 4).
        if (VegetationCloseRadius > 0) CloseVegetationClass(idKey, w, h, VegetationCloseRadius);

        // ---- 3. НЕОБЯЗАТЕЛЬНОЕ ДРОБЛЕНИЕ ПО ЦВЕТУ ----
        //
        // ВЫКЛЮЧЕНО ПО УМОЛЧАНИЮ. Оно заводилось, пока проход идентификаторов знал
        // четыре категории и линий не хватало. Но цвет исходника — это плавные
        // градиенты рельефа, и квантование даёт не формы, а ПОЛОСЫ: замер на реальном
        // кадре — границы кванта покрывали 5.85% кадра против 2.65% у границ ID, то
        // есть картинку определял не состав сцены, а банды цветовой шкалы. Именно они
        // резали луг на ленты и рисовали горизонтали поперёк склона.
        //
        // Теперь высотные полосы и уклон приходят из прохода ID честно, и добирать
        // цветом нечего. Оставлено выключателем, а не удалено: если понадобится
        // разделить что-то, чего нет в категориях, это дешевле включить, чем писать
        // заново.
        var colorKey = UseColorSplit && sourceImg != null
            ? BuildColorKey(sourceImg, w, h)
            : null;

        // ---- 4. ПЕРВИЧНОЕ РАЗБИЕНИЕ ----
        var seed = new long[n];
        bool[] silh = SilhouetteEdges(depth, w, h, SilhouetteRelativeStep);
        for (int i = 0; i < n; i++)
        {
            long s = idKey[i];
            if (colorKey != null) s = s * 1000003L + colorKey[i];
            // Силуэт входит в ключ: точки по разные стороны скачка глубины не сольются
            // в одну область, даже если у них совпал идентификатор.
            seed[i] = s * 2 + (silh[i] ? 1 : 0);
        }

        int regions = LabelConnected(seed, w, h, out int[] label);

        // ---- 5. СЛИЯНИЕ НЕЗАКРАШИВАЕМЫХ ОБЛАСТЕЙ ----
        //
        // Здесь и лежит вся разница с прежним конвейером. Раньше чистились ЧЕРНИЛА:
        // убирались короткие обрывки линий. Но обрывок линии и незакрашиваемая область
        // — разные вещи: связная сетка границ по кроне даёт одну длинную компоненту
        // чернил (её фильтр не тронет) и тысячу дырок внутри, в которые невозможно
        // попасть. Отсюда прежние 2482 области при двадцати пригодных.
        //
        // Теперь режется по самой области: у кого вписанный радиус меньше порога, тот
        // сливается с соседом по самой длинной общей границе. Прототип на реальном
        // кадре: 7985 областей до слияния (25 пригодных), 156 после (51 пригодная),
        // крапин ноль.
        regions = MergeThinRegions(label, regions, w, h, MinRegionRadius);

        // ---- 6. ГРАНИЦЫ ----
        //
        // ЧЕРНИЛА ДОЛЖНЫ БЫТЬ НЕПРОНИЦАЕМЫ ПО ДИАГОНАЛИ.
        //
        // Прежде граница ставилась по двум соседям — справа и снизу. На косой границе
        // это даёт лесенку, у которой углы соприкасаются лишь диагонально, и заливка,
        // работающая по восьми направлениям, ПРОТЕКАЕТ через такой угол в соседнюю
        // область. Замер на реальном кадре: 128 областей карты превращались в 25 при
        // восьмисвязной заливке — то есть пять шестых границ были фиктивны, и раскраска
        // расползлась бы при первом же касании.
        //
        // Заметить это по картинке невозможно: линия выглядит сплошной. Поэтому
        // сравниваются ещё и диагональные соседи — угол лесенки закрывается. Цена
        // около полутора процентов кадра под чернилами; проверка: после правки
        // четырёхсвязная и восьмисвязная заливки дают 134 и 133 области, то есть
        // результат перестал зависеть от того, как устроена заливка в приложении.
        var ink = new bool[n];
        for (int y = 0; y < h - 1; y++)
        for (int x = 0; x < w - 1; x++)
        {
            int i = y * w + x;
            int c = label[i];
            if (c != label[i + 1] || c != label[i + w] || c != label[i + w + 1]) ink[i] = true;
            if (x > 0 && label[i] != label[i + w - 1]) ink[i] = true;
        }

        // Граница двух КРУПНЫХ форм обводится жирнее: так рисунок читается как
        // набросок с главными формами, а не как равномерная сетка.
        var areas = new int[regions + 1];
        for (int i = 0; i < n; i++) areas[label[i]]++;
        float total = n;
        var thick = new bool[n];
        for (int y = 0; y < h - 1; y++)
        for (int x = 0; x < w - 1; x++)
        {
            int i = y * w + x;
            if (!ink[i]) continue;
            float fa = areas[label[i]] / total;
            float fb = MathF.Min(areas[label[i + 1]], areas[label[i + w]]) / total;
            if (MathF.Min(fa, fb) > BigRegionFraction) thick[i] = true;
        }
        for (int pass = 0; pass < ThickExtra; pass++)
        {
            var grown = (bool[])thick.Clone();
            for (int y = 1; y < h - 1; y++)
            for (int x = 1; x < w - 1; x++)
            {
                int i = y * w + x;
                if (!thick[i]) continue;
                grown[i - 1] = true; grown[i + 1] = true;
                grown[i - w] = true; grown[i + w] = true;
            }
            thick = grown;
        }
        for (int i = 0; i < n; i++) if (thick[i]) ink[i] = true;

        // ---- 7. ФОН (НЕБО) ----
        //
        // Небо — не закрашиваемая область, а бумага: его внутренние границы не
        // рисуются, и в отчёт оно не идёт.
        //
        // РАНЬШЕ ОНО ОПРЕДЕЛЯЛОСЬ ПО УГЛАМ КАДРА — самая частая метка в верхних углах,
        // если её больше 60%. Проверка на пяти реальных снимках: НЕ СРАБОТАЛО НИ РАЗУ.
        // Углы кадра постоянно заняты кроной или склоном, порог не набирается, и небо
        // шло в отчёт как обычная область. На одном из снимков оно и оказалось
        // «крупнейшей областью» — 18% кадра, 93% её площади в верхней трети, то есть
        // отчёт мерил небо.
        //
        // Гадать незачем: у неба есть собственный класс в проходе ID. Там, где нет
        // геометрии, проход даёт чистый ноль, и это точный признак, а не эвристика.
        var sky = new bool[n];
        bool hasSky = false;
        for (int i = 0; i < n; i++)
            if (idKey[i] == 0) { sky[i] = true; hasSky = true; }
        if (hasSky)
        {
            for (int y = 0; y < h - 1; y++)
            for (int x = 0; x < w - 1; x++)
            {
                int i = y * w + x;
                if (sky[i] && sky[i + 1] && sky[i + w]) ink[i] = false;
            }
        }

        // ---- 8. РАСТЕРИЗАЦИОННЫЕ КРАПИНЫ ----
        //
        // Слияние работает с картой областей, а игрок закрашивает КАРТИНКУ, и это не
        // одно и то же: обводка съедает по точке с края, лесенка косой границы
        // отсекает одиночные точки, утолщение перерезает перемычки. На реальном
        // шаблоне так набралось 150 белых пятен медианной площадью в ОДИН пиксель
        // при отчёте «непригодных 0».
        //
        // Такое пятно — не область, а дырка в линии: закрасить его нельзя, а глазу
        // оно и не видно (все вместе занимали 0.089% кадра). Поэтому оно становится
        // чернилами. Проходов несколько: залив одну крапину, можно обнажить соседнюю.
        for (int pass = 0; pass < 4; pass++)
        {
            var seedInk = new long[n];
            for (int i = 0; i < n; i++) seedInk[i] = ink[i] ? 1L : 0L;
            int cnt = LabelConnected(seedInk, w, h, out int[] lab2);
            var rad2 = RegionRadii(lab2, cnt, w, h);
            var isInk2 = new bool[cnt + 1];
            for (int i = 0; i < n; i++) if (ink[i]) isInk2[lab2[i]] = true;
            var skyPart = SkyLabels(lab2, cnt, sky);
            var dissolve = new bool[cnt + 1];
            bool any = false;
            for (int r = 1; r <= cnt; r++)
                if (!isInk2[r] && !skyPart[r] && rad2[r] < MinRegionRadius) { dissolve[r] = true; any = true; }
            if (!any) break;
            for (int i = 0; i < n; i++) if (dissolve[lab2[i]]) ink[i] = true;
        }

        LastReport = BuildReport(ink, sky, w, h);
        // ---- БЕЗЫМЯННАЯ ПЕЧАТЬ УБРАНА ----
        //
        // Разбор записи: из 645 строк 222 были «[sketch]», и 111 из них —
        // ЧИСТЫЙ ДУБЛЬ. Отчёт печатался дважды: здесь без имени и в обходе
        // с именем.
        //
        // Безымянный бесполезен: неизвестно, к какому обходу относится.
        //
        // Отчёт остаётся в LastReport; печатает его тот, кто знает имя.

        // ---- 9. ШТРИХОВКА УБРАНА ----
        //
        // Она вводилась, чтобы передать на раскраске геометрию: контурный рисунок
        // показывал только границы, объём в нём не читался. Но плата оказалась
        // несоразмерной: под штриховкой лежало 29% кадра, и это ровно те области —
        // горы и кроны, — которые на раскраске самые крупные и самые желанные.
        // Закрашивать их игроку уже не давали.
        //
        // Задача осталась, решение будет другим: форму передают высотные полосы и
        // класс уклона в проходе ID (они дают ЗАКРАШИВАЕМЫЕ области вместо серого
        // поля) и силуэтные рёбра по глубине. Проход нормалей больше не нужен.
        var outImg = Image.CreateEmpty(w, h, false, Image.Format.Rgba8);
        outImg.Fill(new Color(1, 1, 1, 1));
        var lineCol = new Color(0.08f, 0.08f, 0.10f, 1f);
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
            if (ink[y * w + x]) outImg.SetPixel(x, y, lineCol);
        return outImg.SavePngToBuffer();
    }

    /// <summary>Отчёт о пригодности последнего шаблона. Пишется в лог и доступен
    /// снаружи: это единственная величина, измеряющая ПРОДУКТ, а не промежуточное
    /// представление.</summary>
    public string LastReport { get; private set; } = "";

    /// <summary>Включить дробление областей по квантованному цвету исходника.
    /// См. пояснение в BuildOutline: выключено намеренно.</summary>
    public bool UseColorSplit { get; set; } = false;

    /// <summary>
    /// ОТЧЁТ СЧИТАЕТСЯ ПО ГОТОВОМУ ИЗОБРАЖЕНИЮ, а не по карте областей.
    ///
    /// Первая версия мерила карту меток — то есть состояние ДО того, как линии
    /// обвели и утолщили. На первом же реальном шаблоне это дало неверный ответ:
    /// отчёт сказал «непригодных 0», а независимая проверка по самому PNG нашла
    /// 141 крапину медианной площадью в один пиксель, выкроенную утолщением.
    ///
    /// Разница невелика по площади (0.089% кадра), но принцип нарушен ровно тот,
    /// ради которого отчёт и заводился: он должен мерить то, что видит игрок.
    /// Поэтому считается по маске чернил, уже со всеми утолщениями и вычетом фона.
    /// </summary>
    /// <summary>Метки, которые следует считать небом: больше половины их площади
    /// приходится на точки без геометрии. Доля, а не «есть хоть одна точка», —
    /// иначе область, задевшая небо одним пикселем на кромке, выпала бы из отчёта.</summary>
    private static bool[] SkyLabels(int[] lab, int cnt, bool[] sky)
    {
        var total = new int[cnt + 1];
        var skyN = new int[cnt + 1];
        for (int i = 0; i < lab.Length; i++)
        {
            total[lab[i]]++;
            if (sky[i]) skyN[lab[i]]++;
        }
        var res = new bool[cnt + 1];
        for (int r = 1; r <= cnt; r++) res[r] = total[r] > 0 && skyN[r] * 2 > total[r];
        return res;
    }

    private string BuildReport(bool[] ink, bool[] sky, int w, int h)
    {
        int n = w * h;
        var seed = new long[n];
        for (int i = 0; i < n; i++) seed[i] = ink[i] ? 1L : 0L;
        int cnt = LabelConnected(seed, w, h, out int[] lab);
        var radius = RegionRadii(lab, cnt, w, h);

        // Метки чернил из отчёта исключаются: закрашивают белое.
        var isInk = new bool[cnt + 1];
        for (int i = 0; i < n; i++) if (ink[i]) isInk[lab[i]] = true;

        var areas = new int[cnt + 1];
        for (int i = 0; i < n; i++) areas[lab[i]]++;

        var isSky = SkyLabels(lab, cnt, sky);
        int usable = 0, comfy = 0, huge = 0, biggest = 0;
        for (int r = 1; r <= cnt; r++)
        {
            if (isInk[r] || isSky[r]) continue;
            if (radius[r] >= MinRegionRadius) usable++;
            if (radius[r] >= ComfortRegionRadius && radius[r] < 60f) comfy++;
            if (radius[r] >= 60f) huge++;
            if (areas[r] > biggest) biggest = areas[r];
        }
        int inkPx = 0;
        for (int i = 0; i < n; i++) if (ink[i]) inkPx++;
        // ---- ПОЛЕ «НЕПРИГОДНЫХ» УБРАНО ----
        //
        // Разбор записи за прогон: во всех 111 замерах оно равнялось НУЛЮ.
        // Мелкие области отсеиваются раньше, и до отчёта не доходят.
        //
        // Счёт его тоже убран: мёртвого в проекте не держим.
        return $"шаблон: областей {usable}, из них удобных без увеличения {comfy}, "
             + $"крупных заливок {huge}; "
             + $"самая большая занимает {biggest * 100f / n:F0}% кадра, "
             + $"чернил {inkPx * 100f / n:F1}%";
    }

    /// <summary>
    /// РАСКОДИРОВАНИЕ УЗЛА СЕТКИ 1/5 ИЗ ПРОЧИТАННОГО ПИКСЕЛЯ.
    ///
    /// Шейдер пишет значения 0, 0.2 … 1.0, но текстура вьюпорта хранит их в sRGB, и
    /// обратно приходят 0, 124, 170, 203, 231, 255. Простое округление round(c*5)
    /// даёт 0, 2, 3, 4, 5, 5 — то есть смещает четыре узла из шести и СКЛЕИВАЕТ два
    /// последних. Практически это значило, что дёрн и камыш попадали в один подкласс,
    /// а из шести значений хеша экземпляра работало пять.
    ///
    /// Раньше этого не было видно, потому что прежний проход пользовался только
    /// значениями 0 и 1 — единственными, кого преобразование не трогает. Проверка
    /// «цвета выходят ровными 0 и 255» была верна для той палитры и неверна для этой:
    /// разница живёт ровно на промежуточных узлах, которых тогда не было.
    /// </summary>
    private static int Grid5Index(float channel)
    {
        float linear = channel <= 0.04045f
            ? channel / 12.92f
            : MathF.Pow((channel + 0.055f) / 1.055f, 2.4f);
        return Math.Clamp((int)MathF.Round(linear * 5f), 0, 5);
    }

    /// <summary>
    /// Силуэтные рёбра по глубине: ОТНОСИТЕЛЬНЫЙ скачок расстояния.
    ///
    /// Делится на саму глубину не для красоты: пологая поверхность, уходящая вдаль,
    /// даёт постоянный абсолютный градиент, и абсолютный порог помечал контуром
    /// половину кадра — это уже измерялось при подборе порогов Собеля.
    /// </summary>
    private static bool[] SilhouetteEdges(float[] depth, int w, int h, float rel)
    {
        var e = new bool[w * h];
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            int i = y * w + x;
            float d = MathF.Max(depth[i], 1e-4f);
            float gx = x + 1 < w ? MathF.Abs(depth[i + 1] - depth[i]) : 0f;
            float gy = y + 1 < h ? MathF.Abs(depth[i + w] - depth[i]) : 0f;
            if (MathF.Max(gx, gy) / d > rel) e[i] = true;
        }
        return e;
    }

    /// <summary>Класс растительности — старший разряд ключа (R = 4).</summary>
    private const int VegetationClass = 4;

    private static void CloseVegetationClass(int[] idKey, int w, int h, int radius)
    {
        int n = w * h;
        var mask = new bool[n];
        for (int i = 0; i < n; i++) mask[i] = idKey[i] / 36 == VegetationClass;
        var dil = Morph(mask, w, h, radius, dilate: true);
        var closed = Morph(dil, w, h, radius, dilate: false);
        // Значение, которым заполняются проколы: самое частое значение растительности
        // в окрестности не считаем — берём ближайшее, иначе смыкание перекрасило бы
        // кроны разных экземпляров в один цвет и слило бы их обратно в пятно.
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            int i = y * w + x;
            if (!closed[i] || mask[i]) continue;
            int found = NearestVegetationKey(idKey, mask, w, h, x, y, radius + 1);
            if (found >= 0) idKey[i] = found;
        }
    }

    private static int NearestVegetationKey(int[] idKey, bool[] mask, int w, int h, int cx, int cy, int r)
    {
        int best = -1, bestD = int.MaxValue;
        for (int y = Math.Max(0, cy - r); y <= Math.Min(h - 1, cy + r); y++)
        for (int x = Math.Max(0, cx - r); x <= Math.Min(w - 1, cx + r); x++)
        {
            int i = y * w + x;
            if (!mask[i]) continue;
            int d = (x - cx) * (x - cx) + (y - cy) * (y - cy);
            if (d < bestD) { bestD = d; best = idKey[i]; }
        }
        return best;
    }

    private static bool[] Morph(bool[] src, int w, int h, int r, bool dilate)
    {
        var tmp = new bool[w * h];
        // Разделимая морфология: сперва по X, потом по Y — O(n·r) вместо O(n·r²).
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            bool acc = !dilate;
            for (int dx = -r; dx <= r; dx++)
            {
                int xx = Math.Clamp(x + dx, 0, w - 1);
                bool v = src[y * w + xx];
                acc = dilate ? (acc || v) : (acc && v);
            }
            tmp[y * w + x] = acc;
        }
        var outp = new bool[w * h];
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            bool acc = !dilate;
            for (int dy = -r; dy <= r; dy++)
            {
                int yy = Math.Clamp(y + dy, 0, h - 1);
                bool v = tmp[yy * w + x];
                acc = dilate ? (acc || v) : (acc && v);
            }
            outp[y * w + x] = acc;
        }
        return outp;
    }

    /// <summary>Связные области одинакового значения seed. Обход стеком, а не
    /// рекурсией: кадр в миллион точек переполнил бы стек вызовов.</summary>
    private static int LabelConnected(long[] seed, int w, int h, out int[] label)
    {
        int n = w * h;
        label = new int[n];
        var stack = new Stack<int>(1024);
        int cur = 0;
        for (int start = 0; start < n; start++)
        {
            if (label[start] != 0) continue;
            cur++;
            long v = seed[start];
            stack.Push(start);
            label[start] = cur;
            while (stack.Count > 0)
            {
                int i = stack.Pop();
                int x = i % w, y = i / w;
                if (x > 0 && label[i - 1] == 0 && seed[i - 1] == v) { label[i - 1] = cur; stack.Push(i - 1); }
                if (x < w - 1 && label[i + 1] == 0 && seed[i + 1] == v) { label[i + 1] = cur; stack.Push(i + 1); }
                if (y > 0 && label[i - w] == 0 && seed[i - w] == v) { label[i - w] = cur; stack.Push(i - w); }
                if (y < h - 1 && label[i + w] == 0 && seed[i + w] == v) { label[i + w] = cur; stack.Push(i + w); }
            }
        }
        return cur;
    }

    /// <summary>
    /// Максимальный вписанный радиус каждой области.
    ///
    /// Считается чемферным преобразованием расстояния (3-4) за два прохода, а не
    /// точным евклидовым: порог у нас 4 точки, а погрешность чемфера около 2%, то
    /// есть заведомо меньше шага порога. Точный EDT здесь был бы работой впустую.
    /// </summary>
    private static float[] RegionRadii(int[] label, int regions, int w, int h)
    {
        int n = w * h;
        const int Inf = 1 << 28;
        var d = new int[n];
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            int i = y * w + x;
            bool border = x == 0 || y == 0 || x == w - 1 || y == h - 1
                       || label[i] != label[i - 1] || label[i] != label[i + 1]
                       || label[i] != label[i - w] || label[i] != label[i + w];
            d[i] = border ? 0 : Inf;
        }
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            int i = y * w + x;
            int v = d[i];
            if (x > 0) v = Math.Min(v, d[i - 1] + 3);
            if (y > 0) v = Math.Min(v, d[i - w] + 3);
            if (x > 0 && y > 0) v = Math.Min(v, d[i - w - 1] + 4);
            if (x < w - 1 && y > 0) v = Math.Min(v, d[i - w + 1] + 4);
            d[i] = v;
        }
        for (int y = h - 1; y >= 0; y--)
        for (int x = w - 1; x >= 0; x--)
        {
            int i = y * w + x;
            int v = d[i];
            if (x < w - 1) v = Math.Min(v, d[i + 1] + 3);
            if (y < h - 1) v = Math.Min(v, d[i + w] + 3);
            if (x < w - 1 && y < h - 1) v = Math.Min(v, d[i + w + 1] + 4);
            if (x > 0 && y < h - 1) v = Math.Min(v, d[i + w - 1] + 4);
            d[i] = v;
        }
        var radius = new float[regions + 1];
        for (int i = 0; i < n; i++)
        {
            float r = d[i] / 3f;
            if (r > radius[label[i]]) radius[label[i]] = r;
        }
        return radius;
    }

    /// <summary>
    /// Слить области тоньше порога с соседом по самой длинной общей границе.
    ///
    /// Сосед выбирается по ДЛИНЕ ГРАНИЦЫ, а не по площади: тонкая полоска вдоль
    /// кромки луга должна уйти в луг, а не в небо, с которым у неё общего десять
    /// точек. Проходов несколько, потому что после слияния область может остаться
    /// тонкой (две ленты, слитые вместе, — всё ещё лента) и потребовать ещё одного.
    /// </summary>
    private static int MergeThinRegions(int[] label, int regions, int w, int h, float minRadius)
    {
        const int MaxRounds = 8;
        for (int round = 0; round < MaxRounds; round++)
        {
            var radius = RegionRadii(label, regions, w, h);
            var thin = new List<int>();
            for (int r = 1; r <= regions; r++)
                if (radius[r] < minRadius) thin.Add(r);
            if (thin.Count == 0) break;

            // Длина общей границы для каждой пары соседей.
            var border = new Dictionary<long, int>(thin.Count * 8);
            void Bump(int a, int b)
            {
                if (a == b) return;
                long key = a < b ? ((long)a << 32) | (uint)b : ((long)b << 32) | (uint)a;
                border[key] = border.TryGetValue(key, out int c) ? c + 1 : 1;
            }
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                int i = y * w + x;
                int a = label[i];
                // Проверка на равенство ДО вызова: пар в кадре два миллиона, и
                // подавляющее большинство — точки внутри одной области. Без этой
                // строки словарь опрашивался бы на каждой из них впустую.
                if (x < w - 1 && a != label[i + 1]) Bump(a, label[i + 1]);
                if (y < h - 1 && a != label[i + w]) Bump(a, label[i + w]);
            }
            var best = new int[regions + 1];
            var bestLen = new int[regions + 1];
            foreach (var kv in border)
            {
                int a = (int)(kv.Key >> 32), b = (int)(kv.Key & 0xffffffff);
                if (kv.Value > bestLen[a]) { bestLen[a] = kv.Value; best[a] = b; }
                if (kv.Value > bestLen[b]) { bestLen[b] = kv.Value; best[b] = a; }
            }

            var parent = new int[regions + 1];
            for (int i = 0; i <= regions; i++) parent[i] = i;
            int Find(int i) { while (parent[i] != i) { parent[i] = parent[parent[i]]; i = parent[i]; } return i; }

            // От самых тонких к менее тонким: у самой безнадёжной области выбор соседа
            // делается первой, пока соседи ещё не слиплись между собой.
            thin.Sort((a, b) => radius[a].CompareTo(radius[b]));
            foreach (int r in thin)
            {
                int t = best[r];
                if (t == 0) continue;
                int ra = Find(r), rb = Find(t);
                if (ra != rb) parent[ra] = rb;
            }

            var remap = new int[regions + 1];
            int next = 0;
            for (int i = 1; i <= regions; i++)
            {
                int root = Find(i);
                if (remap[root] == 0) remap[root] = ++next;
                remap[i] = remap[root];
            }
            for (int i = 0; i < label.Length; i++) label[i] = remap[label[i]];
            regions = next;

            // После слияния метка может оказаться на двух несвязных кусках — они
            // разные области, и мерить их вместе значило бы считать тонкую полоску
            // пригодной за счёт далёкого крупного пятна того же цвета.
            var seed = new long[label.Length];
            for (int i = 0; i < label.Length; i++) seed[i] = label[i];
            regions = LabelConnected(seed, w, h, out int[] relabel);
            Array.Copy(relabel, label, label.Length);
        }
        return regions;
    }


    /// <summary>Квантованный ключ цвета исходника. Используется только при
    /// UseColorSplit — см. пояснение в BuildOutline.</summary>
    private int[] BuildColorKey(Image src, int w, int h)
    {
        var lum = new float[w * h];
        var ca = new float[w * h];
        var cb = new float[w * h];
        bool sizeOk = src.GetWidth() == w && src.GetHeight() == h;
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            var c = sizeOk
                ? src.GetPixel(x, y)
                : src.GetPixel(x * src.GetWidth() / w, y * src.GetHeight() / h);
            RgbToLab(c.R, c.G, c.B, out float L, out float A, out float B);
            int i = y * w + x;
            lum[i] = L; ca[i] = A; cb[i] = B;
        }
        int blurR = Math.Max(1, (int)MathF.Round(ColorBlurFraction * MathF.Max(w, h)));
        lum = BoxBlur(lum, w, h, blurR);
        ca = BoxBlur(ca, w, h, blurR);
        cb = BoxBlur(cb, w, h, blurR);
        var key = new int[w * h];
        for (int i = 0; i < w * h; i++)
        {
            int qL = (int)MathF.Floor(lum[i] * ColorQuantSteps);
            int qA = (int)MathF.Floor((ca[i] + 1f) * ColorQuantSteps);
            int qB = (int)MathF.Floor((cb[i] + 1f) * ColorQuantSteps);
            key[i] = (qL * 10000) + (qA * 100) + qB;
        }
        return key;
    }


    // SpeckleFraction убран (V148): чистка велась по ЧЕРНИЛАМ, а теперь режется по
    // ОБЛАСТЯМ — см. MinRegionRadius и MergeThinRegions. Это разные вещи: связная
    // сетка границ по кроне давала одну длинную компоненту чернил, которую фильтр не
    // трогал, и тысячу незакрашиваемых дырок внутри неё.



    /// <summary>Разделимое коробчатое сглаживание: два прохода по одной оси каждый,
    /// поэтому стоимость линейна по радиусу, а не квадратична.</summary>
    /// <summary>sRGB -> CIE Lab, нормированный так, что L в 0..1, a и b в -1..1.
    /// Lab выбран потому, что в нём яркость отделена от цветности: на мобильных
    /// экранах с разной цветопередачей разбиение по Lab устойчивее, чем по RGB.</summary>
    private static void RgbToLab(float r, float g, float b, out float L, out float A, out float B)
    {
        float X = r * 0.4124f + g * 0.3576f + b * 0.1805f;
        float Y = r * 0.2126f + g * 0.7152f + b * 0.0722f;
        float Z = r * 0.0193f + g * 0.1192f + b * 0.9505f;
        X /= 0.9505f; Z /= 1.089f;
        static float F(float t) => t > 0.008856f ? MathF.Cbrt(t) : 7.787f * t + 16f / 116f;
        float fx = F(X), fy = F(Y), fz = F(Z);
        L = (116f * fy - 16f) / 100f;
        A = 500f * (fx - fy) / 128f;
        B = 200f * (fy - fz) / 128f;
    }

    private static float[] BoxBlur(float[] src, int w, int h, int r)
    {
        var tmp = new float[src.Length];
        var dst = new float[src.Length];

        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            float sum = 0f; int cnt = 0;
            for (int k = -r; k <= r; k++)
            {
                int xx = x + k;
                if (xx < 0 || xx >= w) continue;
                sum += src[y * w + xx]; cnt++;
            }
            tmp[y * w + x] = sum / MathF.Max(cnt, 1);
        }

        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            float sum = 0f; int cnt = 0;
            for (int k = -r; k <= r; k++)
            {
                int yy = y + k;
                if (yy < 0 || yy >= h) continue;
                sum += tmp[yy * w + x]; cnt++;
            }
            dst[y * w + x] = sum / MathF.Max(cnt, 1);
        }
        return dst;
    }
}
