using System;

namespace ColoringBook.Infrastructure.Generation;

/// <summary>
/// Простой детерминированный PRNG (xorshift32).
/// Один и тот же seed всегда даёт одну и ту же последовательность.
/// </summary>
public sealed class SeededRandom
{
    private uint _state;

    public SeededRandom(int seed)
    {
        _state = seed == 0 ? 1u : (uint)seed;
    }

    public int NextInt(int maxExclusive)
    {
        if (maxExclusive <= 0) return 0;
        return (int)(NextUInt() % (uint)maxExclusive);
    }

    public float NextFloat()
    {
        return NextUInt() / (float)uint.MaxValue;
    }

    public float NextFloat(float min, float max)
    {
        return min + NextFloat() * (max - min);
    }

    private uint NextUInt()
    {
        uint x = _state;
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        _state = x;
        return x;
    }
}
