using System;
using System.Globalization;
using System.Text;

namespace ColoringBook.Infrastructure.Generation.Diagnostics;

/// <summary>
/// Диагностика УЖЕ ПОСТРОЕННОЙ поверхности (heightmap), а не графа регионов.
///
/// ЗАЧЕМ ОТДЕЛЬНО ОТ GenerationDiagnostics. Тот считается по AlpineTerrain.Result,
/// то есть ДО того, как LevelView3D построит меш. А между ними происходит многое:
/// интерполяция высот в сетку, врезка русел, складки рельефа, эрозионные гребни,
/// микрорельеф. Всё, что портится на этом этапе, в региональные метрики не попадает
/// ВООБЩЕ — например, зубцы на дне долин от складок рельефа были невидимы в логах,
/// хотя на экране бросались в глаза.
///
/// Главная метрика — КРУТИЗНА РЁБЕР СЕТКИ: угол между соседними вершинами по
/// горизонтали. Считается отдельно для трёх зон, потому что норма у них разная:
///   - дно долин: должно быть пологим. Ориентир по замеру: только рельеф даёт
///     p95 = 23°, складки, привязанные к высоте, задирали до 61° (это и были зубцы),
///     привязка к уклону вернула 26°.
///   - склоны: расчленение нужно, p95 около 77-78° — норма.
///   - вершины: острые, но не иглы.
/// </summary>
public sealed class MeshDiagnostics
{
    public int Resolution;
    public int ValidVertices;

    public float EdgeAngleMeanAll;
    public float EdgeAngleP95All;

    public float FloorEdgeAngleMean;
    public float FloorEdgeAngleP95;
    public float FloorEdgeAngleMax;
    public float FloorAreaFraction;

    public float SlopeEdgeAngleP95;
    public float PeakEdgeAngleP95;

    /// <summary>Вершины выше ВСЕХ четырёх соседей более чем на SpikeThresholdMetres.
    /// Это и есть «иглы»: если их много на дне — что-то добавляет высокочастотный
    /// шум там, где его быть не должно.</summary>
    public int SpikeCount;
    public int SpikeCountOnFloor;

    public const float SpikeThresholdMetres = 1.0f;

    /// <summary>Ниже этого выход воды за берег на глаз неразличим.</summary>
    public const float VisibleBankOverflow = 0.05f;

    // ---- ВОДА ----
    /// <summary>Узлов под водой (глубина врезки выше порога).</summary>
    public int WaterVertices;

    /// <summary>Из них — в озере (плоское зеркало), остальное реки.</summary>
    public int LakeVertices;

    /// <summary>РАЗБРОС ВЫСОТЫ ЗЕРКАЛА внутри озёр, мировые единицы: разность между
    /// узлом и средним по его окрестности. У настоящего озера зеркало плоское, и это
    /// число должно быть близко к нулю. Именно оно ловит «многогранники»: пока
    /// поверхность озера выводилась из рельефа дна, она повторяла его неровности.</summary>
    public float LakeSurfaceSpreadMean;
    public float LakeSurfaceSpreadMax;

    /// <summary>Узлов, где поверхность воды оказалась НИЖЕ дна. Такого быть не должно
    /// вовсе: вода провалилась бы под рельеф и пропала из виду.</summary>
    public int WaterBelowBedCount;

    /// <summary>Крутизна рёбер САМОЙ поверхности воды, p95. У озера должна быть около
    /// нуля, у реки — небольшой уклон вдоль русла.</summary>
    public float WaterEdgeAngleP95;
    public float WaterEdgeAngleMax;

    /// <summary>ТОЛЩИНА ВОДЫ У КРОМКИ, мировые единицы: насколько зеркало выше дна в
    /// узлах, где глубина близка к порогу. Если это число заметно больше нуля, лист
    /// воды обрывается «в воздухе» и между водой и берегом виден зазор.</summary>
    public float ShoreThicknessMean;
    public float ShoreThicknessMax;

    /// <summary>Узлов, где зеркало заметно выше неврезанной поверхности.
    ///
    /// ПОЧЕМУ ПОРОГ, А НЕ ЛЮБОЕ ПРЕВЫШЕНИЕ. Первая версия считала превышение от
    /// 0.001, и метрика оказалась бесполезной: она давала одно и то же число (2136)
    /// и до, и после введения ограничителя, потому что ограничитель уменьшал
    /// ВЕЛИЧИНУ выхода, а не сам факт. Судить надо по величине — она ниже.</summary>
    public int WaterAboveBankCount;

    /// <summary>Насколько зеркало выходит за неврезанную поверхность, мировые
    /// единицы. Для масштаба: толщина воды у кромки около 0.8.</summary>
    public float WaterAboveBankMean;
    public float WaterAboveBankMax;

    /// <param name="y">Мировые высоты вершин сетки res x res.</param>
    /// <param name="elev">Нормированная высота (0..1) в тех же узлах.</param>
    /// <param name="valid">Годность узла.</param>
    /// <param name="horizontalStepWorld">Шаг сетки в мировых единицах.</param>
    public static MeshDiagnostics Build(
        float[] y, float[] elev, bool[] valid, int res, float horizontalStepWorld,
        float[]? waterY = null, float[]? lakeFrac = null,
        float[]? carveBlur = null, float waterMinDepth = 0f, float[]? surfRaw = null)
    {
        var d = new MeshDiagnostics { Resolution = res };
        float step = Math.Max(horizontalStepWorld, 1e-4f);

        // Классификация узлов: дно / склон / вершина.
        var isFloor = new bool[y.Length];
        var isPeak = new bool[y.Length];
        int validCount = 0, floorCount = 0;

        for (int gz = 0; gz < res; gz++)
        for (int gx = 0; gx < res; gx++)
        {
            int i = gz * res + gx;
            if (!valid[i]) continue;
            validCount++;

            int gxm = gx > 0 ? gx - 1 : gx, gxp = gx < res - 1 ? gx + 1 : gx;
            int gzm = gz > 0 ? gz - 1 : gz, gzp = gz < res - 1 ? gz + 1 : gz;
            float gX = (y[gz * res + gxp] - y[gz * res + gxm]) / Math.Max((gxp - gxm) * step, 1e-4f);
            float gZ = (y[gzp * res + gx] - y[gzm * res + gx]) / Math.Max((gzp - gzm) * step, 1e-4f);
            float slope = MathF.Sqrt(gX * gX + gZ * gZ);

            if (elev[i] < 0.45f && slope < 0.6f) { isFloor[i] = true; floorCount++; }
            else if (elev[i] > 0.68f) isPeak[i] = true;

            // Игла: выше всех четырёх соседей на заметную величину.
            if (gx > 0 && gx < res - 1 && gz > 0 && gz < res - 1)
            {
                float me = y[i];
                float mx = Math.Max(
                    Math.Max(y[gz * res + gx - 1], y[gz * res + gx + 1]),
                    Math.Max(y[(gz - 1) * res + gx], y[(gz + 1) * res + gx]));
                if (me - mx > SpikeThresholdMetres)
                {
                    d.SpikeCount++;
                    if (isFloor[i]) d.SpikeCountOnFloor++;
                }
            }
        }

        d.ValidVertices = validCount;
        d.FloorAreaFraction = validCount > 0 ? floorCount / (float)validCount : 0f;

        var all = new ResizableFloats(y.Length * 2);
        var floor = new ResizableFloats(y.Length);
        var slopeZone = new ResizableFloats(y.Length);
        var peak = new ResizableFloats(y.Length);

        void Edge(int a, int b)
        {
            if (!valid[a] || !valid[b]) return;
            float ang = MathF.Atan2(MathF.Abs(y[a] - y[b]), step) * 180f / MathF.PI;
            all.Add(ang);
            if (isFloor[a] && isFloor[b]) floor.Add(ang);
            else if (isPeak[a] || isPeak[b]) peak.Add(ang);
            else slopeZone.Add(ang);
        }

        for (int gz = 0; gz < res; gz++)
        for (int gx = 0; gx < res; gx++)
        {
            int i = gz * res + gx;
            if (gx < res - 1) Edge(i, i + 1);
            if (gz < res - 1) Edge(i, i + res);
        }

        d.EdgeAngleMeanAll = all.Mean();
        d.EdgeAngleP95All = all.Percentile(0.95f);
        d.FloorEdgeAngleMean = floor.Mean();
        d.FloorEdgeAngleP95 = floor.Percentile(0.95f);
        d.FloorEdgeAngleMax = floor.Max();
        d.SlopeEdgeAngleP95 = slopeZone.Percentile(0.95f);
        d.PeakEdgeAngleP95 = peak.Percentile(0.95f);

        // ---- вода ----
        if (waterY != null)
        {
            var waterEdges = new ResizableFloats(y.Length);
            var lakeSpread = new ResizableFloats(y.Length);

            for (int gz = 0; gz < res; gz++)
            for (int gx = 0; gx < res; gx++)
            {
                int i = gz * res + gx;
                if (!valid[i] || float.IsNaN(waterY[i])) continue;
                d.WaterVertices++;
                bool inLake = lakeFrac != null && lakeFrac[i] > 0.5f;
                if (inLake) d.LakeVertices++;
                if (waterY[i] < y[i] - 1e-3f) d.WaterBelowBedCount++;

                if (gx < res - 1)
                {
                    int j = i + 1;
                    if (valid[j] && !float.IsNaN(waterY[j]))
                        waterEdges.Add(MathF.Atan2(MathF.Abs(waterY[i] - waterY[j]), step) * 180f / MathF.PI);
                }
                if (gz < res - 1)
                {
                    int j = i + res;
                    if (valid[j] && !float.IsNaN(waterY[j]))
                        waterEdges.Add(MathF.Atan2(MathF.Abs(waterY[i] - waterY[j]), step) * 180f / MathF.PI);
                }

                // Разброс зеркала: отклонение от среднего по 4 соседям, только в озере.
                if (inLake && gx > 0 && gx < res - 1 && gz > 0 && gz < res - 1)
                {
                    float sum = 0f; int cnt = 0;
                    int[] nb = { i - 1, i + 1, i - res, i + res };
                    foreach (int k in nb)
                    {
                        if (!valid[k] || float.IsNaN(waterY[k])) continue;
                        if (lakeFrac == null || lakeFrac[k] <= 0.5f) continue;
                        sum += waterY[k]; cnt++;
                    }
                    if (cnt > 0) lakeSpread.Add(MathF.Abs(waterY[i] - sum / cnt));
                }
            }

            // Толщина у кромки и выход воды на берег.
            if (carveBlur != null)
            {
                var shore = new ResizableFloats(1024);
                var overflow = new ResizableFloats(1024);
                for (int i = 0; i < y.Length; i++)
                {
                    if (!valid[i] || float.IsNaN(waterY[i])) continue;
                    if (surfRaw != null)
                    {
                        float over = waterY[i] - surfRaw[i];
                        if (over > VisibleBankOverflow)
                        {
                            d.WaterAboveBankCount++;
                            overflow.Add(over);
                        }
                    }
                    // «У кромки» — глубина от порога до полутора порогов.
                    if (carveBlur[i] > waterMinDepth && carveBlur[i] < waterMinDepth * 1.5f)
                        shore.Add(MathF.Max(0f, waterY[i] - y[i]));
                }
                d.ShoreThicknessMean = shore.Mean();
                d.ShoreThicknessMax = shore.Max();
                d.WaterAboveBankMean = overflow.Mean();
                d.WaterAboveBankMax = overflow.Max();
            }

            d.WaterEdgeAngleP95 = waterEdges.Percentile(0.95f);
            d.WaterEdgeAngleMax = waterEdges.Max();
            d.LakeSurfaceSpreadMean = lakeSpread.Mean();
            d.LakeSurfaceSpreadMax = lakeSpread.Max();
        }

        return d;
    }

    public string ToJson()
    {
        var sb = new StringBuilder();
        var c = CultureInfo.InvariantCulture;
        sb.Append('{');
        sb.Append("\"resolution\":").Append(Resolution).Append(',');
        sb.Append("\"validVertices\":").Append(ValidVertices).Append(',');
        sb.Append("\"edgeAngleMeanAll\":").Append(EdgeAngleMeanAll.ToString("R", c)).Append(',');
        sb.Append("\"edgeAngleP95All\":").Append(EdgeAngleP95All.ToString("R", c)).Append(',');
        sb.Append("\"floorAreaFraction\":").Append(FloorAreaFraction.ToString("R", c)).Append(',');
        sb.Append("\"floorEdgeAngleMean\":").Append(FloorEdgeAngleMean.ToString("R", c)).Append(',');
        sb.Append("\"floorEdgeAngleP95\":").Append(FloorEdgeAngleP95.ToString("R", c)).Append(',');
        sb.Append("\"floorEdgeAngleMax\":").Append(FloorEdgeAngleMax.ToString("R", c)).Append(',');
        sb.Append("\"slopeEdgeAngleP95\":").Append(SlopeEdgeAngleP95.ToString("R", c)).Append(',');
        sb.Append("\"peakEdgeAngleP95\":").Append(PeakEdgeAngleP95.ToString("R", c)).Append(',');
        sb.Append("\"spikeCount\":").Append(SpikeCount).Append(',');
        sb.Append("\"spikeCountOnFloor\":").Append(SpikeCountOnFloor).Append(',');
        sb.Append("\"waterVertices\":").Append(WaterVertices).Append(',');
        sb.Append("\"lakeVertices\":").Append(LakeVertices).Append(',');
        sb.Append("\"lakeSurfaceSpreadMean\":").Append(LakeSurfaceSpreadMean.ToString("R", c)).Append(',');
        sb.Append("\"lakeSurfaceSpreadMax\":").Append(LakeSurfaceSpreadMax.ToString("R", c)).Append(',');
        sb.Append("\"waterBelowBedCount\":").Append(WaterBelowBedCount).Append(',');
        sb.Append("\"waterEdgeAngleP95\":").Append(WaterEdgeAngleP95.ToString("R", c)).Append(',');
        sb.Append("\"waterEdgeAngleMax\":").Append(WaterEdgeAngleMax.ToString("R", c)).Append(',');
        sb.Append("\"shoreThicknessMean\":").Append(ShoreThicknessMean.ToString("R", c)).Append(',');
        sb.Append("\"shoreThicknessMax\":").Append(ShoreThicknessMax.ToString("R", c)).Append(',');
        sb.Append("\"waterAboveBankCount\":").Append(WaterAboveBankCount).Append(',');
        sb.Append("\"waterAboveBankMean\":").Append(WaterAboveBankMean.ToString("R", c)).Append(',');
        sb.Append("\"waterAboveBankMax\":").Append(WaterAboveBankMax.ToString("R", c));
        sb.Append('}');
        return sb.ToString();
    }

    /// <summary>Простой растущий буфер float — чтобы не тянуть List&lt;float&gt; с
    /// боксингом при сортировке и не выделять массив на максимум заранее.</summary>
    private sealed class ResizableFloats
    {
        private float[] _a;
        private int _n;
        public ResizableFloats(int cap) => _a = new float[Math.Max(16, cap)];

        public void Add(float v)
        {
            if (_n == _a.Length) Array.Resize(ref _a, _a.Length * 2);
            _a[_n++] = v;
        }

        public float Mean()
        {
            if (_n == 0) return 0f;
            double s = 0;
            for (int i = 0; i < _n; i++) s += _a[i];
            return (float)(s / _n);
        }

        public float Max()
        {
            float m = 0f;
            for (int i = 0; i < _n; i++) if (_a[i] > m) m = _a[i];
            return m;
        }

        public float Percentile(float p)
        {
            if (_n == 0) return 0f;
            var copy = new float[_n];
            Array.Copy(_a, copy, _n);
            Array.Sort(copy);
            int idx = Math.Clamp((int)(_n * p), 0, _n - 1);
            return copy[idx];
        }
    }
}
