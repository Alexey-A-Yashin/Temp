using System;
using System.IO;

namespace ColoringBook.Infrastructure.Generation.Diagnostics;

/// <summary>
/// Пишет GenerationDiagnostics в JSON-файл на диск, чтобы результаты генерации можно
/// было посмотреть/проанализировать вне игры (например, отдать в чат для разбора).
///
/// Путь — НЕ через Godot user:// (чтобы этот класс, как и весь Infrastructure/Generation,
/// оставался Godot-независимым и тестировался headless): обычная пользовательская папка
/// профиля. На Windows это %LOCALAPPDATA%\ColoringBook\mapgen_logs, на Linux/macOS —
/// ~/.local/share/ColoringBook/mapgen_logs (или ~/Library/Application Support/... на
/// macOS — .NET сам выбирает подходящий путь для each платформы).
///
/// Путь к записанному файлу печатается в консоль Godot при каждой генерации — искать
/// строку "[mapgen] лог записан:".
/// </summary>
public static class GenerationLog
{
    private const int MaxFilesToKeep = 200;

    /// <summary>
    /// Куда писать логи. Если задано — используется вместо папки профиля.
    /// Ставится из GameBootstrap как res://logs, чтобы логи лежали прямо в проекте и
    /// их было удобно забирать. Свойство, а не прямое обращение к Godot, потому что
    /// весь Infrastructure/Generation намеренно держится Godot-независимым и
    /// проверяется headless.
    /// </summary>
    public static string? OverrideDirectory { get; set; }

    public static string LogDirectory
    {
        get
        {
            if (!string.IsNullOrEmpty(OverrideDirectory)) return OverrideDirectory!;
            string baseDir = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            return Path.Combine(baseDir, "ColoringBook", "mapgen_logs");
        }
    }

    /// <summary>Записывает JSON-файл и возвращает полный путь к нему.</summary>
    public static string Write(GenerationDiagnostics diagnostics)
    {
        string dir = LogDirectory;
        Directory.CreateDirectory(dir);

        string fileName = $"{diagnostics.TimestampUtc:yyyyMMdd_HHmmss}_seed{diagnostics.Seed}.json";
        string path = Path.Combine(dir, fileName);
        File.WriteAllText(path, diagnostics.ToJson());

        CleanupOldFiles(dir);
        return path;
    }

    /// <summary>Пишет диагностику построенной поверхности рядом с основным логом.
    /// Отдельный файл, потому что считается ПОЗЖЕ — уже в LevelView3D, когда меш
    /// построен, а основной лог к тому моменту записан.</summary>
    public static string WriteMesh(MeshDiagnostics mesh, int seed)
    {
        string dir = LogDirectory;
        Directory.CreateDirectory(dir);
        string fileName = $"{DateTime.UtcNow:yyyyMMdd_HHmmss}_seed{seed}_mesh.json";
        string path = Path.Combine(dir, fileName);
        File.WriteAllText(path, mesh.ToJson());
        CleanupOldFiles(dir);
        return path;
    }

    /// <summary>Пишет произвольный JSON-снимок с указанным суффиксом. Используется
    /// для статистики роста растений (суффикс "plants").</summary>
    public static string WriteRaw(string json, int seed, string suffix)
    {
        string dir = LogDirectory;
        Directory.CreateDirectory(dir);
        string fileName = $"{DateTime.UtcNow:yyyyMMdd_HHmmss}_seed{seed}_{suffix}.json";
        string path = Path.Combine(dir, fileName);
        File.WriteAllText(path, json);
        CleanupOldFiles(dir);
        return path;
    }

    /// <summary>Держим не больше MaxFilesToKeep файлов — панель может перегенерировать
    /// уровень десятки раз за сессию тестирования, папка не должна расти бесконечно.</summary>
    private static void CleanupOldFiles(string dir)
    {
        try
        {
            var files = Directory.GetFiles(dir, "*.json");
            if (files.Length <= MaxFilesToKeep) return;
            Array.Sort(files, (a, b) => File.GetCreationTimeUtc(a).CompareTo(File.GetCreationTimeUtc(b)));
            int toDelete = files.Length - MaxFilesToKeep;
            for (int i = 0; i < toDelete; i++) File.Delete(files[i]);
        }
        catch
        {
            // Чистка — не критична; если не получилось (права доступа и т.п.), просто пропускаем.
        }
    }
}
