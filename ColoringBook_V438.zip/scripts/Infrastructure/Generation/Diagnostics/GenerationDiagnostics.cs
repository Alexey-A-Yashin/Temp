using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using ColoringBook.Domain.Common;
using ColoringBook.Domain.Level;
using ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

namespace ColoringBook.Infrastructure.Generation.Diagnostics;

/// <summary>
/// Снимок результата генерации уровня в машиночитаемом виде — чтобы вопросы вида
/// "что реально получилось при таких-то настройках эрозии/гидрологии" можно было
/// разобрать по файлу, без пересборки движка. Пишется на диск при каждой генерации
/// (см. GenerationLog.Write), путь печатается в консоль.
///
/// Специально НЕ зависит от Godot — считается тем же кодом, что тестируется в
/// mapgen-харнессе, чтобы не разойтись с тем, что реально видит игрок.
/// </summary>
public sealed class GenerationDiagnostics
{
    public DateTime TimestampUtc;
    public int Seed;
    public string Quality = "";
    public int PointCount;
    public double GenerationMs;

    public int ValleyCount;
    public int PeakCount;
    public int RidgeCount;
    public int LakeCount;
    public int RiverCount;
    public int WaterCellCount;

    // Метрики СВЯЗНОСТИ речной сети. Именно они, а не число русел, показывают,
    // получилась ли настоящая ветвящаяся сеть: число русел жёстко задано порогом
    // (доля регионов), поэтому оно почти не меняется и диагностической ценности
    // не имеет. Ориентиры из замеров: до починки — 42 фрагмента, длиннейшее
    // русло 42 клетки, главная река собирает 8.6% карты; после — 12-24
    // фрагмента, длиннейшее до 234, главная река 85-99%.
    public int RiverComponentCount;
    public int LongestRiverCells;
    public float TrunkDrainageFraction;
    public int OutletCellCount;
    public float WaterFraction;

    // ---- Судоходный ствол (MainChannel / RiverWorld) ----
    public int? ChunkIndex;
    public int? WorldSeed;
    public int MainStemCount;
    public int TributaryCount;
    public bool StemTouchesInlet;
    public bool StemTouchesOutlet;
    public bool StemPathExists;
    public float? InletLateral;
    public float? OutletLateral;
    public float? InletBedElev;
    public float? OutletBedElev;

    public float SlopeMedian;
    public float SlopeP90;
    public float SlopeMax;
    public int LocalMaximaCount;

    public Dictionary<string, int> BiomeCounts = new();

    // ConditionedErosion убран: 206 строк, не выполнявшихся никогда.
    // Его держала только эта запись, а саму диагностику из счёта не зовут.
    public Hydrology.Settings HydrologySettings = new();

    // ---- ПОСТРОИТЕЛЬ ОТЧЁТА УБРАН ВМЕСТЕ СО СТАРЫМ ГЕНЕРАТОРОМ ----
    //
    // Метод принимал AlpineTerrain.Result — данные старого генератора, которого
    // больше нет. Его никто не звал: отчёт по нашему рельефу строит
    // TerrainReport с мерами правдоподобия (геоморфоны, Хортон, светотень).
    //
    // Сам тип оставлен: его поля пишет журнал построения.


    public string ToJson()
    {
        var sb = new StringBuilder();
        sb.Append('{');
        AppendField(sb, "timestampUtc", TimestampUtc.ToString("o", CultureInfo.InvariantCulture));
        AppendField(sb, "seed", Seed);
        AppendField(sb, "quality", Quality);
        AppendField(sb, "pointCount", PointCount);
        AppendField(sb, "generationMs", GenerationMs);
        AppendField(sb, "valleyCount", ValleyCount);
        AppendField(sb, "peakCount", PeakCount);
        AppendField(sb, "ridgeCount", RidgeCount);
        AppendField(sb, "lakeCount", LakeCount);
        AppendField(sb, "riverCount", RiverCount);
        AppendField(sb, "waterCellCount", WaterCellCount);
        AppendField(sb, "slopeMedian", SlopeMedian);
        AppendField(sb, "slopeP90", SlopeP90);
        AppendField(sb, "slopeMax", SlopeMax);
        AppendField(sb, "localMaximaCount", LocalMaximaCount);
        AppendField(sb, "riverComponentCount", RiverComponentCount);
        AppendField(sb, "longestRiverCells", LongestRiverCells);
        AppendField(sb, "trunkDrainageFraction", TrunkDrainageFraction);
        AppendField(sb, "outletCellCount", OutletCellCount);
        AppendField(sb, "waterFraction", WaterFraction);
        if (ChunkIndex.HasValue) AppendField(sb, "chunkIndex", ChunkIndex.Value);
        if (WorldSeed.HasValue) AppendField(sb, "worldSeed", WorldSeed.Value);
        AppendField(sb, "mainStemCount", MainStemCount);
        AppendField(sb, "tributaryCount", TributaryCount);
        AppendField(sb, "stemTouchesInlet", StemTouchesInlet ? 1 : 0);
        AppendField(sb, "stemTouchesOutlet", StemTouchesOutlet ? 1 : 0);
        AppendField(sb, "stemPathExists", StemPathExists ? 1 : 0);
        if (InletLateral.HasValue) AppendField(sb, "inletLateral", InletLateral.Value);
        if (OutletLateral.HasValue) AppendField(sb, "outletLateral", OutletLateral.Value);
        if (InletBedElev.HasValue) AppendField(sb, "inletBedElev", InletBedElev.Value);
        if (OutletBedElev.HasValue) AppendField(sb, "outletBedElev", OutletBedElev.Value);

        sb.Append("\"biomeCounts\":{");
        bool first = true;
        foreach (var kv in BiomeCounts)
        {
            if (!first) sb.Append(',');
            first = false;
            sb.Append('"').Append(Escape(kv.Key)).Append("\":").Append(kv.Value);
        }
        sb.Append("},");

        // Блок erosionSettings убран вместе с ConditionedErosion.
        sb.Append("},");

        sb.Append("\"hydrologySettings\":{");
        AppendField(sb, "minLakeDepth", HydrologySettings.MinLakeDepth);
        AppendField(sb, "riverFraction", HydrologySettings.RiverFraction);
        AppendField(sb, "epsilon", HydrologySettings.Epsilon);
        AppendFieldLast(sb, "minRiverFlux", HydrologySettings.MinRiverFlux);
        sb.Append('}');

        sb.Append('}');
        return sb.ToString();
    }

    private static void AppendField(StringBuilder sb, string name, string value)
    {
        sb.Append('"').Append(name).Append("\":\"").Append(Escape(value)).Append("\",");
    }

    private static void AppendField(StringBuilder sb, string name, int value)
    {
        sb.Append('"').Append(name).Append("\":").Append(value.ToString(CultureInfo.InvariantCulture)).Append(',');
    }

    private static void AppendField(StringBuilder sb, string name, float value)
    {
        sb.Append('"').Append(name).Append("\":").Append(value.ToString("R", CultureInfo.InvariantCulture)).Append(',');
    }

    private static void AppendField(StringBuilder sb, string name, double value)
    {
        sb.Append('"').Append(name).Append("\":").Append(value.ToString("R", CultureInfo.InvariantCulture)).Append(',');
    }

    private static void AppendFieldLast(StringBuilder sb, string name, int value)
    {
        sb.Append('"').Append(name).Append("\":").Append(value.ToString(CultureInfo.InvariantCulture));
    }

    private static void AppendFieldLast(StringBuilder sb, string name, float value)
    {
        sb.Append('"').Append(name).Append("\":").Append(value.ToString("R", CultureInfo.InvariantCulture));
    }

    private static string Escape(string s) => s.Replace("\\", "\\\\").Replace("\"", "\\\"");
}
