using System.Collections.Generic;

namespace ColoringBook.Infrastructure.Generation.Plants;

/// <summary>
/// Чистый C#-меш растения (без Godot). Presentation конвертирует в ArrayMesh.
/// Цвета — относительные (1,1,1 = «белый» шаблон); сезонная окраска накладывается при инстансинге.
/// UV указывает на ячейку foliage-атласа (см. FoliageAtlas): солид-ячейка для стволов/веток
/// (непрозрачный дефолт), листовые/игольчатые ячейки — для alpha-cutout карточек листвы.
/// </summary>
public sealed class PlantMeshData
{
    public List<float> Positions { get; } = new(256);
    public List<float> Colors { get; } = new(256);
    public List<float> UVs { get; } = new(256);
    public List<int> Indices { get; } = new(384);

    /// <summary>Примерная высота в локальных единицах (для нормализации scale).</summary>
    public float LocalHeight { get; set; } = 1f;

    /// <summary>Вершина сплошной геометрии (ствол/ветка) — UV указывает в непрозрачную ячейку атласа.</summary>
    public void AddVertex(float x, float y, float z, float r, float g, float b)
        => AddVertex(x, y, z, r, g, b, FoliageAtlas.SolidU, FoliageAtlas.SolidV);

    /// <summary>Вершина с явным UV (карточки листвы/игл).</summary>
    public void AddVertex(float x, float y, float z, float r, float g, float b, float u, float v)
    {
        Positions.Add(x);
        Positions.Add(y);
        Positions.Add(z);
        Colors.Add(r);
        Colors.Add(g);
        Colors.Add(b);
        Colors.Add(1f);
        UVs.Add(u);
        UVs.Add(v);
    }

    public int VertexCount => Positions.Count / 3;


    public void AddQuad(int a, int b, int c, int d)
    {
        Indices.Add(a);
        Indices.Add(b);
        Indices.Add(c);
        Indices.Add(a);
        Indices.Add(c);
        Indices.Add(d);
    }
}
