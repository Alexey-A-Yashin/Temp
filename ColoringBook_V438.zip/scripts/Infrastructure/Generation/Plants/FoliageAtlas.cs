using System;

namespace ColoringBook.Infrastructure.Generation.Plants;

/// <summary>
/// Координаты ячеек текстурного атласа листвы (assets/textures/foliage/foliage_atlas.png).
///
/// V87: атлас перерисован и расширен. Прежний был 256×256, сетка 2×2, и — что
/// важнее размера — в нём было ровно ЧЕТЫРЕ фигуры сплошного белого цвета: квадрат,
/// спица и два скруглённых ромба. Проверено по извлечённому файлу: среди
/// непрозрачных точек в каждой ячейке ровно ОДИН цвет (255,255,255). То есть
/// текстура задавала только силуэт, а силуэтом листа был ромб — отсюда и «зелёные
/// квадраты» на экране, независимо от того, сколько труда вложено в скелет дерева.
///
/// Теперь 1024×1024, сетка 4×4 по 256 точек. Размер выбран по замеру экранного
/// покрытия: карточка листа занимает 119 точек экрана на дистанции 5 мировых единиц
/// и 59 на десяти, то есть ячейка читается почти один к одному, и вложенная в неё
/// форма видна. У каждого листа есть центральная жилка и боковые — они нарисованы
/// В ЦВЕТЕ (тёмно-серое на белом), а материал умножает текстуру на цвет вершины,
/// поэтому жилки становятся тёмной зеленью, а сезонная окраска работает как прежде.
///
/// Раскладка (колонка, строка), строка 0 — верхняя:
///   (0,0) Solid        — непрозрачный белый: стволы, ветви, всё без alpha-cutout
///   (1,0) Needle       — одиночная хвоинка, заострённая с обоих концов
///   (2,0) FirSpray     — лапа пихты: ось с хвоинками в обе стороны
///   (3,0) PineFascicle — пучок сосны: три длинные хвоинки из общего основания
///   (0,1) LeafOak      — перистолопастной (дуб)
///   (1,1) LeafBirch    — яйцевидный мелкозубчатый (берёза)
///   (2,1) LeafMaple    — пальчатый пятилопастный (клён)
///   (3,1) LeafWillow   — ланцетный (ива)
///   (0,2) LeafHazel    — округло-яйцевидный зубчатый (лещина, кустарники)
///   (1,2) GrassBlade   — травинка с изгибом
///   (2,2) Petal        — лепесток
///   (3,2) LeafOak2     — второй дубовый лист, чуть иной рисунок жилок
///
/// Строка 3 пока пуста и зарезервирована. Один атлас на все растения — один
/// материал и один вызов отрисовки на группу MultiMesh.
///
/// Атлас генерируется скриптом tools/make_foliage_atlas.py: силуэты заданы формулами,
/// поэтому их можно править и пересобирать, не рисуя руками.
/// </summary>
public static class FoliageAtlas
{
    private const int Grid = 4;
    private const float Cell = 1f / Grid;

    /// <summary>Отступ от края ячейки в долях атласа. При 1024 точках и сетке 4×4
    /// это примерно 6 точек — защита от подмешивания соседней ячейки на мип-уровнях.
    /// Прежнее значение 0.012 задавалось для атласа 256×256, где ячейка занимала
    /// половину стороны, и в долях ЯЧЕЙКИ было вчетверо крупнее нынешнего.</summary>
    private const float Inset = 0.006f;

    /// <summary>Центр сплошной ячейки. Служит признаком «это не листва»: сравнение
    /// UV с этой парой используется в PlantMetrics, BuildLodMesh и BuildImpostorMesh.</summary>
    public const float SolidU = Cell * 0.5f;
    public const float SolidV = Cell * 0.5f;

    private static (float uMin, float vMin, float uMax, float vMax) At(int col, int row)
        => (col * Cell + Inset, row * Cell + Inset,
            (col + 1) * Cell - Inset, (row + 1) * Cell - Inset);

    public static readonly (float uMin, float vMin, float uMax, float vMax) Needle = At(1, 0);
    public static readonly (float uMin, float vMin, float uMax, float vMax) FirSpray = At(2, 0);
    public static readonly (float uMin, float vMin, float uMax, float vMax) PineFascicle = At(3, 0);

    public static readonly (float uMin, float vMin, float uMax, float vMax) LeafOak = At(0, 1);
    public static readonly (float uMin, float vMin, float uMax, float vMax) LeafBirch = At(1, 1);
    public static readonly (float uMin, float vMin, float uMax, float vMax) LeafMaple = At(2, 1);
    public static readonly (float uMin, float vMin, float uMax, float vMax) LeafWillow = At(3, 1);

    public static readonly (float uMin, float vMin, float uMax, float vMax) LeafHazel = At(0, 2);
    public static readonly (float uMin, float vMin, float uMax, float vMax) GrassBlade = At(1, 2);
    public static readonly (float uMin, float vMin, float uMax, float vMax) Petal = At(2, 2);

    // ---- V130: ПУЧКИ (строка 3) ----
    // Ячейка изображает веточку с несколькими листьями натуральной пропорции, а не
    // один лист. Именно её и рисует уровень: карточка полуметрового размера тогда
    // читается как облиственная веточка, а не как двухметровый лопух. Одиночные
    // листья остаются витрине и подробному режиму.
    public static readonly (float uMin, float vMin, float uMax, float vMax) ClusterOak = At(0, 3);
    public static readonly (float uMin, float vMin, float uMax, float vMax) ClusterBirch = At(1, 3);
    public static readonly (float uMin, float vMin, float uMax, float vMax) ClusterMaple = At(2, 3);
    public static readonly (float uMin, float vMin, float uMax, float vMax) ClusterConifer = At(3, 3);

    /// <summary>Ячейка для КОМПАКТНОГО режима: пучок вместо одиночного листа.</summary>
    public static (float uMin, float vMin, float uMax, float vMax) ClusterFor(PlantSpecies.LeafCell cell)
        => cell switch
        {
            PlantSpecies.LeafCell.Birch => ClusterBirch,
            PlantSpecies.LeafCell.Maple => ClusterMaple,
            PlantSpecies.LeafCell.Willow => ClusterBirch,
            PlantSpecies.LeafCell.Needle => ClusterConifer,
            _ => ClusterOak,
        };

    /// <summary>
    /// КОРА (V140). Ячейка бывшего дубликата дуба отдана продольным бороздам и
    /// чечевичкам: ствол рисовался сплошным цветом, потому что указывал в непрозрачную
    /// ячейку. Фактура из текстуры не стоит ни одного лишнего треугольника.
    /// </summary>
    public static readonly (float uMin, float vMin, float uMax, float vMax) Bark = At(3, 2);

    /// <summary>
    /// Листва ли это по координатам UV.
    ///
    /// Раньше признаком служило «не сплошная ячейка», и этого хватало: всё, что не
    /// листва, указывало в Solid. С появлением коры у древесины стало ДВЕ возможные
    /// ячейки, и прежняя проверка записала бы стволы в листву — прореживание среднего
    /// уровня применило бы к ним шаг и компенсацию площади, рассчитанные на карточки.
    /// </summary>
    public static bool IsFoliageUv(float u, float v)
    {
        bool solid = MathF.Abs(u - SolidU) < 1e-4f && MathF.Abs(v - SolidV) < 1e-4f;
        if (solid) return false;
        // Кора занимает свою ячейку целиком, поэтому проверяем попадание в диапазон.
        bool bark = u >= Bark.uMin - 1e-4f && u <= Bark.uMax + 1e-4f
                 && v >= Bark.vMin - 1e-4f && v <= Bark.vMax + 1e-4f;
        return !bark;
    }

    /// <summary>Прежние имена сохранены: на них ссылается код, которому нужен
    /// «какой-нибудь широкий» и «какой-нибудь узкий» лист — например, построение
    /// дальнего уровня в LevelView3D.</summary>
    public static readonly (float uMin, float vMin, float uMax, float vMax) LeafA = At(0, 1);
    public static readonly (float uMin, float vMin, float uMax, float vMax) LeafB = At(3, 1);
}
