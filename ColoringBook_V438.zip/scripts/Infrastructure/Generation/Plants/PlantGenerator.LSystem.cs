using System;
using System.Collections.Generic;
using ColoringBook.Infrastructure.Generation;

namespace ColoringBook.Infrastructure.Generation.Plants;

// ------------------------------------------------------------------
//  Параметрическая Л-система (ABOP гл.1.10 "Parametric L-systems") —
//  общий движок для мелких растений (п.8.3: Bush/Flower/Reed).
//
//  В отличие от RunTurtleProgram в PlantGenerator.cs (используется хвоей
//  Pine/Fir) — там черепашка интерпретирует ГОТОВУЮ фиксированную строку,
//  без порождающих правил. Здесь есть настоящий шаг ДЕРИВАЦИИ: аксиома ->
//  правила (predecessor -> successor) -> N итераций -> раскрытая
//  последовательность символов -> та же черепашка.
//
//  Правила заданы не текстовой грамматикой (как в примерах ABOP), а C#-
//  делегатами: предиктор — символ (char), тело правила — функция
//  (символ, rnd) -> список символов-преемников. Тот же формализм (символы
//  с параметрами, правила, деривация), просто без парсера мини-языка —
//  он не нужен для фиксированного набора видов и был бы лишней точкой
//  отказа.
// ------------------------------------------------------------------
public static partial class PlantGenerator
{
    /// <summary>
    /// Символ Л-системы с параметрами (ABOP: A(l,w) и т.п.). Двух float-параметров
    /// хватает всем видам ниже — смысл параметра зависит от Id (см. RunLSystem).
    /// </summary>
    private readonly struct LSym
    {
        public readonly char Id;
        public readonly float P0, P1;
        public LSym(char id, float p0 = 0f, float p1 = 0f) { Id = id; P0 = p0; P1 = p1; }
    }

    /// <summary>Порождающее правило: символ -> список символов-преемников. Символы без
    /// правила в словаре проходят без изменений — как F/+/-/[]/N и т.п. в ABOP,
    /// "финальные" символы алфавита, которые не переписываются.</summary>
    private delegate List<LSym> LRule(LSym s, SeededRandom rnd);

    /// <summary>N шагов деривации: аксиома -> правила -> итоговая строка символов.
    /// Лишние итерации после того, как все правила перестали что-то менять, безвредны
    /// (символы без правила просто продолжают проходить насквозь) — поэтому n можно
    /// брать с небольшим запасом, не считая точный "истинный" момент остановки.</summary>
    private static List<LSym> Derive(List<LSym> axiom, Dictionary<char, LRule> rules, int n, SeededRandom rnd)
    {
        var cur = axiom;
        for (int step = 0; step < n; step++)
        {
            var next = new List<LSym>(cur.Count * 2 + 4);
            foreach (var s in cur)
            {
                if (rules.TryGetValue(s.Id, out var rule))
                    next.AddRange(rule(s, rnd));
                else
                    next.Add(s);
            }
            cur = next;
        }
        return cur;
    }

    /// <summary>
    /// Палитра черепашки: цвет ветки/стебля + до 3 самостоятельных "ролей" органа
    /// (L/O/C — например лист/лепесток/сердцевина, или лист/метёлка/—). Не все виды
    /// используют все роли.
    /// </summary>
    private readonly struct LPalette
    {
        public readonly float TwR, TwG, TwB;
        public readonly float LR, LG, LB;
        public readonly float OR, OG, OB;
        public readonly float CR, CG, CB;
        public LPalette(
            float twR, float twG, float twB,
            float lR, float lG, float lB,
            float oR = 0, float oG = 0, float oB = 0,
            float cR = 0, float cG = 0, float cB = 0)
        {
            TwR = twR; TwG = twG; TwB = twB;
            LR = lR; LG = lG; LB = lB;
            OR = oR; OG = oG; OB = oB;
            CR = cR; CG = cG; CB = cB;
        }
    }

    /// <summary>
    /// Интерпретация раскрытой Л-строки черепашкой (та же геометрия Родрига, что у
    /// RunTurtleProgram). Алфавит (ABOP Appendix C, сокращённый под наши примитивы):
    ///   F(len,radius) — сегмент стебля/ветки (AddBranch);
    ///   f(len)        — шаг БЕЗ рисования (для позиционирования органов не на оси ветки);
    ///   L/O/C(size)   — карточка листвы своей роли (AddFoliageBlob);
    ///   N(len)        — узкая карточка-лезвие (AddNeedle) — для травы/камыша;
    ///   +/-           — рыскание (yaw) вокруг Up;
    ///   &amp;/^       — тангаж (pitch) вокруг Side;
    ///   /             — крен (roll) вокруг Fwd — приём ABOP для разведения дочерних
    ///                   веток по кругу вместо одной плоскости (см. $ и /(d) в главе 2);
    ///   [ / ]         — стек состояний черепашки (точка ветвления).
    /// Параметр P0 у +/-/&amp;/^// — угол в градусах для ЭТОГО символа; если |P0|≈0,
    /// используется общий angleDeg, переданный в RunLSystem (нужно для регулярных углов
    /// на каждый символ — вроде вееров лепестков — без раздувания P0 у каждого F).
    /// </summary>
    /// <param name="tropism">Вектор тропизма T из ABOP (гл. 2, «Tropism»).</param>
    /// <param name="tropismE">Податливость оси к изгибу e из той же формулы.
    /// 0 — тропизма нет (прежнее поведение).</param>
    /// <param name="leafCell">Форма листа вида. V87: раньше Л-система рисовала лист
    /// всегда одной и той же ячейкой атласа, поэтому у лещины, ивы и можжевельника
    /// был один силуэт — проверено выборкой UV из готовых мешей. Теперь ячейка
    /// приходит из PlantSpecies, как у лиственных деревьев.</param>
    private static void RunLSystem(
        List<LSym> symbols, Vec3 startPos, Vec3 startFwd, float angleDeg,
        PlantMeshData mesh, SeededRandom rnd, LPalette pal,
        Vec3 tropism = default, float tropismE = 0f,
        PlantSpecies.LeafCell leafCell = PlantSpecies.LeafCell.Rounded)
    {
        var fwd = Norm(startFwd);
        if (float.IsNaN(fwd.X)) fwd = new Vec3(0, 1, 0);
        var upRef = MathF.Abs(fwd.Y) < 0.9f ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        var side = Norm(Cross(fwd, upRef));
        var up = Norm(Cross(side, fwd));
        var st = new TurtleState { Pos = startPos, Fwd = fwd, Up = up, Side = side };
        var stack = new Stack<TurtleState>();
        float defaultAng = angleDeg * MathF.PI / 180f;

        static void Clip(ref Vec3 p) { if (p.Y < 0.02f) p = new Vec3(p.X, 0.02f, p.Z); }

        foreach (var s in symbols)
        {
            switch (s.Id)
            {
                case 'F':
                {
                    var np = Add(st.Pos, Mul(st.Fwd, s.P0));
                    Clip(ref np);
                    float r = MathF.Max(0.003f, s.P1);
                    // В компактном режиме тонкий побег рисуется крестом из двух карточек
                    // (4 треугольника) вместо четырёхгранной трубки (8). Порог абсолютный,
                    // а не от высоты: Л-система обслуживает и куст, и цветок, и камыш,
                    // у которых собственная высота отличается на порядок.
                    if (Detail == FoliageDetail.Compact && r < 0.012f)
                        AddBranchCross(mesh, st.Pos, np, r, pal.TwR, pal.TwG, pal.TwB);
                    else
                        AddBranch(mesh, st.Pos, np, r, pal.TwR, pal.TwG, pal.TwB);
                    st.Pos = np;

                    // ТРОПИЗМ (ABOP, гл. 2): после отрисовки сегмента черепашка слегка
                    // доворачивается к заданному вектору T на угол α = e·|H × T|, где
                    // H — текущее направление. Формула имеет физический смысл: если
                    // считать T силой, приложенной к концу H, то H × T — момент.
                    //
                    // Раньше тропизма не было вовсе, и стебли шли строго по прямой от
                    // развилки до развилки. Именно он даёт кустарнику и камышу
                    // естественный прогиб: побег отклоняется под собственным весом или,
                    // наоборот, тянется вверх к свету.
                    if (tropismE > 1e-5f)
                    {
                        var hxt = Cross(st.Fwd, tropism);
                        float alpha = tropismE * Len(hxt);
                        if (alpha > 1e-5f)
                        {
                            var axis = Norm(hxt);
                            st.Fwd = Norm(RotateAroundAxis(st.Fwd, axis, alpha));
                            st.Up = Norm(RotateAroundAxis(st.Up, axis, alpha));
                            st.Side = Norm(Cross(st.Fwd, st.Up));
                        }
                    }
                    break;
                }
                case 'f':
                {
                    var np = Add(st.Pos, Mul(st.Fwd, s.P0));
                    Clip(ref np);
                    st.Pos = np;
                    break;
                }
                case 'L':
                case 'O':
                case 'C':
                {
                    (float r, float g, float b) c = s.Id switch
                    {
                        'L' => (pal.LR, pal.LG, pal.LB),
                        'O' => (pal.OR, pal.OG, pal.OB),
                        _ => (pal.CR, pal.CG, pal.CB)
                    };
                    var pos = st.Pos; Clip(ref pos);
                    // Лепесток и сердцевина цветка сохраняют собственные роли, а лист
                    // берёт видовую ячейку.
                    var cellFor = s.Id == 'L'
                        ? leafCell
                        : PlantSpecies.LeafCell.Petal;
                    AddFoliageBlob(mesh, pos, MathF.Max(0.005f, s.P0), rnd, conical: false,
                        c.r, c.g, c.b, st.Fwd, leafCell: cellFor);
                    break;
                }
                case 'N':
                {
                    var tip = Add(st.Pos, Mul(st.Fwd, s.P0));
                    Clip(ref tip);
                    var basePos = st.Pos; Clip(ref basePos);
                    // N — узкое лезвие: у травы и камыша это травинка, а не хвоинка.
                    AddNeedle(mesh, basePos, tip, MathF.Max(0.01f, s.P0 * 0.06f), pal.LR, pal.LG, pal.LB,
                        FoliageAtlas.GrassBlade);
                    break;
                }
                case '+':
                {
                    float a = MathF.Abs(s.P0) > 1e-6f ? s.P0 * MathF.PI / 180f : defaultAng;
                    st.Fwd = Norm(RotateAroundAxis(st.Fwd, st.Up, a));
                    st.Side = Norm(Cross(st.Fwd, st.Up));
                    break;
                }
                case '-':
                {
                    float a = MathF.Abs(s.P0) > 1e-6f ? s.P0 * MathF.PI / 180f : defaultAng;
                    st.Fwd = Norm(RotateAroundAxis(st.Fwd, st.Up, -a));
                    st.Side = Norm(Cross(st.Fwd, st.Up));
                    break;
                }
                case '&':
                {
                    float a = MathF.Abs(s.P0) > 1e-6f ? s.P0 * MathF.PI / 180f : defaultAng;
                    st.Fwd = Norm(RotateAroundAxis(st.Fwd, st.Side, a));
                    st.Up = Norm(Cross(st.Side, st.Fwd));
                    break;
                }
                case '^':
                {
                    float a = MathF.Abs(s.P0) > 1e-6f ? s.P0 * MathF.PI / 180f : defaultAng;
                    st.Fwd = Norm(RotateAroundAxis(st.Fwd, st.Side, -a));
                    st.Up = Norm(Cross(st.Side, st.Fwd));
                    break;
                }
                case '/':
                {
                    float a = MathF.Abs(s.P0) > 1e-6f ? s.P0 * MathF.PI / 180f : defaultAng;
                    st.Side = Norm(RotateAroundAxis(st.Side, st.Fwd, a));
                    st.Up = Norm(Cross(st.Side, st.Fwd));
                    break;
                }
                case '[':
                    stack.Push(st);
                    break;
                case ']':
                    if (stack.Count > 0) st = stack.Pop();
                    break;
            }
        }
    }
}
