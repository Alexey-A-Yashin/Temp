using System;
using System.Collections.Generic;
using System.Diagnostics;
using ColoringBook.Domain.Level;
using ColoringBook.Infrastructure.Generation;

namespace ColoringBook.Infrastructure.Generation.Plants;

/// <summary>
/// Процедурная генерация растений (чистый C#).
/// Лиственные / кусты — Space Colonization (Runions et al. / Palubicki).
/// Хвойные — Weber-Penn (SeedThree) + ориентированные иголки.
///
/// QualityLevel (0..12) — LOD для разных устройств, НЕ «делать дерево деревом».
/// Дерево должно читаться уже при q=0. Вклад q ограничен qEff≤GameQEffMax;
/// целевой qEff = GameQEffTarget (mid-high mobile). Выше почти нет визуала.
/// AgeLevel игровой: GameAgeMin..GameAgeMax (ниже — саженцы без вариативности).
/// v14: fir cards age8/q4 цель 20–30k (было ~58k).
/// </summary>
public static partial class PlantGenerator
{
    // ---- Игровые диапазоны (realtime-пул / будущий prebake) ----
    // Витрина (P) по-прежнему позволяет крутить Age/Quality в полном 0..8 / 0..12
    // для отладки. Каталог уровня (EnsureInitialized) собирается только в этих рамках.
    public const int GameAgeMin = 5; // V114: ближе к зрелому пологу
    public const int GameAgeMax = 8;
    public const int GameQEffTarget = 4; // V114: верх мобильного бюджета
    public const int GameQEffMax = 5;
    /// <summary>Jitter FoliageDensity / densMul при создании генома (±15%).</summary>
    public const float DensMulJitterMin = 0.85f;
    public const float DensMulJitterMax = 1.15f;

    /// <summary>LOD 0..12. Для лиственных эффективно 0..GameQEffMax.</summary>
    public static int QualityLevel { get; set; }

    /// <summary>
    /// Отладочный режим: полностью убирает листву/хвою и красит ветки в контрастный цвет
    /// вместо коричневого — чтобы оценивать форму самого скелета дерева отдельно от шума
    /// card-карточек листвы поверх него. Переключается по S в витрине (GameBootstrap).
    /// Сейчас применяется только к SCA-генератору (Deciduous/Bush), т.к. именно там сейчас
    /// разбираемся с формой скелета; хвойные/трава пока не трогал.
    /// </summary>
    public static bool SkeletonDebugMode { get; set; }

    // ---- Самоорганизующийся рост (Palubicki 2009). Реализация — SelfOrganizingTree.cs.
    // Прежний вспомогательный класс SelfOrganizing обслуживал ГИБРИД (space colonization
    // + механизмы статьи поверх) и после перехода на чистую модель не используется. ----

    /// <summary>
    /// ВОЗРАСТ дерева, 0..8. В статье Палубицки это число шагов развития, и оно —
    /// главный переключатель формы, а не косметика: «многие деревья умеренного климата
    /// имеют выраженную главную ось в молодости, но переходят к decurrent-форме к
    /// старости» (Fig. 11 — анимация именно такого перехода).
    ///
    /// Возраст влияет на две вещи: сколько шагов роста отработает дерево и насколько
    /// силён апикальный контроль λ (см. AgeLambda).
    ///
    /// Игровой пул: GameAgeMin..GameAgeMax. Витрина: полный 0..8 для отладки.
    /// </summary>
    public static int AgeLevel { get; set; } = GameAgeMin;

    /// <summary>
    /// ПОДРОБНОСТЬ ЛИСТВЫ.
    ///
    /// Detailed — для витрины растений: дерево одно, его разглядывают вплотную,
    /// бюджет не важен. Compact — для уровня: одна карточка-лапа на сегмент ветви
    /// вместо десятков отдельных пучков хвои.
    ///
    /// Замер, из-за которого это появилось: ель в подробном режиме — 40 504
    /// треугольника, а бюджет ВСЕЙ сцены при 60 fps на среднем Android — 400 000.
    /// Даже при идеально работающем LOD 297 деревьев ближней полосы давали 11.9 млн.
    /// </summary>
    public enum FoliageDetail { Detailed, Compact }

    public static FoliageDetail Detail { get; set; } = FoliageDetail.Compact;

    /// <summary>Длина лапы в долях базовой длины хвоинки.</summary>
    // V97: 3.4 -> 1.30. Карточка лапы вытягивалась в длинную тонкую спицу, и крона
    // сосны на отрисовке читалась как взрыв прямых лучей, а не как хвоя. Лапа в
    // натуре примерно так же широка, как длинна, поэтому длина сокращена, а ширина
    // ниже поднята — карточка стала почти квадратной, как рисунок в атласе.
    private const float CompactSprayLength = 0.60f;   // V130: пучок в ячейке

    /// <summary>Ширина лапы в долях длины сегмента ветви.</summary>
    // V97: 0.55 -> 1.05 от длины сегмента. Вместе с сокращением длины это даёт
    // карточку с отношением сторон около 1:1 — ровно такую, какой нарисована лапа
    // пихты и пучок сосны в атласе.
    private const float CompactSprayWidth = 0.55f;    // V130: пучок в ячейке

    /// <summary>
    /// ЛАП НА СЕГМЕНТ ВЕТВИ у хвойных в компактном режиме. РУЧКА ПОДБОРА.
    ///
    /// Держится здесь, а не внутри метода, потому что это величина, которую
    /// придётся подгонять по замеру: заполненность кроны видна только после
    /// запуска, а зависит она не от числа лап напрямую, а от ПОКРЫТИЯ —
    /// произведения числа лап на площадь лапы, делённого на площадь кроны.
    /// Отклик пологий, прогон модели: покрытие 0.47 даёт 53% заполненности,
    /// 0.77 — 57%, 1.18 — 67%, 1.77 — 73%.
    ///
    /// История значений:
    ///   16 — набиралось при рыхлой ячейке (20% непрозрачности). После V151, где
    ///        ячейка стала 37%, те же 16 дали заполненность кроны 83-87%, и на
    ///        шаблоне витрины крона превратилась в ОДНО замкнутое пятно: полторы
    ///        области на дерево, контур кроны и контур ствола.
    ///    8 — цель 60-70%, как у лиственных, которые на раскраске читаются лучше
    ///        всех. Покрытие падает вдвое; по модели этого хватает на 10-15
    ///        пунктов, то есть ожидается 70-75% — возможно, ещё не в цель.
    ///
    /// ЕСЛИ ПОСЛЕ ЗАПУСКА ЗАПОЛНЕННОСТЬ ВЫШЕ 78% («МОНОЛИТ» в логе) — уменьшать
    /// дальше, следующий шаг 6. Если ниже 45% («РЕДКО») — возвращать к 10.
    /// </summary>
    private const int CompactSpraysPerSegment = 8;


    /// <summary>Потолок числа ветвей первого порядка в компактном режиме.
    /// Древесина стоит 8 треугольников на сегмент: при 40 ветвях по 8 сегментов
    /// это 2560 треугольников — больше всего бюджета дерева ещё до хвои.</summary>
    /// <summary>
    /// Потолок числа ветвей первого порядка в компактном режиме.
    ///
    /// V142: 22 -> 40. Снимок «под елью, взгляд вверх» показал причину, которую
    /// метрики не улавливали: крона у ели — узкий столбик хвои вокруг ствола, а самих
    /// ветвей почти нет. У взрослой ели ветвей первого порядка больше сотни; двадцать
    /// две — это молодое деревце, сколько хвои на них ни навешивай.
    ///
    /// Потолок вводился ради бюджета, но с тех пор карточка листвы стала натурального
    /// размера, а полоса полного меша сжалась до двадцати метров: подробный меш
    /// работает у считаных деревьев в кадре, и его цена перестала быть определяющей.
    /// </summary>
    private const int CompactMaxBranches = 40;

    /// <summary>Потолок числа сегментов ветви в компактном режиме.</summary>
    private const int CompactMaxCurveRes = 4;

    /// <summary>Во сколько раз крупнее листовая масса в компактном режиме.
    /// Число карточек падает примерно в 6 раз, поэтому каждая должна закрыть
    /// большую площадь, иначе крона станет прозрачной.</summary>
    // V97: 2.4 -> 1.15. Множитель наращивался, пока карточек было мало, и в итоге
    // отдельный «лист» стал размером с ветвь: на отрисовке крона дуба сложена из
    // полутора десятков огромных пятен вместо листвы. Размер возвращён к почти
    // натуральному, а покрытие держится числом карточек — их теперь вшестеро больше
    // (см. blobsPerSite ниже), что и есть правильный размен.
    // V130: 2.60 -> 1.05. Пучок в ячейке снял нужду в исполинской карточке: теперь
    // полметра на карточку — это веточка с десятком листьев, а не один лист.
    private const float CompactLeafMassScale = 0.52f;

    /// <summary>С какой доли высоты начинается прореживание кроны (V97).</summary>
    private const float HeightThinStart = 0.55f;

    /// <summary>Насколько разрежается самая макушка: 0.5 — вдвое.</summary>
    private const float HeightThinAmount = 0.5f;

    /// <summary>Золотой угол в радианах. Тот же филлотаксис, что применяется к листьям
    /// и хвое ниже по файлу; вынесен в поле, потому что нужен в двух методах.</summary>
    private const float GoldenAngleRad = 2.39996323f;

    /// <summary>
    /// Общий множитель ширины кроны.
    ///
    /// ЗАМЕР, ИЗ КОТОРОГО ОН ВЗЯТ. Среднее расстояние между соседними деревьями на
    /// уровне — 0.50 мировой единицы, а радиус кроны компактного дерева 1.05–1.49.
    /// То есть крона втрое шире, чем расстояние до соседа, и кроны перекрываются
    /// втрое-впятеро. На экране это и даёт сплошную зелёную массу вместо отдельных
    /// деревьев, а вместе с преградами делает лес непроходимым.
    ///
    /// Отношение радиуса кроны к высоте у нас выходило около 1:2, у настоящих
    /// хвойных оно 1:8…1:10, у широколиственных 1:3…1:4. Множитель приводит хвойные
    /// ближе к справочному, лиственным оставляет их природную раскидистость.
    ///
    /// Величина СКВОЗНАЯ по всем местам, где ширина кроны участвует: длина ветвей
    /// первого порядка, радиус размещения листвы, радиус хвойной лапы. Иначе части
    /// дерева разъезжаются между собой.
    /// </summary>
    public static float CrownWidthScale(VegetationKind kind) => kind switch
    {
        // Отношение радиуса кроны к высоте по фотографиям: у ели и пихты около 0.28,
        // у сосны 0.20 (крона короткая, но широкая), у дуба 0.45.
        // V120: шире крона по рефам (фото пород + тирольский лес)
        // V128: выставлено ПО ЗАМЕРУ, а не общим множителем. Прежняя правка «шире
        // крона по рефам» подняла всех разом, и вышло в обе стороны мимо: ель 0.38 и
        // кедр 0.43 при натурных 0.28–0.32, а дуб 0.33 при натурных 0.40–0.50.
        // ---- V136: ЗАМЕР ПО ВИТРИНЕ В ИГРОВОМ ВОЗРАСТЕ ----
        //
        // Витрина наконец показала то, что стоит на уровне (age 6–8), и метрики
        // разошлись с натурой в обе стороны:
        //   ель 0.49, пихта 0.40, тсуга 0.59 при натурных 0.28–0.32;
        //   сосна 0.40 при натурных 0.20–0.25;
        //   дуб 1.27 и клён 1.37 при натурных 0.40–0.50 — крона ВТРОЕ шире нормы,
        //   отсюда и «зонтики» на снимке: плоские блины шире собственной высоты.
        //
        // Прежние значения подбирались по замеру в возрасте 8 БЕЗ учёта того, что
        // CrownMul вида домножается сверху, — потому и промахнулись кратно.
        VegetationKind.Pine => 0.33f,
        VegetationKind.Fir => 0.66f,
        VegetationKind.Deciduous => 0.85f,
        _ => 1f,
    };

    /// <summary>
    /// Бюджет узлов скелета самоорганизующегося дерева. Растёт с возрастом, поэтому
    /// возраст виден в силуэте; в компактном режиме на порядок меньше, потому что
    /// каждый узел — это отрезок ветви в меше уровня.
    /// </summary>
    /// <summary>
    /// Бюджет узлов ГОТОВОГО скелета — сколько остаётся после прореживания.
    /// Числа те же, что были потолком роста до V161: стоимость меша на уровне не
    /// меняется, меняется только то, КАК дерево до неё доводится.
    /// </summary>
    /// <summary>
    /// Наибольшая доля освещённости, которую отнимает тень соседей у ОСНОВАНИЯ кроны
    /// при полном смыкании полога. РУЧКА ПОДБОРА.
    ///
    /// ЧИСЛО ПОДОБРАНО ПО МОДЕЛИ ЦИКЛА РОСТА, а не на глаз. Прогон повторяет ключевую
    /// часть Палубицки (почки растут, затеняют вниз, затенённые сбрасываются) и
    /// сравнивает два способа задать затенённость, по пять деревьев на точку:
    ///
    ///   через ПОРОГ сброса:   0.30 → 27%, 0.22 → 28%, 0.14 → 32%   (эффекта нет)
    ///   через БОКОВУЮ тень:   0.00 → 28%, 0.28 → 26%, 0.55 → 25%, 0.80 → 17%
    ///
    /// Порог не влияет — это подтверждает замер на реальных деревьях (78 / 78 / 78).
    /// Тень влияет монотонно, но заметно только к 0.8; при 0.55 разница три пункта,
    /// то есть снова шум. Взято 0.75: даёт около десяти пунктов, как у ели, и не
    /// доходит до единицы, при которой низ кроны остался бы вовсе без света и дерево
    /// в чаще превратилось бы в метлу на голом стволе.
    ///
    /// ОГОВОРКА: модель — игрушечная, у неё свои пропорции и своя мера доли кроны.
    /// Она даёт направление и порядок величины, но не точное значение; настоящая
    /// проверка — прогон витрины.
    /// </summary>
    private const float NeighbourShadeMax = 0.75f;

    private static int SoNodeBudget(int age)
    {
        int a = Math.Clamp(age, 0, 8);
        return Detail == FoliageDetail.Compact
            ? 110 + a * 30    // V120: age4→230, age8→350 — плотнее скелет
            : 700 + a * 290;   // витрина: возраст 4 → 1860, возраст 8 → 3020
    }

    /// <summary>
    /// ПОТОЛОК РОСТА — защита от взрывного ветвления, а не рабочий предел.
    ///
    /// Берётся одинаковым для обоих режимов и с запасом над тем, до чего дерево
    /// дорастает само: замер витрины дал 2440 узлов на дерево при возрасте 6.
    /// Если этот потолок будет достигнут, в логе появится пометка об упоре — и это
    /// уже дефект, потому что означает оборванный рост.
    /// </summary>
    private static int SoGrowthCeiling(int age)
    {
        // ---- V162: ПОТОЛОК ПОДНЯТ, ПОТОМУ ЧТО ПРЕЖНИЙ БЫЛ ВПРИТЫК ----
        //
        // Прежние 900 + возраст·420 я вывел из замера витрины: 2440 узлов на дерево
        // при возрасте 6. Ошибка была в источнике: витринное дерево ТОЖЕ обрывалось,
        // просто более щедрым потолком, и я снова оценил величину по данным, снятым
        // в ограниченном режиме.
        //
        // Замер V161, где рост наконец пошёл дальше: возраст 8 даёт 4169 узлов на
        // дерево при потолке 4260 — впритык, и семь деревьев из девяти всё равно
        // упёрлись. Новые числа с двукратным запасом: возраст 8 → 10 100.
        //
        // Это ЗАЩИТА ОТ ВЗРЫВНОГО ВЕТВЛЕНИЯ, а не рабочий предел. Если пометка об
        // упоре появится снова, значит рост действительно разошёлся, и разбираться
        // надо с параметрами ветвления, а не поднимать число дальше.
        int a = Math.Clamp(age, 0, 8);
        return 2500 + a * 950;   // возраст 6 → 8200, возраст 8 → 10 100
    }

    /// <summary>
    /// В компактном режиме тонкие ветви рисуются КРЕСТОМ из двух карточек (4 треугольника)
    /// вместо четырёхгранной трубки (8 треугольников). Приём и порог те же, что у ножки
    /// листа (AddPetiole): на толщине меньше этой доли высоты трубка на экране всё равно
    /// в один-два пикселя шириной, и грани не читаются.
    /// </summary>
    // ---- V133: ПОРОГ БЫЛ ВЫШЕ РАДИУСА СТВОЛА ----
    //
    // В V128 порог подняли с 0.012 до 0.030 доли высоты, чтобы удешевить древесину.
    // Замер, который надо было сделать тогда: у дуба высотой 7.6 радиус ствола 0.151,
    // а порог при 0.030 равен 0.228. То есть СТВОЛ проходил как «тонкая ветвь» и
    // рисовался плоским крестом из двух карточек — на скриншотах это гигантские
    // оранжевые доски вместо стволов, и так у всех четырёх пород.
    //
    // Порог теперь считается не от высоты дерева, а от РАДИУСА СТВОЛА: крестом
    // рисуется то, что тоньше пятой части ствола, — это заведомо мелкие веточки
    // последнего порядка, у которых грани трубки и правда не читаются.
    private const float CompactThinBranchOfTrunk = 0.20f;

    /// <summary>Радиус, выше которого сегмент рисуется восемью гранями с корой.
    /// В локальных единицах меша: у дерева высотой около 8 ствол имеет радиус 0.11–0.15,
    /// то есть под порог попадают ствол и первые суки, а их в скелете единицы.</summary>
    private const float BarkThickRadius = 0.055f;

    /// <summary>Радиус, выше которого сегмент рисуется шестью гранями и получает кору.</summary>
    private const float BarkMidRadius = 0.022f;

    /// <summary>
    /// АПИКАЛЬНЫЙ КОНТРОЛЬ λ для расширенной модели Борхерта-Хонды (§4.2 статьи):
    ///     vm = v·λQm / (λQm + (1-λ)Ql),   vl = v·(1-λ)Ql / (…)
    /// λ &gt; 0.5 отдаёт ресурс продолжению оси (excurrent, выраженный ствол),
    /// λ &lt; 0.5 — боковым ветвям (decurrent, раскидистая крона). В статье вся Fig. 7
    /// это λ от 0.46 до 0.54, то есть переключатель очень чувствительный.
    ///
    /// Снижаем λ с возрастом: молодое дерево — с лидером, старое — раскидистое.
    /// </summary>
    // Offline-harness: старт 0.56 давал узкую крону и top-heavy bands.
    // 0.50 с плоским спадом — больше боковых, crownRatio 0.55–0.85.
    private static float AgeLambda(int age) =>
        0.46f - 0.08f * Math.Clamp(age, 0, 8) / 8f;




    /// <summary>
    /// Счётчики самоорганизующегося роста — уходят в лог, чтобы эффект от теневой
    /// модели был виден числом, а не только на скриншоте. Копятся по всем деревьям
    /// уровня; сбрасываются перед расстановкой растительности.
    /// </summary>
    public static class SoStats
    {
        public static int TreesGenerated;
        public static long NodesBeforeShed;
        public static long NodesAfterShed;
        public static long BudsSuppressed;   // почки, не давшие побега из-за тени
        public static long BudsGrown;
        public static double LightSum;
        public static long LightSamples;

        /// <summary>Вид, который генерируется прямо сейчас, — чтобы разложить
        /// счётчики по видам. В витрине это главное, что нужно видеть: какой именно
        /// вид просел, а не общая цифра по всем шести сразу.</summary>
        public static VegetationKind CurrentKind;

        /// <summary>Узлов скелета по видам (после сброса) и число вершин меша.</summary>
        public static readonly Dictionary<VegetationKind, long> NodesByKind = new();
        public static readonly Dictionary<VegetationKind, long> VertsByKind = new();

        /// <summary>Геометрические метрики по видам — по ним и оценивается качество
        /// генерации в логе (см. PlantMetrics).</summary>
        /// <summary>
        /// Метрики по ПОРОДАМ, а не по типам. Раньше здесь была разбивка по
        /// VegetationKind, и метрики усреднялись по всем вариантам — а варианты теперь
        /// несут РАЗНЫЕ породы. Из-за этого различия пород в логе не были видны в
        /// принципе: вопрос «а различаются ли породы?» по нему нельзя было проверить.
        /// </summary>
        public static readonly Dictionary<string, List<PlantMetrics>> MetricsBySpecies = new();

        /// <summary>Сколько экземпляров каждого ВИДА сгенерировано — чтобы по логу
        /// было видно, что виды реально разные и все встречаются.</summary>
        public static readonly Dictionary<string, int> SpeciesCounts = new();

        /// <summary>Уровень качества, при котором собирались меши.</summary>
        public static int Quality;

        /// <summary>Возраст, при котором собирались меши.</summary>
        public static int Age;

        /// <summary>Фактические Steps / MaxMetamers, переданные в SO (для сверки
        /// с формулой в GenerateColonizedTree).</summary>
        public static int SoSteps;
        public static int SoMaxMetamers;
        /// <summary>Сколько деревьев упёрлось в MaxNodes (audit K-2).</summary>
        public static int NodeCapHit;

        /// <summary>Сколько узлов убрано прореживанием готового скелета (V161).</summary>
        public static int NodesPruned;

        /// <summary>Эффективное качество после clamp (qEff = Min(Quality, 4)).
        /// Нужно, чтобы по логу было видно: рост Quality выше 4 не даёт вклада.</summary>
        public static int QEff;

        /// <summary>Суммарное время генерации всех растений текущего прогона, мс.</summary>
        public static double TotalGenerationMs;

        /// <summary>Время генерации по породам (сумма по экземплярам), мс.</summary>
        public static readonly Dictionary<string, double> GenerationMsBySpecies = new();

        /// <summary>Фактический densMul листвы (лиственные) / масштаб плотности хвои
        /// (хвойные) по породам — чтобы видеть, как quality/age влияют на бюджет карт.</summary>
        public static readonly Dictionary<string, float> DensMulBySpecies = new();

        /// <summary>BaseSize Weber-Penn по породам (доля голого ствола).</summary>
        public static readonly Dictionary<string, float> BaseSizeBySpecies = new();

        /// <summary>Масштаб плотности точек крепления хвои (attachPoints/fascicles factor).</summary>
        public static readonly Dictionary<string, float> NeedleScaleBySpecies = new();

        public static void Reset()
        {
            TreesGenerated = 0; NodesBeforeShed = 0; NodesAfterShed = 0;
            BudsSuppressed = 0; BudsGrown = 0; LightSum = 0; LightSamples = 0;
            NodesByKind.Clear(); VertsByKind.Clear(); MetricsBySpecies.Clear();
            SpeciesCounts.Clear();
            GenerationMsBySpecies.Clear();
            DensMulBySpecies.Clear();
            BaseSizeBySpecies.Clear();
            NeedleScaleBySpecies.Clear();
            Quality = QualityLevel; Age = AgeLevel;
            SoSteps = 0; SoMaxMetamers = 0; NodeCapHit = 0; NodesPruned = 0;
            QEff = Math.Min(Math.Clamp(QualityLevel, 0, 12), 4);
            TotalGenerationMs = 0;
        }

        public static string ToJson()
        {
            double shedFrac = NodesBeforeShed > 0
                ? 1.0 - (double)NodesAfterShed / NodesBeforeShed : 0;
            double supprFrac = (BudsSuppressed + BudsGrown) > 0
                ? (double)BudsSuppressed / (BudsSuppressed + BudsGrown) : 0;
            double meanLight = LightSamples > 0 ? LightSum / LightSamples : 0;
            var c = System.Globalization.CultureInfo.InvariantCulture;
            return "{"
                + "\"treesGenerated\":" + TreesGenerated.ToString(c) + ","
                + "\"nodesBeforeShed\":" + NodesBeforeShed.ToString(c) + ","
                + "\"nodesAfterShed\":" + NodesAfterShed.ToString(c) + ","
                + "\"shedFraction\":" + shedFrac.ToString("R", c) + ","
                + "\"budsSuppressedFraction\":" + supprFrac.ToString("R", c) + ","
                + "\"meanBudLight\":" + meanLight.ToString("R", c) + ","
                + "\"quality\":" + Quality.ToString(c) + ","
                + "\"qEff\":" + QEff.ToString(c) + ","
                + "\"age\":" + Age.ToString(c) + ","
                + "\"totalGenerationMs\":" + TotalGenerationMs.ToString("F2", c) + ","
                + "\"soSteps\":" + SoSteps.ToString(c) + ","
                + "\"soMaxMetamers\":" + SoMaxMetamers.ToString(c) + ","
                + "\"nodeCapHit\":" + NodeCapHit.ToString(c) + ","
                + "\"nodesPruned\":" + NodesPruned.ToString(c) + ","
                + "\"nodesByKind\":" + DictToJson(NodesByKind) + ","
                + "\"meshVertsByKind\":" + DictToJson(VertsByKind) + ","
                + "\"speciesCounts\":" + SpeciesJson() + ","
                + "\"generationMsBySpecies\":" + DoubleDictToJson(GenerationMsBySpecies) + ","
                + "\"metricsBySpecies\":" + MetricsJson()
                + "}";
        }

        /// <summary>Средние геометрические метрики по каждому виду.</summary>
        private static string SpeciesJson()
        {
            var sb = new System.Text.StringBuilder("{");
            bool first = true;
            foreach (var kv in SpeciesCounts)
            {
                if (!first) sb.Append(',');
                first = false;
                sb.Append('"').Append(kv.Key).Append("\":").Append(kv.Value);
            }
            return sb.Append('}').ToString();
        }

        private static string MetricsJson()
        {
            var c = System.Globalization.CultureInfo.InvariantCulture;
            var sb = new System.Text.StringBuilder("{");
            bool first = true;
            foreach (var kv in MetricsBySpecies)
            {
                if (!first) sb.Append(',');
                first = false;
                // Базовые геометрические метрики + cost-параметры.
                string geo = PlantMetrics.Average(kv.Value).ToJson();
                // ToJson() возвращает {...}; вставляем доп. поля перед закрывающей }.
                var extra = new System.Text.StringBuilder();
                if (GenerationMsBySpecies.TryGetValue(kv.Key, out double ms))
                    extra.Append(",\"generationMs\":").Append(ms.ToString("F2", c));
                extra.Append(",\"qEff\":").Append(QEff.ToString(c));
                if (DensMulBySpecies.TryGetValue(kv.Key, out float dm))
                    extra.Append(",\"densMul\":").Append(dm.ToString("F3", c));
                if (BaseSizeBySpecies.TryGetValue(kv.Key, out float bs))
                    extra.Append(",\"baseSize\":").Append(bs.ToString("F3", c));
                if (NeedleScaleBySpecies.TryGetValue(kv.Key, out float ns))
                    extra.Append(",\"needleScale\":").Append(ns.ToString("F3", c));
                // geo ends with '}'; insert before it.
                sb.Append('"').Append(kv.Key).Append("\":")
                  .Append(geo.Substring(0, geo.Length - 1))
                  .Append(extra)
                  .Append('}');
            }
            return sb.Append('}').ToString();
        }

        private static string DictToJson(Dictionary<VegetationKind, long> d)
        {
            var sb = new System.Text.StringBuilder("{");
            bool first = true;
            foreach (var kv in d)
            {
                if (!first) sb.Append(',');
                first = false;
                sb.Append('"').Append(kv.Key).Append("\":").Append(kv.Value);
            }
            return sb.Append('}').ToString();
        }

        private static string DoubleDictToJson(Dictionary<string, double> d)
        {
            var c = System.Globalization.CultureInfo.InvariantCulture;
            var sb = new System.Text.StringBuilder("{");
            bool first = true;
            foreach (var kv in d)
            {
                if (!first) sb.Append(',');
                first = false;
                sb.Append('"').Append(kv.Key).Append("\":").Append(kv.Value.ToString("F2", c));
            }
            return sb.Append('}').ToString();
        }
    }


    // Коричневый ствол
    private const float TrR = 0.42f, TrG = 0.27f, TrB = 0.12f;
    // Зелёная листва (базовая, сезонная модуляция — снаружи)
    private const float FoR = 0.28f, FoG = 0.55f, FoB = 0.22f;
    private const float FoR2 = 0.35f, FoG2 = 0.62f, FoB2 = 0.18f; // светлее
    private const float FoDarkR = 0.18f, FoDarkG = 0.40f, FoDarkB = 0.15f;

    public static PlantMeshData Generate(VegetationKind kind, int variantSeed)
        => Generate(PlantGenome.Create(kind, variantSeed));

    public static PlantMeshData Generate(PlantGenome genome)
    {
        var rnd = new SeededRandom(genome.Seed ^ 0x51A17 ^ (QualityLevel * 9176));
        SoStats.CurrentKind = genome.Kind;
        string spName = $"{genome.Kind}:{PlantSpecies.Get(genome.Kind, genome.Species).Name}";
        SoStats.SpeciesCounts.TryGetValue(spName, out int spSoFar);
        SoStats.SpeciesCounts[spName] = spSoFar + 1;

        var sw = Stopwatch.StartNew();
        var built = GenerateInner(rnd, genome);
        sw.Stop();
        double ms = sw.Elapsed.TotalMilliseconds;
        SoStats.TotalGenerationMs += ms;
        SoStats.GenerationMsBySpecies.TryGetValue(spName, out double msSoFar);
        SoStats.GenerationMsBySpecies[spName] = msSoFar + ms;

        SoStats.VertsByKind.TryGetValue(genome.Kind, out long vsofar);
        SoStats.VertsByKind[genome.Kind] = vsofar + built.VertexCount;

        if (!SoStats.MetricsBySpecies.TryGetValue(spName, out var mlist))
        {
            mlist = new List<PlantMetrics>();
            SoStats.MetricsBySpecies[spName] = mlist;
        }
        mlist.Add(PlantMetrics.Compute(built));

        return built;
    }

    private static PlantMeshData GenerateInner(SeededRandom rnd, PlantGenome genome)
    {
        return genome.Kind switch
        {
            // ПРАВКА (откат по результатам исследования SeedThree docs/generation-design.md):
            // их же таблица выбора алгоритма прямо говорит "хвойные → Weber-Penn или L-система,
            // НЕ space colonization" — excurrent-форма и мутовчатый филлотаксис это явные
            // параметры уровня (nDownAngle/nRotate), а не то, что естественно возникает из
            // конкуренции за пространство. GenerateConiferSca (ниже) — оставлен как
            // эксперимент/референс, но по факту не вызывается.
            VegetationKind.Pine => GenerateConifer(rnd, genome, isFir: false),
            VegetationKind.Fir => GenerateConifer(rnd, genome, isFir: true),
            VegetationKind.Deciduous => GenerateColonizedTree(rnd, genome, bush: false),
            // ПРАВКА (п.8.3): Bush/Flower/Reed переведены на общий движок Л-систем
            // (PlantGenerator.LSystem.cs / PlantGenerator.SmallPlants.cs) — решение по
            // архитектуре было принято раньше (см. лог), это его реализация. Bush раньше
            // шёл через тот же SCA, что Deciduous (GenerateColonizedTree(bush:true), см.
            // ниже — функция никуда не делась, откат на неё — правка одной строки).
            // GenerateFlower/GenerateReed (были простыми процедурными циклами без
            // порождающих правил) оставлены ниже как GenerateFlowerLegacy/
            // GenerateReedLegacy — для численного A/B сравнения, не вызываются.
            VegetationKind.Bush => GenerateBushL(rnd, genome),
            VegetationKind.Flower => GenerateFlowerL(rnd, genome),
            VegetationKind.Reed => GenerateReedL(rnd, genome),
            // Покрытия — см. PlantGenerator.Cover.cs. Намеренно без Л-систем: у травинки
            // и камня нет ветвления, ради которого нужна деривация, а экземпляров десятки
            // тысяч, поэтому важна дешевизна одного меша.
            VegetationKind.GrassTuft => GenerateGrassTuft(rnd, genome),
            VegetationKind.Moss => GenerateMoss(rnd, genome),
            VegetationKind.Stone => GenerateStone(rnd, genome),
            _ => GenerateConifer(rnd, genome, isFir: false)
        };
    }

    // ------------------------------------------------------------------
    //  Хвойные: ствол + ярусы + плотные «тарелки» листвы
    // ------------------------------------------------------------------
    // =====================================================================
    // Weber–Penn conifer (ported from SeedThree src/core/weber-penn.js
    // + species presets pine.js / douglas-fir.js). No experimental tweaks.
    //
    // *** АКТИВНО ИСПОЛЬЗУЕТСЯ (см. Generate() выше). Был временно заменён
    // на GenerateConiferSca, откат — см. правку про docs/generation-design.md:
    // сам SeedThree рекомендует Weber-Penn для хвойных, не SCA. ***
    // =====================================================================

    private sealed class WpParams
    {
        public float Scale, ScaleV, Ratio, RatioPower, BaseSize, Flare, AttractionUp;
        public int Shape, Levels;
        public float[] Length = new float[4];
        public float[] LengthV = new float[4];
        public float[] Taper = new float[4];
        public int[] CurveRes = new int[4];
        public float[] Curve = new float[4];
        public float[] CurveBack = new float[4];
        public float[] CurveV = new float[4];
        public float[] DownAngle = new float[4];
        public float[] DownAngleV = new float[4];
        public float[] Rotate = new float[4];
        public float[] RotateV = new float[4];
        public int[] Branches = new int[4];
    }

    private struct WpQuat
    {
        public float X, Y, Z, W;
        public static WpQuat Identity => new() { X = 0, Y = 0, Z = 0, W = 1 };
        public static WpQuat FromAxisAngle(Vec3 axis, float rad)
        {
            float h = rad * 0.5f;
            float s = MathF.Sin(h);
            float c = MathF.Cos(h);
            axis = Norm(axis);
            return new WpQuat { X = axis.X * s, Y = axis.Y * s, Z = axis.Z * s, W = c };
        }
        public static WpQuat Mul(WpQuat a, WpQuat b) => new()
        {
            W = a.W * b.W - a.X * b.X - a.Y * b.Y - a.Z * b.Z,
            X = a.W * b.X + a.X * b.W + a.Y * b.Z - a.Z * b.Y,
            Y = a.W * b.Y - a.X * b.Z + a.Y * b.W + a.Z * b.X,
            Z = a.W * b.Z + a.X * b.Y - a.Y * b.X + a.Z * b.W
        };
        public static Vec3 Rotate(WpQuat q, Vec3 v)
        {
            // q * v * q^-1
            var qv = new WpQuat { X = v.X, Y = v.Y, Z = v.Z, W = 0 };
            var qi = new WpQuat { X = -q.X, Y = -q.Y, Z = -q.Z, W = q.W };
            var r = Mul(Mul(q, qv), qi);
            return new Vec3(r.X, r.Y, r.Z);
        }
    }

    private sealed class WpStem
    {
        public int Level;
        public List<Vec3> Points = new();
        public List<float> Radii = new();
        public float Length;
    }

    private static PlantMeshData GenerateConifer(SeededRandom rnd, PlantGenome g, bool isFir)
    {
        // Exact SeedThree presets (douglas-fir.js / pine.js), scale reduced for gallery.
        var p = isFir ? MakeDouglasFirParams(g) : MakePonderosaPineParams(g);
        int q = Math.Clamp(QualityLevel, 0, 12);

        // ЧИСТЫЙ СТВОЛ (самоочищение хвойных). Сознательное отступление от эталонных
        // пресетов: в них BaseSize = 0.12, и замер это подтверждал — boleClearance
        // выходил 0.038-0.118, то есть ветви шли почти от земли. Для взрослого
        // хвойного в лесу это нехарактерно: нижние ветви, оказавшись в тени, отмирают
        // и ствол оголяется. У лиственного дерева этим занимается механизм сброса из
        // статьи Палубицки, но хвойные строятся по Weber & Penn, где его нет.
        //
        // У Weber & Penn за безветвенную часть отвечает ровно один параметр —
        // BaseSize (доля длины ствола, на которой ветвей не бывает). Поэтому вместо
        // отдельного механизма сброса просто задаём ему разумный разброс: молодое
        // дерево ближе к эталонным 0.12, взрослое — к 0.4. Разброс берётся от генома,
        // поэтому в одном лесу стоят деревья разного возраста, а не одинаковые.
        // Возраст: у старого хвойного ствол очищен выше, дерево крупнее и гуще.
        // В статье Палубицки это следствие сброса затенённых нижних ветвей, здесь —
        // прямая зависимость, потому что Weber-Penn механизма сброса не имеет.
        // Диапазон был 0.62-1.17 по масштабу: даже при age 0 дерево выходило почти
        // взрослым (замер: Fir 8.56 при age 4 и 11.26 при age 8 — разница всего в
        // треть, а молодой ели на сцене вовсе не получалось). Расширен.
        // ВИД задаёт силуэт кроны через Shape (Weber-Penn) и пропорции. У обоих
        // хвойных раньше стояло Shape = 0 при любом сиде, из-за чего ель и сосна
        // отличались только мелочами. Теперь у каждого вида свой силуэт.
        var sp = PlantSpecies.Get(g.Kind, g.Species);
        p.Shape = sp.WpShape;
        p.Scale *= sp.HeightMul;
        // Толщина ствола — параметр Ratio (radius0 = length0 * Ratio). Замер показал
        // стройность около 20 у всех хвойных, тогда как у ели она порядка 50, а у
        // стелющейся горной сосны около 12 — то есть все выходили одинаково толстыми.
        p.Ratio = sp.TrunkRatio;

        float ageT = Math.Clamp(AgeLevel, 0, 8) / 8f;
        // v9: ageScale 0.50→1.15. age0 = саженец, age8 = зрелое (не гигант).
        // HeightMul вида + пост-нормализация (ниже) держат gallery 7–12 м.
        p.Scale *= 0.50f + ageT * 0.65f;                 // age 0 -> 0.50, age 8 -> 1.15
        // Густота кроны и угол отхождения — видовые (BranchMul / DownAngleShift).
        // v14: BranchMul cap 1.00 (было 1.15). age-scale L1 мягче (0.55 вместо 0.70).
        // Цель age8/qEff3–4: fir ~20–30k cards (замер v13: ель/пихта 58k, кедр 50k).
        // Видовая густота — через densMul хвои и CrownMul, не через взрыв L1.
        float branchMulCap = Math.Min(sp.BranchMul, 1.00f);
        p.Branches[1] = Math.Max(6, (int)(p.Branches[1] * (0.40f + ageT * 0.55f) * branchMulCap));
        p.Length[1] *= sp.CrownMul * CrownWidthScale(g.Kind);
        p.DownAngle[1] += sp.DownAngleShift;
        // v9 BaseSize — видовой + возрастной.
        // Сосна: высокий голый ствол (Weber-Penn / Pinus sylvestris).
        // Ель: молодая почти от земли, зрелая ~0.20.
        // Пихта: колонна, средний bole.
        // Тсуга: провисающие нижние ветви — bole ниже.
        // Кедр: широкий, bole средний.
        // Замер age0 ель bole=0.017 (куст) — пол поднят.
        // v10: ель/тсуга bole поднят — замер age0 ель=0.026, тсуга=0.015
        // (поникающие L1 уводят хвою ниже точки крепления; BaseSize должен
        // компенсировать провисание). Сосна без изменений.
        // ---- V95: ГОЛЫЙ СТВОЛ ПО ФОТОГРАФИЯМ ПОРОД ----
        //
        // На присланных снимках разница между породами гораздо резче, чем была здесь.
        // У ели и пихты крона идёт почти от земли и смыкается плотным конусом —
        // ствола снизу не видно вовсе. У сосны наоборот: чистая колонна на две трети
        // высоты и плоская крона наверху, это её узнаваемый силуэт.
        //
        // Прежние значения давали всем породам примерно одно: 0.12–0.18 плюс возраст,
        // то есть 30–40% голого ствола у зрелого дерева. Ель выходила похожей на
        // сосну, только пожиже, и ни одна не походила на себя.
        float boleBase = sp.Name switch
        {
            "сосна" => 0.42f,  // колонна: две трети высоты без ветвей
            "кедр"  => 0.22f,  // высокий, но крона длиннее сосновой
            "ель"   => 0.07f,  // крона почти от земли
            "пихта" => 0.06f,  // то же, колонновидная и очень плотная
            "тсуга" => 0.06f,  // нижние ветви провисают до земли
            _       => 0.12f
        };
        float boleAge = ageT * (sp.Name == "сосна" ? 0.22f : 0.10f);

        // ---- V156: ГОЛЫЙ СТВОЛ ЗАВИСИТ ОТ ЗАТЕНЁННОСТИ ----
        //
        // Замер по витрине (игровой меш, возраст 7): ель 88% высоты под кроной, пихта
        // 97%, тсуга 85%, кедр 71%, СОСНА 43%. Для сосны в густом древостое это
        // правдоподобно — она самоочищается, — но в кадре ВСЕ сосны выходили
        // одинаковыми свечками, тогда как на референсах у тропы они раскидистые, с
        // ветвями от середины ствола. Порода задаёт склонность к самоочищению, а
        // насколько оно случилось — решает тень соседей.
        //
        // Размах взят видовым: сосна теряет нижние ветви охотно (±0.16 вокруг
        // видового значения), ель и пихта почти не теряют (±0.05), иначе в чаще они
        // превратились бы в те же свечки и различие пород пропало бы.
        float boleSwing = sp.Name switch
        {
            "сосна" => 0.16f,
            "кедр"  => 0.10f,
            _       => 0.05f
        };
        // Crowding 0.5 — середина, то есть прежнее поведение: правка не смещает
        // среднее по лесу, а разводит края.
        float boleCrowd = (g.Crowding - 0.5f) * 2f * boleSwing;
        float boleTarget = boleBase + rnd.NextFloat(0f, 0.03f) + boleAge + boleCrowd;
        // Верхняя граница поднята: без неё сосна упиралась в 0.40 и теряла свой силуэт.
        p.BaseSize = Math.Clamp(boleTarget, 0.05f, 0.68f);
        // Cost-параметры в лог.
        string spKeyCon = $"{g.Kind}:{sp.Name}";
        SoStats.BaseSizeBySpecies[spKeyCon] = p.BaseSize;

        // v14 QUALITY: qEff≤3 для mid-high mobile (q>3 почти не даёт силуэта, только cards).
        // Игровой целевой qEff = 3; 4 оставляем как потолок для самых мощных устройств.
        int qEff = Math.Min(q, GameQEffMax); // V114
        SoStats.QEff = qEff;
        // v14: qMul и L2 ещё ниже — v13 age8/q4 fir=58k cards (цель 20–30k).
        float qMul = 0.55f + qEff * 0.05f; // q0→0.55, q3→0.70, q4→0.75
        p.Branches[1] = Math.Max(6, (int)(p.Branches[1] * qMul));

        // Потолки компактного режима: применяются ПОСЛЕ всех множителей, иначе
        // возраст и качество снова разгоняют геометрию.
        if (Detail == FoliageDetail.Compact)
        {
            p.Branches[1] = Math.Min(p.Branches[1], CompactMaxBranches);
            for (int lvl = 0; lvl < p.CurveRes.Length; lvl++)
                p.CurveRes[lvl] = Math.Min(p.CurveRes[lvl], CompactMaxCurveRes);
            // V120: до 3 уровней — объём кроны, не «блин» из L1
            if (p.Levels > 3) p.Levels = 3;
        }
        p.Branches[2] = Math.Max(2, (int)(p.Branches[2] * qMul * 0.50f));
        // ПРАВКА: убрал доп. урезание CurveRes по quality (было ×(0.6+q·0.035), на q:0 срезало
        // и без того невысокие curveRes источника ещё почти вдвое — до 3 сегментов на L1 у
        // Pine, при том что curve/curveV НЕ уменьшались пропорционально. Меньше сегментов на
        // тот же угол изгиба = каждый сегмент гнётся резче и рандомнее, чем в реальном
        // pine.js/douglas-fir.js — это и есть механическая причина "водорослей", а не выбор
        // алгоритма. CurveRes теперь берётся из пресета как есть (те же числа, что в
        // источнике); экономия полигонов на мобильном — через Branches[] выше, как и было.

        float trunkLen = p.Scale * g.HeightMul;
        // v9: gallery-нормализация высоты. Без неё пихта age8 = 17 м при дубе 9 м.
        // Целевая зрелая высота вида (м): ель~10, пихта~12, тсуга~7, сосна~10, кедр~11.
        float targetMature = sp.Name switch
        {
            "пихта" => 12.0f,
            "кедр"  => 11.0f,
            "ель"   => 10.0f,
            "сосна" => 10.0f,
            "тсуга" => 7.0f,
            _       => 10.0f
        };
        // age0 ≈ 35% зрелой, age8 = 100%.
        float targetH = targetMature * (0.35f + ageT * 0.65f);
        if (trunkLen > 0.01f)
            trunkLen *= targetH / trunkLen;
        float trunkRadius = trunkLen * p.Ratio;

        var stems = new List<WpStem>();
        var tips = new List<Vec3>();
        BuildWpStem(
            level: 0,
            origin: new Vec3(0, 0, 0),
            orient: WpQuat.Identity,
            length: trunkLen,
            radius: trunkRadius,
            p: p,
            rnd: rnd,
            stems: stems,
            tips: tips);

        var mesh = new PlantMeshData { LocalHeight = trunkLen };

        // Mesh stems — V111: кора по породе (референсы: сосна рыжее, ель серо-коричневая,
        // пихта темнее, кедр красноватый). Раньше один цвет 0.32/0.20/0.10 на всех.
        {
            var spBark = PlantSpecies.Get(g.Kind, g.Species);
            float bkR, bkG, bkB;
            switch (spBark.Name)
            {
                case "сосна": bkR = 0.55f; bkG = 0.32f; bkB = 0.18f; break;
                case "ель":   bkR = 0.28f; bkG = 0.24f; bkB = 0.18f; break;
                case "пихта": bkR = 0.22f; bkG = 0.20f; bkB = 0.16f; break;
                case "кедр":  bkR = 0.48f; bkG = 0.28f; bkB = 0.16f; break;
                case "тсуга": bkR = 0.34f; bkG = 0.26f; bkB = 0.16f; break;
                default:      bkR = 0.32f; bkG = 0.20f; bkB = 0.10f; break;
            }
            for (int s = 0; s < stems.Count; s++)
            {
                var st = stems[s];
                for (int i = 0; i < st.Points.Count - 1; i++)
                {
                    float r = (st.Radii[i] + st.Radii[i + 1]) * 0.5f;
                    AddBranch(mesh, st.Points[i], st.Points[i + 1], Math.Max(r, 0.008f), bkR, bkG, bkB);
                }
            }
        }

        // Needle sprays oriented along each branch (SeedThree-style clusters, geometric).
        // Fir: denser, shorter, cooler green. Pine: sparser, longer, warmer green.
        // Оттенок хвои — признак вида (пихта синеватая, сосна желтее и т.п.).
        var spNeedle = PlantSpecies.Get(g.Kind, g.Species);
        float needleR = (isFir ? 0.20f : 0.26f) * spNeedle.TintR;
        float needleG = (isFir ? 0.46f : 0.50f) * spNeedle.TintG;
        float needleB = (isFir ? 0.18f : 0.16f) * spNeedle.TintB;

        // ПРАВКА (реальная морфология вместо единой схемы на оба вида — по референсам
        // пользователя): раньше Pine и Fir использовали ПОЧТИ ОДИНАКОВУЮ раскладку
        // (один и тот же "пучок из N скрещённых карточек на каждой часовой позиции"),
        // отличаясь только числами. На деле это два разных паттерна:
        //   Fir (Дугласова пихта) — ОДИНОЧНЫЕ короткие иглы, крепятся по отдельности,
        //     но густо и почти по всей окружности побега — сплошной "ёршик"/bottlebrush
        //     без больших просветов голой ветки.
        //   Pine (сосна) — настоящие ПУЧКИ (фасцикулы) по неск. длинных, почти
        //     параллельных игл из ОДНОЙ точки на побеге, с заметными промежутками
        //     голой ветки МЕЖДУ пучками — редкий, а не сплошной силуэт.
        // ПРАВКА (постоянная длина иглы): раньше длина иглы/фасцикулы считалась от длины
        // ЛОКАЛЬНОГО СЕГМЕНТА ВЕТКИ (segLen), который сильно различается между толстыми
        // нижними ветвями и тонкими веточками у верхушки. У толстых сегментов клэмп-потолок
        // почти всегда срабатывал (игла = фиксированный потолок), у тонких — не срабатывал
        // (игла честно пропорциональна и получалась заметно короче) — отсюда разнобой длин
        // по одному дереву. В реальности длина иглы у хвойных примерно ПОСТОЯННА по всему
        // дереву и не зависит от толщины ветки, на которой она растёт. Теперь длина — доля
        // от trunkLen (размер дерева целиком), одна и та же для всех веток дерева.
        float baseNeedleLen = (isFir ? trunkLen * 0.027f : trunkLen * 0.044f)
            * (0.85f + g.FoliageDensity * 0.3f) * spNeedle.LeafSize
            // Хвоя молодого дерева короче: она растёт вместе с деревом.
            * (0.60f + ageT * 0.50f);

        for (int s = 0; s < stems.Count; s++)
        {
            var st = stems[s];
            if (st.Level < 1 || st.Points.Count < 2) continue;

            int segs = st.Points.Count - 1;

            for (int i = 0; i < segs; i++)
            {
                var a = st.Points[i];
                var b = st.Points[i + 1];
                var dir = Norm(Sub(b, a));
                float segLen = Len(Sub(b, a));
                if (segLen < 1e-4f) continue;
                float rad = st.Radii.Count > i ? st.Radii[i] : 0.01f;

                // v9: L1 у ствола — startT 0.28 (было 0.15). Иначе хвоя
                // визуально «сидит на стволе», как листья у лиственных до v8.
                float startT = (st.Level == 1 && i == 0) ? 0.32f : 0.05f;

                // ПЛОТНОСТЬ ХВОИ ПРОПОРЦИОНАЛЬНА ДЛИНЕ СЕГМЕНТА.
                //
                // Раньше число точек крепления задавалось на сегмент и от его длины не
                // зависело. Пока все ветви были одной длины, это не мешало. Но у пород
                // с широкой кроной множитель CrownMul удлиняет ветви первого порядка
                // (у тсуги 1.15, у горной сосны 1.45), а хвои на них остаётся столько
                // же — она расползается, и ветвь читается как голая палка. Это и был
                // артефакт «длинные ветки» у пород 3 и 6.
                //
                // Опорная длина — 6% высоты дерева: примерно столько составляет сегмент
                // у породы со средней кроной, поэтому для неё множитель равен единице и
                // прежнее поведение сохраняется.
                // v10: lenScale max 1.6 (было 2.5) — длинные L1 у кедра/тсуги не взрывают cards.
                float lenScale = Math.Clamp(segLen / MathF.Max(trunkLen * 0.06f, 1e-4f), 0.55f, 1.6f);
                var up0 = MathF.Abs(dir.Y) < 0.9f ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
                var side0 = Norm(Cross(dir, up0));
                var outv0 = Norm(Cross(side0, dir));

                // ---- V82: КОМПАКТНАЯ ХВОЯ ДЛЯ УРОВНЯ ----
                //
                // Замер показал, что одна ель — 40 504 треугольника, а бюджет кадра при
                // 60 fps на среднем Android — 400k на ВСЮ сцену. Даже при идеально
                // работающем LOD 297 деревьев ближней полосы давали 11.9 млн.
                //
                // Прежняя схема моделировала хвою отдельными пучками: на каждом
                // сегменте ветви несколько точек крепления, на каждой — «пёрышко» из
                // пар игл, каждая игла — крестовина из 4 треугольников. Это правильно
                // для витрины, где дерево одно и его разглядывают вплотную, и
                // безнадёжно для леса из 16 тысяч экземпляров.
                //
                // В компактном режиме на сегмент приходится ОДНА крупная карточка-лапа:
                // 4 треугольника вместо нескольких сотен. Витрина остаётся на подробном
                // режиме — она инструмент отладки и в бюджет уровня не входит.
                if (Detail == FoliageDetail.Compact)
                {
                    // ПРАВКА: было ОДНА лапа на сегмент. Вблизи ветвь читалась как голая
                    // палка с одним флажком — на скриншоте это и видно. Лап стало три,
                    // разнесённых вдоль сегмента и по азимуту вокруг него: 12 треугольников
                    // на сегмент вместо 4. У хвойного 60 сегментов, то есть 720
                    // треугольников листвы вместо 240 — при бюджете около 1500 на
                    // экземпляр это проходит, а ветвь перестаёт быть пустой.
                    // V94: лап на сегмент шесть вместо трёх — хвойная крона в
                    // референсах непрозрачна, сквозь неё не видно неба.
                    // ---- V128: ТОТ ЖЕ СИЛУЭТ ВЧЕТВЕРО ДЕШЕВЛЕ ----
                    //
                    // Замер разложил стоимость: у хвойного 14 344 треугольника из
                    // 17 192 — это ЛИСТВА, древесина всего 2 848. Резать надо её, но
                    // силуэт держится не числом карточек, а ПЛОЩАДЬЮ, которую они
                    // закрывают. Значит карточек вчетверо меньше, а каждая вдвое
                    // больше по стороне: покрытие то же, цена вчетверо ниже.
                    //
                    // Полный меш работает только ближе 4.5 единиц (45 м); на этой
                    // дистанции лапа занимает считаные точки экрана, и разница между
                    // десятью мелкими и тремя крупными не читается.
                    // ---- V154: ЛАП МЕНЬШЕ, ПОТОМУ ЧТО ЯЧЕЙКА СТАЛА ПЛОТНЕЕ ----
                    //
                    // Шестнадцать лап набирались, пока ячейка ClusterConifer была
                    // непрозрачна на 20%: сквозь крону просвечивало небо, и число
                    // карточек компенсировало рыхлость рисунка. После V151 ячейка даёт
                    // 37% при толщине детали 18 точек вместо 4, и те же шестнадцать
                    // лап дали заполненность кроны 83-87%.
                    //
                    // Замер по шаблону витрины показал, что это перебор: крона сосны
                    // стала ОДНИМ замкнутым пятном без единого просвета — на дереве
                    // повторился тот же дефект, что был у ячейки. На четыре хвойных
                    // дерева в кадре приходилось 12-17 областей, то есть полторы на
                    // дерево: контур кроны и контур ствола.
                    //
                    // Лиственные при заполненности 56-74% дают внутри кроны структуру
                    // из перекрывающихся клубов — и на раскраске читаются заметно
                    // лучше. Значит цель для хвойных та же полоса 60-70%, а не 85%.
                    // Девять лап вместо шестнадцати возвращают просветы между слоями
                    // и заодно около 400 треугольников на дерево.
                    // ---- V163: ЛАП НА СЕГМЕНТ — С ПОПРАВКОЙ НА ГУСТОТУ ВЕТВЛЕНИЯ ----
                    //
                    // Константа была общей на все хвойные, а ветвей у пород разное
                    // число: BranchMul у сосны 0.75, у кедра 1.08. Значит на ту же
                    // крону кедр получает в 1.44 раза больше сегментов, а с ними и лап.
                    // Замер это и показал: сосна 70% заполненности, кедр 82% и пометка
                    // «МОНОЛИТ», хотя ячейка и число лап у них одни и те же.
                    //
                    // Поправка обратная: гуще ветвление — меньше лап на сегмент, чтобы
                    // плотность кроны определялась силуэтом вида, а не побочно числом
                    // его ветвей. Нормируется на сосну, для которой число подбиралось.
                    int compactSprays = Math.Max(4, (int)MathF.Round(
                        CompactSpraysPerSegment * (0.75f / MathF.Max(sp.BranchMul, 0.4f))));
                    for (int sprayIdx = 0; sprayIdx < compactSprays; sprayIdx++)
                    {
                        float sprayLen = baseNeedleLen * CompactSprayLength
                                         * (0.80f + 0.20f * ((sprayIdx + 1) % 2));
                        float tPos = (sprayIdx + 0.5f) / compactSprays + rnd.NextFloat(-0.08f, 0.08f);
                        var mid = Lerp(a, b, Math.Clamp(tPos, 0.05f, 0.95f));
                        // Лапа ориентирована ПОПЕРЁК ветви и слегка провисает — так силуэт
                        // читается как хвойная лапа, а не как флажок на палке. Азимут
                        // разнесён золотым углом, иначе три лапы легли бы в одну плоскость.
                        float ang = sprayIdx * GoldenAngleRad + rnd.NextFloat(-0.2f, 0.2f);
                        var radial = Add(Mul(side0, MathF.Cos(ang)), Mul(outv0, MathF.Sin(ang)));
                        var sprayDir = Norm(Add(radial, new Vec3(0, -0.35f, 0)));
                        var tip = Add(mid, Mul(sprayDir, sprayLen));
                        AddNeedle(mesh, mid, tip, segLen * CompactSprayWidth,
                            needleR + rnd.NextFloat(-0.03f, 0.03f),
                            needleG + rnd.NextFloat(-0.04f, 0.04f),
                            needleB + rnd.NextFloat(-0.02f, 0.02f),
                            FoliageAtlas.ClusterConifer);
                    }
                }
                else if (isFir)
                {
                    // ПРАВКА (frond вместо веера из точки, см. AddNeedleFrond): реже точек
                    // крепления, чем раньше (каждая теперь несёт целую веточку-пёрышко с
                    // несколькими иглами, а не одну спицу) — иначе геометрия разрослась бы
                    // без пользы для картинки.
                    // ПРАВКА (лысые хвойные): было (2 + q / 8) при ЦЕЛОМ q — деление
                    // целочисленное, поэтому q/8 == 0 на всём диапазоне quality 0..7, а
                    // q/9 == 0 на 0..8. Плотность хвои была ЗАКОЛОЧЕНА на минимуме
                    // (2 точки × 2 слота) для всех quality, которые реально используются.
                    // При этом число веток росло (qMul = 0.65 + q·0.04), то есть веток
                    // становилось больше, а хвои на каждой столько же — дерево выглядело
                    // тем голее, чем выше quality. Теперь множитель дробный и растёт
                    // плавно с первого же уровня.
                    // v14: dens ×~0.65 от v13 (0.85+q*0.18 → 0.55+q*0.12).
                    // radialSlots фиксировано 2 (гребень L/R) — больше не растёт с q.
                    // pairCount=2 всегда (убран бонус q≥6).
                    float needleScaleFir = (0.55f + Math.Min(q, GameQEffMax) * 0.12f) * Math.Max(0.50f, g.FoliageDensity);
                    SoStats.NeedleScaleBySpecies[spKeyCon] = needleScaleFir;
                    SoStats.DensMulBySpecies[spKeyCon] = needleScaleFir;
                    int attachPoints = Math.Max(2, (int)(needleScaleFir * lenScale));
                    for (int c = 0; c < attachPoints; c++)
                    {
                        float t = startT + (1f - startT) * ((c + 0.5f) / attachPoints);
                        t += rnd.NextFloat(-0.03f, 0.03f);
                        t = Math.Clamp(t, 0.02f, 0.98f);
                        var pos = Lerp(a, b, t);

                        // Гребень: ровно 2 слота (лево/право). Больше слотов на mobile
                        // почти не читается, а cards растут линейно.
                        const int radialSlots = 2;
                        for (int k = 0; k < radialSlots; k++)
                        {
                            // ПРАВКА (гребень по бокам вместо равномерного кольца): по
                            // референсу — на горизонтальной ветке иглы Fir лежат в ОДНОЙ
                            // ПЛОСКОСТИ по обе стороны побега ("гребень"/"расчёска"), а верх
                            // побега почти голый. Раньше ang был равномерен по всем 2π —
                            // иглы торчали и сверху, и снизу, и с боков одинаково часто, что
                            // и читалось как "колючий хаос" вблизи, а не как гребень. В базисе
                            // (side0, outv0): ang=0 и ang=π — это ЛЕВЫЙ/ПРАВЫЙ бок ветки,
                            // ang=π/2 — верх. Концентрируем вокруг боков, избегая верха.
                            float lateralSide = (k % 2 == 0) ? 0f : MathF.PI;
                            float ang = lateralSide + rnd.NextFloat(-1.0f, 1.0f);
                            var radial = Add(Mul(side0, MathF.Cos(ang)), Mul(outv0, MathF.Sin(ang)));
                            radial = Norm(Add(radial, new Vec3(0, -0.12f, 0))); // лёгкий подъём/изгиб

                            var basePos = Add(pos, Mul(radial, rad * 1.05f));
                            if (basePos.Y < 0.02f) basePos = new Vec3(basePos.X, 0.02f, basePos.Z);

                            float rC = needleR + rnd.NextFloat(-0.03f, 0.03f);
                            float gC = needleG + rnd.NextFloat(-0.04f, 0.04f);
                            float bC = needleB + rnd.NextFloat(-0.02f, 0.02f);

                            float needleLen = baseNeedleLen * rnd.NextFloat(0.85f, 1.15f);
                            const int pairCount = 2;
                            AddNeedleFrond(mesh, basePos, radial, needleLen * 1.1f, pairCount,
                                needleLen, rnd, rC, gC, bC);
                        }
                    }
                }
                else
                {
                    // Заметно РЕЖЕ вдоль сегмента (видна голая ветка между пучками), каждая
                    // точка — фасцикула из неск. длинных почти параллельных игл из одной базы.
                    // Пучок из одной точки — здесь правильная ботаника (настоящая фасцикула),
                    // в отличие от Fir выше, поэтому остаётся на AddNeedleTuft.
                    // ПРАВКА (реже, видны просветы): по референсу пучки сидят на побеге
                    // "довольно редко, поверхность ветви не кажется сплошь покрытой" — было
                    // слишком плотно, из-за чего соседние фасцикулы перекрещивались в кашу.
                    // Та же беда с целочисленным делением, что и у Fir выше: q / 6 давало
                    // 0 на quality 0..5 и q / 8 — на 0..7, то есть фасцикулы не густели
                    // вовсе. Множители дробные.
                    // v14: dens ×~0.70 от v13. fascicleSlots ≤ 2 (не растёт с q).
                    float needleScalePine = (0.75f + Math.Min(q, GameQEffMax) * 0.12f) * Math.Max(0.50f, g.FoliageDensity);
                    SoStats.NeedleScaleBySpecies[spKeyCon] = needleScalePine;
                    SoStats.DensMulBySpecies[spKeyCon] = needleScalePine;
                    int fascicles = Math.Max(2, (int)(needleScalePine * lenScale));
                    for (int c = 0; c < fascicles; c++)
                    {
                        float t = startT + (1f - startT) * ((c + 0.5f) / fascicles);
                        t += rnd.NextFloat(-0.05f, 0.05f);
                        t = Math.Clamp(t, 0.02f, 0.98f);
                        var pos = Lerp(a, b, t);

                        int fascicleSlots = Math.Max(2, Math.Min(2, (int)(1.00f + Math.Min(q, GameQEffMax) * 0.08f)));
                        for (int k = 0; k < fascicleSlots; k++)
                        {
                            float ang = rnd.NextFloat(0f, MathF.PI * 2f); // случайный азимут — не строгий круг
                            var radial = Add(Mul(side0, MathF.Cos(ang)), Mul(outv0, MathF.Sin(ang)));
                            radial = Norm(Add(radial, new Vec3(0, -0.20f, 0)));

                            var basePos = Add(pos, Mul(radial, rad * 1.05f));
                            if (basePos.Y < 0.02f) basePos = new Vec3(basePos.X, 0.02f, basePos.Z);

                            float rC = needleR + rnd.NextFloat(-0.03f, 0.03f);
                            float gC = needleG + rnd.NextFloat(-0.04f, 0.04f);
                            float bC = needleB + rnd.NextFloat(-0.02f, 0.02f);

                            float fascicleLen = baseNeedleLen * rnd.NextFloat(0.85f, 1.15f);
                            // Ponderosa Pine — характерный 3-игольный пучок; узкий конус
                            // (0.02-0.09 рад) держит иглы почти параллельными, как в пучке.
                            const int needlesPerFascicle = 3;
                            AddNeedleTuft(mesh, basePos, radial, fascicleLen * 0.02f, fascicleLen,
                                0.02f, 0.09f, needlesPerFascicle, rnd, rC, gC, bC);
                        }
                    }
                }
            }
        }

        // terminal buds
        for (int i = 0; i < tips.Count; i++)
        {
            var tip = tips[i];
            if (tip.Y < 0.05f) continue;
            float sz = isFir ? 0.06f : 0.08f;
            AddNeedle(mesh, tip, new Vec3(tip.X, tip.Y + sz, tip.Z), sz * 0.3f,
                needleR, needleG, needleB);
        }

        return mesh;
    }

    // SeedThree douglas-fir.js params (scale reduced for gallery size)
    private static WpParams MakeDouglasFirParams(PlantGenome g)
    {
        // ПРАВКА: значения теперь скопированы 1:1 из настоящего src/species/douglas-fir.js
        // (клонировал репозиторий, сверил построчно — раньше это было "по памяти"
        // приближение, местами заметно разошедшееся, особенно CurveRes). Scale оставлен
        // уменьшенным для галереи — это не влияет на пропорции, т.к. LocalHeight потом
        // нормализуется под целевую высоту в LevelView3D (проверено).
        return new WpParams
        {
            Scale = 9.0f, ScaleV = 0.5f, Levels = 3,
            Ratio = 0.02f, RatioPower = 1.4f,
            BaseSize = 0.12f, Shape = 0, Flare = 0.5f, AttractionUp = 0.0f,
            Length    = new[] { 1.0f, 0.34f, 0.34f, 0.28f },
            LengthV   = new[] { 0.0f, 0.08f, 0.1f, 0.1f },
            Taper     = new[] { 1.0f, 1.0f, 1.0f, 1.0f },
            CurveRes  = new[] { 14, 6, 4, 3 },
            Curve     = new[] { 2f, 16f, 22f, 0f },
            CurveBack = new[] { 0f, 0f, 0f, 0f },
            // ПРАВКА (прямизна): CurveV — это СЛУЧАЙНЫЙ разброс изгиба, отдельно от
            // систематического Curve. На уровне 1 он был 18°, сопоставим с самим
            // Curve (16-22°), из-за чего главные ветви шли волной, а у хвойных они
            // почти прямые: ветвь отходит от ствола и идёт ровно, лишь плавно
            // провисая или приподнимаясь целиком. Систематический Curve оставлен без
            // изменений (это и есть провисание), урезан только разброс.
            CurveV    = new[] { 3f, 7f, 14f, 24f },
            DownAngle = new[] { 0f, 84f, 82f, 78f },
            DownAngleV= new[] { 0f, 10f, 12f, 12f },
            Rotate    = new[] { 0f, 137f, 137f, 137f },
            RotateV   = new[] { 0f, 22f, 22f, 22f },
            Branches  = new[] { 0, 52, 18, 0 },
        };
    }

    // SeedThree pine.js (Ponderosa) params
    private static WpParams MakePonderosaPineParams(PlantGenome g)
    {
        // ПРАВКА: то же самое — значения 1:1 из настоящего src/species/pine.js.
        return new WpParams
        {
            Scale = 7.6f, ScaleV = 0.8f, Levels = 3,
            Ratio = 0.02f, RatioPower = 1.4f,
            BaseSize = 0.12f, Shape = 0, Flare = 0.5f, AttractionUp = 0.0f,
            Length    = new[] { 1.0f, 0.34f, 0.34f, 0.28f },
            LengthV   = new[] { 0.0f, 0.08f, 0.1f, 0.1f },
            Taper     = new[] { 1.0f, 1.0f, 1.0f, 1.0f },
            CurveRes  = new[] { 14, 6, 4, 3 },
            // ---- V160: СТВОЛ СОСНЫ НЕ ЛИНЕЙКА ----
            //
            // Curve[0] = 2° давал идеально прямую колонну одинаковой толщины: на
            // шаблоне это две параллельные линии на половину кадра, самая длинная и
            // самая бессмысленная форма листа. У живой сосны ствол заметно изгибается
            // и сбегает к вершине. Систематический изгиб поднят до 7°, случайный
            // разброс по стволу — с 3° до 9°: тогда деревья одного вида перестают
            // быть копиями друг друга, а это на раскраске важнее точности изгиба.
            Curve     = new[] { 7f, 12f, 16f, 0f },
            CurveBack = new[] { 0f, 0f, 0f, 0f },
            // ПРАВКА (прямизна): CurveV — это СЛУЧАЙНЫЙ разброс изгиба, отдельно от
            // систематического Curve. На уровне 1 он был 18°, сопоставим с самим
            // Curve (16-22°), из-за чего главные ветви шли волной, а у хвойных они
            // почти прямые: ветвь отходит от ствола и идёт ровно, лишь плавно
            // провисая или приподнимаясь целиком. Систематический Curve оставлен без
            // изменений (это и есть провисание), урезан только разброс.
            CurveV    = new[] { 9f, 7f, 14f, 24f },
            DownAngle = new[] { 0f, 82f, 80f, 74f },
            DownAngleV= new[] { 0f, 10f, 12f, 12f },
            Rotate    = new[] { 0f, 137f, 137f, 137f },
            RotateV   = new[] { 0f, 22f, 22f, 22f },
            Branches  = new[] { 0, 46, 16, 0 },
        };
    }

    // Exact SeedThree shapeRatio
    private static float WpShapeRatio(int shape, float ratio)
    {
        float r = Math.Clamp(ratio, 0f, 1f);
        return shape switch
        {
            0 => 0.2f + 0.8f * r,                                          // conical
            1 => 0.2f + 0.8f * MathF.Sin(MathF.PI * r),                    // spherical
            2 => 0.2f + 0.8f * MathF.Sin(0.5f * MathF.PI * r),             // hemispherical
            3 => 1.0f,                                                       // cylindrical
            4 => 0.5f + 0.5f * r,                                          // tapered cylindrical
            5 => r <= 0.7f ? r / 0.7f : (1f - r) / 0.3f,                   // flame
            6 => 1.0f - 0.8f * r,                                          // inverse conical
            7 => r <= 0.7f ? 0.5f + 0.5f * r / 0.7f : 0.5f + 0.5f * (1f - r) / 0.3f,
            _ => 1.0f
        };
    }

    private static float WpVary(SeededRandom rnd, float baseVal, float variance)
        => baseVal + rnd.NextFloat(-variance, variance);

    private static void BuildWpStem(
        int level, Vec3 origin, WpQuat orient, float length, float radius,
        WpParams p, SeededRandom rnd, List<WpStem> stems, List<Vec3> tips)
    {
        int curveRes = Math.Max(2, p.CurveRes[level]);
        float segLen = length / curveRes;
        float uTaper = p.Taper[level] < 1f ? p.Taper[level] : (p.Taper[level] < 2f ? 2f - p.Taper[level] : 0f);

        float curve = p.Curve[level];
        float curveBack = p.CurveBack[level];
        float curveV = p.CurveV[level];

        var points = new List<Vec3>(curveRes + 1) { origin };
        var radii = new List<float>(curveRes + 1) { radius };
        var orients = new List<WpQuat>(curveRes + 1) { orient };

        var o = orient;
        var pos = origin;
        var axisX = new Vec3(1, 0, 0);
        var axisY = new Vec3(0, 1, 0);

        for (int i = 1; i <= curveRes; i++)
        {
            float segCurve;
            if (curveBack == 0f) segCurve = curve / curveRes;
            else segCurve = (i <= curveRes / 2 ? curve : curveBack) / (curveRes / 2f);
            segCurve += WpVary(rnd, 0f, curveV / curveRes);
            o = WpQuat.Mul(o, WpQuat.FromAxisAngle(axisX, segCurve * MathF.PI / 180f));

            // AttractionUp tropism (0 for both pine and fir presets)
            if (level >= 2 && p.AttractionUp != 0f)
            {
                var fwd = WpQuat.Rotate(o, axisY);
                var target = new Vec3(0, 1, 0);
                var axis = Cross(fwd, target);
                if (Len(axis) > 1e-6f)
                {
                    axis = Norm(axis);
                    float decl = MathF.Acos(Math.Clamp(fwd.Y, -1f, 1f)); // fwd·UP
                    o = WpQuat.Mul(WpQuat.FromAxisAngle(axis, MathF.Abs(p.AttractionUp) * decl / curveRes), o);
                }
            }

            var step = WpQuat.Rotate(o, axisY);
            step = Norm(step);
            pos = Add(pos, Mul(step, segLen));

            float z = i / (float)curveRes;
            float r = radius * (1f - uTaper * z);
            if (level == p.Levels - 1 && p.Taper[level] >= 0.99f)
                r = radius * (1f - z);
            r = Math.Max(r, 0.002f);

            points.Add(pos);
            radii.Add(r);
            orients.Add(o);
        }

        // Base flare on trunk
        if (level == 0 && p.Flare > 0f)
        {
            for (int i = 0; i < points.Count; i++)
            {
                float z = i / (float)(points.Count - 1);
                if (z < 0.15f)
                    radii[i] *= 1f + p.Flare * (1f - z / 0.15f);
            }
        }

        var stem = new WpStem { Level = level, Points = points, Radii = radii, Length = length };
        stems.Add(stem);

        if (level == p.Levels - 1)
            tips.Add(points[points.Count - 1]);

        int childLevel = level + 1;
        if (childLevel >= p.Levels) return;

        int nChildren = p.Branches[childLevel];
        if (level > 0) nChildren = Math.Max(1, (int)(nChildren * 0.6f));
        if (nChildren <= 0) return;

        float offsetStart = level == 0 ? p.BaseSize : 0.1f;
        float azimuth = rnd.NextFloat(0f, 360f);

        for (int c = 0; c < nChildren; c++)
        {
            // РАСПРЕДЕЛЕНИЕ ВЕТВЕЙ ВДОЛЬ РОДИТЕЛЯ — НЕПРЕРЫВНОЕ, как в модели
            // Weber & Penn: offset ветви равномерно растёт по длине родителя.
            //
            // ИСТОРИЯ. Здесь была квантизация по «мутовкам»: для level == 0 высоты
            // крепления сгонялись в несколько колец с равным шагом. Она давала
            // характерный рисунок «кольцо веток — голый ствол — кольцо», который
            // выглядел искусственно. В самих материалах опоры для неё нет: Weber &
            // Penn строят чёрную ель и три вида сосны (Plate 2) непрерывным
            // распределением, а слово whorl не встречается ни в одной из пяти работ.
            // Метрика тоже её показывала: у Pine пояса листвы шли
            // [0.027, 0.313, 0.295, 0.072, 0.294] — провал на фоне соседей.
            // Мутовки убраны целиком, распределение снова непрерывное.
            //
            // Небольшой разброс по высоте оставлен: без него ветви садятся строго
            // через равные промежутки, что тоже читается как «по линейке».
            float frac = offsetStart + (1f - offsetStart) * ((c + 0.5f) / nChildren);
            frac = Math.Clamp(frac + WpVary(rnd, 0f, 0.02f), offsetStart, 1f);
            float seg = frac * curveRes;
            int si = Math.Min(curveRes - 1, (int)MathF.Floor(seg));
            float st = seg - si;

            var cpos = Lerp(points[si], points[si + 1], st);
            // slerp orientations approximately via lerp of rotated vectors is hard;
            // use orientation at si (good enough for skeleton)
            var cor = orients[si];
            float pradiusHere = radii[si] * (1f - st) + radii[si + 1] * st;

            float down = p.DownAngle[childLevel] + WpVary(rnd, 0f, p.DownAngleV[childLevel]);
            azimuth += p.Rotate[childLevel] + WpVary(rnd, 0f, p.RotateV[childLevel]);

            var cOrient = cor;
            cOrient = WpQuat.Mul(cOrient, WpQuat.FromAxisAngle(axisY, azimuth * MathF.PI / 180f));
            cOrient = WpQuat.Mul(cOrient, WpQuat.FromAxisAngle(axisX, down * MathF.PI / 180f));

            float lenFactor = p.Length[childLevel] + WpVary(rnd, 0f, p.LengthV[childLevel]);
            float shapeFrac = level == 0
                ? WpShapeRatio(p.Shape, 1f - (frac - offsetStart) / Math.Max(1e-4f, 1f - offsetStart))
                : 1f;
            float childLen = Math.Max(0.05f, length * lenFactor * shapeFrac);

            float pipeRadius = radius * MathF.Pow(childLen / Math.Max(length, 1e-4f), p.RatioPower);
            float childRadius = Math.Min(pipeRadius, pradiusHere * 0.9f);

            BuildWpStem(childLevel, cpos, cOrient, childLen, childRadius, p, rnd, stems, tips);
        }
    }

    private static PlantMeshData GenerateColonizedTree(
        SeededRandom rnd, PlantGenome g, bool bush)
    {
        int q = Math.Clamp(QualityLevel, 0, 12);
        // ПРАВКА: лиственное было 3.2 против 6.2 у хвойного SCA и 7.6-9.0 у
        // Weber-Penn — вдвое ниже. По замеру: Deciduous height 3.1-3.5, Pine 8.0,
        // Fir 9.5. На фоне таких соседей лиственное читалось как подрост, а не
        // как взрослое дерево, что усиливало впечатление «куста на палочке».
        // ВОЗРАСТ ЗАДАЁТ РАЗМЕР. Раньше высота была фиксированной, и «увеличение
        // возраста» не приводило к росту дерева вовсе — возраст влиял только на число
        // шагов и λ. Молодое дерево должно быть НИЖЕ и уже, старое — выше и шире.
        float ageF = Math.Clamp(AgeLevel, 0, 8) / 8f;
        // v7: пол ageScale 0.50 — age0 уже саженец, не «прутик». age8 → 1.30.
        // На уровне ставить AgeLevel ≥ 3: ниже визуально почти одинаковые палки.
        float ageScale = 0.50f + ageF * 0.80f;   // age 0 -> 0.50, age 8 -> 1.30
        float height = (bush ? 1.4f : 6.0f) * g.HeightMul * ageScale
                       * PlantSpecies.Get(g.Kind, g.Species).HeightMul;
        // Крона у молодого дерева относительно узкая (excurrent), у старого шире
        // (decurrent) — тот же переход, что задаёт λ, только в силуэте.
        // ВИД задаёт ширину кроны и смещение апикального контроля: дуб раскидистый,
        // берёза узкая с выраженной осью, клён посередине.
        var species = PlantSpecies.Get(g.Kind, g.Species);
        float crownR = height * (bush ? 0.70f : (0.36f + ageF * 0.20f))
                       * g.CrownMul * species.CrownMul * CrownWidthScale(g.Kind);
        // ДЛИНА СТВОЛА. Прежние 0.16-0.24 высоты давали крону, начинающуюся почти от
        // земли, — по замеру boleClearance выходил 0.19-0.25, и дерево читалось как
        // кустарник на ножке. У дерева ствол до первых крупных сучьев — заметная доля
        // высоты; в открытом стоянии меньше, в лесу больше. Ставим 0.30-0.42.
        //
        // Прежний комментарий объяснял укорочение тем, что так «SCA-рост начинается
        // пониже и распределяется по высоте постепенно». Но у space colonization за
        // распределение кроны отвечает ОБЛАКО ТОЧЕК ПРИТЯЖЕНИЯ (его форма и нижняя
        // граница), а не длина жёсткого ствола, — так что укорачивать ствол ради этого
        // было не нужно, а силуэт он портил.
        // ДЛИНА СТВОЛА ЗАВИСИТ ОТ ВОЗРАСТА — как BaseSize у хвойных.
        //
        // Была фиксированной долей 0.30-0.42 при любом возрасте, и замер это ловил:
        // у молодого дерева (age 1) boleClearance выходил 0.443, то есть чистый ствол
        // почти половина высоты. У молодого дерева ветви идут низко, ствол оголяется
        // как раз С ВОЗРАСТОМ — по мере того как нижние ветви уходят в тень и
        // отмирают (Palubicki, §4.4). Теперь доля растёт с 0.14 до 0.38.
        float trunkFrac = (0.14f + ageF * 0.24f) * rnd.NextFloat(0.88f, 1.12f);
        float trunkH = bush ? height * 0.12f : height * trunkFrac;
        var mesh = new PlantMeshData { LocalHeight = height };

        // --- 1. Attraction points в объёме кроны ---
        // Облако точек притяжения больше не строится: чистая модель самоорганизации
        // (SelfOrganizingTree) формирует крону из конкуренции почек за свет, а не по
        // заданному объёму. Осталась только высота и радиус кроны — они нужны для
        // размещения листвы и для метрик.

        // ---- СКЕЛЕТ: ЧИСТАЯ МОДЕЛЬ ПАЛУБИЦКИ (см. SelfOrganizingTree.cs) ----
        //
        // Здесь строился скелет по space colonization: облако точек притяжения, рост к
        // ближайшим точкам, удаление достигнутых. Сверка с материалами показала, что в
        // таком гибриде механизмы статьи декоративны — форму задаёт облако, а не свет:
        // прогон λ от 0.44 до 0.60 давал ширину/высоту 0.96…1.06 без закономерности.
        // После перехода на чистую модель тот же прогон даёт 0.68 → 0.49 и порядки
        // ветвления 8 → 5, то есть переход decurrent → excurrent с Fig. 7 статьи.
        // Параметры SO подобраны offline (so_harness.py, combo D):
        // шире угол ветвления, слабее тропизм, ниже λ → crownRatio 0.55–0.85,
        // меньше top-heavy bands. Shed у зрелых агрессивнее → bole ~0.20–0.25.
        // v7 QUALITY: для лиственных q>4 почти не меняет силуэт (MaxNodes
        // упирается раньше, densMul даёт <10% cards). На слабом устройстве
        // QualityLevel=0..2, на сильном 3..4 — дерево уже «дерево». Выше 4 —
        // только лишняя CPU/GPU без визуала. qEff режет вклад в SO.
        int qEff = Math.Min(q, GameQEffMax); // V114
        SoStats.QEff = qEff;
        var soSettings = new SelfOrganizingTree.Settings
        {
            // V55 (audit K-2): Steps/MaxMetamers согласованы с MaxNodes.
            // MaxMetamers=3 при Steps≈26 упирался в потолок на шаге ~5 — возраст
            // выше 5 не влиял, а теневая сетка пересчитывалась впустую.
            // MaxMetamers=2 + Steps=8+age+qEff (≤20) даёт различимые силуэты без cap.
            Steps = 8 + Math.Clamp(AgeLevel, 0, 8) + qEff,
            Lambda = Math.Clamp(AgeLambda(AgeLevel) + species.LambdaShift, 0.40f, 0.56f),
            Alpha = 2.1f,
            // ---- V99: ДЕРЕВО ПЕРЕСТАЁТ ЗАВАЛИВАТЬСЯ НАБОК ----
            //
            // На отрисовке дуб и клён кренились так, что ствол уходил вбок почти на
            // ширину кроны, а крона висела с одной стороны. Причина в соотношении
            // весов: направление к свету (ξ = 0.35) вчетверо-впятеро перевешивало
            // гравитропизм (η = 0.06). Свет считается по градиенту собственной тени,
            // и у отдельно стоящего дерева этот градиент всегда асимметричен —
            // случайный перекос на первых шагах усиливается и уводит весь ствол.
            //
            // У настоящего дерева всё наоборот: отрицательный гравитропизм ствола —
            // сильнейший из ориентирующих механизмов, а к свету тянутся ветви, не
            // ствол. Поэтому η поднят до 0.30 и ξ снижен до 0.26. У куста
            // гравитропизм намеренно слабее — он и должен расти вразвал.
            LightPull = 0.34f,
            TropismWeight = (bush ? 0.10f : 0.55f) * Math.Clamp(trunkH / MathF.Max(height * 0.25f, 1e-3f), 0.5f, 1.5f),
            BaseLength = height * 0.047f,
            BranchAngle = (bush ? 58f : 58f) * Math.Clamp(crownR / MathF.Max(height * 0.45f, 1e-3f), 0.7f, 1.35f),
            MaxMetamers = 2,
            ShedStartStep = AgeLevel <= 2 ? 7 : (AgeLevel <= 4 ? 5 : 3),
            // ЗАТЕНЁННОСТЬ — ЧЕРЕЗ СОБСТВЕННЫЙ МЕХАНИЗМ СБРОСА, а не отдельной ручкой.
            //
            // У лиственных доля голого ствола не задаётся числом: ветви отмирают сами,
            // когда освещённость падает ниже ShedRatio от средней (Палубицки). Это ровно
            // то, что моделирует Crowding, поэтому он и подмешивается сюда — заводить
            // рядом вторую ручку значило бы иметь два источника правды об одном.
            //
            // Замер витрины: без этого лиственные давали 77 / 77 / 77 на трёх ступенях,
            // то есть не реагировали вовсе, тогда как у ели ряд шёл 99 / 93 / 88.
            // Ниже порог — агрессивнее сброс, поэтому в чаще он уменьшается.
            // ---- V164: ЗАТЕНЁННОСТЬ УБРАНА ИЗ ПОРОГА СБРОСА ----
            //
            // Она подмешивалась сюда две итерации и не работала: ±15% дали два пункта
            // разницы по трём ступеням, ±35% — один, то есть шум. Порог решает,
            // СКОЛЬКО узлов отомрёт, а не ГДЕ они расположены, и доля голого ствола
            // от него почти не зависит.
            //
            // Теперь затенённость соседями входит туда, где ей место, — в саму
            // теневую модель (Settings.NeighbourShade), боковой тенью, растущей
            // книзу. Порог вернулся к прежнему виду: одна величина — один смысл.
            ShedRatio = AgeLevel <= 3 ? 0.38f : 0.22f,
            Noise = bush ? 0.30f : 0.24f,
            // ПОТОЛОК УЗЛОВ — ЭТО БЮДЖЕТ, А НЕ СТРАХОВКА (audit K-2, перепроверено).
            //
            // Прежний комментарий утверждал, что при MaxMetamers=2 и Steps≤20 рост
            // до потолка не доходит. Это неверно: почка за шаг даёт до двух метамеров,
            // то есть число узлов удваивается, и при Steps=15 счёт уходит в десятки
            // тысяч. Замер по каждому дереву: created = РОВНО 3000 на всех возрастах
            // 4…8, то есть возраст не влиял вообще ни на что — ровно тот дефект,
            // который K-2 и описывал.
            //
            // Поэтому потолок задаётся явно и РАСТЁТ С ВОЗРАСТОМ: именно он, а не
            // Steps, определяет размер кроны, и возраст снова становится различим.
            // Compact (уровень) на порядок меньше: каждый узел — это отрезок ветви,
            // а древесина составляла 83% стоимости компактного лиственного
            // (18 683 треугольника из 22 618).
            // РОСТ ИДЁТ ДО КОНЦА, БЮДЖЕТ ПРИМЕНЯЕТСЯ ПОСЛЕ.
            //
            // MaxNodes теперь защита от взрывного роста, а не рабочий предел: он один
            // для обоих режимов и заведомо выше того, до чего дерево дорастает.
            // К игровому бюджету скелет приводится прореживанием готового дерева
            // (PruneTo), поэтому самоорганизация успевает отработать целиком.
            MaxNodes = SoGrowthCeiling(AgeLevel),
            PruneTo = SoNodeBudget(AgeLevel),
            NeighbourShade = g.Crowding * NeighbourShadeMax,
        };
        // Запоминаем фактические параметры SO для лога (один раз — все лиственные
        // в каталоге строятся с одинаковым Age/Quality).
        SoStats.SoSteps = soSettings.Steps;
        SoStats.SoMaxMetamers = soSettings.MaxMetamers;
        var soNodes = SelfOrganizingTree.Grow(g.Seed ^ 0x50A17, soSettings);
        if (SelfOrganizingTree.LastNodeCapHit != 0) SoStats.NodeCapHit++;
        SoStats.NodesPruned += SelfOrganizingTree.LastNodesPruned;

        var nodes = new List<Node>(soNodes.Count);
        foreach (var sn in soNodes)
        {
            nodes.Add(new Node
            {
                Pos = new Vec3(sn.Pos.X, sn.Pos.Y, sn.Pos.Z),
                Parent = sn.Parent,
                Wander = new Vec3(0, 0, 0),
                Order = sn.Order,
            });
        }
        if (nodes.Count < 4)
        {
            // Вырожденный случай (совсем молодое растение) — оставляем короткий ствол,
            // чтобы дальнейший код не получил пустой список.
            nodes.Clear();
            nodes.Add(new Node { Pos = new Vec3(0, 0, 0), Parent = -1, Order = 0 });
            for (int i = 1; i <= 3; i++)
                nodes.Add(new Node
                {
                    Pos = new Vec3(0, height * 0.12f * i, 0),
                    Parent = i - 1, Order = 0,
                });
        }

        // --- 3а. НОРМАЛИЗАЦИЯ ВЫСОТЫ СКЕЛЕТА ---
        // SO растёт свободными шагами BaseLength; при Steps=20+ суммарная длина лидера
        // выходит в 5–8 раз больше целевого LocalHeight. Витрина потом масштабирует
        // меш как (targetH / LocalHeight), и дерево визуально «вырастает до неба»
        // (логи age 8: дуб 57 м, клён 64 м при LocalHeight ≈ 8).
        // Приводим maxY скелета ровно к height — пропорции (crownRatio, bole) сохраняются,
        // а абсолютный размер совпадает с LocalHeight и корректно нормируется сценой.
        {
            float maxY = 0f;
            for (int i = 0; i < nodes.Count; i++)
                if (nodes[i].Pos.Y > maxY) maxY = nodes[i].Pos.Y;
            if (maxY > 1e-4f)
            {
                float s = height / maxY;
                for (int i = 0; i < nodes.Count; i++)
                {
                    var n = nodes[i];
                    n.Pos = new Vec3(n.Pos.X * s, n.Pos.Y * s, n.Pos.Z * s);
                    nodes[i] = n;
                }
            }
        }

        // В чистой модели жёсткого ствола нет — он ВОЗНИКАЕТ как цепочка узлов нулевого
        // порядка ветвления. Прежний код опирался на счётчик trunkNodes, которого больше
        // не существует, поэтому «ствол» определяется по порядку.
        int trunkNodes = 0;
        for (int i = 0; i < nodes.Count; i++)
            if (nodes[i].Order == 0) trunkNodes = Math.Max(trunkNodes, i);

        // --- 3б. Сглаживание + выпрямление скелета ---
        // ПРАВКА (борьба с "водорослями", часть 2): раньше здесь был только пасс усреднения
        // проходных узлов к соседям — он делает УЖЕ существующие изгибы более гладкими, а не
        // более прямыми, то есть работал против задачи, а не на неё. Настоящая ветка дерева
        // почти прямая на протяжении междоузлия и изламывается только в точках роста боковых
        // веток — а не гнётся непрерывно на всём протяжении, как рисует накопленный Wander.
        // Теперь после лёгкого локального сглаживания (убирает мелкую "рубленость" полилинии)
        // добавлен пасс выпрямления: для каждой цепочки "проходных" узлов (ровно один
        // потомок) между двумя точками ветвления/концами узлы притягиваются к прямой линии
        // между началом и концом цепочки. Сама траектория ветки (куда она в итоге растёт —
        // определено настоящим SCA-ростом) не трогается, выпрямляется только её внутренняя
        // кривизна.
        {
            var children = new List<int>[nodes.Count];
            for (int i = 0; i < nodes.Count; i++) children[i] = new List<int>();
            for (int i = 1; i < nodes.Count; i++) children[nodes[i].Parent].Add(i);

            const int SmoothPasses = 1;
            for (int pass = 0; pass < SmoothPasses; pass++)
            {
                var updated = new Vec3[nodes.Count];
                for (int i = 0; i < nodes.Count; i++) updated[i] = nodes[i].Pos;
                for (int i = 1; i < nodes.Count; i++)
                {
                    if (children[i].Count != 1) continue; // развилки и кончики — не трогаем
                    int parentIdx = nodes[i].Parent;
                    int childIdx = children[i][0];
                    var avg = Mul(Add(nodes[parentIdx].Pos, nodes[childIdx].Pos), 0.5f);
                    updated[i] = Lerp(nodes[i].Pos, avg, 0.35f);
                }
                for (int i = 0; i < nodes.Count; i++)
                {
                    var node = nodes[i];
                    node.Pos = updated[i];
                    nodes[i] = node;
                }
            }

            // Выпрямление: обходим от каждой "точки решения" (корень, развилка — 2+ детей,
            // или конец — 0 детей) вдоль цепочек ровно-одного-потомка до следующей такой
            // точки, и тянем внутренние узлы цепочки к прямой между началом и концом.
            const float StraightenAmount = 0.7f; // 0=не трогать, 1=идеально прямая линия
            for (int i = 0; i < nodes.Count; i++)
            {
                bool isDecision = i == 0 || children[i].Count != 1;
                if (!isDecision) continue;
                foreach (int firstChild in children[i])
                {
                    if (children[firstChild].Count != 1) continue; // сразу развилка/конец — цепочки нет

                    var chain = new List<int> { firstChild };
                    int cur = firstChild;
                    while (children[cur].Count == 1)
                    {
                        cur = children[cur][0];
                        chain.Add(cur);
                    }
                    // Последний элемент chain — сама точка решения (развилка/конец), её не
                    // двигаем; выпрямляем только внутренние (проходные) узлы перед ней.
                    var startPos = nodes[i].Pos;
                    var endPos = nodes[cur].Pos;
                    int n = chain.Count;
                    for (int k = 0; k < n - 1; k++)
                    {
                        float t = (k + 1) / (float)n;
                        var straight = Lerp(startPos, endPos, t);
                        int idx = chain[k];
                        var nd = nodes[idx];
                        nd.Pos = Lerp(nd.Pos, straight, StraightenAmount);
                        nodes[idx] = nd;
                    }
                }
            }
        }

        // V55: повторная нормализация после straighten (страховка audit K-1).
        {
            float maxY2 = 0f;
            for (int i = 0; i < nodes.Count; i++)
                if (nodes[i].Pos.Y > maxY2) maxY2 = nodes[i].Pos.Y;
            if (maxY2 > 1e-4f && MathF.Abs(maxY2 - height) > height * 0.02f)
            {
                float s2 = height / maxY2;
                for (int i = 0; i < nodes.Count; i++)
                {
                    var n = nodes[i];
                    n.Pos = new Vec3(n.Pos.X * s2, n.Pos.Y * s2, n.Pos.Z * s2);
                    nodes[i] = n;
                }
            }
        }

        // СБРОС ЗАТЕНЁННЫХ ВЕТВЕЙ выполняется ВНУТРИ модели самоорганизации
        // (SelfOrganizingTree.Shed, §4.4 статьи) — там он идёт на каждом шаге развития,
        // как и положено, а не один раз в конце. Прежний блок работал с теневой сеткой
        // из удалённого SCA-роста и после перехода на чистую модель ссылался на
        // несуществующую переменную.
        SoStats.TreesGenerated++;
        // Created = пик за рост; Final = итог после всех Shed.
        SoStats.NodesBeforeShed += SelfOrganizingTree.LastNodesCreated;
        SoStats.NodesAfterShed += SelfOrganizingTree.LastNodesFinal;
        SoStats.NodesByKind.TryGetValue(SoStats.CurrentKind, out long nsofar);
        SoStats.NodesByKind[SoStats.CurrentKind] = nsofar + nodes.Count;


        // --- 4. Толщина веток (от листьев к корню) ---
        var childCount = new int[nodes.Count];
        for (int i = 1; i < nodes.Count; i++)
            childCount[nodes[i].Parent]++;

        // МОДЕЛЬ ТРУБ (Palubicki 2009, §4.5): d^n = d1^n + d2^n, n обычно 2..3.
        //
        // ЧТО БЫЛО НЕ ТАК. Накопление шло ВОСЕМЬЮ проходами по одной и той же формуле
        // radius[p] = sqrt(rp² + contrib²·0.55). Узлы уже отсортированы «родитель
        // раньше потомка», поэтому одного обратного прохода достаточно, а восемь
        // подряд повторно добавляли вклад потомков к уже накопленным родителям.
        // Расчёт: одна ветка за 8 проходов раздувалась до 0.0634 при жёстком потолке
        // 0.063 — то есть В ПОТОЛОК упиралось practически всё, и ствол с ветками
        // получались ОДИНАКОВОЙ толщины. Отсюда и вид «толстые ветки на тонком
        // стволе»: контраста толщин не было вовсе, все трубы одного диаметра.
        //
        // Правильные значения при листе 0.008 и n = 2.5:
        //   ствол (400 листьев) 0.088, крупный сук (60) 0.041,
        //   ветка (20) 0.027, веточка (5) 0.015 — разница ствола и ветки втрое.
        const float PipeExponent = 2.5f;
        var radius = new float[nodes.Count];
        var pipeAcc = new float[nodes.Count];

        // Один проход от концов к основанию: к моменту обработки узла все его потомки
        // уже посчитаны, потому что потомок всегда стоит в списке ПОЗЖЕ родителя.
        float leafR = 0.008f;
        for (int i = nodes.Count - 1; i >= 0; i--)
        {
            // Лист (нет потомков) — минимальный радиус.
            float own = childCount[i] == 0 ? MathF.Pow(leafR, PipeExponent) : 0f;
            pipeAcc[i] += own;
            radius[i] = MathF.Pow(pipeAcc[i], 1f / PipeExponent);
            if (i > 0) pipeAcc[nodes[i].Parent] += pipeAcc[i];
        }

        // МАСШТАБ ТОЛЩИНЫ ПО ПАРАМЕТРУ Ratio (Weber & Penn): модель труб задаёт верные
        // ПРОПОРЦИИ между ветвями, но общий масштаб у неё привязан к числу листьев, а их
        // в нашей геометрии на порядок меньше, чем у настоящего дерева. Замер: дуб выходил
        // 1:67 по отношению диаметра к высоте при справочных 1:20…1:30. Поэтому все радиусы
        // умножаются на общий множитель так, чтобы ствол попал в целевую долю высоты.
        if (!bush && radius.Length > 0 && radius[0] > 1e-5f)
        {
            float targetTrunkR = height * species.TrunkRatio;
            float k = targetTrunkR / radius[0];
            // Верхний предел был 6: у берёзы (мало терминалов → малый raw-радиус)
            // k упирался в потолок и ствол оставался втрое тоньше целевого
            // (slenderness 120 вместо ~40). При достаточном числе узлов (норма после
            // увеличения Steps) ограничиваем мягче; для вырожденных деревцев
            // (nodes < 40) оставляем жёсткий потолок.
            float kMax = nodes.Count >= 40 ? 18f : 6f;
            k = Math.Clamp(k, 0.5f, kMax);
            for (int i = 0; i < radius.Length; i++) radius[i] *= k;
        }

        // Потолок оставлен только как предохранитель от вырожденных случаев и НЕ
        // должен срабатывать в норме — иначе он снова сотрёт разницу толщин.
        float hardCap = bush ? 0.075f : height * 0.06f;
        for (int i = 0; i < nodes.Count; i++)
            if (radius[i] > hardCap) radius[i] = hardCap;

        // РАДИУС СТВОЛА — база для порога «тонкой ветви». У самоорганизующегося
        // дерева ствол и есть самый толстый сегмент, поэтому берём максимум.
        float trunkRadius = 0f;
        for (int ri = 0; ri < radius.Length; ri++)
            if (radius[ri] > trunkRadius) trunkRadius = radius[ri];

        // --- 5. Меш веток ---
        // В SkeletonDebugMode красим по ОТДЕЛЬНОЙ ВЕТКЕ МЕЖДУ РАЗВИЛКАМИ, а не только по
        // первичному суку от ствола: новый цвет стартует на каждом узле с более чем одним
        // потомком (childCount[i] > 1) и на выходе с верхушки жёсткого ствола, а дальше
        // тянется без смены цвета до следующей развилки/кончика. Раньше цвет менялся только
        // один раз (на первом уровне ветвления от ствола), и все более мелкие веточки внутри
        // одного сука были одного тона — из-за этого нельзя было отличить "одна ветка сама
        // на себя намоталась" (петля одним цветом) от "две ветки того же сука пересеклись"
        // (петля из двух разных цветов). Теперь различие видно на любом уровне вложенности.
        int[] branchRootOf = new int[nodes.Count];
        branchRootOf[0] = 0;
        for (int i = 1; i < nodes.Count; i++)
        {
            int p = nodes[i].Parent;
            branchRootOf[i] = (p <= trunkNodes || childCount[p] > 1) ? i : branchRootOf[p];
        }

        for (int i = 1; i < nodes.Count; i++)
        {
            int p = nodes[i].Parent;
            float r = MathF.Max(0.005f, (radius[i] + radius[p]) * 0.5f);
            float brR, brG, brB;
            if (SkeletonDebugMode)
            {
                float hue = (branchRootOf[i] * 0.6180339887f) % 1f;
                HsvToRgb(hue, 0.72f, 0.95f, out brR, out brG, out brB);
            }
            else
            {
                // Видовой оттенок коры: берёза светлее, дуб темнее, клён красноватый.
                // Из материалов (Weber-Penn / видовые описания) — не общий TrR для всех.
                string sn = species.Name;
                if (sn == "берёза") { brR = 0.82f; brG = 0.78f; brB = 0.68f; } // V111: белее, реф
                else if (sn == "дуб") { brR = 0.28f; brG = 0.18f; brB = 0.10f; }
                else if (sn == "клён") { brR = 0.52f; brG = 0.28f; brB = 0.14f; }
                else { brR = TrR; brG = TrG; brB = TrB; }
            }
            if (Detail == FoliageDetail.Compact && r < trunkRadius * CompactThinBranchOfTrunk)
                AddBranchCross(mesh, nodes[p].Pos, nodes[i].Pos, r, brR, brG, brB);
            else
                AddBranch(mesh, nodes[p].Pos, nodes[i].Pos, r, brR, brG, brB);
        }

        // --- 6. Листва на концевых узлах (листья) ---
        // В SkeletonDebugMode листву не добавляем вовсе — весь смысл режима в том, чтобы
        // видеть голый скелет без карточек поверх него.
        if (!SkeletonDebugMode)
        {
            // v6: листва ВДОЛЬ ветвей, не только на терминалах.
            // v4/v5: только tips → «палки с пучками» (особенно age 0–3).
            // Реальное дерево: листья по всей периферии кроны, вдоль тонких ветвей.
            //
            // Бюджет: age0 ~0.8–2k cards, age8 ~18–28k (читаемый скелет + плотная крона).
            float folSize = bush ? 0.16f : 0.18f;
            folSize *= 0.90f + g.FoliageDensity * 0.25f;
            folSize *= Math.Clamp(height / 6.5f, 0.60f, 1.20f);
            // v7: densMul почти не зависит от q (qEff≤4). Пол выше → q=0 уже крона.
            int qEffFol = Math.Min(q, GameQEffMax);
            float densMul = 0.85f + g.FoliageDensity * 0.30f + qEffFol * 0.04f;
            if (ageF < 0.35f) densMul *= 1.15f; // age 0–2 чуть плотнее
            // Берёза: узкий лист — лёгкий буст, без 40k cards age8.
            if (species.Name == "берёза") densMul *= 1.15f;
            // Cost-параметры в лог (последний экземпляр породы перезаписывает).
            SoStats.QEff = qEffFol;
            string spKeyDec = $"{g.Kind}:{species.Name}";
            SoStats.DensMulBySpecies[spKeyDec] = densMul;

            // bole floor: молодые 12%, зрелые 28% — ствол всегда голый.
            float boleFloorY = bush ? 0f : height * (0.12f + ageF * 0.16f);

            // Вероятность листвы на внутренних узлах: выше у молодых.
            float internalProb = ageF < 0.4f ? 0.70f : 0.48f;

            for (int i = 1; i < nodes.Count; i++)
            {
                // v8: НИКОГДА листва на оси ствола (Order==0). Раньше
                // «Order==0 && childCount<=1» пропускало развилки ствола, и листья
                // садились прямо на ствол — видно на видео age 0–5.
                if (nodes[i].Order == 0) continue;
                if (nodes[i].Pos.Y < boleFloorY) continue;

                bool isTerminal = childCount[i] == 0;
                // Только периферия: order≥1, мало детей. Order≥2 предпочтительнее
                // для внутренних — меньше «листвы у ствола» на коротких L1.
                bool isOuter = nodes[i].Order >= 1 && childCount[i] <= 3;
                if (nodes[i].Order == 1 && !isTerminal && childCount[i] > 1)
                    isOuter = false; // толстые развилки 1-го порядка — без листвы

                if (!isTerminal && !isOuter) continue;
                if (!isTerminal && rnd.NextFloat(0f, 1f) > internalProb) continue;

                int parentIdx = nodes[i].Parent;
                bool parentIsTrunk = parentIdx >= 0 && nodes[parentIdx].Order == 0;

                // Сайты вдоль сегмента. Если parent = ствол — начинаем дальше (t≥0.55),
                // иначе листья визуально «сидят на стволе».
                int sites = isTerminal
                    ? 2 + (int)(densMul * 1.5f) + (q > 3 ? 1 : 0)
                    : 1 + (rnd.NextFloat(0f, 1f) < densMul * 0.4f ? 1 : 0);
                if (parentIsTrunk) sites = Math.Max(1, sites - 1); // меньше сайтов у основания

                var pPos = nodes[parentIdx].Pos;
                var nPos = nodes[i].Pos;
                var branchDir = Norm(Sub(nPos, pPos));
                float segLen = MathF.Sqrt(
                    (nPos.X - pPos.X) * (nPos.X - pPos.X) +
                    (nPos.Y - pPos.Y) * (nPos.Y - pPos.Y) +
                    (nPos.Z - pPos.Z) * (nPos.Z - pPos.Z));

                var perpSide = Norm(Cross(branchDir, MathF.Abs(branchDir.Y) < 0.9f ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0)));
                var perpOut = Cross(branchDir, perpSide);
                const float GoldenAngle = 2.39996323f;
                float baseAng = rnd.NextFloat(0f, MathF.PI * 2f);

                // ---- V84: КОМПАКТНАЯ ЛИСТВА ----
                //
                // Компактный режим прошлой итерации накрыл ТОЛЬКО хвойные — лиственные
                // и кусты строят листву отдельными карточками и остались на 40 768
                // треугольниках. Замер по HUD это показал прямо: при 36 чанках полного
                // меша выходило 33 652k треугольников, то есть 19 320 на экземпляр
                // вместо расчётных 736.
                //
                // Здесь тот же приём, что у хвои: одна крупная листовая масса на точку
                // вместо россыпи мелких листьев. Силуэт кроны сохраняется, потому что
                // точки распределены по тем же ветвям.
                int blobsPerSite;
                int sitesEff = sites;
                if (Detail == FoliageDetail.Compact)
                {
                    // ПЛОТНОСТЬ ПЕРЕСЧИТАНА ПОД НОВЫЙ БЮДЖЕТ УЗЛОВ.
                    //
                    // Прежние значения (1 масса на точку, не больше 1–2 точек на ветвь)
                    // подбирались, когда скелет имел ~2400 узлов. После введения бюджета
                    // узлов их стало 158–246, то есть в десять раз меньше, и та же
                    // настройка оставила на всё дерево около 56 карточек — крона
                    // рассыпалась, на ветвях остались голые прутья.
                    //
                    // Число масс на точку возвращено, места по-прежнему меньше, чем в
                    // витрине. Бюджет это выдерживает: компактное лиственное стоило
                    // 1165 треугольников при ориентире около 1500 на экземпляр.
                    // V94: крона стала втрое гуще. Деревьев на уровне втрое меньше,
                    // и бюджет, который они занимали числом, отдан листве каждого.
                    // Тот же размен, что у хвои: масс вчетверо меньше, каждая крупнее
                    // (CompactLeafMassScale). Крона по объёму та же, стоимость — нет.
                    // Карточка вчетверо мельче — покрытие возвращаем числом, а не
                    // размером. Это и есть правильная сторона размена.
                    blobsPerSite = isTerminal ? 10 : 7;
                    sitesEff = Math.Min(sites, isTerminal ? 6 : 5);

                    // ---- V97: ПРОРЕЖИВАНИЕ ВЕРХА КРОНЫ ----
                    //
                    // Дерево втрое-вдесятеро выше человека, и верх кроны всегда дальше
                    // от глаз, чем низ: у тридцатиметровой ели вершина в тридцати с
                    // лишним метрах даже когда стоишь у ствола. Видимый размер карточки
                    // там вдвое-втрое меньше, и та же плотность листвы тратится впустую.
                    //
                    // Ослабление считается по доле высоты: ниже HeightThinStart всё
                    // как есть, выше — плавно вдвое реже. Компенсации размером НЕТ
                    // намеренно: увеличенные карточки наверху выдали бы себя силуэтом
                    // на фоне неба, а именно там силуэт и виден лучше всего.
                    float hFrac = height > 1e-4f ? nodes[i].Pos.Y / height : 0f;
                    if (hFrac > HeightThinStart)
                    {
                        float t01 = Math.Clamp((hFrac - HeightThinStart) / (1f - HeightThinStart), 0f, 1f);
                        float keep = 1f - HeightThinAmount * t01;
                        blobsPerSite = Math.Max(2, (int)MathF.Round(blobsPerSite * keep));
                        sitesEff = Math.Max(1, (int)MathF.Round(sitesEff * keep));
                    }
                }
                else
                {
                    blobsPerSite = isTerminal
                        ? 2 + (int)(densMul * 2.0f)
                        : 1 + (int)(densMul * 1.2f);
                }

                for (int s = 0; s < sitesEff; s++)
                {
                    // t вдоль сегмента. От ствола — минимум 0.55, иначе «листья на стволе».
                    float tMin = parentIsTrunk ? 0.55f : 0.35f;
                    float t = isTerminal
                        ? (sites == 1 ? 1f : tMin + (1f - tMin) * s / Math.Max(sites - 1, 1))
                        : (Math.Max(tMin, 0.50f) + 0.40f * s / Math.Max(sites, 1));
                    t = Math.Clamp(t, tMin, 1f);
                    var sitePos = Add(pPos, Mul(Sub(nPos, pPos), t));
                    // Радиус в точке сайта (линейная интерполяция).
                    float rSite = radius[parentIdx] * (1f - t) + radius[i] * t;

                    for (int b = 0; b < blobsPerSite; b++)
                    {
                        float ang = baseAng + (s * blobsPerSite + b) * GoldenAngle
                                    + rnd.NextFloat(-0.20f, 0.20f);
                        var radial = Add(Mul(perpSide, MathF.Cos(ang)), Mul(perpOut, MathF.Sin(ang)));
                        var petioleDir = Norm(Add(Mul(radial, 1.20f),
                            new Vec3(0, isTerminal ? -0.20f : -0.30f, 0)));

                        // Молодые: не сжимать лист слишком сильно (было 0.55+age*0.5).
                        float ageSize = 0.75f + ageF * 0.35f;
                        float sz = folSize * rnd.NextFloat(0.70f, 1.10f)
                                   * (isTerminal ? 1f : 0.70f)
                                   * species.LeafSize * ageSize;
                        var leafDir = Norm(Add(petioleDir, new Vec3(
                            rnd.NextFloat(-0.20f, 0.20f),
                            rnd.NextFloat(-0.12f, 0.12f),
                            rnd.NextFloat(-0.20f, 0.20f))));

                        float offset = rSite * 1.30f + sz * rnd.NextFloat(0.35f, 0.80f);
                        var leafAnchor = Add(sitePos, Mul(petioleDir, offset));

                        // V108: компакт — 2 скрещенные карточки с разным наклоном, не один
                        // горизонтальный «блин». Одна карточка + normal≈up давала плоские
                        // диски/зонтики (обход V106, «Чаща леса 1»).
                        int cards = Detail == FoliageDetail.Compact
                            ? (rnd.NextFloat() < 0.45f ? 3 : 2) // V111 объём
                            : ((rnd.NextFloat(0f, 1f) < 0.18f) ? 2 : 1);
                        if (Detail == FoliageDetail.Compact) sz *= CompactLeafMassScale * 0.92f;
                        leafAnchor = Add(leafAnchor, new Vec3(
                            rnd.NextFloat(-sz * 0.15f, sz * 0.15f),
                            rnd.NextFloat(-sz * 0.40f, sz * 0.55f), // V111 толще крона
                            rnd.NextFloat(-sz * 0.15f, sz * 0.15f)));
                        AddFoliageBlob(mesh, leafAnchor, sz, rnd, conical: false, branchDir: leafDir,
                            cardCountOverride: cards, leafCell: species.Leaf,
                            tintR: species.TintR, tintG: species.TintG, tintB: species.TintB);
                    }
                }
            }
        }

        return mesh;
    }

    // ------------------------------------------------------------------
    //  Хвойные (SCA-скелет + Л-система для хвои)
    // ------------------------------------------------------------------
    //  *** БОЛЬШЕ НЕ ИСПОЛЬЗУЕТСЯ (см. Generate() выше — откат на
    //  Weber-Penn для хвойных). Причина отката: docs/generation-design.md
    //  самого SeedThree прямо рекомендует Weber-Penn/L-систему для
    //  хвойных, а НЕ space colonization — excurrent-форма и мутовчатый филлотаксис это
    //  явные параметры уровня, а не то, что естественно даёт SCA. Оставлено
    //  как референс/на случай если решение снова изменится. ***
    //
    //  Решение по архитектуре (историческое, для контекста): у ВСЕХ
    //  деревьев основа — Space Colonization Algorithm, тот же, что и у
    //  GenerateColonizedTree выше (Deciduous/Bush). Л-система работает НЕ
    //  вместо SCA, а поверх уже готового SCA-скелета — добавляет хвою на
    //  концевых ветках (гребень у Fir, фасцикула у Pine), см.
    //  RunTurtleProgram выше.
    //
    //  Отличие Pine от Fir — не алгоритм, а ДВЕ вещи, обе по
    //  colonization.pdf: (1) форма envelope точек притяжения — узкий
    //  плотный конус у Fir против широкого рыхлого объёма у Pine
    //  (Figures 4-7: форма envelope прямо определяет силуэт кроны);
    //  (2) параметры самого SCA — у Pine меньше N и больше kill distance
    //  (Figure 3: статья прямо связывает малое N/большое dk с
    //  нерегулярными, "блуждающими" ветками — то, что нужно для сосны).
    //
    //  СТАРЫЙ генератор (GenerateConifer/BuildWpStem/WpParams ниже)
    //  ПЕРЕСТАЛ ИСПОЛЬЗОВАТЬСЯ (см. dispatcher в Generate()), оставлен
    //  только для сравнения/отката — можно удалить, когда результат
    //  этой версии устроит.
    // ------------------------------------------------------------------
    private static PlantMeshData GenerateConiferSca(SeededRandom rnd, PlantGenome g, bool isFir)
    {
        int q = Math.Clamp(QualityLevel, 0, 12);
        float height = (isFir ? 5.4f : 6.2f) * g.HeightMul;
        // ПРАВКА (excurrent-форма — численно проверено вне Godot, см. sca_sim2.py):
        // раньше ствол был коротким (10-46% высоты), а дальше рост SCA расползался вширь
        // безо всякого доминирующего лидера — итог: nodes с lateral_span >= vertical_span
        // (дерево такой же ширины, как высоты — по факту куст, не дерево). Хвойные почти
        // всегда моноподиальны (один главный лидер на всю высоту, боковые ветки —
        // подчинённые), в терминах самой статьи colonization.pdf это "excurrent" форма
        // (в противовес "decurrent" — тому, что уже правильно для Deciduous выше). Ствол
        // теперь высокий на ОБОИХ видах; разница видов — не в длине ствола, а в высоте, с
        // которой НАЧИНАЕТСЯ крона (crownBase ниже).
        float trunkH = height * 0.90f;
        // Fir: "нижние ветви сохраняются почти до земли" → крона начинается низко.
        // Pine: "у взрослых нижние ветви часто отмирают, крона поднимается высоко" →
        // заметно более высокий голый низ ствола.
        float crownBase = height * (isFir ? 0.08f : 0.30f);
        float crownTop = height;
        float crownR = height * (isFir ? 0.34f : 0.46f) * g.CrownMul * CrownWidthScale(g.Kind);

        var mesh = new PlantMeshData { LocalHeight = height };

        // --- 1. Envelope точек притяжения (форма → силуэт кроны, Fig.4-7) ---
        int nAttract = isFir ? (500 + Math.Min(q, GameQEffMax) * 200) : (220 + Math.Min(q, GameQEffMax) * 100); // Fir гуще (Fig.3)
        var attractions = new List<Vec3>(nAttract);
        float lobeAngle = rnd.NextFloat(0f, MathF.PI * 2f);
        float lobeOffset = crownR * rnd.NextFloat(0.04f, isFir ? 0.08f : 0.22f);
        var crownCenterOffset = new Vec3(MathF.Cos(lobeAngle) * lobeOffset, 0f, MathF.Sin(lobeAngle) * lobeOffset);

        for (int i = 0; i < nAttract; i++)
        {
            float hf = rnd.NextFloat(0f, 1f); // 0=низ кроны, 1=верхушка
            float y = crownBase + hf * (crownTop - crownBase);
            // ПРАВКА (баг-фикс, проверено численно): профиль ТЕПЕРЬ СХОДИТСЯ К ОСИ у ОБОИХ
            // полюсов (hf=0 и hf=1) — как sin(phi) в проверенном GenerateColonizedTree
            // (там это встроено в саму сферическую параметризацию через phi, здесь —
            // явно через sin(hf*π)). Раньше radiusHere у Fir был МАКСИМАЛЕН ровно при
            // hf=0 (там же, где стартует рост) — единственный стартовый узел физически
            // не мог дотянуться до точек притяжения дальше influenceRadius, и SCA-рост
            // не мог забутстрапиться вообще (iters_used=0, growth_beyond_trunk=0 — это
            // и есть "дерево не генерируется" из отчёта). Без сходимости к оси у полюсов
            // та же ловушка грозит любой форме envelope, не только конусу.
            float radiusHere;
            if (isFir)
            {
                // Пик ширины ближе к низу кроны, острая узкая верхушка — плотный конус.
                float shape = MathF.Pow(MathF.Sin(hf * MathF.PI), 0.5f) * (1f - hf * 0.55f);
                radiusHere = crownR * shape * rnd.NextFloat(0.5f, 1f);
            }
            else
            {
                // Более плоский профиль (шире держится дольше) — округло-зонтиковидная
                // крона по референсу, но всё ещё сходится к оси у обоих полюсов.
                float shape = MathF.Pow(MathF.Sin(hf * MathF.PI), 0.7f);
                radiusHere = crownR * shape * rnd.NextFloat(0.3f, 1f);
            }
            float theta = rnd.NextFloat(0f, MathF.PI * 2f);
            attractions.Add(new Vec3(
                crownCenterOffset.X + MathF.Cos(theta) * radiusHere,
                y,
                crownCenterOffset.Z + MathF.Sin(theta) * radiusHere));
        }

        // --- 2. Жёсткий ствол ---
        float stepLen = height * (isFir ? 0.030f : 0.034f);
        stepLen = MathF.Max(stepLen * (1f - q * 0.02f), height * 0.016f);
        float influenceRadius = crownR * (isFir ? 0.32f : 0.40f);
        // Pine: заметно больше kill distance → крупные разрежённые извилистые сучья
        // (см. paper про di/dk выше).
        float killDistance = stepLen * (isFir ? 1.8f : 2.6f);

        var nodes = new List<Node>();
        nodes.Add(new Node { Pos = new Vec3(0, 0, 0), Parent = -1, Wander = new Vec3(0, 0, 0), Order = 0 });
        int trunkNodes = Math.Max(2, (int)(trunkH / stepLen));
        for (int i = 1; i <= trunkNodes; i++)
        {
            float t = i / (float)trunkNodes;
            nodes.Add(new Node
            {
                Pos = new Vec3(MathF.Sin(g.Lean) * trunkH * 0.05f * t * t, t * trunkH, 0f),
                Parent = nodes.Count - 1,
                Wander = new Vec3(0, 0, 0)
            });
        }

        // --- 3. SCA рост (идентично GenerateColonizedTree выше) ---
        int maxIter = 40 + Math.Min(q, GameQEffMax) * 12;
        for (int iter = 0; iter < maxIter && attractions.Count > 0; iter++)
        {
            var influence = new Dictionary<int, List<int>>();
            for (int a = 0; a < attractions.Count; a++)
            {
                int best = -1;
                float bestD = influenceRadius * influenceRadius;
                for (int n = 0; n < nodes.Count; n++)
                {
                    float d = DistSq(nodes[n].Pos, attractions[a]);
                    if (d < bestD) { bestD = d; best = n; }
                }
                if (best >= 0)
                {
                    if (!influence.TryGetValue(best, out var list)) { list = new List<int>(); influence[best] = list; }
                    list.Add(a);
                }
            }
            if (influence.Count == 0) break;

            int nodesBefore = nodes.Count;
            foreach (var kv in influence)
            {
                int nIdx = kv.Key;
                var dir = new Vec3(0, 0, 0);
                foreach (int aIdx in kv.Value)
                {
                    var d = Sub(attractions[aIdx], nodes[nIdx].Pos);
                    float len = Len(d);
                    if (len > 1e-6f) dir = Add(dir, Mul(d, 1f / len));
                }
                float dlen = Len(dir);
                if (dlen < 1e-6f) continue;
                dir = Mul(dir, 1f / dlen);

                var parentWander = nodes[nIdx].Wander;
                float wanderLim = isFir ? 0.10f : 0.24f; // Fir ровнее, Pine извилистее
                var wander = new Vec3(
                    Math.Clamp(parentWander.X + rnd.NextFloat(-0.04f, 0.04f), -wanderLim, wanderLim),
                    Math.Clamp(parentWander.Y + rnd.NextFloat(-0.02f, 0.02f), -wanderLim * 0.5f, wanderLim * 0.5f),
                    Math.Clamp(parentWander.Z + rnd.NextFloat(-0.04f, 0.04f), -wanderLim, wanderLim));

                float tropism = (isFir ? 0.34f : 0.22f) * rnd.NextFloat(0.85f, 1.15f);
                dir = new Vec3(
                    dir.X + wander.X + rnd.NextFloat(-0.07f, 0.07f),
                    dir.Y + wander.Y + tropism + rnd.NextFloat(-0.04f, 0.06f),
                    dir.Z + wander.Z + rnd.NextFloat(-0.07f, 0.07f));
                dir = Norm(dir);
                if (dir.Y < 0.05f) dir = Norm(new Vec3(dir.X, 0.12f + MathF.Abs(dir.Y) * 0.5f, dir.Z));

                float thisStep = stepLen * rnd.NextFloat(0.82f, 1.22f);
                var newPos = Add(nodes[nIdx].Pos, Mul(dir, thisStep));
                if (newPos.Y < 0.02f) newPos = new Vec3(newPos.X, 0.02f, newPos.Z);
                nodes.Add(new Node { Pos = newPos, Parent = nIdx, Wander = wander });
            }

            var remain = new List<Vec3>(attractions.Count);
            for (int a = 0; a < attractions.Count; a++)
            {
                bool killed = false;
                for (int n = 0; n < nodes.Count; n++)
                    if (DistSq(nodes[n].Pos, attractions[a]) < killDistance * killDistance) { killed = true; break; }
                if (!killed) remain.Add(attractions[a]);
            }
            attractions = remain;

            if (nodes.Count == nodesBefore) break;
            if (nodes.Count > 420 + Math.Min(q, GameQEffMax) * 120) break;
        }

        // --- 3б. Сглаживание скелета (идентично GenerateColonizedTree) ---
        {
            var children = new List<int>[nodes.Count];
            for (int i = 0; i < nodes.Count; i++) children[i] = new List<int>();
            for (int i = 1; i < nodes.Count; i++) children[nodes[i].Parent].Add(i);
            const int SmoothPasses = 2;
            for (int pass = 0; pass < SmoothPasses; pass++)
            {
                var updated = new Vec3[nodes.Count];
                for (int i = 0; i < nodes.Count; i++) updated[i] = nodes[i].Pos;
                for (int i = 1; i < nodes.Count; i++)
                {
                    if (children[i].Count != 1) continue;
                    int parentIdx = nodes[i].Parent;
                    int childIdx = children[i][0];
                    var avg = Mul(Add(nodes[parentIdx].Pos, nodes[childIdx].Pos), 0.5f);
                    updated[i] = Lerp(nodes[i].Pos, avg, 0.5f);
                }
                for (int i = 0; i < nodes.Count; i++) { var nd = nodes[i]; nd.Pos = updated[i]; nodes[i] = nd; }
            }
        }

        // --- 4. Толщина (pipe model, идентично GenerateColonizedTree) ---
        var childCount = new int[nodes.Count];
        for (int i = 1; i < nodes.Count; i++) childCount[nodes[i].Parent]++;
        var radius = new float[nodes.Count];
        for (int i = 0; i < nodes.Count; i++) radius[i] = 0.007f;
        for (int pass = 0; pass < 8; pass++)
            for (int i = nodes.Count - 1; i >= 1; i--)
            {
                int p = nodes[i].Parent;
                float rp = radius[p];
                radius[p] = MathF.Sqrt(rp * rp + radius[i] * radius[i] * 0.55f);
            }
        float maxR = isFir ? 0.075f : 0.065f;
        for (int i = 0; i <= trunkNodes && i < nodes.Count; i++)
            if (radius[i] > maxR) radius[i] = maxR;
        float hardCap = maxR * 1.15f;
        for (int i = 0; i < nodes.Count; i++)
            if (radius[i] > hardCap) radius[i] = hardCap;

        // --- 5. Меш веток ---
        for (int i = 1; i < nodes.Count; i++)
        {
            int p = nodes[i].Parent;
            float r = MathF.Max(0.004f, (radius[i] + radius[p]) * 0.5f);
            float brR, brG, brB;
            if (SkeletonDebugMode)
            {
                float hue = (i * 0.6180339887f) % 1f;
                HsvToRgb(hue, 0.72f, 0.95f, out brR, out brG, out brB);
            }
            else
            {
                brR = TrR; brG = TrG; brB = TrB;
            }
            AddBranch(mesh, nodes[p].Pos, nodes[i].Pos, r, brR, brG, brB);
        }

        // --- 6. Хвоя: Л-система поверх готового SCA-скелета ---
        if (!SkeletonDebugMode)
        {
            // Fir: гуще, короче, холоднее зелёный. Pine: реже, длиннее, теплее зелёный.
            float needleR = isFir ? 0.20f : 0.26f;
            float needleG = isFir ? 0.46f : 0.50f;
            float needleB = isFir ? 0.18f : 0.16f;
            float needleBase = (isFir ? height * 0.014f : height * 0.030f) * (0.85f + g.FoliageDensity * 0.3f);
            const float GoldenAngle = 2.39996323f; // 137.5°, филлотаксис — как у листвы выше

            for (int i = 1; i < nodes.Count; i++)
            {
                if (i <= trunkNodes) continue;
                bool isTip = childCount[i] == 0;
                if (!isTip)
                {
                    if (childCount[i] > 2) continue;
                    if (rnd.NextFloat(0f, 1f) > 0.55f) continue;
                }

                var branchDir = Norm(Sub(nodes[i].Pos, nodes[nodes[i].Parent].Pos));
                var up = MathF.Abs(branchDir.Y) < 0.9f ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
                var side = Norm(Cross(branchDir, up));
                var outv = Norm(Cross(side, branchDir));

                float rC = needleR + rnd.NextFloat(-0.03f, 0.03f);
                float gC = needleG + rnd.NextFloat(-0.04f, 0.04f);
                float bC = needleB + rnd.NextFloat(-0.02f, 0.02f);
                float nLen = needleBase * rnd.NextFloat(0.85f, 1.15f);

                int organsHere = isTip ? (isFir ? 3 : 1) : 1;
                float baseAng = rnd.NextFloat(0f, MathF.PI * 2f);
                for (int o = 0; o < organsHere; o++)
                {
                    float ang = baseAng + o * GoldenAngle;
                    var radial = Add(Mul(side, MathF.Cos(ang)), Mul(outv, MathF.Sin(ang)));
                    radial = Norm(Add(radial, new Vec3(0, isFir ? -0.12f : -0.20f, 0)));
                    var basePos = Add(nodes[i].Pos, Mul(radial, radius[i] * 1.05f));
                    if (basePos.Y < 0.02f) basePos = new Vec3(basePos.X, 0.02f, basePos.Z);

                    if (isFir)
                    {
                        // Л-грамматика "гребень": 3 сегмента стержня, на каждом — пара игл
                        // под ~50° по обе стороны (см. RunTurtleProgram). Заменяет прежний
                        // процедурный AddNeedleFrond той же формой, но через строку-программу.
                        RunTurtleProgram("F[+N][-N]F[+N][-N]F[+N][-N]", basePos, radial,
                            nLen * 0.38f, 50f, mesh, MathF.Max(0.003f, nLen * 0.03f),
                            0.30f, 0.19f, 0.09f, nLen, rnd, rC, gC, bC);
                    }
                    else
                    {
                        // Л-грамматика "фасцикула": 3 иглы из одной точки, узкий угол (6°) —
                        // почти параллельны, как в настоящем пучке сосны.
                        RunTurtleProgram("[+N][N][-N]", basePos, radial,
                            0f, 6f, mesh, 0f, 0f, 0f, 0f, nLen, rnd, rC, gC, bC);
                    }
                }
            }
        }

        return mesh;
    }
    // ------------------------------------------------------------------
    // НЕ ВЫЗЫВАЕТСЯ — оставлена для A/B сравнения со GenerateFlowerL (см. п.8.3).
    private static PlantMeshData GenerateFlowerLegacy(SeededRandom rnd, PlantGenome g)
    {
        int q = Math.Clamp(QualityLevel, 0, 12);
        float h = 0.95f * g.HeightMul; // крупнее, чтобы читалось в ряду
        var mesh = new PlantMeshData { LocalHeight = h };
        int stems = 3 + q / 2;
        for (int s = 0; s < stems; s++)
        {
            float ox = rnd.NextFloat(-0.14f, 0.14f);
            float oz = rnd.NextFloat(-0.14f, 0.14f);
            var baseP = new Vec3(ox, 0, oz);
            float hh = h * rnd.NextFloat(0.65f, 1f);
            var top = new Vec3(
                ox + rnd.NextFloat(-0.04f, 0.04f),
                hh,
                oz + rnd.NextFloat(-0.04f, 0.04f));
            AddBranch(mesh, baseP, top, 0.012f, 0.22f, 0.48f, 0.14f);

            // Листья на стебле
            if (rnd.NextFloat(0f, 1f) > 0.3f)
            {
                var leafPos = Lerp(baseP, top, rnd.NextFloat(0.3f, 0.6f));
                AddFoliageBlob(mesh, leafPos, 0.06f, rnd, conical: false, 0.30f, 0.55f, 0.20f);
            }

            // Крупные лепестки
            int petals = 5 + q / 2;
            float petalR = 0.12f + q * 0.008f;
            for (int p = 0; p < petals; p++)
            {
                float ang = (p / (float)petals) * MathF.PI * 2f + rnd.NextFloat(0f, 0.2f);
                var petal = new Vec3(
                    top.X + MathF.Cos(ang) * petalR,
                    top.Y + 0.03f,
                    top.Z + MathF.Sin(ang) * petalR);
                float pr = rnd.NextFloat(0.88f, 1f);
                float pg = rnd.NextFloat(0.70f, 0.92f);
                float pb = rnd.NextFloat(0.15f, 0.40f);
                AddFoliageBlob(mesh, petal, 0.07f, rnd, conical: false, pr, pg, pb);
            }
            // Центр цветка
            AddFoliageBlob(mesh, top, 0.05f, rnd, conical: false, 0.95f, 0.80f, 0.15f);
        }
        return mesh;
    }

    // НЕ ВЫЗЫВАЕТСЯ — оставлена для A/B сравнения со GenerateReedL (см. п.8.3).
    private static PlantMeshData GenerateReedLegacy(SeededRandom rnd, PlantGenome g)
    {
        int q = Math.Clamp(QualityLevel, 0, 12);
        float h = 2.2f * g.HeightMul; // выше и заметнее
        var mesh = new PlantMeshData { LocalHeight = h };
        int stems = 4 + q / 2;
        for (int s = 0; s < stems; s++)
        {
            float ox = rnd.NextFloat(-0.18f, 0.18f);
            float oz = rnd.NextFloat(-0.18f, 0.18f);
            float hh = h * rnd.NextFloat(0.70f, 1f);
            var baseP = new Vec3(ox, 0, oz);
            // Лёгкий изгиб стебля
            var mid = new Vec3(
                ox + rnd.NextFloat(-0.04f, 0.04f),
                hh * 0.55f,
                oz + rnd.NextFloat(-0.04f, 0.04f));
            var top = new Vec3(
                mid.X + rnd.NextFloat(-0.03f, 0.03f),
                hh,
                mid.Z + rnd.NextFloat(-0.03f, 0.03f));
            AddBranch(mesh, baseP, mid, 0.016f, 0.28f, 0.40f, 0.13f);
            AddBranch(mesh, mid, top, 0.012f, 0.30f, 0.42f, 0.14f);
            // Метёлка (крупнее)
            AddFoliageBlob(mesh, top, 0.14f, rnd, conical: false, 0.58f, 0.52f, 0.22f);
            AddFoliageBlob(mesh,
                new Vec3(top.X, top.Y - 0.06f, top.Z),
                0.10f, rnd, conical: false, 0.50f, 0.48f, 0.20f);
        }
        return mesh;
    }

    // ------------------------------------------------------------------
    //  Геометрия
    // ------------------------------------------------------------------
    /// <summary>
    /// Тонкая ветвь как КРЕСТ из двух карточек: 2 quad = 4 треугольника против 8 у
    /// четырёхгранной трубки AddBranch. Приём тот же, что у AddPetiole и AddNeedle —
    /// одна плоская карточка была бы видна почти ребром с части ракурсов, крест это
    /// снимает. Вершины идут без явных UV, то есть попадают в непрозрачную ячейку
    /// атласа и рисуются сплошным цветом, как трубка.
    /// </summary>
    private static void AddBranchCross(
        PlantMeshData mesh, Vec3 a, Vec3 b, float radius,
        float cr, float cg, float cb)
    {
        var axis = Sub(b, a);
        float len = Len(axis);
        if (len < 1e-5f) return;
        axis = Mul(axis, 1f / len);
        var up = MathF.Abs(axis.Y) < 0.9f ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        var side0 = Norm(Cross(axis, up));
        var side1 = Norm(Cross(axis, side0));

        void EmitQuad(Vec3 side)
        {
            int bi = mesh.VertexCount;
            var b0 = Sub(a, Mul(side, radius));
            var b1 = Add(a, Mul(side, radius));
            var t1 = Add(b, Mul(side, radius * 0.75f));
            var t0 = Sub(b, Mul(side, radius * 0.75f));
            mesh.AddVertex(b0.X, b0.Y, b0.Z, cr, cg, cb);
            mesh.AddVertex(b1.X, b1.Y, b1.Z, cr, cg, cb);
            mesh.AddVertex(t1.X, t1.Y, t1.Z, cr, cg, cb);
            mesh.AddVertex(t0.X, t0.Y, t0.Z, cr, cg, cb);
            mesh.AddQuad(bi, bi + 1, bi + 2, bi + 3);
        }

        EmitQuad(side0);
        EmitQuad(side1);
    }

    private static void AddBranch(
        PlantMeshData mesh, Vec3 a, Vec3 b, float radius,
        float cr, float cg, float cb)
    {
        var dir = Sub(b, a);
        float len = Len(dir);
        if (len < 1e-5f) return;
        dir = Mul(dir, 1f / len);

        Vec3 up = MathF.Abs(dir.Y) < 0.9f ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        var right = Norm(Cross(dir, up));
        var fwd = Norm(Cross(right, dir));

        // ---- V140: ЧИСЛО ГРАНЕЙ ПО ТОЛЩИНЕ, КОРА ИЗ АТЛАСА ----
        //
        // Четыре грани на любой сегмент — причина того, что ствол читается призмой:
        // вблизи видны ровно два-три плоских бока и резкое ребро между ними. У толстых
        // сегментов граней теперь восемь, у средних шесть, у тонких по-прежнему четыре
        // (на веточке в сантиметр разницы не видно ни с какой дистанции).
        //
        // Цена ограничена тем, что толстых сегментов в дереве единицы: ствол и первые
        // суки. Вся мелочь, которой в скелете сотни, остаётся четырёхгранной.
        int sides = radius > BarkThickRadius ? 8 : radius > BarkMidRadius ? 6 : 4;

        // UV: продольная развёртка по ячейке коры. V идёт вдоль сегмента, поэтому
        // борозды тянутся по стволу, а не поперёк; U обходит окружность, и рисунок
        // замыкается без шва. Тонкие ветви оставляем в сплошной ячейке — на них
        // текстура всё равно неразличима, а лишние UV усложнили бы прореживание.
        bool textured = radius > BarkMidRadius;
        var bark = FoliageAtlas.Bark;
        float vSpan = MathF.Min(len / MathF.Max(radius * 8f, 0.05f), 3f);

        int baseIdx = mesh.VertexCount;
        float r0 = radius;
        float r1 = radius * 0.75f;
        for (int i = 0; i < sides; i++)
        {
            float t = i / (float)sides;
            float ang = t * MathF.PI * 2f + 0.3f;
            float cx = MathF.Cos(ang);
            float cz = MathF.Sin(ang);
            var o0 = Add(Mul(right, cx * r0), Mul(fwd, cz * r0));
            var o1 = Add(Mul(right, cx * r1), Mul(fwd, cz * r1));
            if (textured)
            {
                float u = bark.uMin + (bark.uMax - bark.uMin) * (t * 2f % 1f);
                float v0 = bark.vMin;
                float v1 = bark.vMin + (bark.vMax - bark.vMin) * (vSpan % 1f);
                mesh.AddVertex(a.X + o0.X, a.Y + o0.Y, a.Z + o0.Z, cr, cg, cb, u, v0);
                mesh.AddVertex(b.X + o1.X, b.Y + o1.Y, b.Z + o1.Z, cr, cg, cb, u, v1);
            }
            else
            {
                mesh.AddVertex(a.X + o0.X, a.Y + o0.Y, a.Z + o0.Z, cr, cg, cb);
                mesh.AddVertex(b.X + o1.X, b.Y + o1.Y, b.Z + o1.Z, cr, cg, cb);
            }
        }
        for (int i = 0; i < sides; i++)
        {
            int i0 = baseIdx + i * 2;
            int i1 = baseIdx + i * 2 + 1;
            int i2 = baseIdx + ((i + 1) % sides) * 2 + 1;
            int i3 = baseIdx + ((i + 1) % sides) * 2;
            mesh.AddQuad(i0, i1, i2, i3);
        }
    }

    /// <summary>
    /// Тонкая соединительная ножка (черешок листа) как billboard-cross из двух карточек
    /// под 90° друг к другу вокруг оси — 2 quad = 4 tris, вместо полного 4-гранного
    /// цилиндра AddBranch (8 tris). Тот же приём и по той же причине, что и у AddNeedle:
    /// одна плоская карточка была бы видна почти ребром с части ракурсов (нормаль карточки
    /// зависит от ориентации оси — см. комментарий у AddNeedle), крест решает это так же,
    /// как уже решил для игл. В отличие от иглы, ножке не нужен альфа-крой — она короткая
    /// и толстая, сплошного цвета (как раньше AddBranch) достаточно, поэтому вершины идут
    /// БЕЗ явных UV — 6-арг. AddVertex сам подставляет непрозрачную ячейку атласа
    /// (FoliageAtlas.SolidU/V), то есть рендерится идентично прежнему цилиндру.
    /// </summary>
    private static void AddPetiole(PlantMeshData mesh, Vec3 baseP, Vec3 tipP, float radius, float r, float g, float b)
    {
        var axis = Sub(tipP, baseP);
        float len = Len(axis);
        if (len < 1e-5f) return;
        axis = Mul(axis, 1f / len);
        var up = MathF.Abs(axis.Y) < 0.9f ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        var side0 = Norm(Cross(axis, up));
        var side1 = Norm(Cross(axis, side0)); // вторая плоскость, повёрнута на 90° вокруг axis

        void EmitQuad(Vec3 side)
        {
            int bi = mesh.VertexCount;
            var b0 = Sub(baseP, Mul(side, radius));
            var b1 = Add(baseP, Mul(side, radius));
            var t1 = Add(tipP, Mul(side, radius * 0.75f)); // тот же конус 1.0→0.75, что был у цилиндра
            var t0 = Sub(tipP, Mul(side, radius * 0.75f));
            mesh.AddVertex(b0.X, b0.Y, b0.Z, r, g, b);
            mesh.AddVertex(b1.X, b1.Y, b1.Z, r, g, b);
            mesh.AddVertex(t1.X, t1.Y, t1.Z, r, g, b);
            mesh.AddVertex(t0.X, t0.Y, t0.Z, r, g, b);
            mesh.AddQuad(bi, bi + 1, bi + 2, bi + 3);
        }

        EmitQuad(side0);
        EmitQuad(side1);
    }


    /// <summary>
    /// Хвоинка как alpha-cutout карточка (quad) от base к tip, текстурированная узкой
    /// заострённой «спицей» из FoliageAtlas.Needle — вместо сплошного гранёного тетраэдра.
    /// CullMode на материале отключён, поэтому один quad виден с обеих сторон.
    ///
    /// ПРАВКА (billboard-cross): раньше был ОДИН плоский quad. Его нормаль = axis × side,
    /// где side = axis × up. Если игла направлена почти горизонтально (обычный случай для
    /// бокового спрея), эта нормаль получается почти вертикальной — карточка физически лежит
    /// "плашмя", как крышка стола. С типичного, почти горизонтального ракурса камеры такая
    /// карточка видна почти ребром: крона выглядела как голый скелет с редкими штрихами
    /// НЕЗАВИСИМО от quality (число игл тут ни при чём — дело в ориентации одной карточки).
    /// Фикс: как и для листвы (AddFoliageBlob — "billboard-cross приём"), рисуем не одну,
    /// а КРЕСТ из двух карточек под 90° друг к другу вокруг оси иглы (axis). Тогда с любого
    /// разумного ракурса хотя бы одна из двух плоскостей развёрнута к камере на достаточный
    /// угол, а не обе одновременно ребром.
    /// </summary>
    /// <param name="cell">Ячейка атласа. По умолчанию одиночная хвоинка. В компактном
    /// режиме на сегмент приходится ОДНА крупная карточка, и рисовать на ней одну
    /// растянутую спицу бессмысленно: та же карточка с рисунком целой лапы или пучка
    /// стоит ровно столько же треугольников, но читается как хвоя, а не как штрих.</param>
    private static void AddNeedle(PlantMeshData mesh, Vec3 baseP, Vec3 tipP, float width, float r, float g, float b,
        (float uMin, float vMin, float uMax, float vMax)? cell = null)
    {
        var axis = Sub(tipP, baseP);
        float len = Len(axis);
        if (len < 1e-5f) return;
        axis = Mul(axis, 1f / len);
        var up = MathF.Abs(axis.Y) < 0.9f ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        var side0 = Norm(Cross(axis, up));
        var side1 = Norm(Cross(axis, side0)); // вторая плоскость, повёрнута на 90° вокруг axis

        // ПРАВКА: было *1.4 — при маске Needle с ~11% альфа-покрытия ячейки (см. FoliageAtlas)
        // это давало почти волосяную линию на дистанции витрины. Маска атласа перерисована
        // на ~26% покрытия (сопоставимо с LeafA), плюс здесь чуть увеличена геом. ширина
        // карточки — вместе это возвращает хвое видимый объём без изменения количества card'ов.
        // ПРАВКА: множитель был 1.7 — компенсировал ШИРОКУЮ веретенообразную маску (~26%
        // покрытия), которая читалась как узкий ЛИСТ (вплоть до "как у ивы" по обратной
        // связи). Маска Needle в атласе перерисована на настоящую тонкую спицу (~11%
        // покрытия, соотношение ширина:длина ≈1:12 вместо прежних ≈1:2.7). Компенсация за
        // счёт ширины карточки больше не нужна — видимость теперь даёт крестовая пара
        // (EmitQuad ×2) и кластеризация в пучок (AddNeedleTuft), а не толщина одной иглы.
        float w = Math.Max(0.005f, width) * 1.15f;

        var uv = cell ?? FoliageAtlas.Needle;

        void EmitQuad(Vec3 side)
        {
            int bi = mesh.VertexCount;
            // Карточка чуть длиннее реального base→tip, т.к. маска сама сводит края на конус к нулю
            var b0 = Sub(baseP, Mul(side, w));
            var b1 = Add(baseP, Mul(side, w));
            var t1 = Add(tipP, Mul(side, w));
            var t0 = Sub(tipP, Mul(side, w));
            mesh.AddVertex(b0.X, b0.Y, b0.Z, r, g, b, uv.uMin, uv.vMax);
            mesh.AddVertex(b1.X, b1.Y, b1.Z, r, g, b, uv.uMax, uv.vMax);
            mesh.AddVertex(t1.X, t1.Y, t1.Z, r, g, b, uv.uMax, uv.vMin);
            mesh.AddVertex(t0.X, t0.Y, t0.Z, r, g, b, uv.uMin, uv.vMin);
            mesh.AddQuad(bi, bi + 1, bi + 2, bi + 3);
        }

        EmitQuad(side0);
        EmitQuad(side1);
    }

    // ------------------------------------------------------------------
    //  Л-система: черепашка + интерпретатор (по статье с Хабра — turtle
    //  graphics, алфавит F/f/+/-/&/^/|/[/]). Здесь минимальный набор,
    //  которого хватает для органов хвои; тот же интерпретатор годится
    //  и для будущих мелких растений (кусты/цветы, тоже на Л-системах).
    //  Алфавит: F — шаг вперёд с рисованием твёрдого сегмента (AddBranch);
    //  +/- — поворот (yaw) на угол δ вокруг Up; &/^ — наклон (pitch) вокруг
    //  Side; [ / ] — сохранить/восстановить состояние черепашки (= точка
    //  ветвления); N — прикрепить одну хвоинку (AddNeedle) в текущей точке
    //  вдоль текущего Fwd.
    // ------------------------------------------------------------------
    private struct TurtleState
    {
        public Vec3 Pos, Fwd, Up, Side;
    }

    private static Vec3 RotateAroundAxis(Vec3 v, Vec3 axis, float rad)
    {
        // Формула Родрига
        axis = Norm(axis);
        var term1 = Mul(v, MathF.Cos(rad));
        var term2 = Mul(Cross(axis, v), MathF.Sin(rad));
        var term3 = Mul(axis, Dot(axis, v) * (1f - MathF.Cos(rad)));
        return Add(Add(term1, term2), term3);
    }

    /// <summary>
    /// Прогон Л-программы (строка в алфавите F+-&amp;^[]N) черепашкой из точки startPos,
    /// смотрящей вдоль startFwd. segLen — длина шага F, angleDeg — угол δ для +/-/&amp;/^,
    /// needleLen — длина каждой хвоинки N. Используется вместо разбросанного по коду
    /// ручного расчёта углов гребня/фасцикулы — сама раскладка теперь просто строка.
    /// </summary>
    private static void RunTurtleProgram(
        string program, Vec3 startPos, Vec3 startFwd, float segLen, float angleDeg,
        PlantMeshData mesh, float twigR, float twigColorR, float twigColorG, float twigColorB,
        float needleLen, SeededRandom rnd, float needleColorR, float needleColorG, float needleColorB)
    {
        var fwd = Norm(startFwd);
        if (float.IsNaN(fwd.X)) fwd = new Vec3(0, 1, 0);
        var upRef = MathF.Abs(fwd.Y) < 0.9f ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        var side = Norm(Cross(fwd, upRef));
        var up = Norm(Cross(side, fwd));
        var st = new TurtleState { Pos = startPos, Fwd = fwd, Up = up, Side = side };
        var stack = new Stack<TurtleState>();
        float ang = angleDeg * MathF.PI / 180f;

        foreach (char c in program)
        {
            switch (c)
            {
                case 'F':
                {
                    var np = Add(st.Pos, Mul(st.Fwd, segLen));
                    if (np.Y < 0.02f) np = new Vec3(np.X, 0.02f, np.Z);
                    AddBranch(mesh, st.Pos, np, twigR, twigColorR, twigColorG, twigColorB);
                    st.Pos = np;
                    break;
                }
                case '+':
                {
                    float a = ang * rnd.NextFloat(0.85f, 1.15f);
                    st.Fwd = Norm(RotateAroundAxis(st.Fwd, st.Up, a));
                    st.Side = Norm(Cross(st.Fwd, st.Up));
                    break;
                }
                case '-':
                {
                    float a = -ang * rnd.NextFloat(0.85f, 1.15f);
                    st.Fwd = Norm(RotateAroundAxis(st.Fwd, st.Up, a));
                    st.Side = Norm(Cross(st.Fwd, st.Up));
                    break;
                }
                case '&':
                {
                    float a = ang * rnd.NextFloat(0.85f, 1.15f);
                    st.Fwd = Norm(RotateAroundAxis(st.Fwd, st.Side, a));
                    st.Up = Norm(Cross(st.Side, st.Fwd));
                    break;
                }
                case '^':
                {
                    float a = -ang * rnd.NextFloat(0.85f, 1.15f);
                    st.Fwd = Norm(RotateAroundAxis(st.Fwd, st.Side, a));
                    st.Up = Norm(Cross(st.Side, st.Fwd));
                    break;
                }
                case '[':
                    stack.Push(st);
                    break;
                case ']':
                    if (stack.Count > 0) st = stack.Pop();
                    break;
                case 'N':
                {
                    float nl = needleLen * rnd.NextFloat(0.85f, 1.15f);
                    var tip = Add(st.Pos, Mul(st.Fwd, nl));
                    if (tip.Y < 0.02f) tip = new Vec3(tip.X, 0.02f, tip.Z);
                    var baseN = st.Pos;
                    if (baseN.Y < 0.02f) baseN = new Vec3(baseN.X, 0.02f, baseN.Z);
                    float rr = Clamp01(needleColorR + rnd.NextFloat(-0.02f, 0.02f));
                    float gg = Clamp01(needleColorG + rnd.NextFloat(-0.03f, 0.03f));
                    float bb = Clamp01(needleColorB + rnd.NextFloat(-0.015f, 0.015f));
                    AddNeedle(mesh, baseN, tip, nl * 0.05f, rr, gg, bb);
                    break;
                }
            }
        }
    }

    /// <summary>
    /// Пучок игольчатых карточек вокруг общей базовой точки — общий примитив и для
    /// одиночной хвоинки Fir (bladeCount=1-2, широкий конус), и для настоящей фасцикулы
    /// Pine (bladeCount=3, узкий конус, длинные почти параллельные иглы). Параметры
    /// разведены явно: spreadRadius — джиттер базовой точки (у фасцикулы почти 0, иглы
    /// растут из одного места; у одиночной иглы тоже мал), bladeLen — длина иглы,
    /// coneSpreadMin/Max — разброс направления вокруг outDir в радианах (у фасцикулы
    /// узкий — иглы почти параллельны; у одиночной иглы шире — естественный разброс).
    /// </summary>
    private static void AddNeedleTuft(
        PlantMeshData mesh, Vec3 center, Vec3 outDir, float spreadRadius, float bladeLen,
        float coneSpreadMin, float coneSpreadMax, int bladeCount,
        SeededRandom rnd, float r, float g, float b)
    {
        var od = Norm(outDir);
        if (float.IsNaN(od.X)) od = new Vec3(0, 1, 0);
        var up = MathF.Abs(od.Y) < 0.9f ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        var side = Norm(Cross(od, up));
        var perp = Norm(Cross(side, od));

        for (int i = 0; i < bladeCount; i++)
        {
            float coneAng = rnd.NextFloat(0f, MathF.PI * 2f);
            float coneSpread = rnd.NextFloat(coneSpreadMin, coneSpreadMax);
            var radialOff = Add(Mul(side, MathF.Cos(coneAng)), Mul(perp, MathF.Sin(coneAng)));
            var bladeDir = Norm(Add(Mul(od, MathF.Cos(coneSpread)), Mul(radialOff, MathF.Sin(coneSpread))));
            if (float.IsNaN(bladeDir.X)) bladeDir = od;

            var jitter = new Vec3(
                rnd.NextFloat(-spreadRadius, spreadRadius),
                rnd.NextFloat(-spreadRadius, spreadRadius) * 0.6f,
                rnd.NextFloat(-spreadRadius, spreadRadius));
            var baseP = Add(center, jitter);

            float len = bladeLen * rnd.NextFloat(0.88f, 1.12f);
            var tip = Add(baseP, Mul(bladeDir, len));

            if (tip.Y < 0.02f) tip = new Vec3(tip.X, 0.02f, tip.Z);
            if (baseP.Y < 0.02f) baseP = new Vec3(baseP.X, 0.02f, baseP.Z);

            float rr = Clamp01(r + rnd.NextFloat(-0.02f, 0.02f));
            float gg = Clamp01(g + rnd.NextFloat(-0.03f, 0.03f));
            float bb = Clamp01(b + rnd.NextFloat(-0.015f, 0.015f));

            // Тонкое соотношение ширина:длина (≈1:9 с учётом множителя *1.15 в AddNeedle) —
            // держит силуэт "иглы", а не "листа" (см. правку маски Needle в атласе выше).
            AddNeedle(mesh, baseP, tip, len * 0.05f, rr, gg, bb);
        }
    }

    /// <summary>
    /// Игольчатая "ветка-пёрышко" (frond/branchlet) — короткий древесный стержень (rachis) с
    /// иглами, растущими гребнем по обе стороны под ~45-50°. Сам проект SeedThree, чьи
    /// параметры используются для форм деревьев, прямо предупреждает в своей документации:
    /// "A radial burst from one point reads as a grass tuft on the tree, not a conifer" —
    /// именно этим и был веер AddNeedleTuft для одиночных игл Fir/Douglas Fir (в отличие от
    /// настоящих pine-фасцикул, где пучок из одной точки — правильная ботаника, см. вызов
    /// ниже с needlesPerFascicle). Здесь — гребень вдоль стержня, а не веер из точки.
    /// </summary>
    private static void AddNeedleFrond(
        PlantMeshData mesh, Vec3 baseP, Vec3 outDir, float rachisLen, int pairCount,
        float needleLen, SeededRandom rnd, float r, float g, float b)
    {
        var od = Norm(outDir);
        if (float.IsNaN(od.X)) od = new Vec3(0, 1, 0);
        var up = MathF.Abs(od.Y) < 0.9f ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        var side = Norm(Cross(od, up));

        var rachisEnd = Add(baseP, Mul(od, rachisLen));
        // ПРАВКА (перф): раньше здесь рисовался полноценный 4-гранный цилиндр-стержень
        // (AddBranch, 8 треугольников) НА КАЖДОЙ позиции гребня — а таких позиций на одном
        // дереве тысячи (замерено реальным запуском генератора: Fir q:6 — под 1 млн вершин
        // на одно дерево, из них заметная доля — этот почти невидимый под иглами стержень).
        // rachisEnd по-прежнему нужен как виртуальная линия для расстановки игл — просто
        // саму геометрию стержня больше не рисуем.

        const float combAngle = 50f * MathF.PI / 180f; // ~50° от стержня, гребнем по обе стороны
        for (int i = 0; i < pairCount; i++)
        {
            float t = (i + 0.5f) / pairCount;
            var pos = Lerp(baseP, rachisEnd, t);
            if (pos.Y < 0.02f) pos = new Vec3(pos.X, 0.02f, pos.Z);

            for (int sgn = -1; sgn <= 1; sgn += 2)
            {
                var needleDir = Norm(Add(Mul(od, MathF.Cos(combAngle)), Mul(side, sgn * MathF.Sin(combAngle))));
                needleDir = Norm(Add(needleDir, new Vec3(
                    rnd.NextFloat(-0.10f, 0.10f), rnd.NextFloat(-0.08f, 0.02f), rnd.NextFloat(-0.10f, 0.10f))));
                if (float.IsNaN(needleDir.X)) needleDir = od;

                float nl = needleLen * rnd.NextFloat(0.85f, 1.15f);
                var tip = Add(pos, Mul(needleDir, nl));
                if (tip.Y < 0.02f) tip = new Vec3(tip.X, 0.02f, tip.Z);

                float rr = Clamp01(r + rnd.NextFloat(-0.02f, 0.02f));
                float gg = Clamp01(g + rnd.NextFloat(-0.03f, 0.03f));
                float bb = Clamp01(b + rnd.NextFloat(-0.015f, 0.015f));

                AddNeedle(mesh, pos, tip, nl * 0.05f, rr, gg, bb);
            }
        }
    }

    /// <summary>
    /// Кластер листвы как 2–3 «скрещённых» alpha-cutout карточки (классический billboard-cross
    /// приём) вместо сплошных гранёных тетраэдров/конусов. Каждая карточка — вертикальный quad,
    /// повёрнутый на свой азимут вокруг Y, с текстурой листа из FoliageAtlas (LeafA/LeafB —
    /// вперемешку для разнообразия силуэта). CullMode на материале отключён, поэтому карточка
    /// видна с обеих сторон без доп. геометрии.
    /// Параметр <paramref name="conical"/> сохранён для совместимости вызовов и сейчас не влияет
    /// на форму — форму даёт альфа-маска атласа, а не полигон.
    /// </summary>
    /// <param name="leafCell">Форма листа ВИДА (см. PlantSpecies). По умолчанию
    /// округлая — прежнее поведение для видов, у которых форма не задана.</param>
    private static void AddFoliageBlob(
        PlantMeshData mesh, Vec3 center, float size, SeededRandom rnd, bool conical,
        float? cr = null, float? cg = null, float? cb = null, Vec3? branchDir = null,
        int? cardCountOverride = null,
        PlantSpecies.LeafCell leafCell = PlantSpecies.LeafCell.Rounded,
        float tintR = 1f, float tintG = 1f, float tintB = 1f)
    {
        // Вариация оттенка зелени
        float r, g, b;
        if (cr.HasValue)
        {
            r = cr.Value; g = cg!.Value; b = cb!.Value;
        }
        else
        {
            float pick = rnd.NextFloat(0f, 1f);
            if (pick < 0.35f) { r = FoDarkR; g = FoDarkG; b = FoDarkB; }
            else if (pick < 0.70f) { r = FoR; g = FoG; b = FoB; }
            else { r = FoR2; g = FoG2; b = FoB2; }
            // лёгкий шум
            r = Clamp01(r + rnd.NextFloat(-0.03f, 0.03f));
            g = Clamp01(g + rnd.NextFloat(-0.04f, 0.04f));
            b = Clamp01(b + rnd.NextFloat(-0.02f, 0.02f));
        }

        // Оттенок ВИДА поверх общей вариации: у дуба листва темнее и желтее, у берёзы
        // светлее и холоднее. Множители по умолчанию единичные, поэтому вызовы без
        // указания вида ведут себя как прежде.
        r = Clamp01(r * tintR);
        g = Clamp01(g * tintG);
        b = Clamp01(b * tintB);

        var dir = branchDir ?? new Vec3(0, 1, 0);
        // Раньше тут всегда 2-3 СКРЕЩЁННЫХ карточки — приём для облака-кластера листвы без
        // индивидуальных черешков. Теперь, когда у каждого листа есть настоящая ножка
        // (петиола), один вызов = один физический лист, и крестовина из нескольких карточек
        // в одной точке выглядит как растопыренная звёздочка/игла, а не как одна пластинка.
        // cardCountOverride=1 используется именно для этого случая.
        int cards = cardCountOverride ?? (2 + rnd.NextInt(2));
        float baseAngle = rnd.NextFloat(0f, MathF.PI);
        for (int k = 0; k < cards; k++)
        {
            // Было ±0.30/±0.22/±0.30 от size — с выросшим размером карточек (плотность
            // листвы) абсолютное смещение выросло вместе с ним и стало местами больше
            // толщины самой ветки, из-за чего отдельные карточки визуально отрывались от
            // неё ("висели в воздухе"). Уменьшено.
            var jitter = new Vec3(
                rnd.NextFloat(-size, size) * 0.16f,
                rnd.NextFloat(-size, size) * 0.12f,
                rnd.NextFloat(-size, size) * 0.16f);
            var c = Add(center, jitter);
            float s = size * rnd.NextFloat(0.95f, 1.35f); // карточка компенсирует пустые поля альфа-маски
            float angle = baseAngle + k * (MathF.PI / cards) + rnd.NextFloat(-0.2f, 0.2f);
            // ФОРМА ЛИСТА — ПРИЗНАК ВИДА. Раньше ячейка атласа выбиралась случайно на
            // КАЖДЫЙ лист (LeafA с вероятностью 0.6, иначе LeafB), поэтому на одном
            // дереве оказывались вперемешку округлые и узкие листья. У настоящего
            // дерева форма листа постоянна — она и есть главный видовой признак.
            // В КОМПАКТНОМ РЕЖИМЕ — ПУЧОК, а не одиночный лист.
            //
            // На уровне карточка вынужденно крупная: покрытие кроны при ограниченном
            // числе треугольников иначе не набрать. С одиночным листом в ячейке это
            // давало двухметровые лопухи (замер: 2.33 м при натурных 12 см). Пучок
            // натуральных листьев на веточке при том же размере карточки читается
            // правильно, а густоту несёт рисунок, а не масштаб.
            var uv = Detail == FoliageDetail.Compact
                ? FoliageAtlas.ClusterFor(leafCell)
                : leafCell switch
            {
                PlantSpecies.LeafCell.Oak => FoliageAtlas.LeafOak,
                PlantSpecies.LeafCell.Birch => FoliageAtlas.LeafBirch,
                PlantSpecies.LeafCell.Maple => FoliageAtlas.LeafMaple,
                PlantSpecies.LeafCell.Willow => FoliageAtlas.LeafWillow,
                PlantSpecies.LeafCell.Hazel => FoliageAtlas.LeafHazel,
                PlantSpecies.LeafCell.Grass => FoliageAtlas.GrassBlade,
                PlantSpecies.LeafCell.Petal => FoliageAtlas.Petal,
                PlantSpecies.LeafCell.Narrow => FoliageAtlas.LeafWillow,
                PlantSpecies.LeafCell.Needle => FoliageAtlas.Needle,
                _ => FoliageAtlas.LeafOak,
            };
            // Персональный случайный наклон на каждую карточку, поверх общего branchDir —
            // без этого все карточки на гладком (после сглаживания скелета) участке ветки
            // получали почти одинаковое направление и выглядели одним плоским "веером"
            // вместо естественно разбросанной листвы. Реальные листья ориентируются к свету
            // довольно независимо от точного угла своей веточки.
            var cardDir = Norm(Add(dir, new Vec3(
                rnd.NextFloat(-0.6f, 0.6f), rnd.NextFloat(-0.4f, 0.4f), rnd.NextFloat(-0.6f, 0.6f))));
            // V111: больше вертикальных карточек — объём сбоку, не стопка блинов
            float upW = rnd.NextFloat(0.12f, 0.78f);
            AddVerticalCard(mesh, c, s, angle, cardDir, uv, r, g, b, upW);
        }
    }

    /// <summary>
    /// Alpha-cutout quad. Присланные материалы по расстановке листвы прямо указывают:
    /// пластинка листа держится ПОЧТИ ГОРИЗОНТАЛЬНО (к свету), с небольшим наклоном —
    /// а не "стоит" вертикально. Прошлые версии этой функции строили карточку так, что её
    /// плоскость почти всегда СОДЕРЖАЛА вертикаль (карточка стояла, как флажок) — именно
    /// поэтому переориентация на branchDir/petioleDir почти не меняла общую картину на
    /// глаз: главная, доминирующая ось всё равно оставалась вертикальной.
    /// Теперь нормаль плоскости карточки — почти мировой верх (лист "смотрит" в небо),
    /// с небольшой примесью направления ножки/ветки для наклона. Обе оси карточки лежат
    /// в этой почти-горизонтальной плоскости.
    /// </summary>
    private static void AddVerticalCard(
        PlantMeshData mesh, Vec3 center, float size, float angle, Vec3 branchDir,
        (float uMin, float vMin, float uMax, float vMax) uv, float r, float g, float b,
        float upWeight = 0.55f)
    {
        var worldUp = new Vec3(0, 1, 0);
        var bd = Norm(branchDir);
        if (float.IsNaN(bd.X)) bd = worldUp;
        float uw = Math.Clamp(upWeight, 0.05f, 0.95f);
        var normal = Norm(Add(Mul(worldUp, uw), Mul(bd, 1f - uw)));
        if (float.IsNaN(normal.X)) normal = worldUp;
        var aux = MathF.Abs(normal.Y) < 0.97f ? worldUp : new Vec3(1, 0, 0);
        var axis1_0 = Norm(Cross(aux, normal));
        var normalXaxis1 = Cross(normal, axis1_0);
        // Поворот axis1_0 вокруг normal на angle (формула Родрига)
        var axis1 = Add(Mul(axis1_0, MathF.Cos(angle)), Mul(normalXaxis1, MathF.Sin(angle)));
        var axis2 = Cross(normal, axis1);

        float hw = size * 0.5f;
        float hh = size * 0.55f;
        var c = Add(center, Mul(normal, size * 0.05f));

        int bi = mesh.VertexCount;
        var bl = Sub(Sub(c, Mul(axis1, hw)), Mul(axis2, hh));
        var br = Sub(Add(c, Mul(axis1, hw)), Mul(axis2, hh));
        var tr = Add(Add(c, Mul(axis1, hw)), Mul(axis2, hh));
        var tl = Add(Sub(c, Mul(axis1, hw)), Mul(axis2, hh));
        mesh.AddVertex(bl.X, bl.Y, bl.Z, r, g, b, uv.uMin, uv.vMax);
        mesh.AddVertex(br.X, br.Y, br.Z, r, g, b, uv.uMax, uv.vMax);
        mesh.AddVertex(tr.X, tr.Y, tr.Z, r, g, b, uv.uMax, uv.vMin);
        mesh.AddVertex(tl.X, tl.Y, tl.Z, r, g, b, uv.uMin, uv.vMin);
        mesh.AddQuad(bi, bi + 1, bi + 2, bi + 3);
    }

    private static Vec3 SampleTrunk(Vec3[] pts, float y)
    {
        for (int i = 0; i < pts.Length - 1; i++)
        {
            if (y <= pts[i + 1].Y || i == pts.Length - 2)
            {
                float span = pts[i + 1].Y - pts[i].Y;
                float tt = span > 1e-5f ? (y - pts[i].Y) / span : 0f;
                if (tt < 0f) tt = 0f;
                if (tt > 1f) tt = 1f;
                return Lerp(pts[i], pts[i + 1], tt);
            }
        }
        return pts[pts.Length - 1];
    }

    private struct Node
    {
        public Vec3 Pos;
        public int Parent;

        /// <summary>
        /// ПОРЯДОК ВЕТВЛЕНИЯ (depth в терминах статьи по space colonization): число
        /// развилок между корневой ветвью и этой. Нужен для формулы (3) той же
        /// статьи, задающей длину сегмента:
        ///     l = l_min + (l_max - l_min) / (1 + e^(depth - 10))
        /// У основания сегменты длинные, к концам короткие. Без этого все сегменты
        /// дерева одной длины, иерархии ветвей нет и крона читается как метла.
        /// </summary>
        public int Order;
        // Персистентный "уклон" ветки, наследуется от родителя с небольшой мутацией на
        // каждом шаге роста (см. GenerateColonizedTree). В отличие от независимого шума на
        // каждом шаге (который в среднем гасится и тянет ветку обратно к детерминированному
        // направлению — attraction + tropism), накопленный Wander даёт каждой линии веток
        // свой устойчивый персональный изгиб, из-за чего дерево не выглядит одинаково
        // симметричным во всех развилках.
        public Vec3 Wander;
    }

    private struct Vec3
    {
        public float X, Y, Z;
        public Vec3(float x, float y, float z) { X = x; Y = y; Z = z; }
    }

    private static Vec3 Add(Vec3 a, Vec3 b) => new(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
    private static Vec3 Sub(Vec3 a, Vec3 b) => new(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
    private static Vec3 Mul(Vec3 a, float s) => new(a.X * s, a.Y * s, a.Z * s);
    private static float Dot(Vec3 a, Vec3 b) => a.X * b.X + a.Y * b.Y + a.Z * b.Z;
    private static float Len(Vec3 a) => MathF.Sqrt(a.X * a.X + a.Y * a.Y + a.Z * a.Z);
    private static float DistSq(Vec3 a, Vec3 b)
    {
        float dx = a.X - b.X, dy = a.Y - b.Y, dz = a.Z - b.Z;
        return dx * dx + dy * dy + dz * dz;
    }
    private static Vec3 Norm(Vec3 a)
    {
        float l = Len(a);
        return l > 1e-8f ? Mul(a, 1f / l) : new Vec3(0, 1, 0);
    }
    private static Vec3 Cross(Vec3 a, Vec3 b) =>
        new(a.Y * b.Z - a.Z * b.Y, a.Z * b.X - a.X * b.Z, a.X * b.Y - a.Y * b.X);
    private static void HsvToRgb(float h, float s, float v, out float r, out float g, out float b)
    {
        h = (h % 1f + 1f) % 1f; // на случай отрицательного остатка
        int hi = (int)(h * 6f) % 6;
        float f = h * 6f - (int)(h * 6f);
        float p = v * (1f - s);
        float q = v * (1f - f * s);
        float t = v * (1f - (1f - f) * s);
        switch (hi)
        {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
    }

    private static Vec3 Lerp(Vec3 a, Vec3 b, float t) =>
        new(a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t, a.Z + (b.Z - a.Z) * t);
    private static float Clamp01(float v) => v < 0f ? 0f : (v > 1f ? 1f : v);
}
