using System;
using System.Collections.Generic;

namespace ColoringBook.Infrastructure.Generation.Plants;

/// <summary>
/// САМООРГАНИЗУЮЩИЙСЯ СЛОЙ роста дерева по Pałubicki et al., «Self-organizing tree
/// models for image synthesis», SIGGRAPH 2009 (файл в присланных материалах).
///
/// ЗАЧЕМ ЭТО ПОВЕРХ УЖЕ ИМЕЮЩЕГОСЯ SCA. В проекте уже есть space colonization
/// (GenerateColonizedTree) и Weber-Penn (BuildWpStem). Обе схемы задают форму кроны
/// ИЗВНЕ: SCA — через облако точек притяжения, Weber-Penn — через параметры силуэта.
/// Статья 2009 года устроена иначе: форма не задаётся, а ВОЗНИКАЕТ из конкуренции
/// почек за свет. Отсюда три механизма, которых у нас не было ни одного:
///
///   1. РАСПРОСТРАНЕНИЕ ТЕНИ (§4.1). Каждая почка отбрасывает вниз пирамидальную
///      полутень в воксельной сетке; освещённость почки Q = max(C - s + a, 0).
///      Это даёт то, чего точки притяжения не дают в принципе: ветка в глубине
///      кроны получает меньше света, чем ветка снаружи, и ведёт себя иначе.
///
///   2. СУДЬБА ПОЧКИ (§4.2). Почка с малым Q не растёт (остаётся спящей или
///      отмирает). У нас раньше росли ВСЕ узлы, до которых дотянулись точки
///      притяжения, отчего крона получалась равномерно плотной.
///
///   3. СБРОС ВЕТВЕЙ (§4.4). Если суммарный свет ветви, делённый на её размер в
///      междоузлиях, ниже порога, ветвь — обуза для дерева и сбрасывается. Именно
///      это, по статье, формирует высокий чистый ствол (Fig. 14): нижние
///      затенённые ветви отмирают. Раньше в коде про это был только комментарий
///      у сосны, что «у взрослых нижние ветви отмирают», но механизма не было.
///
/// Направление роста (§4.3) считается как взвешенная сумма трёх векторов: своё
/// направление, направление к свету (вес ξ) и тропизм (вес η).
///
/// Класс НЕ ЗАВИСИТ ОТ GODOT.
/// </summary>
public static class SelfOrganizing
{
    /// <summary>
    /// Воксельная сетка теней. Почка в вокселе (I,J,K) затемняет воксели под собой:
    /// (I±p, J-q, K±p), где q = 0..qmax, p = 0..q, добавляя s += a * b^(-q).
    /// </summary>
    public sealed class ShadowGrid
    {
        private readonly float[] _s;
        private readonly int _nx, _ny, _nz;
        private readonly float _cell;
        private readonly float _minX, _minY, _minZ;

        public float A = 0.9f;      // вклад самой почки
        public float B = 1.8f;      // во сколько раз слабеет тень на слой ниже
        public int QMax = 5;        // глубина полутени в слоях (в статье 4..8)
        public float C = 2.4f;      // «полная освещённость»

        public ShadowGrid(float minX, float minY, float minZ,
                          float sizeX, float sizeY, float sizeZ, float cell)
        {
            _cell = MathF.Max(cell, 1e-3f);
            _minX = minX; _minY = minY; _minZ = minZ;
            _nx = Math.Clamp((int)(sizeX / _cell) + 2, 2, 96);
            _ny = Math.Clamp((int)(sizeY / _cell) + 2, 2, 96);
            _nz = Math.Clamp((int)(sizeZ / _cell) + 2, 2, 96);
            _s = new float[_nx * _ny * _nz];
        }

        public void Clear() => Array.Clear(_s, 0, _s.Length);

        private bool ToCell(float x, float y, float z, out int i, out int j, out int k)
        {
            i = (int)((x - _minX) / _cell);
            j = (int)((y - _minY) / _cell);
            k = (int)((z - _minZ) / _cell);
            return (uint)i < _nx && (uint)j < _ny && (uint)k < _nz;
        }


        /// <summary>Освещённость точки: Q = max(C - s + A, 0). Слагаемое A —
        /// допущение статьи, что почка не затеняет саму себя.</summary>
        public float Light(float x, float y, float z)
        {
            if (!ToCell(x, y, z, out int i, out int j, out int k)) return C;
            float s = _s[(j * _nz + k) * _nx + i];
            return MathF.Max(C - s + A, 0f);
        }

    }

    /// <summary>Узел скелета в терминах статьи: междоузлие с почкой на конце.</summary>
    public struct SoNode
    {
        public int Parent;
        public float X, Y, Z;
        public float Light;      // Q, освещённость почки
        public float Resource;   // v, доставшийся ресурс (модель Борхерта-Хонды)
        public bool Alive;
    }




}
