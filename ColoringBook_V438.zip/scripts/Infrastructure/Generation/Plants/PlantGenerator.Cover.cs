using System;
using ColoringBook.Domain.Level;
using ColoringBook.Infrastructure.Generation;

namespace ColoringBook.Infrastructure.Generation.Plants;

// ------------------------------------------------------------------
//  Покрытия земли: трава, мох, камни.
//
//  Главное отличие от деревьев/кустов — БЮДЖЕТ. Деревьев на уровне сотни, покрытий
//  будут десятки тысяч, поэтому здесь важен не силуэт отдельного объекта, а стоимость
//  одного экземпляра. Ориентир: единицы-десятки треугольников, не сотни.
//
//  Поэтому здесь СОЗНАТЕЛЬНО не используется Л-система: у травинки нет ветвления,
//  которое она описывает, а деривация строки ради трёх лезвий — лишняя работа на
//  ровном месте. Тот же принцип, что и с иглами хвои: прямой примитив дешевле.
// ------------------------------------------------------------------
public static partial class PlantGenerator
{
    /// <summary>
    /// КУРТИНА — группа растений на одной подошве, а не одиночный пучок.
    ///
    /// ЗАЧЕМ. Расчёт покрытия: уровень занимает 21 609 квадратных мировых единиц,
    /// одиночный пучок покрывал около 0.0025, и четырнадцати тысяч пучков хватало на
    /// 0.17% поверхности. Чтобы земля выглядела задернованной, экземпляров нужно в
    /// сотни раз больше — это миллионы, и ни в один бюджет они не помещаются.
    ///
    /// Выход — не множить экземпляры, а укрупнять их. Одна куртина радиусом около
    /// четверти единицы покрывает 0.2, то есть в восемьдесят раз больше пучка, а стоит
    /// впятеро дороже. При том же числе экземпляров покрытие вырастает с 0.17% до
    /// 13%, а с учётом того, что куртины ставятся полями, на лугу оно куда выше.
    ///
    /// СОСТАВ КУРТИНЫ ЗАВИСИТ ОТ ВАРИАНТА. Варианты уже есть в каталоге по пять на
    /// вид, и разделение по ним ничего не стоит: это те же группы MultiMesh:
    ///   0, 1 — чистая трава;
    ///   2, 3 — трава с цветами;
    ///   4    — трава с камнями и мхом (опушка, каменистый луг).
    /// Иначе пришлось бы заводить новые значения VegetationKind и тянуть их через
    /// все таблицы высот, LOD и размещения.
    /// </summary>
    private static PlantMeshData GenerateGrassTuft(SeededRandom rnd, PlantGenome g)
    {
        int q = Math.Clamp(QualityLevel, 0, 12);
        float h = 0.38f * g.HeightMul; // V124
        var mesh = new PlantMeshData { LocalHeight = h };

        
        // V144: составов стало три (PlantSpecies.GroundPatches), и признак берётся
        // по НОМЕРУ ВИДА, а не по индексу варианта: варианты чередуют составы, и
        // жёсткая привязка к номеру варианта развалилась бы при смене их числа.
        int comp = g.Species % 3;
        bool withFlowers = comp == 1;
        bool withStones = comp == 2;

        // Радиус куртины в долях её высоты. Подошва шире высоты: трава ложится,
        // а не стоит столбом, и именно ширина подошвы даёт покрытие.
        // Подошва сужена с 3.4 до 2.0 высоты. При широкой подошве 34 карточки
        // расползались, и на отрисовке куртина читалась как горсть отдельных длинных
        // травинок, а не как дернина. Покрытие площади при этом падает втрое, но его
        // и не должно давать геометрия: сплошной ковёр рисует шейдер рельефа, а
        // куртины нужны для ближнего плана, где важна плотность, а не площадь.
        // V116: шире подошва — один фрагмент закрывает пятно, не точку
        // ---- V132: ДЕРНИНА, А НЕ БЛИН ----
        //
        // Замер: радиус/высота = 11.1. При высоте 34 см это круг радиусом 3.8 метра —
        // лезвия разбросаны по семиметровому пятну, и на кадре это редкие штрихи по
        // земле, а не дёрн. Настоящая дернина плотная: радиус сопоставим с высотой.
        //
        // Сплошной ковёр всё равно рисует шейдер рельефа (grass_detail), а мешам
        // остаётся ближний круг, где важен объём у ног. Плотный пучок при том же
        // числе лезвий выглядит травой, а разреженный блин — мусором.
        float spread = h * (withStones ? 1.1f : 1.4f);

        // Лезвий на куртину. Каждое — карточка в 2 треугольника.
        // ---- V128: КУРТИНА ВТРОЕ ДЕШЕВЛЕ ПРИ ТОЙ ЖЕ ПОДОШВЕ ----
        //
        // 280 лезвий — это 1300 треугольников на куртину. При плотности 2.5 на
        // квадратную единицу круг радиусом даже в девять единиц даёт 640 куртин и
        // 860 тысяч треугольников на одну траву. Между тем сплошной ковёр рисует
        // шейдер рельефа, а мешам остаётся ближний круг, где важна не площадь, а
        // объём у ног. Лезвий втрое меньше, каждое шире — силуэт дернины держится.
        // ---- V146: КРЕСТОВЫЕ КАРТОЧКИ ВМЕСТО ОТДЕЛЬНЫХ ЛЕЗВИЙ ----
        //
        // Приём стандартный (cross-quads): вместо одиночной карточки ставится две-три
        // пересекающиеся под углом. Клочок читается густым с любого направления, тогда
        // как отдельные лезвия с части ракурсов видны ребром и пропадают.
        //
        // Выигрыш в том, что густота берётся РИСУНКОМ карточки, а не числом лезвий:
        // тридцать крестов дают вид девяноста лезвий и стоят вчетверо меньше. Это и
        // позволило отодвинуть дистанцию показа с 20 до 50 метров, не выйдя из бюджета.
        // Крестов в куртине. Замер после первой прикидки: 30 крестов при радиусе
        // показа 5 давали 709 тысяч треугольников — вдвое выше всего бюджета сцены.
        // Восемнадцать при вдвое более широкой карточке дают тот же силуэт клочка.
        int clumps = (Detail == FoliageDetail.Compact ? 18 : 30) + Math.Min(q, 6) * 2;
        float baseR = 0.34f, baseG = 0.62f, baseB = 0.26f;

        for (int i = 0; i < clumps; i++)
        {
            // Точки расходятся от центра по золотому углу с корневым радиусом —
            // так они ложатся равномерно по кругу, а не сбиваются к середине,
            // как при равномерном броске радиуса.
            float t = (i + 0.5f) / clumps;
            float rad = spread * MathF.Sqrt(t) * rnd.NextFloat(0.75f, 1.0f);
            float aRad = i * GoldenAngleRad + rnd.NextFloat(-0.3f, 0.3f);
            float ox = MathF.Cos(aRad) * rad;
            float oz = MathF.Sin(aRad) * rad;

            float ang = rnd.NextFloat(0f, MathF.PI * 2f);
            // К краю куртины трава ниже и наклоннее — силуэт получается подушкой,
            // а не диском с обрывом по краю.
            float edge = 1f - 0.45f * t;
            float lean = rnd.NextFloat(0.05f, 0.22f) + t * 0.18f; // V124: плотнее куртина
            float len = h * rnd.NextFloat(0.60f, 1.0f) * edge;
            var dir = Norm(new Vec3(MathF.Cos(ang) * lean, 1f, MathF.Sin(ang) * lean));
            var b = new Vec3(ox, 0f, oz);
            var tip = Add(b, Mul(dir, len));
            float rr = Clamp01(baseR + rnd.NextFloat(-0.05f, 0.05f));
            float gg = Clamp01(baseG + rnd.NextFloat(-0.08f, 0.08f));
            float bb = Clamp01(baseB + rnd.NextFloat(-0.04f, 0.04f));
            // Крест: две карточки под 60° друг к другу вокруг оси клочка. Ширина
            // втрое больше прежнего лезвия — карточка изображает пучок, а не травинку.
            AddNeedle(mesh, b, tip, len * 0.42f, rr, gg, bb, FoliageAtlas.GrassBlade);
            var perp = Norm(Cross(Sub(tip, b), new Vec3(0.5f, 0f, 0.87f)));
            var tip2 = Add(b, Add(Mul(Sub(tip, b), 0.94f), Mul(perp, len * 0.10f)));
            AddNeedle(mesh, b, tip2, len * 0.42f, rr, gg * 0.94f, bb, FoliageAtlas.GrassBlade);
        }

        if (withFlowers)
        {
            // Цветы В КУРТИНЕ, а не отдельными экземплярами. Так они попадают ровно
            // туда, где трава, и не требуют собственной группы MultiMesh — а именно
            // редкие группы и составляли основную часть вызовов отрисовки.
            int heads = (Detail == FoliageDetail.Compact ? 14 : 22) + Math.Min(q, 6); // V117
            for (int i = 0; i < heads; i++)
            {
                float t = (i + 0.5f) / heads;
                float rad = spread * MathF.Sqrt(t) * rnd.NextFloat(0.5f, 0.95f);
                float aRad = i * GoldenAngleRad * 1.7f + rnd.NextFloat(-0.4f, 0.4f);
                var b = new Vec3(MathF.Cos(aRad) * rad, 0f, MathF.Sin(aRad) * rad);
                float stem = h * rnd.NextFloat(0.85f, 1.25f);
                var tip = Add(b, new Vec3(rnd.NextFloat(-0.05f, 0.05f), stem, rnd.NextFloat(-0.05f, 0.05f)));
                // Стебель зелёный, венчик — своим цветом.
                AddNeedle(mesh, b, tip, stem * 0.030f, 0.32f, 0.55f, 0.24f, FoliageAtlas.GrassBlade);
                var pal = FlowerPalette(rnd);
                AddFoliageBlob(mesh, tip, stem * 0.22f, rnd, conical: false,
                    pal.r, pal.g, pal.b, new Vec3(0, 1, 0), leafCell: PlantSpecies.LeafCell.Petal);
            }
        }

        if (withStones)
        {
            int stones = 4 + rnd.NextInt(4); // V116
            for (int i = 0; i < stones; i++)
            {
                float rad = spread * rnd.NextFloat(0.2f, 0.9f);
                float aRad = rnd.NextFloat(0f, MathF.PI * 2f);
                var b = new Vec3(MathF.Cos(aRad) * rad, 0f, MathF.Sin(aRad) * rad);
                float sr = h * rnd.NextFloat(0.20f, 0.45f);
                // Камень рисуется той же плоской массой, что и мох: на такой величине
                // объёмный камень неотличим от пятна, а стоит вчетверо дороже.
                AddFoliageBlob(mesh, Add(b, new Vec3(0, sr * 0.25f, 0)), sr, rnd, conical: false,
                    0.52f, 0.50f, 0.46f, new Vec3(0, 1, 0), leafCell: PlantSpecies.LeafCell.Rounded);
            }
            int mossN = 3 + rnd.NextInt(4);
            for (int i = 0; i < mossN; i++)
            {
                float rad = spread * rnd.NextFloat(0.1f, 0.85f);
                float aRad = rnd.NextFloat(0f, MathF.PI * 2f);
                var mb = new Vec3(MathF.Cos(aRad) * rad, 0.01f, MathF.Sin(aRad) * rad);
                float sz = h * rnd.NextFloat(0.12f, 0.28f);
                AddFoliageBlob(mesh, mb, sz, rnd, conical: false,
                    0.22f, 0.42f, 0.20f, new Vec3(0, 1, 0), cardCountOverride: 1);
            }
        }

        return mesh;
    }

    /// <summary>Цвет венчика: жёлтый, белый, лиловый или розовый — палитра
    /// альпийского разнотравья.</summary>
    private static (float r, float g, float b) FlowerPalette(SeededRandom rnd)
        => rnd.NextInt(4) switch
        {
            0 => (0.96f, 0.86f, 0.28f),
            1 => (0.95f, 0.95f, 0.92f),
            2 => (0.72f, 0.55f, 0.86f),
            _ => (0.92f, 0.52f, 0.66f),
        };

    /// <summary>
    /// Мох/лишайник: несколько почти горизонтальных пятен у самой земли. Не торчит вверх —
    /// именно этим отличается от травы и читается как «налёт» на камне и в тени леса.
    /// </summary>
    private static PlantMeshData GenerateMoss(SeededRandom rnd, PlantGenome g)
    {
        int q = Math.Clamp(QualityLevel, 0, 12);
        float h = 0.07f;
        var mesh = new PlantMeshData { LocalHeight = h };

        int patches = 2 + Math.Min(q, 6) / 3; // 2..4 пятна
        for (int i = 0; i < patches; i++)
        {
            float ox = rnd.NextFloat(-0.13f, 0.13f);
            float oz = rnd.NextFloat(-0.13f, 0.13f);
            float oy = rnd.NextFloat(0.004f, 0.03f);
            float size = rnd.NextFloat(0.10f, 0.20f);
            float rr = Clamp01(0.24f + rnd.NextFloat(-0.05f, 0.05f));
            float gg = Clamp01(0.46f + rnd.NextFloat(-0.07f, 0.09f));
            float bb = Clamp01(0.20f + rnd.NextFloat(-0.04f, 0.06f));
            // Нормаль вверх — пятно лежит на земле, а не стоит ребром.
            AddFoliageBlob(mesh, new Vec3(ox, oy, oz), size, rnd, conical: false,
                rr, gg, bb, new Vec3(0, 1, 0), cardCountOverride: 1);
        }
        return mesh;
    }

    /// <summary>
    /// Камень: низкополигональный валун — восьмигранная «шапка» с неровным радиусом.
    /// 8 боковых треугольников + 8 на верх = 16 треугольников, независимо от quality:
    /// у камня нет уровня детализации, который стоил бы дополнительных полигонов на
    /// общем плане, а экземпляров очень много.
    /// </summary>
    /// <summary>
    /// КАМЕННАЯ КУРТИНА: группа валунов, часть из них покрыта мхом и лишайником.
    ///
    /// Одиночный валун был отключён от размещения 02.08 — он читался как мусор поверх
    /// рельефа. Причина та же, что у одиночного пучка травы: объект слишком мелкий,
    /// чтобы прочитаться сам по себе, и слишком редкий, чтобы прочитаться массой.
    /// Группой камни выглядят курумником, а не сором, и заодно закрывают осыпь и
    /// скалу — биомы, где на замере приходилось 0.28–0.50 растения на регион при
    /// 4.9 в лесу.
    ///
    /// Варианты: 0–2 голый камень, 3–4 камень со мхом и лишайником.
    /// </summary>
    private static PlantMeshData GenerateStone(SeededRandom rnd, PlantGenome g)
    {
        float h = 0.30f * g.HeightMul;
        var mesh = new PlantMeshData { LocalHeight = h };
        bool mossy = (g.Species % 5) >= 3;

        int boulders = 3 + rnd.NextInt(4);
        float spread = h * 2.6f;

        for (int k = 0; k < boulders; k++)
        {
            float t = (k + 0.5f) / boulders;
            float rad = k == 0 ? 0f : spread * MathF.Sqrt(t) * rnd.NextFloat(0.6f, 1.0f);
            float aRad = k * GoldenAngleRad + rnd.NextFloat(-0.4f, 0.4f);
            float ox = MathF.Cos(aRad) * rad, oz = MathF.Sin(aRad) * rad;
            // Главный валун крупнее спутников — иначе группа читается как горсть щебня.
            float sc = (k == 0 ? 1.0f : rnd.NextFloat(0.35f, 0.75f));
            AddBoulder(mesh, rnd, ox, oz, h * sc, 0.24f * (0.75f + g.CrownMul * 0.4f) * sc);

            if (mossy && rnd.NextFloat() < 0.7f)
            {
                // Мох ложится НА камень, а не рядом: плоская масса у его макушки.
                float my = h * sc * rnd.NextFloat(0.35f, 0.6f);
                AddFoliageBlob(mesh, new Vec3(ox, my, oz), h * sc * 0.55f, rnd, conical: false,
                    0.30f, 0.46f, 0.24f, new Vec3(0, 1, 0),
                    leafCell: PlantSpecies.LeafCell.Rounded);
            }
        }

        if (mossy)
        {
            // Между камнями — лишайник и редкая трава: так курумник перестаёт быть
            // голым и связывается с окружающим дёрном.
            int tufts = 2 + rnd.NextInt(3);
            for (int k = 0; k < tufts; k++)
            {
                float rad = spread * rnd.NextFloat(0.3f, 1.0f);
                float aRad = rnd.NextFloat(0f, MathF.PI * 2f);
                var b = new Vec3(MathF.Cos(aRad) * rad, 0f, MathF.Sin(aRad) * rad);
                var tip = Add(b, new Vec3(rnd.NextFloat(-0.05f, 0.05f), h * rnd.NextFloat(0.5f, 0.9f), rnd.NextFloat(-0.05f, 0.05f)));
                AddNeedle(mesh, b, tip, h * 0.05f, 0.36f, 0.55f, 0.26f, FoliageAtlas.GrassBlade);
            }
        }
        return mesh;
    }

    /// <summary>
    /// Один валун: купол из ДВУХ поясов вершин плюс макушка.
    ///
    /// С одним поясом силуэт получался конусом — на отрисовке камни выглядели
    /// плоскими палатками. Второй пояс даёт перегиб профиля: широкое основание,
    /// плечо и скруглённая макушка. Восемь граней на пояс и два пояса — 32
    /// треугольника на валун, при трёх-шести валунах в куртине это полсотни, что
    /// сопоставимо с прежним одиночным камнем.
    /// </summary>
    private static void AddBoulder(PlantMeshData mesh, SeededRandom rnd,
        float ox, float oz, float height, float baseR)
    {
        const int Seg = 8;
        baseR = MathF.Min(baseR, height * 0.95f);
        float topY = height * rnd.NextFloat(0.80f, 1.0f);
        float tone = rnd.NextFloat(0.42f, 0.62f);
        float rr = tone, gg = tone * rnd.NextFloat(0.95f, 1.02f), bb = tone * rnd.NextFloat(0.92f, 1.0f);

        int apex = mesh.VertexCount;
        mesh.AddVertex(ox, topY, oz, rr * 1.10f, gg * 1.10f, bb * 1.10f);

        // Пояс «плечо» — узкий и высокий, и пояс «основание» — широкий и низкий.
        int shoulder = mesh.VertexCount;
        for (int i = 0; i < Seg; i++)
        {
            float a = i / (float)Seg * MathF.PI * 2f;
            float radius = baseR * 0.62f * rnd.NextFloat(0.85f, 1.15f);
            float y = topY * rnd.NextFloat(0.62f, 0.78f);
            float sh = rnd.NextFloat(0.92f, 1.02f);
            mesh.AddVertex(ox + MathF.Cos(a) * radius, y, oz + MathF.Sin(a) * radius,
                rr * sh, gg * sh, bb * sh);
        }
        int baseRing = mesh.VertexCount;
        for (int i = 0; i < Seg; i++)
        {
            float a = i / (float)Seg * MathF.PI * 2f;
            float radius = baseR * rnd.NextFloat(0.85f, 1.15f);
            float y = topY * rnd.NextFloat(0.10f, 0.26f);
            float sh = rnd.NextFloat(0.80f, 0.92f);   // низ темнее — так читается объём
            mesh.AddVertex(ox + MathF.Cos(a) * radius, y, oz + MathF.Sin(a) * radius,
                rr * sh, gg * sh, bb * sh);
        }

        for (int i = 0; i < Seg; i++)
        {
            int s0 = shoulder + i, s1 = shoulder + (i + 1) % Seg;
            int b0 = baseRing + i, b1 = baseRing + (i + 1) % Seg;
            mesh.Indices.Add(apex); mesh.Indices.Add(s0); mesh.Indices.Add(s1);
            mesh.Indices.Add(s0); mesh.Indices.Add(b0); mesh.Indices.Add(b1);
            mesh.Indices.Add(s0); mesh.Indices.Add(b1); mesh.Indices.Add(s1);
        }
    }
}
