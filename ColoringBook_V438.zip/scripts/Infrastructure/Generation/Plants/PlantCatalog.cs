using System;
using System.Collections.Generic;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Plants;

/// <summary>
/// Каталог растений.
/// Хранит PlantGenome (промежуточное состояние) + закешированный меш.
/// Фоновая догенерация = новый genome → ReplaceVariant.
/// </summary>
public sealed class PlantCatalog
{
    private static PlantCatalog? _instance;

    public static PlantCatalog Instance =>
        _instance ?? throw new InvalidOperationException("PlantCatalog.EnsureInitialized() first");

    public static bool IsInitialized => _instance != null;

    /// <summary>
    /// ВАРИАНТОВ НА ТИП: три вида × три ступени затенённости.
    ///
    /// Было пять, и это ломало правку V156. Вид считался как v % Count(kind), а
    /// затенённость как v / 4 — то есть они оказались СЦЕПЛЕНЫ: при трёх видах и пяти
    /// вариантах пихта существовала только при затенённости 0.5, а ель только при 0 и
    /// 0.75. Дерево чащи для трети пород не строилось вовсе, и разница силуэтов,
    /// ради которой всё делалось, не могла проявиться.
    ///
    /// Девять вариантов расцепляют их: вид = v % 3, ступень = v / 3, то есть каждый
    /// вид получает открытый рост, среднее и чащу. Ступеней три, а не пять: разница
    /// между соседними ступенями пятибалльной шкалы меньше видового разброса, и
    /// платить за неё мешами не стоит.
    ///
    /// ЦЕНА. Групп MultiMesh на уровне стало бы больше, но их число ограничено сверху
    /// плотностью: allowed = inCell / MinInstancesPerNode (см. LevelView3D), то есть
    /// редкие породы как использовали один-два варианта, так и используют. Растёт в
    /// основном время сборки каталога, причём у лиственных оно отложенное.
    /// </summary>
    public const int VariantsPerKind = 9;

    /// <summary>Ступеней затенённости в шкале вариантов (см. VariantsPerKind).</summary>
    public const int CrowdingLevels = 3;

    private readonly Dictionary<VegetationKind, PlantGenome[]> _genomes = new();
    private readonly Dictionary<VegetationKind, PlantMeshData[]> _meshes = new();

    // ---- ЧЕМ ИМЕННО ЗАСАЖЕН УРОВЕНЬ ----
    //
    // Возраст и качество каждого варианта до сих пор нигде не сохранялись: они
    // выставлялись в статические PlantGenerator.AgeLevel/QualityLevel на время
    // сборки и тут же возвращались обратно. По готовому каталогу узнать, какими
    // они были, было нельзя — а именно этого не хватало, когда уровень оказывался
    // засажен всходами после захода в витрину (см. IsGamePool). Теперь параметры
    // сборки хранятся рядом с самим вариантом и попадают в телеметрию обхода.
    private readonly Dictionary<VegetationKind, VariantBuild[]> _built = new();

    /// <summary>Чем собран конкретный вариант. MeshReady = false у отложенных
    /// лиственных: геном есть, меш соберётся при первом Get.</summary>
    public readonly record struct VariantBuild(int Age, int Quality, bool MeshReady);

    private PlantCatalog() { }

    /// <summary>
    /// Собран ли текущий каталог для ИГРОВОГО пула.
    ///
    /// Витрина растений пересобирает каталог целиком через RegenerateAll, применяя ко
    /// ВСЕМ вариантам один возраст и одно качество — те, что выставлены в её интерфейсе.
    /// Каталог при этом общий с уровнем, и после возврата из витрины уровень оказывался
    /// засажен деревьями одного возраста и того качества, на котором её оставили.
    /// Возраст витрина ставит нулевой при открытии, а обратно его никто не возвращал:
    /// достаточно было один раз заглянуть в витрину, чтобы весь лес стал всходами.
    ///
    /// Признак позволяет отличить одно состояние от другого и восстановить игровой пул.
    /// </summary>
    public static bool IsGamePool { get; private set; }

    /// <summary>
    /// Гарантировать, что каталог собран для уровня: у каждого варианта свой возраст из
    /// игрового диапазона, качество — GameQEffTarget. Пересобирает, если каталога нет
    /// ИЛИ если он остался от витрины.
    /// </summary>
    public static void EnsureGamePool(int baseSeed = 0xC01A7)
    {
        if (_instance != null && IsGamePool) return;
        _instance = null;
        EnsureInitialized(baseSeed);
    }

    public static void EnsureInitialized(int baseSeed = 0xC01A7)
    {
        if (_instance != null) return;
        // Счётчики самоорганизующегося роста сбрасываются ИМЕННО ЗДЕСЬ, а не при
        // сборке растительности: меши строятся один раз на старте, в этом методе, и
        // сброс где-либо позже просто затирал уже накопленные числа — из-за чего в
        // первом же логе оказалось treesGenerated = 0 при явно построенных деревьях.
        PlantGenerator.SoStats.Reset();
        int savedAge = PlantGenerator.AgeLevel;
        int savedQ = PlantGenerator.QualityLevel;
        try
        {
            // Игровой realtime-пул: age 4..8 по слотам, qEff = GameQEffTarget.
            // Витрина (RegenerateAll) по-прежнему использует текущие Age/Quality UI.
            int ageSpan = PlantGenerator.GameAgeMax - PlantGenerator.GameAgeMin + 1;
            PlantGenerator.QualityLevel = PlantGenerator.GameQEffTarget;

            var catalog = new PlantCatalog();
            foreach (VegetationKind kind in Enum.GetValues(typeof(VegetationKind)))
            {
                var genomes = new PlantGenome[VariantsPerKind];
                var meshes = new PlantMeshData[VariantsPerKind];
                var built = new VariantBuild[VariantsPerKind];
                // Тяжёлые SCA-деревья (Deciduous) — только геном; меш при первом Get().
                // Иначе старт игры = 5×~2.5с только на дуб/берёзу/клён.
                bool deferMesh = kind == VegetationKind.Deciduous;
                for (int v = 0; v < VariantsPerKind; v++)
                {
                    PlantGenerator.AgeLevel = PlantGenerator.GameAgeMin + (v % ageSpan);
                    int variantSeed = GenomeSeedFor(baseSeed, kind, v);
                    // Варианты — ШКАЛА ЗАТЕНЁННОСТИ, а не случайные пересевы: нулевой
                    // растёт на открытом месте, последний в чаще. Расстановка выбирает
                    // по фактическому числу соседей (см. PlantGenome.Crowding).
                    genomes[v] = PlantGenome.Create(kind, variantSeed,
                        SpeciesOfVariant(v), CrowdingOfVariant(v));
                    // Пустой меш = ленивая генерация в Get().
                    meshes[v] = deferMesh
                        ? new PlantMeshData()
                        : PlantGenerator.Generate(genomes[v]);
                    built[v] = new VariantBuild(
                        PlantGenerator.AgeLevel, PlantGenerator.QualityLevel, !deferMesh);
                }
                catalog._genomes[kind] = genomes;
                catalog._meshes[kind] = meshes;
                catalog._built[kind] = built;
            }
            _instance = catalog;
            IsGamePool = true;
            // Лог только по уже собранным (хвойные и мелочь); лиственные — при первом Get.
            LogGrowthStats(baseSeed);
        }
        finally
        {
            PlantGenerator.AgeLevel = savedAge;
            PlantGenerator.QualityLevel = savedQ;
        }
    }

    /// <summary>Пишет статистику самоорганизующегося роста рядом с логами уровня.</summary>
    private static void LogGrowthStats(int seed)
    {
        try
        {
            string path = ColoringBook.Infrastructure.Generation.Diagnostics.GenerationLog.WriteRaw(
                PlantGenerator.SoStats.ToJson(), seed, "plants");
            // Console, а не GD.Print: этот слой намеренно Godot-независим и проверяется
            // headless. В консоли Godot строка видна так же.
            Console.WriteLine($"[plants] лог роста записан: {path}");
        }
        catch (Exception ex)
        {
            // Лог не критичен: генерация растений не должна падать из-за записи файла.
            Console.WriteLine($"[plants] лог роста не записан: {ex.Message}");
        }
    }

    public PlantMeshData Get(VegetationKind kind, int variantIndex)
    {
        if (!_meshes.TryGetValue(kind, out var arr) || arr.Length == 0)
            throw new InvalidOperationException($"No variants for {kind}");
        int idx = variantIndex % arr.Length;
        if (idx < 0) idx += arr.Length;
        // Ленивая сборка (Deciduous при старте не генерировались).
        if (arr[idx].VertexCount == 0 && _genomes.TryGetValue(kind, out var gArr))
        {
            int savedAge = PlantGenerator.AgeLevel;
            int savedQ = PlantGenerator.QualityLevel;
            try
            {
                int ageSpan = PlantGenerator.GameAgeMax - PlantGenerator.GameAgeMin + 1;
                PlantGenerator.AgeLevel = PlantGenerator.GameAgeMin + (idx % ageSpan);
                PlantGenerator.QualityLevel = PlantGenerator.GameQEffTarget;
                arr[idx] = PlantGenerator.Generate(gArr[idx]);
                if (_built.TryGetValue(kind, out var bArr) && idx < bArr.Length)
                    bArr[idx] = new VariantBuild(
                        PlantGenerator.AgeLevel, PlantGenerator.QualityLevel, true);
            }
            finally
            {
                PlantGenerator.AgeLevel = savedAge;
                PlantGenerator.QualityLevel = savedQ;
            }
        }
        return arr[idx];
    }

    public PlantGenome GetGenome(VegetationKind kind, int variantIndex)
    {
        if (!_genomes.TryGetValue(kind, out var arr) || arr.Length == 0)
            throw new InvalidOperationException($"No genomes for {kind}");
        int idx = variantIndex % arr.Length;
        if (idx < 0) idx += arr.Length;
        return arr[idx];
    }

    /// <summary>
    /// СИД ГЕНОМА — ПО ВИДУ, НЕ ПО ВАРИАНТУ.
    ///
    /// Раньше сид включал номер варианта целиком, поэтому три ступени затенённости
    /// одного вида оказывались ТРЕМЯ РАЗНЫМИ ДЕРЕВЬЯМИ: у каждого свой HeightMul,
    /// CrownMul, Branchiness. Замер это и показал — у сосны доля кроны шла 55% на
    /// открытом месте, 71% в среднем лесу и 36% в чаще, то есть середина выпадала из
    /// ряда. Разброс генома оказался сильнее размаха от затенённости, и мы мерили
    /// сумму двух эффектов, приписывая её одному.
    ///
    /// Теперь сид зависит от вида и не зависит от ступени: ступени одного вида — это
    /// ОДНО дерево в трёх условиях, и разница между ними может быть только от
    /// затенённости. Иначе подбор размаха boleSwing был бы подгонкой числа под шум.
    ///
    /// Разнообразие леса от этого не страдает: экземпляры на уровне различаются
    /// масштабом, поворотом и видом, а вариант отвечает за условия роста.
    /// </summary>
    private static int GenomeSeedFor(int baseSeed, VegetationKind kind, int variant)
        => baseSeed ^ ((int)kind * 7919) ^ ((variant % PlantSpecies.MaxSpeciesPerKind) * 104729);

    /// <summary>
    /// ВИД ПО НОМЕРУ ВАРИАНТА. Шаг шкалы — MaxSpeciesPerKind, а НЕ число видов типа.
    ///
    /// Раньше здесь стояло v % Count(kind), и для типов с числом видов меньше трёх
    /// шкала разъезжалась с той, по которой вариант собирает витрина
    /// (VariantOf = ступень × MaxSpeciesPerKind + вид). У сосен видов два, поэтому
    /// вариант 3 — «сосна, средний лес» по витрине — оказывался КЕДРОМ по каталогу.
    ///
    /// Замер это и показал: доля кроны у «сосны» шла 55% / 73% / 38%, и середина
    /// выпадала из ряда. Я списал это на разброс генома и сделал сид общим на
    /// ступень — ряд не выправился, потому что причина была не в геноме, а в том,
    /// что средним деревом ряда был другой вид. Само по себе выравнивание сида
    /// верно и остаётся: у ели ряд стал монотонным (99 / 93 / 88).
    ///
    /// Итоговое соответствие берётся с усечением по Count внутри PlantGenome.Create,
    /// поэтому у сосен варианты 2, 5, 8 дублируют первый вид — это дешевле, чем
    /// заводить разный шаг шкалы для разных типов.
    /// </summary>
    private static int SpeciesOfVariant(int variant) => variant % PlantSpecies.MaxSpeciesPerKind;

    /// <summary>Затенённость, соответствующая номеру варианта: 0, 0.5, 1.</summary>
    public static float CrowdingOfVariant(int variant)
    {
        int level = Math.Clamp(variant / PlantSpecies.MaxSpeciesPerKind, 0, CrowdingLevels - 1);
        return CrowdingLevels > 1 ? level / (float)(CrowdingLevels - 1) : 0.5f;
    }

    /// <summary>Номер варианта по виду и ступени затенённости — для витрины.</summary>
    public static int VariantOf(int species, int crowdingLevel)
        => Math.Clamp(crowdingLevel, 0, CrowdingLevels - 1) * PlantSpecies.MaxSpeciesPerKind
         + Math.Max(0, species);

    public int VariantCount(VegetationKind kind) =>
        _meshes.TryGetValue(kind, out var arr) ? arr.Length : 0;

    /// <summary>Возраст и качество, при которых собран вариант. Если запись
    /// потерялась, возвращает (-1, -1) — это честнее, чем подставить текущие
    /// значения статических полей генератора: они к этому мешу отношения не имеют.</summary>
    public VariantBuild GetBuild(VegetationKind kind, int variantIndex)
    {
        if (!_built.TryGetValue(kind, out var arr) || arr.Length == 0)
            return new VariantBuild(-1, -1, false);
        int idx = variantIndex % arr.Length;
        if (idx < 0) idx += arr.Length;
        return arr[idx];
    }


    /// <summary>
    /// Полная пересборка всех вариантов форм с новым baseSeed.
    /// Нужно для отладки эволюции растений без смены ландшафта.
    /// </summary>
    public static void RegenerateAll(int baseSeed)
    {
        PlantGenerator.SoStats.Reset();
        var catalog = new PlantCatalog();
        foreach (VegetationKind kind in Enum.GetValues(typeof(VegetationKind)))
        {
            var genomes = new PlantGenome[VariantsPerKind];
            var meshes = new PlantMeshData[VariantsPerKind];
            var built = new VariantBuild[VariantsPerKind];
            for (int v = 0; v < VariantsPerKind; v++)
            {
                int variantSeed = GenomeSeedFor(baseSeed, kind, v);
                // Вид назначается по номеру варианта, а не жребием: так все виды
                // гарантированно присутствуют в каталоге (при 5 вариантах и 3 видах
                // каждый вид встречается минимум один раз).
                genomes[v] = PlantGenome.Create(kind, variantSeed,
                    SpeciesOfVariant(v), CrowdingOfVariant(v));
                meshes[v] = PlantGenerator.Generate(genomes[v]);
                built[v] = new VariantBuild(
                    PlantGenerator.AgeLevel, PlantGenerator.QualityLevel, true);
            }
            catalog._genomes[kind] = genomes;
            catalog._meshes[kind] = meshes;
            catalog._built[kind] = built;
        }
        _instance = catalog;
        // Каталог витрины: один возраст и одно качество на все варианты. Для уровня
        // он непригоден — см. EnsureGamePool.
        IsGamePool = false;
        LogGrowthStats(baseSeed);
    }

}
