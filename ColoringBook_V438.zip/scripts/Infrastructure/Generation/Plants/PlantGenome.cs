using System;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Plants;

/// <summary>
/// Промежуточное состояние растения («на полпути» до меша).
/// Хранится дёшево; из одного генома можно получить много вариантов,
/// меняя Seed / параметры. Меш строится только когда нужен.
/// </summary>
public sealed class PlantGenome
{
    public VegetationKind Kind { get; init; }
    public int Seed { get; init; }

    /// <summary>0.7 … 1.3 — относительная высота.</summary>
    public float HeightMul { get; init; } = 1f;

    /// <summary>0.6 … 1.4 — ширина кроны.</summary>
    public float CrownMul { get; init; } = 1f;

    /// <summary>0 … 1 — «ветвистость» (больше боковых побегов).</summary>
    public float Branchiness { get; init; } = 0.5f;

    /// <summary>0 … 1 — плотность листвы на концах.</summary>
    public float FoliageDensity { get; init; } = 0.7f;

    /// <summary>Случайный наклон ствола (радианы, мало).</summary>
    public float Lean { get; init; }

    /// <summary>
    /// ЗАТЕНЁННОСТЬ СОСЕДЯМИ, 0 … 1. Ноль — дерево открытого роста, единица — в чаще.
    ///
    /// Отвечает за долю голого ствола: нижние ветви, оказавшись в тени, отмирают, и
    /// ствол оголяется. До этого доля задавалась только породой и возрастом, поэтому
    /// все сосны в кадре стояли одинаковыми свечками, а на референсах они и свечки,
    /// и раскидистые — в зависимости от того, где растут.
    ///
    /// ПОЧЕМУ ЭТО ПОЛЕ ГЕНОМА, А НЕ ПАРАМЕТР РАССТАНОВКИ. Деревья строятся как пять
    /// вариантов каталога ДО расстановки, и затенённость на момент генерации ещё не
    /// известна. Поэтому варианты перестают быть случайными пересевами и становятся
    /// шкалой: вариант 0 — открытый рост, вариант 4 — чаща. Расстановка выбирает по
    /// фактическому числу соседей, у неё эта величина уже есть (см. TreeGrid).
    /// Новых мешей это не добавляет: вариантов было и остаётся пять.
    /// </summary>
    public float Crowding { get; init; } = 0.5f;

    /// <summary>
    /// ИНДЕКС ВИДА внутри типа (см. PlantSpecies). Выбирается по сиду, поэтому в лесу
    /// стоят разные виды, а не один силуэт с разбросом размеров.
    /// </summary>
    public int Species { get; init; }

    /// <param name="speciesOverride">Явно заданный вид (см. PlantSpecies). -1 —
    /// выбрать по сиду. Нужен, чтобы каталог гарантированно покрывал ВСЕ виды, а не
    /// полагался на случайный жребий: при пяти вариантах и трёх видах какой-нибудь вид
    /// вполне мог не выпасть ни разу.</param>
    /// <param name="crowding">Затенённость соседями 0…1; -1 — оставить середину.</param>
    public static PlantGenome Create(VegetationKind kind, int seed, int speciesOverride = -1,
        float crowding = -1f)
    {
        var rnd = new SeededRandom(seed ^ 0xA11CE);
        return new PlantGenome
        {
            Kind = kind,
            Seed = seed,
            Crowding = crowding >= 0f ? Math.Clamp(crowding, 0f, 1f) : 0.5f,
            HeightMul = rnd.NextFloat(0.82f, 1.18f),
            CrownMul = rnd.NextFloat(0.75f, 1.25f),
            Branchiness = rnd.NextFloat(0.35f, 0.95f),
            // densMul jitter ±15% (PlantGenerator.DensMulJitter*) — разбивает
            // однородную «зелёную кашу» при одном qEff на уровне.
            FoliageDensity = rnd.NextFloat(
                PlantGenerator.DensMulJitterMin, PlantGenerator.DensMulJitterMax),
            Lean = rnd.NextFloat(-0.08f, 0.08f),
            Species = speciesOverride >= 0
                ? speciesOverride % PlantSpecies.Count(kind)
                : rnd.NextInt(PlantSpecies.Count(kind))
        };
    }
}
