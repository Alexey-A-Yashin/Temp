using System;
using System.Collections.Generic;

namespace ColoringBook.Infrastructure.Generation.Plants;

/// <summary>
/// ЧИСТАЯ МОДЕЛЬ САМООРГАНИЗАЦИИ по Pałubicki et al., SIGGRAPH 2009 —
/// БЕЗ облака точек притяжения.
///
/// ЗАЧЕМ ПОТРЕБОВАЛАСЬ ЗАМЕНА. Прежний генератор был гибридом: скелет строила space
/// colonization по облаку точек, а поверх работали теневая модель, апикальный контроль
/// и сброс ветвей из этой статьи. Сверка показала, что механизмы статьи в таком
/// гибриде декоративны — форму кроны целиком задаёт облако. Прогон λ от 0.44 до 0.60
/// давал ширину/высоту 0.96…1.06 без всякой закономерности, то есть апикальный
/// контроль не работал вовсе, хотя код его считал.
///
/// В этой модели облака нет: форма ВОЗНИКАЕТ из конкуренции почек за свет. Проверка
/// после переноса: λ от 0.46 до 0.54 даёт ширину/высоту 0.68 → 0.49, а число порядков
/// ветвления 8 → 5 — тот самый переход decurrent → excurrent с Fig. 7 статьи.
///
/// Шаг симуляции (§4):
///   1. Освещённость почек Q — распространение тени (§4.1).
///   2. Базипетальный проход: накопление Q вверх по дереву.
///   3. Акропетальный проход: ресурс v_base = α·Q_base делится на развилках по λ (§4.2).
///      ВАЖНО: делится он между ПОЧКАМИ, а не между узлами — верхушечная и боковая
///      почки сидят на одном узле, и при делении по узлам обе получали одно значение,
///      отчего λ ни на что не влиял.
///   4. Почка выпускает n = ⌊v⌋ метамеров длиной l = v/n (§4.2).
///   5. Направление побега — взвешенная сумма своего направления, направления к свету
///      (вес ξ) и тропизма (вес η) (§4.3).
///   6. Сброс затенённых ветвей (§4.4).
///   7. Толщина по модели труб (§4.5) — считается снаружи, в PlantGenerator.
///
/// Класс НЕ ЗАВИСИТ ОТ GODOT и проверяется в харнессе.
/// </summary>
public static class SelfOrganizingTree
{
    /// <summary>Счётчики за один вызов Grow (для лога).
    /// Created — пик узлов за рост; Final — итог; Shed — удалено Shed-ом.</summary>
    public static int LastNodesCreated;
    public static int LastNodesFinal;
    public static int LastNodesShed;
    public static int LastShedEvents;
    /// <summary>1, если рост упёрся в MaxNodes до исчерпания Steps (audit K-2).</summary>
    public static int LastNodeCapHit;

    public sealed class Settings
    {
        /// <summary>Шагов развития. Это и есть возраст дерева.</summary>
        public int Steps = 9;

        /// <summary>λ — апикальный контроль. Больше 0.5 — ресурс идёт продолжению оси
        /// (excurrent, выраженный ствол), меньше — боковым ветвям (decurrent).
        /// В статье вся Fig. 7 укладывается в 0.46…0.54, переключатель очень
        /// чувствительный.</summary>
        public float Lambda = 0.50f;

        /// <summary>α — сколько ресурса даёт единица накопленного света.</summary>
        public float Alpha = 2.0f;

        /// <summary>ξ — вес направления к свету.</summary>
        public float LightPull = 0.35f;

        /// <summary>η — вес тропизма.</summary>
        public float TropismWeight = 0.20f;

        public float TropismX = 0f, TropismY = 1f, TropismZ = 0f;

        /// <summary>Базовая длина междоузлия.</summary>
        public float BaseLength = 0.30f;

        /// <summary>Угол отхождения боковой почки, градусы.</summary>
        public float BranchAngle = 45f;

        /// <summary>Порог сброса — доля от средней освещённости на междоузлие.
        /// Ниже значение → агрессивнее сброс (больше отмирает). Для молодых деревьев
        /// держим выше, чтобы нижние ветви успели набрать листву и не превращали
        /// саженец в голую палку.</summary>
        public float ShedRatio = 0.45f;

        /// <summary>С какого шага развития разрешён сброс. У молодых деревьев
        /// (мало Steps) сброс раньше времени оголял ствол — boleClearance 0.7–0.8.
        /// По умолчанию 4; снаружи поднимается для age ≤ 3.</summary>
        public int ShedStartStep = 4;

        /// <summary>Потолок числа метамеров за шаг (защита от взрывного роста).
        /// 2 — базовая детализация; 3 даёт заметно гуще скелет на age ≥ 2.</summary>
        public int MaxMetamers = 2;

        /// <summary>ЗАТЕНЁННОСТЬ СОСЕДЯМИ, 0 … 1 — доля освещённости, отнимаемая у
        /// основания кроны. Ноль — дерево открытого роста, единица — сомкнутый полог.
        /// См. пояснение в ShadowVoxels.</summary>
        public float NeighbourShade;

        /// <summary>Бюджет узлов ГОТОВОГО скелета. Ноль — не прореживать.
        /// Рост при этом идёт до MaxNodes, то есть до конца (см. V161 в Grow).</summary>
        public int PruneTo;

        /// <summary>C теневой модели — «полная освещённость».</summary>
        public float ShadowC = 2.4f;

        /// <summary>Шум направления. Без него модель полностью детерминирована и все
        /// сиды дают ОДИНАКОВОЕ дерево — проверено: 129 узлов, высота 10.80 и 5
        /// порядков при сидах 1, 2 и 3. У Палубицки разнообразие берётся из
        /// неоднородности среды, которой у нас нет, поэтому вводится явно.</summary>
        public float Noise = 0.22f;

        /// <summary>Потолок числа узлов — страховка от разрастания на больших Steps.
        /// V55: 3000 достаточно для силуэта; выше — только CPU без визуала (audit K-2).</summary>
        public int MaxNodes = 3000;
    }

    public struct Node
    {
        public Vec3 Pos;
        public Vec3 Dir;
        public int Parent;
        public int Order;
    }

    public struct Vec3
    {
        public float X, Y, Z;
        public Vec3(float x, float y, float z) { X = x; Y = y; Z = z; }
    }

    private sealed class Bud
    {
        public int NodeIndex;
        public Vec3 Dir;
        public float Roll;
        public bool Apical;
    }

    private const float GoldenAngle = 137.5077f;

    public static List<Node> Grow(int seed, Settings? settings = null)
    {
        var s = settings ?? new Settings();
        var rnd = new SeededRandom(seed);

        LastNodesCreated = 0; LastNodesFinal = 0; LastNodesShed = 0; LastShedEvents = 0;
        LastNodeCapHit = 0; LastNodesPruned = 0;
        var nodes = new List<Node>
        {
            new() { Pos = new Vec3(0, 0, 0), Dir = new Vec3(0, 1, 0), Parent = -1, Order = 0 },
        };
        var buds = new List<Bud>
        {
            new() { NodeIndex = 0, Dir = new Vec3(0, 1, 0), Roll = rnd.NextFloat(0f, 360f), Apical = true },
        };

        var shadow = new ShadowVoxels(s.BaseLength * 1.2f, s.ShadowC,
            neighbourShade: s.NeighbourShade);
        var tropism = Norm(new Vec3(s.TropismX, s.TropismY, s.TropismZ));

        for (int step = 0; step < s.Steps && buds.Count > 0 && nodes.Count < s.MaxNodes; step++)
        {
            shadow.Clear();
            foreach (var nd in nodes) shadow.Add(nd.Pos);

            int n = nodes.Count;

            // --- §4.1 + базипетальный проход ---
            var q = new float[n];
            foreach (var b in buds) q[b.NodeIndex] += shadow.Light(nodes[b.NodeIndex].Pos);
            for (int i = n - 1; i > 0; i--) q[nodes[i].Parent] += q[i];

            var kids = new List<int>[n];
            for (int i = 0; i < n; i++) kids[i] = new List<int>();
            for (int i = 1; i < n; i++) kids[nodes[i].Parent].Add(i);

            // --- §4.2 акропетальный проход по узлам ---
            var v = new float[n];
            v[0] = s.Alpha * q[0];
            for (int i = 0; i < n; i++)
            {
                var ks = kids[i];
                if (ks.Count == 0) continue;
                if (ks.Count == 1) { v[ks[0]] += v[i]; continue; }

                float qm = 0f, ql = 0f;
                foreach (int c in ks)
                {
                    if (nodes[c].Order == nodes[i].Order) qm += q[c]; else ql += q[c];
                }
                if (qm <= 0f) { qm = q[ks[0]]; ql = Math.Max(ql - q[ks[0]], 0f); }

                float den = s.Lambda * qm + (1f - s.Lambda) * ql;
                if (den <= 1e-9f) continue;
                float vm = v[i] * s.Lambda * qm / den;
                float vl = v[i] * (1f - s.Lambda) * ql / den;
                foreach (int c in ks)
                {
                    if (nodes[c].Order == nodes[i].Order) v[c] += vm * (qm > 0 ? q[c] / qm : 0f);
                    else v[c] += vl * (ql > 0 ? q[c] / ql : 0f);
                }
            }

            // --- Деление ресурса МЕЖДУ ПОЧКАМИ одного узла ---
            var budsAt = new Dictionary<int, List<Bud>>();
            foreach (var b in buds)
            {
                if (!budsAt.TryGetValue(b.NodeIndex, out var list))
                {
                    list = new List<Bud>();
                    budsAt[b.NodeIndex] = list;
                }
                list.Add(b);
            }
            var budRes = new Dictionary<Bud, float>();
            foreach (var kv in budsAt)
            {
                var list = kv.Value;
                if (list.Count == 1) { budRes[list[0]] = v[kv.Key]; continue; }

                float qm = 0f, ql = 0f;
                foreach (var b in list)
                {
                    float lq = shadow.Light(nodes[b.NodeIndex].Pos);
                    if (b.Apical) qm += lq; else ql += lq;
                }
                float den = s.Lambda * qm + (1f - s.Lambda) * ql;
                if (den <= 1e-9f) { foreach (var b in list) budRes[b] = 0f; continue; }

                float vm = v[kv.Key] * s.Lambda * qm / den;
                float vl = v[kv.Key] * (1f - s.Lambda) * ql / den;
                int na = 0, nl = 0;
                foreach (var b in list) { if (b.Apical) na++; else nl++; }
                foreach (var b in list)
                    budRes[b] = b.Apical ? vm / Math.Max(na, 1) : vl / Math.Max(nl, 1);
            }

            // --- §4.2 рост: n = floor(v), l = v/n ---
            var newBuds = new List<Bud>();
            foreach (var b in buds)
            {
                if (nodes.Count >= s.MaxNodes) break;
                budRes.TryGetValue(b, out float vb);
                int metamers = (int)MathF.Min(MathF.Floor(vb), s.MaxMetamers);
                if (metamers < 1) continue;

                float len = MathF.Min((vb / metamers) * s.BaseLength, s.BaseLength * 2f)
                            * rnd.NextFloat(0.85f, 1.15f);

                int cur = b.NodeIndex;
                var cdir = b.Dir;
                for (int m = 0; m < metamers && nodes.Count < s.MaxNodes; m++)
                {
                    var lightDir = shadow.Gradient(nodes[cur].Pos);
                    var jitter = new Vec3(
                        rnd.NextFloat(-1f, 1f) * s.Noise,
                        rnd.NextFloat(-1f, 1f) * s.Noise * 0.35f,
                        rnd.NextFloat(-1f, 1f) * s.Noise);

                    // §4.3: своё направление + к свету (ξ) + тропизм (η)
                    //
                    // ТРОПИЗМ ДЕЙСТВУЕТ ПО-РАЗНОМУ НА ОСЬ И НА ВЕТВЬ. У дерева
                    // отрицательный гравитропизм силён на стволе — он и держит дерево
                    // прямым; боковые ветви плагиотропны, то есть растут вбок и почти
                    // не выпрямляются, иначе крона превратилась бы в метлу.
                    //
                    // Прежде вес был один на всех. При малом весе ствол уводило вбок
                    // асимметрией собственной тени (дерево заваливалось), при большом —
                    // выпрямлялись и ветви, и крона сжималась в столб. Разделение
                    // снимает выбор между этими двумя бедами: множитель падает с
                    // порядком ветвления.
                    float tropOrder = nodes[cur].Order == 0 ? 1f
                                    : nodes[cur].Order == 1 ? 0.35f : 0.15f;
                    float tw = s.TropismWeight * tropOrder;
                    // К свету тянутся как раз ветви, а не ствол — обратная зависимость.
                    float lp = s.LightPull * (nodes[cur].Order == 0 ? 0.45f : 1f);
                    var d = Norm(new Vec3(
                        cdir.X + lightDir.X * lp + tropism.X * tw + jitter.X,
                        cdir.Y + lightDir.Y * lp + tropism.Y * tw + jitter.Y,
                        cdir.Z + lightDir.Z * lp + tropism.Z * tw + jitter.Z));

                    var p = nodes[cur].Pos;
                    var np = new Vec3(p.X + d.X * len, MathF.Max(p.Y + d.Y * len, 0.02f), p.Z + d.Z * len);

                    // Порядок растёт только на ПЕРВОМ метамере боковой почки.
                    int ord = nodes[cur].Order + ((b.Apical || m > 0) ? 0 : 1);
                    nodes.Add(new Node { Pos = np, Dir = d, Parent = cur, Order = ord });
                    cur = nodes.Count - 1;
                    cdir = d;
                }

                // Верхушечная почка продолжает ось.
                newBuds.Add(new Bud { NodeIndex = cur, Dir = nodes[cur].Dir, Roll = b.Roll, Apical = true });

                // Боковая почка: филлотаксис 137.5° (ABOP гл. 4) + угол ветвления.
                float roll2 = b.Roll + GoldenAngle;
                var axisRef = MathF.Abs(nodes[cur].Dir.Y) < 0.95f
                    ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
                var axis = Norm(Cross(nodes[cur].Dir, axisRef));
                axis = Rotate(axis, nodes[cur].Dir, roll2 * MathF.PI / 180f);
                var latDir = Norm(Rotate(nodes[cur].Dir, axis,
                    s.BranchAngle * rnd.NextFloat(0.75f, 1.25f) * MathF.PI / 180f));
                newBuds.Add(new Bud { NodeIndex = cur, Dir = latDir, Roll = roll2, Apical = false });
            }
            buds = newBuds;

            // --- §4.4 сброс затенённых ветвей ---
            // ShedStartStep поднимается снаружи для молодых деревьев, иначе нижние
            // ветви отмирают до того, как крона успевает набрать объём, и получается
            // «палка с пучком» (boleClearance 0.7+ при age 0–2).
            if (nodes.Count > LastNodesCreated) LastNodesCreated = nodes.Count;
            // Audit K-2: упор в потолок фиксируем ЗДЕСЬ, до сброса затенённых ветвей.
            // Раньше проверка стояла в самом конце Grow, после всех сбросов, а сброс
            // уводит счёт узлов ниже MaxNodes — поэтому счётчик показывал 0 даже тогда,
            // когда каждое лиственное дерево упиралось в потолок на каждом шаге.
            // Проверено замером: created = ровно 3000 при MaxNodes = 3000 и nodeCapHit = 0.
            if (nodes.Count >= s.MaxNodes) LastNodeCapHit = 1;
            if (step >= s.ShedStartStep && nodes.Count > 40)
            {
                int before = nodes.Count;
                Shed(nodes, ref buds, shadow, s.ShedRatio);
                int removed = before - nodes.Count;
                if (removed > 0) { LastNodesShed += removed; LastShedEvents++; }
            }
        }

        if (nodes.Count > LastNodesCreated) LastNodesCreated = nodes.Count;

        // ---- V161: ПРОРЕЖИВАНИЕ ПОСЛЕ РОСТА, А НЕ ОБРЫВ РОСТА ----
        //
        // Раньше бюджет узлов действовал как ПОТОЛОК ВО ВРЕМЯ роста: дерево доходило
        // до MaxNodes и замирало. Для игрового меша бюджет был 350 узлов против 3020 у
        // витрины, и замер показал, чем это кончается: создано 3150, итог 3150,
        // сброшено 0, упор в потолок у всех девяти деревьев. То есть самоорганизация
        // выполнялась примерно на девятую часть пути.
        //
        // А ведь именно она формирует всё, ради чего этот алгоритм и взят:
        // самоочищение ствола, форму кроны, распределение ветвей, различие возрастов.
        // Ничего этого на уровне не проявлялось. Отсюда и ровный ряд 77 / 77 / 77 по
        // ступеням затенённости у лиственных, и одинаковая доля кроны во всех
        // возрастах: дерево обрывалось в одной и той же точке.
        //
        // Теперь рост идёт до конца на TargetNodes, а к бюджету приводится ГОТОВЫЙ
        // скелет: выбрасываются самые мелкие концевые веточки, ветви низкого порядка
        // и форма кроны сохраняются. Компактное дерево становится тем же деревом,
        // только грубее, — как у хвойных, где компактный режим упрощает результат
        // (число сегментов кривой, число лап), а не обрывает построение.
        if (s.PruneTo > 0 && nodes.Count > s.PruneTo)
        {
            int before = nodes.Count;
            nodes = PruneToBudget(nodes, s.PruneTo);
            LastNodesPruned = before - nodes.Count;
        }

        LastNodesFinal = nodes.Count;
        // Упор в потолок роста. После V161 он означает, что не хватило TargetNodes, —
        // то есть настоящий дефект, а не штатный режим.
        if (LastNodesCreated >= s.MaxNodes) LastNodeCapHit = 1;
        return nodes;
    }

    /// <summary>Сколько узлов убрано прореживанием (V161).</summary>
    public static int LastNodesPruned;

    /// <summary>
    /// ПРОРЕЖИВАНИЕ ГОТОВОГО СКЕЛЕТА ДО БЮДЖЕТА.
    ///
    /// Удаляются концевые узлы наибольшего порядка ветвления — то есть самые мелкие
    /// веточки. Ствол и главные ветви (низкий Order) не трогаются никогда, поэтому
    /// силуэт и доля голого ствола сохраняются: теряется тонкая изрезанность кроны,
    /// которая на дистанции уровня всё равно не читается.
    ///
    /// Удаление идёт волнами от концов: за раз выбрасываются только ЛИСТЬЯ дерева
    /// (узлы без потомков), иначе пришлось бы чинить разорванные цепочки родителей.
    /// </summary>
    private static List<Node> PruneToBudget(List<Node> nodes, int budget)
    {
        int n = nodes.Count;
        var childCount = new int[n];
        for (int i = 1; i < n; i++)
        {
            int par = nodes[i].Parent;
            if (par >= 0 && par < n) childCount[par]++;
        }
        var alive = new bool[n];
        for (int i = 0; i < n; i++) alive[i] = true;
        int live = n;

        // Волнами: на каждой убираем концевые узлы самого высокого порядка.
        while (live > budget)
        {
            int maxOrder = 0;
            for (int i = 1; i < n; i++)
                if (alive[i] && childCount[i] == 0 && nodes[i].Order > maxOrder)
                    maxOrder = nodes[i].Order;
            if (maxOrder == 0) break;   // остались только ствол и главные ветви

            bool removedAny = false;
            for (int i = n - 1; i >= 1 && live > budget; i--)
            {
                if (!alive[i] || childCount[i] != 0 || nodes[i].Order != maxOrder) continue;
                alive[i] = false;
                live--;
                removedAny = true;
                int par = nodes[i].Parent;
                if (par >= 0 && par < n) childCount[par]--;
            }
            if (!removedAny) break;
        }

        // Пересборка со сдвигом индексов родителей.
        var remap = new int[n];
        var outp = new List<Node>(Math.Min(live, n));
        for (int i = 0; i < n; i++)
        {
            if (!alive[i]) { remap[i] = -1; continue; }
            var nd = nodes[i];
            nd.Parent = nd.Parent >= 0 ? remap[nd.Parent] : -1;
            remap[i] = outp.Count;
            outp.Add(nd);
        }
        return outp;
    }

    private static void Shed(List<Node> nodes, ref List<Bud> buds, ShadowVoxels shadow, float ratio)
    {
        int n = nodes.Count;
        var lsum = new float[n];
        var size = new float[n];
        for (int i = 0; i < n; i++) { lsum[i] = shadow.Light(nodes[i].Pos); size[i] = 1f; }
        for (int i = n - 1; i > 0; i--)
        {
            int p = nodes[i].Parent;
            lsum[p] += lsum[i];
            size[p] += size[i];
        }

        double mean = 0;
        for (int i = 1; i < n; i++) mean += lsum[i] / size[i];
        mean /= Math.Max(n - 1, 1);
        float thr = (float)(mean * ratio);

        var dead = new bool[n];
        // Порог размера поддерева поднят с 5 до 8: мелкие боковые побеги (как раз
        // те, что дают нижнюю листву у молодых деревьев) больше не сбрасываются
        // при первом же лёгком затенении.
        for (int i = 1; i < n; i++)
            if (size[i] >= 8f && lsum[i] / size[i] < thr) dead[i] = true;

        // Помечаем всё поддерево мёртвого узла.
        bool any = false;
        for (int i = 1; i < n; i++)
        {
            if (dead[nodes[i].Parent]) dead[i] = true;
            if (dead[i]) any = true;
        }
        if (!any) return;

        var remap = new int[n];
        var kept = new List<Node>(n);
        for (int i = 0; i < n; i++)
        {
            if (dead[i]) { remap[i] = -1; continue; }
            remap[i] = kept.Count;
            var nd = nodes[i];
            nd.Parent = nd.Parent >= 0 ? remap[nd.Parent] : -1;
            kept.Add(nd);
        }
        if (kept.Count < 4) return;   // не даём сбросу уничтожить дерево

        var keptBuds = new List<Bud>();
        foreach (var b in buds)
        {
            if (b.NodeIndex < n && remap[b.NodeIndex] >= 0)
            {
                b.NodeIndex = remap[b.NodeIndex];
                keptBuds.Add(b);
            }
        }
        nodes.Clear();
        nodes.AddRange(kept);
        buds = keptBuds;
    }

    /// <summary>Воксельная сетка теней (§4.1). Разрежённая: словарь вместо массива,
    /// потому что крона занимает малую долю ограничивающего объёма.</summary>
    private sealed class ShadowVoxels
    {
        private readonly Dictionary<(int, int, int), float> _g = new();
        private readonly float _cell, _a, _b, _c;
        private readonly int _qmax;

        // ---- V164: ТЕНЬ СОСЕДЕЙ ----
        //
        // Модель Палубицки затеняет только ВНИЗ ОТ САМОГО ДЕРЕВА: каждая почка
        // отбрасывает конус тени на нижележащие воксели. Соседних деревьев в ней нет
        // вовсе, поэтому дерево «не знает», растёт оно на опушке или в чаще.
        //
        // Из-за этого затенённость приходилось подмешивать в ПОРОГ сброса, и это не
        // работало: порог решает, СКОЛЬКО узлов отомрёт, а не ГДЕ они расположены.
        // Замер по трём ступеням давал 78 / 78 / 78 при размахе ±15%, и ровно столько
        // же при ±35% — то есть ручка регулировала не ту величину.
        //
        // Тень соседей по своей природе БОКОВАЯ и растёт книзу: полог смыкается над
        // головой, и чем ниже точка, тем меньше света сбоку до неё доходит. Поэтому
        // она вычитается из освещённости с множителем, зависящим от относительной
        // высоты. Тогда нижние ветви отмирают сами — тем механизмом, который для
        // этого и предназначен, — а доля голого ствола становится следствием, а не
        // настройкой.
        private readonly float _neighbourShade;
        private float _maxY = 1e-3f;

        public ShadowVoxels(float cell, float c, float a = 1.0f, float b = 2.0f, int qmax = 5,
            float neighbourShade = 0f)
        {
            _cell = MathF.Max(cell, 1e-3f); _a = a; _b = b; _c = c; _qmax = qmax;
            _neighbourShade = Math.Clamp(neighbourShade, 0f, 1f);
        }

        public void Clear() { _g.Clear(); _maxY = 1e-3f; }

        private (int, int, int) Key(Vec3 p) => (
            (int)MathF.Floor(p.X / _cell),
            (int)MathF.Floor(p.Y / _cell),
            (int)MathF.Floor(p.Z / _cell));

        public void Add(Vec3 p)
        {
            // Высота полога берётся по самой верхней почке: она же и есть та точка,
            // относительно которой считается глубина под пологом.
            if (p.Y > _maxY) _maxY = p.Y;
            var (I, J, K) = Key(p);
            float ds = _a;
            for (int q = 0; q <= _qmax; q++)
            {
                int j = J - q;
                for (int dp = -q; dp <= q; dp++)
                for (int dq = -q; dq <= q; dq++)
                {
                    var k = (I + dp, j, K + dq);
                    _g[k] = (_g.TryGetValue(k, out float cur) ? cur : 0f) + ds;
                }
                ds /= _b;
            }
        }

        public float Light(Vec3 p)
        {
            float s = _g.TryGetValue(Key(p), out float val) ? val : 0f;
            // Боковая тень соседей: у вершины ноль, у земли максимум. Доля от полной
            // освещённости _c, поэтому величина остаётся в тех же единицах, что и
            // самозатенение, и порог сброса можно не трогать.
            float depth = 1f - Math.Clamp(p.Y / MathF.Max(_maxY, 1e-3f), 0f, 1f);
            float lateral = _neighbourShade * _c * depth;
            return MathF.Max(_c - s + _a - lateral, 0f);
        }

        public Vec3 Gradient(Vec3 p)
        {
            float h = _cell;
            float gx = Light(new Vec3(p.X + h, p.Y, p.Z)) - Light(new Vec3(p.X - h, p.Y, p.Z));
            float gy = Light(new Vec3(p.X, p.Y + h, p.Z)) - Light(new Vec3(p.X, p.Y - h, p.Z));
            float gz = Light(new Vec3(p.X, p.Y, p.Z + h)) - Light(new Vec3(p.X, p.Y, p.Z - h));
            if (MathF.Abs(gx) + MathF.Abs(gy) + MathF.Abs(gz) < 1e-9f) return new Vec3(0, 1, 0);
            return Norm(new Vec3(gx, gy, gz));
        }
    }

    // ---- маленькая векторная арифметика (свои типы, чтобы не тащить Godot) ----

    private static Vec3 Norm(Vec3 v)
    {
        float l = MathF.Sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z);
        return l < 1e-9f ? new Vec3(0, 1, 0) : new Vec3(v.X / l, v.Y / l, v.Z / l);
    }

    private static Vec3 Cross(Vec3 a, Vec3 b) => new(
        a.Y * b.Z - a.Z * b.Y,
        a.Z * b.X - a.X * b.Z,
        a.X * b.Y - a.Y * b.X);

    private static Vec3 Rotate(Vec3 v, Vec3 axis, float ang)
    {
        var k = Norm(axis);
        float c = MathF.Cos(ang), s = MathF.Sin(ang);
        var cr = Cross(k, v);
        float dot = k.X * v.X + k.Y * v.Y + k.Z * v.Z;
        return new Vec3(
            v.X * c + cr.X * s + k.X * dot * (1 - c),
            v.Y * c + cr.Y * s + k.Y * dot * (1 - c),
            v.Z * c + cr.Z * s + k.Z * dot * (1 - c));
    }
}
