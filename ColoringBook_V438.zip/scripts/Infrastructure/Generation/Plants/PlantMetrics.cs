using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace ColoringBook.Infrastructure.Generation.Plants;

/// <summary>
/// ГЕОМЕТРИЧЕСКИЕ МЕТРИКИ растения — чтобы судить о качестве генерации по логу, а не
/// по скриншоту.
///
/// Прежние счётчики (число узлов, доля сброса, освещённость) описывали ПРОЦЕСС роста,
/// но ничего не говорили о ФОРМЕ результата. По ним нельзя было понять, получилось ли
/// дерево с чистым стволом или «метла от земли», раскидистая крона или узкая свеча.
///
/// Метрики считаются по готовому мешу, а не по скелету, намеренно: скелет есть только
/// у space colonization (Deciduous), а Weber-Penn (Pine, Fir) и L-системы (Bush,
/// Flower, Reed) его не строят. Через меш измеримы все шесть видов одинаково — а это
/// как раз и было слепым пятном: работа над самоорганизацией касалась одного вида из
/// шести, и по логам это не читалось.
///
/// Листва отличается от древесины по UV: у ствола и веток UV указывает в непрозрачную
/// ячейку атласа (FoliageAtlas.SolidU/SolidV), у карточек листвы — в листовые ячейки.
///
/// Класс НЕ ЗАВИСИТ ОТ GODOT.
/// </summary>
public sealed class PlantMetrics
{
    public float Height;

    /// <summary>Ширина кроны / высота. У ели ожидается узкая (0.3-0.5), у лиственного
    /// раскидистая (0.7-1.1). Если у всех видов одно и то же — силуэты не различаются.</summary>
    public float CrownRatio;

    /// <summary>ВЫСОТА ЧИСТОГО СТВОЛА: от низа растения до самой нижней листвы, в долях
    /// высоты. Это прямая проверка сброса ветвей: механизм из статьи Палубицки нужен
    /// ровно затем, чтобы нижние затенённые ветви отмирали и ствол оголялся. Если
    /// сброс работает, число должно расти; ноль означает листву от самой земли.</summary>
    public float BoleClearance;

    /// <summary>Высота центра тяжести листвы в долях высоты. Показывает, где
    /// сосредоточена масса кроны: 0.5 — равномерно, 0.7+ — крона поднята вверх.</summary>
    public float FoliageCentroid;

    /// <summary>Доля вершин, приходящихся на листву. Косвенно — насколько густо
    /// облиствено растение относительно веток.</summary>
    public float FoliageFraction;

    /// <summary>Распределение листвы по пяти поясам высоты снизу вверх. Ровный профиль
    /// у куста, смещённый вверх — у дерева с чистым стволом.</summary>
    public float[] FoliageBands = new float[5];

    /// <summary>САМЫЙ ДЛИННЫЙ ПРОСВЕТ в кроне по высоте, в долях высоты растения.
    /// Считается по 20 узким поясам: пояс «пустой», если листвы в нём меньше пятой
    /// части от среднего по облиственной части.
    ///
    /// Нужен потому, что пяти широких поясов для этого мало — провал у хвойных
    /// (кольцо веток, потом голый ствол, потом снова кольцо) попадал в них лишь
    /// случайно. Для сосны при quality 0 пояса были [0.027, 0.313, 0.295, 0.072,
    /// 0.294]: провал в четвёртом виден, но соседние кольца уже слиты. Двадцать
    /// поясов различают отдельные мутовки, и длина просвета между ними измерима
    /// напрямую.</summary>
    public float FoliageGapMax;

    /// <summary>Сколько пустых поясов из 20 — грубая мера «просвечивает ли крона».</summary>
    public float FoliageGapFraction;

    /// <summary>СТРОЙНОСТЬ: высота, делённая на диаметр ствола у основания.
    /// Справочные значения: дуб 20-30, клён 25-35, берёза 35-50, ель 40-60.
    /// Без этой метрики нельзя было проверить главное расхождение с эталонными
    /// изображениями — стволы выходили втрое тоньше нужного (дуб 1:67).</summary>
    public float Slenderness;

    public int VertexCount;

    /// <summary>Вершин листвы/хвои (UV не в Solid-ячейке). Для лиственных ≈ 4 × число
    /// карточек листа; для хвойных ≈ 8 × число игл (billboard-cross).</summary>
    public int FoliageVertCount;

    /// <summary>Вершин древесины (ствол/ветки, UV = Solid).</summary>
    public int WoodVertCount;

    /// <summary>Оценка числа листовых карточек / игл: FoliageVertCount / 4.
    /// Для хвойных (крест из 2 quad на иглу) реальных игл ≈ FoliageVertCount / 8.</summary>
    public int FoliageCardEstimate;

    public static PlantMetrics Compute(PlantMeshData mesh)
    {
        var m = new PlantMetrics { VertexCount = mesh.VertexCount };
        int n = mesh.VertexCount;
        if (n == 0) return m;

        float minY = float.MaxValue, maxY = float.MinValue;
        for (int i = 0; i < n; i++)
        {
            float y = mesh.Positions[i * 3 + 1];
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }
        m.Height = maxY - minY;
        if (m.Height < 1e-5f) return m;

        // Диаметр ствола: берём разброс древесных вершин в нижних 3% высоты — там
        // ствол ещё не разветвился.
        float trunkMinX = float.MaxValue, trunkMaxX = float.MinValue;
        float trunkMinZ = float.MaxValue, trunkMaxZ = float.MinValue;
        float trunkBandTop = minY + m.Height * 0.03f;

        float foliageMinY = float.MaxValue;
        double foliageYSum = 0;
        int foliageCount = 0;
        float crownR = 0f;
        var bands = new int[5];
        var fine = new int[20];

        for (int i = 0; i < n; i++)
        {
            float x = mesh.Positions[i * 3];
            float y = mesh.Positions[i * 3 + 1];
            float z = mesh.Positions[i * 3 + 2];

            // Листва — всё, что НЕ указывает в непрозрачную ячейку атласа.
            float u = mesh.UVs[i * 2];
            float v = mesh.UVs[i * 2 + 1];
            // V140: у древесины теперь ДВЕ ячейки — сплошная и кора, поэтому признак
            // вынесен в FoliageAtlas.IsFoliageUv (иначе ствол попал бы в листву).
            bool isFoliage = FoliageAtlas.IsFoliageUv(u, v);
            if (!isFoliage)
            {
                m.WoodVertCount++;
                if (y <= trunkBandTop)
                {
                    if (x < trunkMinX) trunkMinX = x;
                    if (x > trunkMaxX) trunkMaxX = x;
                    if (z < trunkMinZ) trunkMinZ = z;
                    if (z > trunkMaxZ) trunkMaxZ = z;
                }
                continue;
            }

            foliageCount++;
            m.FoliageVertCount++;
            foliageYSum += y;
            if (y < foliageMinY) foliageMinY = y;

            float r = MathF.Sqrt(x * x + z * z);
            if (r > crownR) crownR = r;

            int b = (int)((y - minY) / m.Height * 5f);
            bands[Math.Clamp(b, 0, 4)]++;
            int fb = (int)((y - minY) / m.Height * 20f);
            fine[Math.Clamp(fb, 0, 19)]++;
        }

        if (trunkMaxX > trunkMinX)
        {
            float d = MathF.Max(trunkMaxX - trunkMinX, trunkMaxZ - trunkMinZ);
            if (d > 1e-5f) m.Slenderness = m.Height / d;
        }

        if (foliageCount == 0) return m;

        m.FoliageFraction = foliageCount / (float)n;
        m.FoliageCardEstimate = foliageCount / 4; // 4 verts per card (quad)
        m.CrownRatio = (crownR * 2f) / m.Height;
        m.BoleClearance = (foliageMinY - minY) / m.Height;
        m.FoliageCentroid = (float)(foliageYSum / foliageCount - minY) / m.Height;
        for (int b = 0; b < 5; b++) m.FoliageBands[b] = bands[b] / (float)foliageCount;

        // Просветы ищем только в облиственной части: ниже самой нижней листвы это
        // ствол, а не дыра в кроне (за него отвечает BoleClearance).
        int firstFilled = -1, lastFilled = -1;
        for (int b = 0; b < 20; b++)
        {
            if (fine[b] <= 0) continue;
            if (firstFilled < 0) firstFilled = b;
            lastFilled = b;
        }
        if (firstFilled >= 0 && lastFilled > firstFilled)
        {
            int span = lastFilled - firstFilled + 1;
            double mean = 0;
            for (int b = firstFilled; b <= lastFilled; b++) mean += fine[b];
            mean /= span;
            float emptyLevel = (float)(mean * 0.2);

            int run = 0, best = 0, empties = 0;
            for (int b = firstFilled; b <= lastFilled; b++)
            {
                if (fine[b] < emptyLevel)
                {
                    run++; empties++;
                    if (run > best) best = run;
                }
                else run = 0;
            }
            m.FoliageGapMax = best / 20f;
            m.FoliageGapFraction = empties / (float)span;
        }
        return m;
    }

    /// <summary>Усреднение по нескольким вариантам одного вида.</summary>
    public static PlantMetrics Average(List<PlantMetrics> list)
    {
        var a = new PlantMetrics();
        if (list.Count == 0) return a;
        foreach (var m in list)
        {
            a.Height += m.Height;
            a.CrownRatio += m.CrownRatio;
            a.BoleClearance += m.BoleClearance;
            a.FoliageCentroid += m.FoliageCentroid;
            a.FoliageFraction += m.FoliageFraction;
            a.FoliageGapMax += m.FoliageGapMax;
            a.FoliageGapFraction += m.FoliageGapFraction;
            a.VertexCount += m.VertexCount;
            a.FoliageVertCount += m.FoliageVertCount;
            a.WoodVertCount += m.WoodVertCount;
            a.FoliageCardEstimate += m.FoliageCardEstimate;
            a.Slenderness += m.Slenderness;
            for (int b = 0; b < 5; b++) a.FoliageBands[b] += m.FoliageBands[b];
        }
        float k = 1f / list.Count;
        a.Height *= k; a.CrownRatio *= k; a.BoleClearance *= k;
        a.FoliageCentroid *= k; a.FoliageFraction *= k;
        a.FoliageGapMax *= k; a.FoliageGapFraction *= k;
        a.VertexCount = (int)(a.VertexCount * k);
        a.FoliageVertCount = (int)(a.FoliageVertCount * k);
        a.WoodVertCount = (int)(a.WoodVertCount * k);
        a.FoliageCardEstimate = (int)(a.FoliageCardEstimate * k);
        a.Slenderness *= k;
        for (int b = 0; b < 5; b++) a.FoliageBands[b] *= k;
        return a;
    }

    public string ToJson()
    {
        var c = CultureInfo.InvariantCulture;
        var sb = new StringBuilder("{");
        sb.Append("\"height\":").Append(Height.ToString("F3", c)).Append(',');
        sb.Append("\"crownRatio\":").Append(CrownRatio.ToString("F3", c)).Append(',');
        sb.Append("\"boleClearance\":").Append(BoleClearance.ToString("F3", c)).Append(',');
        sb.Append("\"foliageCentroid\":").Append(FoliageCentroid.ToString("F3", c)).Append(',');
        sb.Append("\"foliageFraction\":").Append(FoliageFraction.ToString("F3", c)).Append(',');
        sb.Append("\"foliageGapMax\":").Append(FoliageGapMax.ToString("F3", c)).Append(',');
        sb.Append("\"foliageGapFraction\":").Append(FoliageGapFraction.ToString("F3", c)).Append(',');
        sb.Append("\"slenderness\":").Append(Slenderness.ToString("F1", c)).Append(',');
        sb.Append("\"verts\":").Append(VertexCount.ToString(c)).Append(',');
        sb.Append("\"foliageVerts\":").Append(FoliageVertCount.ToString(c)).Append(',');
        sb.Append("\"woodVerts\":").Append(WoodVertCount.ToString(c)).Append(',');
        sb.Append("\"foliageCards\":").Append(FoliageCardEstimate.ToString(c)).Append(',');
        sb.Append("\"foliageBands\":[");
        for (int b = 0; b < 5; b++)
        {
            if (b > 0) sb.Append(',');
            sb.Append(FoliageBands[b].ToString("F3", c));
        }
        sb.Append("]}");
        return sb.ToString();
    }
}
