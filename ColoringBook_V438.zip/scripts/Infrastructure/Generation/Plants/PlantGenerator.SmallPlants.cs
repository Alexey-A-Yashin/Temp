using System;
using System.Collections.Generic;
using ColoringBook.Domain.Level;
using ColoringBook.Infrastructure.Generation;

namespace ColoringBook.Infrastructure.Generation.Plants;

// ------------------------------------------------------------------
//  Мелкие растения на Л-системах (п.8.3 — решение принято, это его
//  реализация): Bush, Flower, Reed. Используют движок из
//  PlantGenerator.LSystem.cs.
//
//  Bush раньше шёл через GenerateColonizedTree(bush:true) — тот же SCA,
//  что и Deciduous (уже визуально обкатанный за много итераций). Новая
//  Л-версия ЕЩЁ НЕ проверена глазами — численно она заметно легче старой
//  (см. итоги харнесса в логе), это первая проходка, а не финальная
//  замена "потому что лучше". GenerateColonizedTree(bush:true) никуда не
//  делся (Deciduous по-прежнему его использует) — откат на старый Bush
//  это одна строка в Generate() ниже, если новый не понравится глазами.
// ------------------------------------------------------------------
public static partial class PlantGenerator
{
    /// <summary>
    /// Форма роста кустарника. Различима силуэтом на любой дистанции — в отличие от
    /// вида, который читается ближе трёх метров (замер по обходу: 83.5% кустов в кадре
    /// мельче десяти точек экрана).
    /// </summary>
    private enum BushForm
    {
        /// <summary>Стелющийся: можжевельник, ива сетчатая. Ниже и шире человека.</summary>
        Creeping = 0,
        /// <summary>Подушковидный: рододендрон, альпийская роза. Полусфера от земли.</summary>
        Cushion = 1,
        /// <summary>Высокие заросли: ольха зелёная, ива козья, лещина.</summary>
        Wide = 2,
    }

    private static PlantMeshData GenerateBushL(SeededRandom rnd, PlantGenome g)
    {
        int q = Math.Clamp(QualityLevel, 0, 12);

        // ВОЗРАСТ. Раньше куст был одного размера при любом возрасте — замер по логам
        // показывал height = 0.990 на всех age от 1 до 8, тогда как три дерева росли.
        // У кустарника возраст осмыслен: он и выше становится, и гуще ветвится.
        // В терминах Л-системы «старше» = больше шагов деривации (ABOP: шаг деривации
        // и есть шаг развития), поэтому возраст добавляется именно к n.
        float ageF = Math.Clamp(AgeLevel, 0, 8) / 8f;
        // Высота по форме роста, а не одна на всех. Справочно: можжевельник
        // стелющийся 0.3–0.8 м, рододендрон и альпийская роза 0.5–1.2, ольха
        // зелёная и ива козья 2–4. Раньше все три вида были ровно 3.0 м.
        // V141: множители формы приведены к натуре. Средняя высота типа теперь 1.1 м,
        // поэтому стелющийся получает 0.5 м, подушковидный 0.85, заросли 3.0 — ровно
        // справочные значения для можжевельника, альпийской розы и ольхи зелёной.
        float formH = (BushForm)(g.Species % 3) switch
        {
            BushForm.Creeping => 0.45f,
            BushForm.Cushion  => 0.78f,
            _                 => 2.70f,
        };
        float h = formH * g.HeightMul * (0.45f + ageF * 0.75f);
        var mesh = new PlantMeshData { LocalHeight = h };
        // Вид нужен ради формы листа: лещина, ива и можжевельник рисовались одной
        // ячейкой атласа, потому что Л-система про вид ничего не знала.
        var species = PlantSpecies.Get(g.Kind, g.Species);

        // Реальные кустарники — несколько стволов прямо от земли (Weber-Penn paper,
        // §1: "shrubs... usually shorter and have multiple trunks originating directly
        // from the ground"), а не один ствол с кроной, как у дерева.
        // ---- V132: ФОРМА РОСТА ВМЕСТО ВИДА ----
        //
        // ЗАМЕР: 83.5% кустов в кадре мельче десяти точек экрана, а различить ВИД по
        // форме листа и характеру ветвления можно ближе трёх метров. То есть три вида
        // как список пород избыточны — но не как три РАЗНЫЕ ФОРМЫ РОСТА: силуэт
        // читается на любой дистанции, и именно он различает стелющийся можжевельник,
        // округлый рододендрон и высокие заросли ольхи.
        //
        // Габитус берётся из ботаники (Musso 2025; Beikircher & Mayr 2008): рост
        // кустарника БАЗИТОННЫЙ и СИМПОДИАЛЬНЫЙ — несколько независимых побегов от
        // корневой шейки, главной оси нет, ветвление сильнее у основания. Прежние
        // «2–5 стволов» с деревянной схемой ветвления давали дерево в миниатюре.
        var form = (BushForm)(g.Species % 3);
        int trunks = form switch
        {
            BushForm.Creeping => 9 + (int)(g.Branchiness * 6f),   // стелющийся: много слабых
            BushForm.Cushion  => 7 + (int)(g.Branchiness * 5f),   // подушка: густой пучок
            _                 => 5 + (int)(g.Branchiness * 4f),   // заросли: меньше, но мощнее
        };
        // Глубина деривации. На уровне она короче: число сегментов скелета растёт по
        // ветвлению примерно как 1.8ⁿ, и лишний шаг стоит куста почти вдвое. Качество
        // в компактном режиме в глубину не добавляется вовсе — на дистанции, с которой
        // куст виден, разница между n=6 и n=9 не читается, а цена отличается вчетверо.
        // V129: глубина на шаг меньше. Куст стоит 926 треугольников и даёт 17.9%
        // стоимости кадра при 11 461 экземпляре — это больше, чем все хвойные вместе.
        // Число сегментов скелета растёт по ветвлению примерно как 1.8ⁿ, поэтому один
        // шаг глубины — это почти вдвое.
        int n = Detail == FoliageDetail.Compact
            ? 2 + (int)(ageF * 3f)
            : 4 + (int)(ageF * 4f) + Math.Min(q, 8) / 3; // возраст + немного качества
        float baseLen = h * 0.26f;
        float baseWidth = 0.026f * (0.8f + g.CrownMul * 0.3f);

        var rules = new Dictionary<char, LRule>
        {
            ['A'] = (s, r) =>
            {
                float l = s.P0, w = s.P1;
                float r1 = r.NextFloat(0.68f, 0.85f);
                const float wr = 0.79f; // ~da Vinci/pipe-model falloff на разветвлении (ABOP/Weber-Penn n≈2)
                float a1 = r.NextFloat(26f, 48f);
                float roll1 = r.NextFloat(0f, 360f);
                // Золотой угол между дочерними ветками вокруг оси родителя — тот же
                // приём, что уже используется для филлотаксиса листьев/игл выше по
                // файлу, подтверждён формулой Vogel (ABOP гл.4).
                float roll2 = roll1 + 137.5079f + r.NextFloat(-18f, 18f);
                var list = new List<LSym>
                {
                    new('F', l, w),
                    new('['), new('/', roll1), new('&', a1), new('A', l * r1, w * wr), new(']')
                };
                // ПРАВКА (харнесс-замер: первая версия с 1 листом/узел давала Bush в
                // ~100 раз легче старого SCA-Bush — 2200 tris на q:6 против 227238).
                // У настоящего кустарника на узле пучок листьев, а не один (тот же
                // принцип плотности, что у Deciduous-кроны выше по файлу) — вместо
                // углубления рекурсии (риск комбинаторного взрыва мелких веточек)
                // умножается число карточек НА узел, скелет остаётся дешёвым.
                // КОМПАКТНЫЙ РЕЖИМ. Пучок из 4–7 карточек на узел — причина того, что куст
                // стоил 15 965 треугольников, то есть дороже компактного дерева, при высоте
                // около метра. Флаг FoliageDetail до этой ветки просто не доходил: и в
                // витрине, и на уровне куст строился одинаково (замер: 15 965 в обоих режимах).
                //
                // На уровне вместо пучка ставится ОДНА карточка, увеличенная по площади в
                // корень из среднего размера пучка (5.5) — та же компенсация, что у листвы
                // лиственных и у прореживания в BuildLodMesh: покрытие кроны сохраняется.
                // Тот же размен, что у деревьев: карточек меньше, каждая крупнее.
                // Листва РАВНОМЕРНО ПО ПОБЕГУ. У дерева она сосредоточена на концах
                // ветвей (там свет), у куста побег облиствен по всей длине — потому
                // куст и выглядит плотной массой без просвета внизу.
                int leafTuft = Detail == FoliageDetail.Compact ? 2 : 4 + r.NextInt(4);
                float leafScale = Detail == FoliageDetail.Compact ? 1.60f : 1f;  // V130: пучок в ячейке (куст ниже дерева — карточка крупнее в долях высоты)
                for (int k = 0; k < leafTuft; k++)
                    list.Add(new LSym('L', MathF.Max(0.02f, l * r.NextFloat(0.45f, 0.70f) * leafScale)));
                // Не каждый узел даёт вторую ветку — иначе крона растёт строго 2^n на
                // каждом уровне и выглядит "по линейке" вместо естественно неравномерной.
                if (r.NextFloat() < 0.80f)
                {
                    float a2 = r.NextFloat(30f, 58f);
                    float r2 = r.NextFloat(0.58f, 0.80f);
                    list.Add(new LSym('['));
                    list.Add(new LSym('/', roll2));
                    list.Add(new LSym('&', a2));
                    list.Add(new LSym('A', l * r2, w * wr));
                    list.Add(new LSym(']'));
                }
                return list;
            }
        };

        var pal = new LPalette(TrR, TrG, TrB, FoR, FoG, FoB);

        for (int t = 0; t < trunks; t++)
        {
            // ПОБЕГИ РАСХОДЯТСЯ ОТ КОРНЕВОЙ ШЕЙКИ ВЕЕРОМ.
            //
            // Раньше стволы стояли почти вертикально в пятне ±0.10 — отсюда «пучок
            // палок». У куста побеги отклоняются тем сильнее, чем больше их число:
            // так и получается силуэт вазы или подушки, а не метлы. Азимут задан
            // равномерно по кругу со сдвигом, чтобы побеги не слипались с одной стороны.
            float shootAz = (t + rnd.NextFloat(-0.35f, 0.35f)) / trunks * MathF.PI * 2f;
            float rootR = form == BushForm.Wide ? 0.06f : 0.03f;
            float ox = MathF.Cos(shootAz) * rootR;
            float oz = MathF.Sin(shootAz) * rootR;
            float leanDeg = form switch
            {
                BushForm.Creeping => rnd.NextFloat(52f, 78f),   // почти по земле
                BushForm.Cushion  => rnd.NextFloat(28f, 52f),   // ваза
                _                 => rnd.NextFloat(12f, 34f),   // вверх, но враскид
            };
            float lean = leanDeg * MathF.PI / 180f;
            // Наклон — НАРУЖУ от центра куста, по азимуту собственного побега.
            float leanDir = shootAz + rnd.NextFloat(-0.4f, 0.4f);
            var leanAxis = new Vec3(MathF.Cos(leanDir), 0f, MathF.Sin(leanDir));
            var startFwd = Norm(RotateAroundAxis(new Vec3(0, 1, 0), leanAxis, lean));

            var axiom = new List<LSym> { new('A', baseLen * rnd.NextFloat(0.85f, 1.15f), baseWidth) };
            var derived = Derive(axiom, rules, n, rnd);
            // Тропизм слегка вниз: побеги кустарника прогибаются под собственным весом.
            RunLSystem(derived, new Vec3(ox, 0f, oz), startFwd, 32f, mesh, rnd, pal,
                tropism: new Vec3(0f, -1f, 0f), tropismE: 0.10f, leafCell: species.Leaf);
        }
        return mesh;
    }

    private static PlantMeshData GenerateFlowerL(SeededRandom rnd, PlantGenome g)
    {
        int q = Math.Clamp(QualityLevel, 0, 12);
        // V109: куртина читается пятном. V108 (h=1.35, 7–14 стеблей) всё ещё давала
        // ~1 экземпляр ≥10px на кадр — большинство уходило в impostor <2px.
        float h = 1.00f * g.HeightMul; // V124: низкий куст цветов
        var mesh = new PlantMeshData { LocalHeight = h };

        // ---- V129: ЦЕНА ЦВЕТКА ПРИВЕДЕНА К ЕГО ВИДИМОСТИ ----
        //
        // Замер по обходу: 375 цветов в кадре, из них крупнее десяти точек экрана —
        // ШЕСТЬ, а стоят они 453 000 треугольников. Это худшее соотношение на уровне:
        // 1 158 треугольников на растение высотой в метр, которое почти всегда мельче
        // двух точек.
        //
        // Причина в том, что каждый венчик собирается из отдельных лепестков и диска
        // флоретов — геометрия, рассчитанная на разглядывание вплотную. На дистанции,
        // с которой цветы вообще видны, венчик занимает считаные точки: там достаточно
        // одной карточки с рисунком лепестка из атласа.
        //
        // Стеблей меньше, лепестков меньше, сердцевина одной карточкой вместо диска.
        int stems = 3 + q / 3 + rnd.NextInt(3);
        int petals = 4;
        float petalR = 0.20f + q * 0.008f;
        int discFlorets = 1;

        var rules = new Dictionary<char, LRule>
        {
            ['W'] = (s, r) =>
            {
                int stepsLeft = (int)s.P1;
                float len = s.P0;
                if (stepsLeft <= 0) return new List<LSym> { new('H') };
                var list = new List<LSym> { new('F', len, 0.010f) };
                if (r.NextFloat() < 0.4f) list.Add(new LSym('L', len * 0.55f));
                list.Add(new LSym('W', len * r.NextFloat(0.88f, 1.05f), stepsLeft - 1));
                return list;
            },
            ['H'] = (s, r) =>
            {
                var list = new List<LSym>();
                float baseAng = r.NextFloat(0f, 360f);
                for (int p = 0; p < petals; p++)
                {
                    float roll = baseAng + p * (360f / petals) + r.NextFloat(-8f, 8f);
                    float tilt = r.NextFloat(6f, 22f);
                    list.Add(new LSym('['));
                    list.Add(new LSym('/', roll));
                    list.Add(new LSym('&', tilt));
                    list.Add(new LSym('O', petalR * r.NextFloat(0.85f, 1.05f)));
                    list.Add(new LSym(']'));
                }
                // Диск сердцевины — спираль Vogel (ABOP гл.4, формула 4.1: φ=n·137.5°,
                // r=c·√n), та же математика, что даёт расположение семечек подсолнуха /
                // язычковых цветков ромашковых, вместо одного блоба-заглушки.
                const float GoldenAngle = 137.5079f;
                for (int fi = 0; fi < discFlorets; fi++)
                {
                    float phi = fi * GoldenAngle;
                    float rad = 0.032f * MathF.Sqrt(fi + 1);
                    list.Add(new LSym('['));
                    list.Add(new LSym('/', phi));
                    list.Add(new LSym('&', 5f));
                    list.Add(new LSym('f', rad));
                    list.Add(new LSym('C', 0.026f));
                    list.Add(new LSym(']'));
                }
                return list;
            }
        };

        for (int sIdx = 0; sIdx < stems; sIdx++)
        {
            float ox = rnd.NextFloat(-0.25f, 0.25f);
            float oz = rnd.NextFloat(-0.25f, 0.25f);
            float hh = h * rnd.NextFloat(0.50f, 1f);
            int steps = 3 + rnd.NextInt(3);
            float segLen = hh / steps;

            // Цвет лепестков варьируется по стеблю-инстансу, не по каждому лепестку —
            // иначе цветок выглядит "жёваной палитрой" вместо согласованного бутона.
            float pr = rnd.NextFloat(0.85f, 1f), pg = rnd.NextFloat(0.65f, 0.92f), pb = rnd.NextFloat(0.12f, 0.42f);
            var palI = new LPalette(0.22f, 0.48f, 0.14f, 0.30f, 0.55f, 0.20f, pr, pg, pb, 0.95f, 0.80f, 0.15f);

            var axiom = new List<LSym> { new('W', segLen, steps) };
            var derived = Derive(axiom, rules, steps + 3, rnd); // +3 — с запасом до полного разворота W...H

            RunLSystem(derived, new Vec3(ox, 0f, oz), new Vec3(0, 1, 0), 10f, mesh, rnd, palI);
        }
        return mesh;
    }

    private static PlantMeshData GenerateReedL(SeededRandom rnd, PlantGenome g)
    {
        int q = Math.Clamp(QualityLevel, 0, 12);

        // Возраст: камыш многолетний, куртина с годами становится выше и гуще.
        // Замер по логам: до этой правки height = 2.058 на всех age.
        float ageF = Math.Clamp(AgeLevel, 0, 8) / 8f;
        float h = 2.2f * g.HeightMul * (0.50f + ageF * 0.70f);
        var mesh = new PlantMeshData { LocalHeight = h };
        int stems = 3 + (int)(ageF * 5f) + q / 3;
        int Steps = 4 + (int)(ageF * 2f);

        var rules = new Dictionary<char, LRule>
        {
            ['W'] = (s, r) =>
            {
                int stepsLeft = (int)s.P1;
                float len = s.P0;
                if (stepsLeft <= 0)
                    return new List<LSym> { new('O', len * 0.95f), new('['), new('&', 12f), new('O', len * 0.7f), new(']') };

                var list = new List<LSym>();
                float bend = r.NextFloat(-6f, 6f);
                if (MathF.Abs(bend) > 1e-3f) list.Add(new LSym(bend > 0 ? '&' : '^', MathF.Abs(bend)));
                // Радиус сужается к верхушке — без полного pipe-model для простого
                // линейного стебля (без ветвления копить радиус снизу вверх не от чего).
                float radius = 0.014f * MathF.Pow(0.86f, Steps - stepsLeft);
                list.Add(new LSym('F', len, radius));

                // Листья-лезвия камыша под острым углом от узла, через сегмент.
                if (stepsLeft % 2 == 0)
                {
                    float side = r.NextFloat() < 0.5f ? 1f : -1f;
                    list.Add(new LSym('['));
                    list.Add(new LSym('/', r.NextFloat(0f, 360f)));
                    list.Add(new LSym('&', side * r.NextFloat(35f, 55f)));
                    list.Add(new LSym('N', len * r.NextFloat(1.3f, 1.9f)));
                    list.Add(new LSym(']'));
                }
                list.Add(new LSym('W', len * r.NextFloat(0.90f, 1.02f), stepsLeft - 1));
                return list;
            }
        };

        var pal = new LPalette(0.30f, 0.42f, 0.14f, 0.34f, 0.50f, 0.20f, 0.58f, 0.52f, 0.22f);

        for (int sIdx = 0; sIdx < stems; sIdx++)
        {
            float ox = rnd.NextFloat(-0.18f, 0.18f);
            float oz = rnd.NextFloat(-0.18f, 0.18f);
            float hh = h * rnd.NextFloat(0.70f, 1f);
            float segLen = hh / Steps;

            var axiom = new List<LSym> { new('W', segLen, Steps) };
            var derived = Derive(axiom, rules, Steps + 2, rnd);
            // Камыш заметно клонится метёлкой — тропизм вниз сильнее, чем у куста.
            RunLSystem(derived, new Vec3(ox, 0f, oz), new Vec3(0, 1, 0), 8f, mesh, rnd, pal,
                tropism: new Vec3(0f, -1f, 0f), tropismE: 0.16f);
        }
        return mesh;
    }
}
