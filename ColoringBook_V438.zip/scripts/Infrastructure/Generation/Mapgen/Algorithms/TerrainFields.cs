using System;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

/// <summary>
/// ПОЛЯ СВОЙСТВ МЕСТНОСТИ — вход для цикла эрозии.
///
/// ---- ЗАЧЕМ ОТДЕЛЬНО ----
///
/// Прежде они заводились внутри BuildLevel, метода в 1382 строки. Разбор
/// большой модели показал: он делает двадцать девять разных дел, и оттого
/// нельзя ни заменить часть, ни проверить её отдельно.
///
/// Здесь собраны все поля, которые цикл эрозии ЧИТАЕТ, но не меняет. Они
/// считаются один раз до цикла.
///
/// ---- РАЗМЕР КАК ВХОДНАЯ ВЕЛИЧИНА ----
///
/// Все величины полей заданы в километрах, а не в ячейках: тогда рельеф не
/// зависит от густоты сетки.
///
/// Исключение — осыпание и врез: они считаются на ячейку. Приведение их к
/// километру проверено и отвергнуто: явная схема осыпания при этом
/// РАСХОДИТСЯ. Требует неявной схемы — отдельная работа.
/// </summary>
public sealed class TerrainFields
{
    /// <summary>Прочность породы: врез делится на неё.</summary>
    public float[] Hardness { get; }

    /// <summary>Осадки по месту: с орографией и дождевой тенью.</summary>
    public float[] Rain { get; }

    /// <summary>Скорость вреза по месту, уже делённая на прочность.</summary>
    public float[] Erodibility { get; }

    /// <summary>Скорость осыпания по месту.</summary>
    public float[] Diffusivity { get; }

    /// <summary>Скорость поднятия по месту.</summary>
    public float[] Uplift { get; }

    /// <summary>Прибавка к дну долин по типу гор.</summary>
    public float[]? FloorLift { get; }

    /// <summary>Сторона сетки.</summary>
    public int Side { get; }

    /// <summary>Размер ячейки в километрах — приведение к километру.</summary>
    public float CellKm { get; }

    public TerrainFields(int side, float cellKm, float[] hardness, float[] rain,
                         float[] erodibility, float[] diffusivity, float[] uplift,
                         float[]? floorLift)
    {
        Side = side;
        CellKm = cellKm;
        Hardness = hardness;
        Rain = rain;
        Erodibility = erodibility;
        Diffusivity = diffusivity;
        Uplift = uplift;
        FloorLift = floorLift;
    }
}
