using System;
using System.Collections.Generic;
using System.Linq;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

/// <summary>
/// РОСТ ХРЕБТОВ ПО СЛАБЫМ МЕСТАМ.
///
/// ---- ЗАЧЕМ ----
///
/// Прежний построитель растил дерево звеньев с отрогами, и массивы выходили
/// ОСТРОВКАМИ среди пустоты: каждый рос сам, между ними зазоры шириной с
/// сам массив. Пустот выходило до сорока процентов уровня.
///
/// Из работы о сетях хребтов Земли: в природе горная страна есть СВЯЗНОЕ
/// ДЕРЕВО — узлы это точки ветвления и концы, рёбра связывают их.
///
/// ---- КАК ----
///
/// Приём взят из физики: инвазивная просачиваемость. Хребет растёт туда, где
/// сопротивление НАИМЕНЬШЕЕ — как трещина или разряд молнии.
///
///     1. зёрна кладутся по уровню
///     2. рост идёт в ячейку с наименьшим сопротивлением
///     3. сила ветви есть ЧИСЛО ЕЁ ПОТОМКОВ — как площадь водосбора
///     4. сопротивление растёт с удалением от зерна: рост сам затухает
///
/// ---- ПУТЬ К ЭТОМУ ----
///
/// Пять исполнений были негодны, и дважды я объявлял приём непригодным.
///
///     кратчайший путь         гладкий купол: пути усредняются
///     рост по слабым          связная сеть, но плоская
///     убывание по ветвлениям  ветвлений ПЯТЬСОТ на путь, порядок обнулялся
///     мелкая рябь             пятно вместо ветвей
///     степень сопротивления   то же
///
/// Разбор устройства нашёл две беды, которых подбор не находил:
///
///     ветви БЫЛИ, но толщиной в ячейку (край 87% против 6% у круга)
///     ветвлений на пути пятьсот, а не десяток
///
/// Решение пришло из природы рек: сила ветви есть число потомков.
/// </summary>
public static class RidgeGrowth
{
    /// <summary>Итог роста: сила ветви в каждой ячейке.</summary>
    public readonly struct Result
    {
        public readonly float[] Strength;
        public readonly bool[] Grown;
        public Result(float[] strength, bool[] grown)
        { Strength = strength; Grown = grown; }
    }

    /// <summary>
    /// Растит сеть хребтов на сетке.
    /// </summary>
    /// <param name="side">сторона сетки</param>
    /// <param name="seeds">зёрна: с них начинается рост</param>
    /// <param name="reachCells">докуда растёт массив, в ячейках</param>
    /// <param name="stretch">вытянутость вдоль пояса; 1 — круглый</param>
    /// <param name="beltRad">направление пояса, радианы</param>
    /// <param name="edgePower">резкость края: у плато выше</param>
    /// <param name="fill">какую долю сетки занять</param>
    public static Result Grow(int side, IReadOnlyList<int> seeds, float reachCells,
                              float stretch, float beltRad, float edgePower,
                              float fill, int seed)
    {
        int n = side * side;
        var rnd = new Random(seed);

        // Сопротивление: мелкая рябь. Гладкий шум давал пятно — соседи
        // выходили почти равны, и очередь брала их подряд.
        var res = new float[n];
        for (int k = 0; k < n; k++) res[k] = (float)rnd.NextDouble();

        var grown = new bool[n];
        var parent = new int[n];
        var kids = new int[n];
        var depth = new int[n];
        for (int k = 0; k < n; k++) parent[k] = -1;

        float bc = MathF.Cos(beltRad), bs = MathF.Sin(beltRad);
        var queue = new PriorityQueue<int, float>();

        foreach (int s0 in seeds)
        {
            if (s0 < 0 || s0 >= n || grown[s0]) continue;
            grown[s0] = true;
            foreach (int d in new[] { -side, -1, 1, side })
            {
                int nb = s0 + d;
                if (nb < 0 || nb >= n || grown[nb] || parent[nb] >= 0) continue;
                parent[nb] = s0;
                queue.Enqueue(nb, res[nb]);
            }
        }
        if (seeds.Count == 0) return new Result(new float[n], grown);

        int placed = 0, limit = (int)(n * Math.Clamp(fill, 0.02f, 0.9f));
        while (queue.Count > 0 && placed < limit)
        {
            int c = queue.Dequeue();
            if (grown[c]) continue;
            int i = c % side, j = c / side;
            if (i < 1 || j < 1 || i >= side - 1 || j >= side - 1) continue;

            grown[c] = true; placed++;
            int p = parent[c];
            if (p >= 0) { kids[p]++; depth[c] = depth[p] + 1; }

            foreach (int d in new[] { -side, -1, 1, side })
            {
                int nb = c + d;
                if (nb < 0 || nb >= n || grown[nb] || parent[nb] >= 0) continue;
                parent[nb] = c;

                // Расстояние до ближайшего зерна, вытянутое вдоль пояса.
                int ni = nb % side, nj = nb / side;
                float best = float.MaxValue;
                foreach (int sd in seeds)
                {
                    float dx = ni - sd % side, dy = nj - sd / side;
                    float along = dx * bc + dy * bs;
                    float across = -dx * bs + dy * bc;
                    float dd = along * along / (stretch * stretch) + across * across;
                    if (dd < best) best = dd;
                }

                // Сопротивление растёт с удалением: рост сам затухает на краю.
                float far = MathF.Sqrt(best) / MathF.Max(reachCells, 1f);
                queue.Enqueue(nb, res[nb] + MathF.Pow(far, edgePower));
            }
        }

        // ---- СИЛА ВЕТВИ ЕСТЬ ЧИСЛО ПОТОМКОВ ----
        //
        // У ствола их тысячи, у концевой веточки один. Это то же, чем меряют
        // реки: площадь водосбора.
        //
        // Обход идёт от листьев к корню — по убыванию глубины.
        var weight = new int[n];
        var order = Enumerable.Range(0, n).Where(k => grown[k])
                        .OrderByDescending(k => depth[k]).ToArray();
        foreach (int k in order)
        {
            weight[k]++;
            int p = parent[k];
            if (p >= 0 && grown[p]) weight[p] += weight[k];
        }

        int wmax = Math.Max(1, weight.Max());
        var strength = new float[n];
        for (int k = 0; k < n; k++)
            if (grown[k]) strength[k] = MathF.Pow(weight[k] / (float)wmax, 0.28f);

        return new Result(strength, grown);
    }

    /// <summary>
    /// Утолщает ветви: тонкая нить становится хребтом.
    ///
    /// Ветви растут толщиной в ячейку — замер показал край 87% против 6% у
    /// круга. На снимке они сливались в пятно, и я пять раз счёл приём
    /// негодным.
    /// </summary>
    public static void Thicken(float[] field, int side, int passes, float keep)
    {
        for (int pass = 0; pass < passes; pass++)
        {
            var t = (float[])field.Clone();
            for (int j = 1; j < side - 1; j++)
            for (int i = 1; i < side - 1; i++)
            {
                int c = j * side + i;
                float mx = MathF.Max(MathF.Max(t[c - 1], t[c + 1]),
                                     MathF.Max(t[c - side], t[c + side]));
                field[c] = MathF.Max(t[c], mx * keep);
            }
        }
    }
}
