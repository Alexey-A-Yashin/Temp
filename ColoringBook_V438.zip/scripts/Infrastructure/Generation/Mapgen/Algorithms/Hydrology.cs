using System;
using System.Collections.Generic;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

/// <summary>
/// Гидрология: озёра и реки ЦЕЛИКОМ из рельефа, полученного эрозией.
/// Никакой Valley/Pass-геометрии здесь нет — только граф соседства и высоты.
///
/// СНАЧАЛА КОНДИЦИОНИРОВАНИЕ (priority-flood + epsilon, Barnes et al. 2014):
/// заливаем поверхность так, чтобы из ЛЮБОЙ клетки существовал непрерывный путь
/// вниз до устья. Каждой клетке присваивается filled = max(elev, filled(родителя)
/// + eps); малое eps даёт строго убывающий путь, то есть отсутствие плоских
/// «ступеней-озёр», на которых сток встаёт.
///
/// ПОЧЕМУ БЕЗ ЭТОГО НЕ РАБОТАЕТ (замер, seed 42): в рельефе оставалось 88
/// незаполненных локальных минимумов, и каждый ОБРЫВАЛ накопление стока. Реки
/// получались 42 разорванными фрагментами, крупнейший — 42 клетки, а «главная
/// река» собирала всего 8.6% карты. После кондиционирования и прорезания устья
/// (см. Outlet.cs) главная река собирает 85-99% карты, длиннейшее русло — до 234
/// клеток. Это ровно та разница, которая видна на карте: ветвящаяся сеть вместо
/// синих обрубков.
///
/// ОЗЕРО — там, где поверхность пришлось поднять заметно: filled - elev больше
/// MinLakeDepth. Это ровно те впадины, которые физически заполнились бы водой, и
/// их уровень берётся из фактического рельефа.
///
/// Класс НЕ ЗАВИСИТ ОТ GODOT и проверяется в mapgen-харнессе.
/// </summary>
public static class Hydrology
{
    public sealed class Settings
    {
        /// <summary>Насколько глубоко должна быть залита впадина, чтобы считаться
        /// озером, а не просто сырым понижением.
        ///
        /// БЫЛО 0.03 — воды выходило слишком много (9.5% карты, 19-23 озера), долины
        /// оказывались залиты и как долины не читались. Замер по 4 сидам:
        ///   0.08 -> 2.8-6.8% воды,  8-15 озёр
        ///   0.10 -> 2.0-5.3% воды,  3-14 озёр   <- принято
        ///   0.12 -> 1.7-4.1% воды,  2- 9 озёр
        /// Было взято 0.10, но после расширения долин (правка 02.08: долин 6-9,
        /// радиусы x1.5, полоса перехода 0.85) широкие долины дают меньше замкнутых
        /// котловин, и при 0.10 воды осталось всего 0.8% — озёра почти пропали.
        /// Перемер на новой форме рельефа (4 сида):
        ///   0.05 -> 2.2% воды, 5.8 озера   <- принято
        ///   0.07 -> 1.5% воды, 5.8 озера
        ///   0.10 -> 0.8% воды, 2.2 озера
        /// На реки и сток порог не влияет — сток остаётся 96.5% при любом из них,
        /// меняется только что считать озером.</summary>
        /// <summary>Предельная доля регионов чанка, которую может занять ОДНО озеро.
        /// Больше — считается разливом по пойме и осушается.</summary>
        public float MaxLakeAreaFraction = 0.06f;

        public float MinLakeDepth = 0.10f;

        /// <summary>Доля регионов, которые становятся руслами.</summary>
        public float RiverFraction = 0.045f;

        public float MinRiverFlux = 4f;

        /// <summary>Шаг подъёма при заливке. Должен быть много меньше MinLakeDepth,
        /// иначе накопление eps вдоль длинного пути само создаст «озеро».</summary>
        public float Epsilon = 1e-5f;
    }

    public sealed class Result
    {
        public required float[] Filled;
        public required bool[] IsWater;
        public required int[] LakeId;
        public required float[] Flux;
        public required bool[] IsRiver;
        public required int[] Downstream;
        public int LakeCount;
        public int RiverCount;
    }

    /// <summary>
    /// Заливка от точек стока: возвращает поверхность, с которой вода
    /// гарантированно уходит к устью. Исходный массив НЕ меняется.
    /// </summary>
    public static float[] PriorityFlood(
        float[] elevation, int[][] neighbors, bool[] outletMask, float eps = 1e-5f)
    {
        int n = elevation.Length;
        var filled = (float[])elevation.Clone();
        var visited = new bool[n];
        var heap = new PriorityQueue<int, float>();

        for (int r = 0; r < n; r++)
        {
            if (!outletMask[r]) continue;
            visited[r] = true;
            heap.Enqueue(r, filled[r]);
        }

        // Если устья нет вовсе, заливать не от чего — возвращаем как есть.
        if (heap.Count == 0) return filled;

        while (heap.TryDequeue(out int c, out float e))
        {
            foreach (int nb in neighbors[c])
            {
                if (visited[nb]) continue;
                visited[nb] = true;
                float lvl = filled[nb];
                if (lvl <= e) lvl = e + eps;   // поднимаем ровно до спуска к c
                filled[nb] = lvl;
                heap.Enqueue(nb, lvl);
            }
        }

        return filled;
    }

    /// <summary>Осушает водоёмы, занимающие слишком большую долю карты.</summary>
    private static void DrainOversizedLakes(
        bool[] isWater, float[] filled, float[] elevation, int[][] neighbors, float maxFraction)
    {
        int n = isWater.Length;
        int limit = Math.Max(8, (int)(n * maxFraction));
        var seen = new bool[n];
        var comp = new List<int>();
        var q = new Queue<int>();

        for (int start = 0; start < n; start++)
        {
            if (seen[start] || !isWater[start]) continue;
            comp.Clear();
            seen[start] = true;
            q.Clear();
            q.Enqueue(start);
            while (q.Count > 0)
            {
                int c = q.Dequeue();
                comp.Add(c);
                foreach (int nb in neighbors[c])
                {
                    if (seen[nb] || !isWater[nb]) continue;
                    seen[nb] = true;
                    q.Enqueue(nb);
                }
            }
            if (comp.Count <= limit) continue;

            // Осушаем: возвращаем исходную высоту, иначе зеркало останется висеть.
            foreach (int c in comp)
            {
                isWater[c] = false;
                filled[c] = elevation[c];
            }
        }
    }

    public static Result Build(
        float[] elevation, int[][] neighbors, bool[] outletMask, Settings? settings = null)
    {
        var s = settings ?? new Settings();
        int n = elevation.Length;

        var filled = PriorityFlood(elevation, neighbors, outletMask, s.Epsilon);

        // --- Озёра: где поверхность пришлось поднять ---
        var isWater = new bool[n];
        for (int r = 0; r < n; r++)
            isWater[r] = (filled[r] - elevation[r]) > s.MinLakeDepth;

        // ОГРАНИЧЕНИЕ ПЛОЩАДИ ОЗЕРА.
        //
        // Priority-flood заливает впадину до отметки СТОКА. Если впадина большая и
        // пологая — например, пойма между поднятым внутри петли массивом и краевым
        // порогом — уровень поднимается до её края, и вода разливается по долине,
        // визуально вставая НАД поверхностью. Именно это и было видно на скриншоте.
        //
        // Настоящее озеро занимает малую долю чанка. Всё, что разлилось шире порога,
        // считаем ошибкой заливки и осушаем: такая «вода» не озеро, а артефакт
        // незамкнутого рельефа.
        DrainOversizedLakes(isWater, filled, elevation, neighbors, s.MaxLakeAreaFraction);

        // --- Сток по КОНДИЦИОНИРОВАННОЙ поверхности: связен по построению ---
        var downstream = new int[n];
        Array.Fill(downstream, -1);
        for (int r = 0; r < n; r++)
        {
            if (outletMask[r]) continue;          // с устья вода уходит с карты
            float best = filled[r];
            int bestNb = -1;
            foreach (int nb in neighbors[r])
            {
                if (filled[nb] < best) { best = filled[nb]; bestNb = nb; }
            }
            downstream[r] = bestNb;
        }

        var order = new int[n];
        for (int r = 0; r < n; r++) order[r] = r;
        Array.Sort(order, (a, b) => filled[b].CompareTo(filled[a]));

        var flux = new float[n];
        for (int r = 0; r < n; r++) flux[r] = 1f;
        foreach (int r in order)
        {
            int d = downstream[r];
            if (d >= 0) flux[d] += flux[r];
        }

        // --- Реки: порог по накопленному стоку ---
        var sortedFlux = (float[])flux.Clone();
        Array.Sort(sortedFlux);
        float frac = Math.Clamp(s.RiverFraction, 0.005f, 0.15f);
        int thrIdx = Math.Clamp((int)(n * (1f - frac)), 0, n - 1);
        float threshold = MathF.Max(sortedFlux[thrIdx], s.MinRiverFlux);

        var isRiver = new bool[n];
        int riverCount = 0;
        for (int r = 0; r < n; r++)
        {
            if (!isWater[r] && flux[r] >= threshold) { isRiver[r] = true; riverCount++; }
        }

        // --- Нумерация озёр (связные компоненты воды) ---
        var lakeId = new int[n];
        Array.Fill(lakeId, -1);
        int lakeCount = 0;
        var stack = new Stack<int>();
        for (int r = 0; r < n; r++)
        {
            if (!isWater[r] || lakeId[r] >= 0) continue;
            lakeId[r] = lakeCount;
            stack.Push(r);
            while (stack.Count > 0)
            {
                int c = stack.Pop();
                foreach (int nb in neighbors[c])
                {
                    if (isWater[nb] && lakeId[nb] < 0)
                    {
                        lakeId[nb] = lakeCount;
                        stack.Push(nb);
                    }
                }
            }
            lakeCount++;
        }

        return new Result
        {
            Filled = filled,
            IsWater = isWater,
            LakeId = lakeId,
            Flux = flux,
            IsRiver = isRiver,
            Downstream = downstream,
            LakeCount = lakeCount,
            RiverCount = riverCount,
        };
    }
}
