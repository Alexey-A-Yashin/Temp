using System;
using System.Collections.Generic;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

/// <summary>
/// РАЗВЕДКА МЕСТА ДЛЯ УРОВНЯ.
///
/// Игра строит уровень в два прохода: сперва грубое поле по всей территории,
/// потом подробное — ВОКРУГ ВЫБРАННОЙ ЗДЕСЬ ТОЧКИ.
///
/// Вынесено из FarBackground, чтобы стенд звал ТУ ЖЕ разведку: шум рельефа
/// зависит от координат, и поле вокруг нуля — другой кусок местности. Из-за
/// этого замеры стенда расходились с журналом (озёр 31 против 23, островов 4
/// против нуля), пока я не взял центр из журнала вручную.
/// </summary>
public static class Scout
{
    /// <summary>
    /// Открыта наружу: стенд обязан звать ТУ ЖЕ разведку, иначе он меряет
    /// другой кусок местности.
    ///
    /// Шум рельефа зависит от координат: поле вокруг нуля и поле вокруг
    /// выбранной точки — разные долины в одних горах. Настройки те же, рельеф
    /// другой. Из-за этого замеры стенда расходились с журналом: озёр 31 против
    /// 23, островов 4 против нуля.
    /// </summary>
    public static (float X, float Y) BestPlace(float[] field, float[] drainage,
                                              int seed, int scoutSide, int drainageSide,
                                              float extentWorld)
    {
        int fs = scoutSide;
        float ext = extentWorld;
        float cell = ext / (fs - 1);
        float dcell = ext / (drainageSide - 1);

        float lo = float.MaxValue, hi = float.MinValue;
        foreach (var v in field) { if (v < lo) lo = v; if (v > hi) hi = v; }
        float span = MathF.Max(hi - lo, 1e-3f);

        var samples = new List<float>();
        for (int k = 0; k < field.Length; k += 3) samples.Add(field[k]);
        var belts = new BeltThresholds(samples);

        (float X, float Y) best = (0f, 0f);
        float bestFlow = -1f;
        for (int j = 4; j < fs - 4; j++)
        for (int i = 4; i < fs - 4; i++)
        {
            float frac = (field[j * fs + i] - lo) / span;
            if (frac < belts.Forest || frac > belts.Shrub) continue;

            float wx = -ext * 0.5f + i * cell;
            float wz = -ext * 0.5f + j * cell;
            int di = Math.Clamp((int)((wx + ext * 0.5f) / dcell), 0, drainageSide - 1);
            int dj = Math.Clamp((int)((wz + ext * 0.5f) / dcell), 0, drainageSide - 1);
            float flow = drainage[dj * drainageSide + di];
            if (flow > bestFlow) { bestFlow = flow; best = (wx, wz); }
        }

        // Кандидатов может не оказаться: условия перемножаются, и на мягком нраве
        // лесной пояс с заметным стоком иногда пуст. Тогда строим в середине —
        // это не лучшее место, но рабочее, и это видно в журнале.
        if (bestFlow < 0f)
        {
            return (0f, 0f);
        }
        return best;
    }
}
