using System;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

/// <summary>Порода, слагающая склон. Определяет цвет голого камня и осыпи.</summary>
public enum RockKind
{
    /// <summary>Известняк: светлый, серо-белый, местами кремовый.</summary>
    Limestone = 0,
    /// <summary>Песчаник: рыжий и красноватый.</summary>
    Sandstone = 1,
    /// <summary>Базальт: тёмный, серо-синий до почти чёрного.</summary>
    Basalt = 2,
    /// <summary>Сланец: бурый, охристый, с зеленоватым отливом.</summary>
    Schist = 3
}

/// <summary>
/// ГЕОЛОГИЯ: КАКАЯ ПОРОДА ГДЕ ЛЕЖИТ.
///
/// ---- ЗАЧЕМ ЭТО НУЖНО ----
///
/// Монетизация игры построена на продаже красок, а расход красок задаётся
/// палитрой кадра. Замер по пяти кадрам показал: четыре базовых пигмента из
/// восьми не расходуются ВОВСЕ — красная, охра, умбра почти в ноль. Причина не в
/// том, что в кадре мало красного, а в том, что в нём нет ничего охристого,
/// бурого, каменистого: биомы Rock и Scree крашены одним серым тоном.
///
/// Замер на территории 58 км до этой правки:
///     синяя 35.2%, зелёная 27.7%, охра 22.4%, чёрная 10.3%,
///     красная 2.7%, белила 1.7%, жёлтая 0.0%, умбра 0.0%
///     мёртвых пигментов 2, самый ходовой 35.2% при цели не более 33%
///
/// Разная порода — это крупные области под совсем другие краски, то есть прямой
/// ввод мёртвых пигментов в оборот. По силе воздействия на палитру геология
/// сильнее сезонов: сезон меняет весь кадр однородно, а порода даёт КОНТРАСТ
/// внутри кадра.
///
/// ---- КАК УСТРОЕНО ----
///
/// Поле породы — медленный шум с периодом в десятки километров, разбитый на
/// четыре вида по порогам. Области выходят крупными: игрок видит не пёструю
/// мозаику, а «здесь красные скалы, а за перевалом тёмные».
///
/// Порода НЕ зависит от высоты и уклона — только от места. Это верно и
/// геологически: пласт лежит там, где лежит, а рельеф его вскрывает.
/// </summary>
public static class RockField
{
    /// <summary>Период поля породы, км. Десятки километров: одна территория
    /// (58 км) вмещает две-три области, а не рябь.</summary>
    private const float PeriodKm = 26f;

    /// <summary>Смещение сида: поле породы не должно совпадать с рельефом,
    /// иначе красные скалы окажутся ровно на гребнях.</summary>
    private const int SeedOffset = 7717;

    /// <summary>Порода в мировой точке.</summary>
    /// <summary>
    /// ПРОЧНОСТЬ ПОРОДЫ, доля от обычной.
    ///
    /// ---- ЗАЧЕМ ----
    ///
    /// Цвет породы и её прочность считались по РАЗНЫМ шумам: белый известняк
    /// мог лежать на мягком склоне, а тёмный базальт на твёрдом гребне.
    ///
    /// Теперь прочность выводится из ВИДА породы — того самого, что даёт цвет.
    /// Гребень, сложенный гранитом, и выглядит гранитным.
    ///
    /// ---- ЧИСЛА ИЗ ПРИРОДЫ ----
    ///
    ///     базальт      очень твёрд: плоские покровы, защитная покрышка
    ///     известняк    твёрд в сухом климате: белые обрывы
    ///     песчаник     средний: ступени и уступы
    ///     сланец       мягок: вымывается в пологие склоны
    /// </summary>
    public static float Hardness(RockKind kind) => kind switch
    {
        RockKind.Basalt => 1.8f,
        RockKind.Limestone => 1.3f,
        RockKind.Sandstone => 1.0f,
        RockKind.Schist => 0.55f,
        _ => 1f,
    };

    /// <summary>
    /// ПЛАВНАЯ прочность в точке: смесь по всем четырём породам.
    ///
    /// ---- ЗАЧЕМ ----
    ///
    /// Четыре ступени прочности давали грубый рельеф: на границе пород
    /// врез менялся скачком вдвое-втрое, и склон ломался.
    ///
    /// В природе граница пород не черта, а полоса: породы переслаиваются,
    /// выветриваются, смешиваются осыпями.
    ///
    /// Здесь берутся те же два шума, что выбирают вид породы, но вместо
    /// выбора одной — вес каждой по близости к её углу.
    /// </summary>
    /// <summary>
    /// Прочность с учётом ПЛАСТОВ: твёрдый слой держит обрыв, мягкий
    /// вымывается в полку.
    /// </summary>
    public static float HardnessLayered(SimplexNoise noise, float xKm, float yKm,
                                        float heightM, float layerM, float dipRatio)
    {
        var kind = AtLayered(noise, xKm, yKm, heightM, layerM, dipRatio);
        // Плавный переход между слоями: резкая граница даёт скачок вреза и
        // ломает склон (проверено на породах).
        float t = layerM > 1f
            ? Math.Clamp(MathF.Abs(((heightM + (xKm + yKm) * dipRatio * 1000f)
                                    % layerM) / layerM - 0.5f) * 4f, 0f, 1f)
            : 1f;
        float pure = Hardness(kind);
        float mixed = HardnessAt(noise, xKm, yKm);
        return mixed + (pure - mixed) * t;
    }

    /// <summary>
    /// СКЛАДКИ ПРОЧНОСТИ: волны твёрдого и мягкого поперёк пояса.
    ///
    /// ---- ОТКУДА ----
    ///
    /// Из геологии складчатых поясов: «антиклинали не обязательно и даже не
    /// типично выражены в рельефе как гряды; рельеф определяется в основном
    /// СТОЙКОСТЬЮ РАЗНЫХ СЛОЁВ к размыву».
    ///
    /// То есть параллельные гряды Аппалачей рождает не складка, а ПОРОДА:
    /// твёрдый слой держится грядой, мягкий вымывается в долину. Провинция и
    /// зовётся «Долина и Гряда».
    ///
    /// ---- КАК ----
    ///
    /// Прочность колеблется волной поперёк пояса. Длина волны — десятки
    /// километров, как у настоящих складок.
    ///
    /// Волна не строго правильная: её изгибает шум, иначе выйдет гофрированный
    /// лист вместо гор.
    /// </summary>
    public static float FoldHardness(SimplexNoise noise, float xKm, float yKm,
                                     float waveKm, float dirRad, float strength)
    {
        if (waveKm <= 1f || strength <= 0f) return 1f;

        // Расстояние поперёк пояса.
        float across = xKm * MathF.Sin(dirRad) - yKm * MathF.Cos(dirRad);

        // Изгиб волны: складки не идут по линейке.
        float bend = noise.Noise2D(xKm / (waveKm * 4f), yKm / (waveKm * 4f)) * waveKm * 0.7f;

        float phase = (across + bend) / waveKm * MathF.PI * 2f;
        return 1f + MathF.Sin(phase) * strength;
    }

    public static float HardnessAt(SimplexNoise noise, float xKm, float yKm)
    {
        float a = noise.Noise2D(xKm / PeriodKm, yKm / PeriodKm);
        float b = noise.Noise2D(xKm / PeriodKm + 37.1f, yKm / PeriodKm - 19.7f);

        // Вес породы тем больше, чем дальше точка от границы её четверти.
        // Мягкий переход через ноль: на границе веса равны.
        float wa = Smooth(a), wb = Smooth(b);
        float lime = wa * wb;                    // a>0, b>0
        float sand = wa * (1f - wb);             // a>0, b<0
        float basalt = (1f - wa) * wb;           // a<0, b>0
        float schist = (1f - wa) * (1f - wb);    // a<0, b<0

        return lime * Hardness(RockKind.Limestone)
             + sand * Hardness(RockKind.Sandstone)
             + basalt * Hardness(RockKind.Basalt)
             + schist * Hardness(RockKind.Schist);
    }

    /// <summary>Плавный переход через ноль: −0.3 даёт 0, +0.3 даёт 1.</summary>
    private static float Smooth(float v)
    {
        float t = Math.Clamp(v / 0.6f + 0.5f, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    /// <summary>
    /// ПЛАСТЫ: вид породы с учётом высоты.
    ///
    /// ---- ЗАЧЕМ ----
    ///
    /// Прежде порода зависела только от места на карте: один вид на всю
    /// толщу. Оттого склоны выходили ровными.
    ///
    /// В природе осадочные породы лежат СЛОЯМИ, чередуя твёрдые и мягкие.
    /// Твёрдый слой держит обрыв, мягкий вымывается в полку — отсюда
    /// СТУПЕНЧАТЫЕ склоны, которыми узнаётся Большой каньон.
    ///
    /// ---- КАК ----
    ///
    /// Пятно породы задаёт основной вид, а высота внутри пятна — слой.
    /// Толщина слоя около полутораста метров: на склоне в километр это
    /// шесть-семь ступеней.
    ///
    /// ---- НАКЛОН ----
    ///
    /// Слои лежат не строго горизонтально, а с наклоном: тогда на одном
    /// склоне обнажаются разные пласты, а не один и тот же.
    ///
    /// Из справки по геологии: при наклоне 3-20° выходят КУЭСТЫ —
    /// асимметричные гребни; при 20-50° — ХОГБЭКИ, острые с обеих сторон.
    /// </summary>
    public static RockKind AtLayered(SimplexNoise noise, float xKm, float yKm,
                                     float heightM, float layerM, float dipRatio)
    {
        var baseKind = At(noise, xKm, yKm);

        // Только осадочные породы лежат слоями. Гранит и базальт — сплошные
        // тела, слоёв не имеют.
        if (baseKind == RockKind.Basalt) return baseKind;

        if (layerM <= 1f) return baseKind;

        // Наклон: высота слоя смещается вместе с местом.
        float shifted = heightM + (xKm + yKm) * dipRatio * 1000f;

        // Чётный слой — основная порода, нечётный — соседняя по прочности.
        int layer = (int)MathF.Floor(shifted / layerM);
        if ((layer & 1) == 0) return baseKind;

        return baseKind switch
        {
            RockKind.Limestone => RockKind.Schist,     // известняк / сланец
            RockKind.Sandstone => RockKind.Limestone,  // песчаник / известняк
            RockKind.Schist => RockKind.Sandstone,     // сланец / песчаник
            _ => baseKind,
        };
    }

    public static RockKind At(SimplexNoise noise, float xKm, float yKm)
    {
        // Два слоя: первый делит на светлое и тёмное, второй внутри каждого на
        // два вида. Так границы не совпадают, и получается четыре области
        // неправильной формы, а не шахматка.
        float a = noise.Noise2D(xKm / PeriodKm, yKm / PeriodKm);
        float b = noise.Noise2D(xKm / PeriodKm + 37.1f, yKm / PeriodKm - 19.7f);
        return (a > 0f)
            ? (b > 0f ? RockKind.Limestone : RockKind.Sandstone)
            : (b > 0f ? RockKind.Basalt : RockKind.Schist);
    }

    /// <summary>Шум под поле породы. Заводится один раз на сид.</summary>
    public static SimplexNoise MakeNoise(int seed) => new SimplexNoise(seed + SeedOffset);

    /// <summary>Цвет голой породы.</summary>
    public static (float r, float g, float b) RockColor(RockKind kind) => kind switch
    {
        // Насыщенные и различающиеся ТОНОМ, а не светлотой: белил в наборе нет,
        // и светлота достаётся прозрачностью, а не разбеливанием.
        RockKind.Limestone => (0.78f, 0.72f, 0.52f),   // кремовый: охра разбавленная
        RockKind.Sandstone => (0.70f, 0.31f, 0.16f),   // рыжий: красная и охра
        RockKind.Basalt    => (0.13f, 0.13f, 0.15f),   // почти чёрный: чёрная краска
        RockKind.Schist    => (0.44f, 0.31f, 0.16f),   // бурый: умбра
        _ => (0.46f, 0.45f, 0.44f)
    };

    /// <summary>Цвет осыпи: та же порода, но раздробленная и выветренная —
    /// светлее и глуше, чем монолит.</summary>
    public static (float r, float g, float b) ScreeColor(RockKind kind) => kind switch
    {
        RockKind.Limestone => (0.85f, 0.80f, 0.62f),
        RockKind.Sandstone => (0.82f, 0.48f, 0.22f),   // охристая осыпь
        RockKind.Basalt    => (0.28f, 0.28f, 0.30f),
        RockKind.Schist    => (0.62f, 0.46f, 0.20f),
        _ => (0.58f, 0.56f, 0.50f)
    };
}
