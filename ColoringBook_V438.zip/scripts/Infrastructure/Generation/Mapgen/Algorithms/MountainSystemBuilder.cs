using System;
using System.Collections.Generic;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

/// <summary>
/// ПОСТРОИТЕЛЬ ГОРНЫХ СИСТЕМ.
///
/// ---- ЧТО ДЕЛАЕТ ----
///
/// Выращивает хребты ДЕРЕВОМ: главный водораздел, от него отроги под углом, от
/// отрогов мелкие гряды. Каждый знает своего родителя и растёт ОТ него.
///
/// ---- ЧЕМ ОТЛИЧАЕТСЯ ОТ ПРЕЖНЕГО ----
///
/// Прежде линии разлома были независимы: каждая проводилась через область сама
/// по себе. Оттого они пересекались как дороги на плане, а уровень выглядел
/// сеткой.
///
/// В природе система хребтов ИЕРАРХИЧЕСКАЯ и ДРЕВОВИДНАЯ, дополнительная к
/// речной сети: хребет есть водораздел между реками.
///
/// ---- ДЛЯ БОЛЬШОЙ КАРТЫ ----
///
/// Систем на карте несколько, они сменяют друг друга по мере перемещения
/// игрока. Построитель делает ОДНУ систему в заданном месте; где их ставить,
/// решает слой выше.
/// </summary>
public static class MountainSystemBuilder
{
    /// <summary>
    /// ОЧЕРТАНИЕ ПЕРВООБРАЗА — лучи от середины, километры.
    ///
    /// ---- ЗАЧЕМ ОТДЕЛЬНО ОТ ХРЕБТОВ ----
    ///
    /// Прежде укладка брала очертание из СЛЕДА ХРЕБТОВ. Оттого плита была
    /// вынуждена возвращать поддельные хребты — кольцо по краю, — чтобы
    /// укладка могла её положить.
    ///
    /// Из работы Женево о деревьях построения: рельеф есть дерево, где листья
    /// — ПЕРВООБРАЗЫ (хребет, плато, каньон), а узлы — действия над ними.
    /// У каждого первообраза СВОЁ очертание, и они не приводятся к общему.
    ///
    /// Там же названа наша беда: «добавление нового вида форм требует нового
    /// описания, и потому расширение набора типов ограничено».
    ///
    /// Теперь очертание принадлежит системе, а не выводится из хребтов.
    /// Укладка работает с очертанием, не зная, чем оно порождено.
    /// </summary>
    public static float[] MakeOutline(Random rnd, float radiusKm, int rays,
                                       bool plate)
    {
        var outline = new float[rays];

        if (plate)
        {
            // Плита: очертание округлое с неровным краем — блок поднялся
            // целиком, у него нет отрогов.
            float phase = (float)rnd.NextDouble() * 100f;
            for (int k = 0; k < rays; k++)
            {
                float a = k / (float)rays * MathF.PI * 2f;
                float wob = MathF.Sin(a * 3f + phase) * 0.13f
                          + MathF.Sin(a * 7f + phase * 2.1f) * 0.07f;
                outline[k] = radiusKm * (0.88f + wob);
            }
            return outline;
        }

        // Складчатые горы: очертание звёздчатое, вытянутое — след отрогов.
        float ph = (float)rnd.NextDouble() * 100f;
        float stretchDir = (float)rnd.NextDouble() * MathF.PI;
        float stretch = 0.7f + (float)rnd.NextDouble() * 0.6f;
        for (int k = 0; k < rays; k++)
        {
            float a = k / (float)rays * MathF.PI * 2f;
            float big = 1f + 0.3f * MathF.Cos((a - stretchDir) * 2f) * (stretch - 1f) * 2f;
            float mid = MathF.Sin(a * 3f + ph) * 0.2f;
            float fine = MathF.Sin(a * 7f + ph * 2.3f + mid * 4f) * 0.11f;
            outline[k] = radiusKm * MathF.Max(0.4f, big + mid + fine);
        }
        return outline;
    }



    /// <summary>
    /// Выращивает систему в заданном месте.
    /// </summary>
    /// <param name="seed">Зерно: одно место при одном зерне даёт один рельеф.</param>
    /// <param name="centerXKm">Середина системы, километры.</param>
    /// <param name="centerYKm">Середина системы, километры.</param>
    /// <param name="reachKm">Охват системы, километры.</param>
    /// <param name="character">Нрав: сколько отрогов, как ветвится.</param>
    /// <summary>
    /// ПЛИТА: ровное поднятие с неровным краем.
    ///
    /// Вместо дерева хребтов кладётся кольцо коротких звеньев по краю —
    /// они держат обрыв, а середина остаётся ровной.
    /// </summary>
    public static MountainSystem Build(int seed, float centerXKm, float centerYKm,
                                       float reachKm, in TerrainCharacter character)
    {
        // ---- ОДИН ПОСТРОИТЕЛЬ НА ВСЕ ТИПЫ ----
        //
        // Прежде для плато был ОТДЕЛЬНЫЙ построитель — заплатка, о которой
        // пользователь и говорил.
        //
        // Разница между плитой и хребтами свелась к двум величинам:
        //
        //     плита:   ОДНО замкнутое звено по краю, отрогов нет
        //     хребты:  дерево из многих звеньев с отрогами
        //
        // Это задаётся нравом, а не отдельным приёмом. Тип есть ИМЯ для
        // согласованного набора величин, а не своё устройство построения.

        var rnd = new Random(seed);
        var ridges = new List<MountainSystem.Ridge>();

        // Направление главного водораздела: у соседних систем близко, но не
        // совпадает — так в природе, где оно задано направлением сжатия коры.
        // ---- РАЗБРОС НАПРАВЛЕНИЙ ГЛАВНЫХ ВОДОРАЗДЕЛОВ ----
        //
        // FaultSpread был МЁРТВ при дереве: он стоял в ветке независимых
        // линий, которая при FaultTree = true не выполняется.
        //
        // А запись в карте связей осталась — там сказано, что подъём его с
        // 0.6 до 3.14 «разрушил строй гор». Тот замер был верен ДО введения
        // дерева.
        //
        // Здесь величина возвращена к делу: она задаёт, насколько разнятся
        // направления главных водоразделов соседних систем. Ноль — все
        // системы вытянуты одинаково; π — вразброд.
        float mainDir = (float)(rnd.NextDouble() * Math.PI * character.FaultSpread / 3.14f)
                      + (float)(rnd.NextDouble() * 0.2);

        // ---- ГЛАВНЫЙ ВОДОРАЗДЕЛ ----
        //
        // Идёт через середину системы, изгибаясь. Его длина — почти весь охват:
        // это хребет, определяющий лицо системы.
        var mainPoints = GrowLine(rnd, centerXKm, centerYKm, mainDir,
                                  reachKm * 1.6f, character.FaultLinks,
                                  character.FaultWiggle, fromMiddle: true);
        // ---- ГЛАВНОЕ ЗВЕНО ЗАМЫКАЕТСЯ У ПЛИТЫ ----
        //
        // У складчатых гор главный водораздел — ломаная через массив.
        // У плато он ОБВОДИТ край: блок поднялся целиком, и его граница есть
        // замкнутый обрыв.
        //
        // Это единственная разница в устройстве; всё прочее — величины.
        if (character.PlateLike)
        {
            mainPoints.Clear();
            const int Corners = 20;
            for (int k = 0; k <= Corners; k++)
            {
                float a = k / (float)Corners * MathF.PI * 2f;
                float rr = reachKm * (0.78f + (float)rnd.NextDouble() * 0.22f);
                mainPoints.Add((centerXKm + MathF.Cos(a) * rr,
                                centerYKm + MathF.Sin(a) * rr));
            }
        }

        ridges.Add(new MountainSystem.Ridge
        {
            Rank = 0, Parent = -1, Points = mainPoints, Strength = 1f,
        });

        // ---- ОТРОГИ ОТ ГЛАВНОГО ----
        //
        // Растут ОТ точек на главном хребте, под углом к нему. В природе отрог
        // отходит от водораздела и понижается к равнине.
        int spurs = Math.Max(2, character.SpurCount);
        for (int s = 0; s < spurs; s++)
        {
            // Место на родителе: разнесены по длине, чтобы не жались в кучу.
            float at = (s + 0.5f) / spurs + (float)(rnd.NextDouble() - 0.5) * 0.1f;
            at = Math.Clamp(at, 0.05f, 0.95f);
            var (px, py) = PointAt(mainPoints, at);

            // Угол отхода: в природе отрог отходит под углом 40-80 градусов,
            // попеременно в обе стороны от водораздела.
            float side = (s % 2 == 0) ? 1f : -1f;
            float angle = mainDir + side * (float)(0.7 + rnd.NextDouble() * 0.7);

            var pts = GrowLine(rnd, px, py, angle,
                               reachKm * character.SpurLength,
                               Math.Max(3, character.FaultLinks / 2),
                               character.FaultWiggle * 1.3f, fromMiddle: false);
            ridges.Add(new MountainSystem.Ridge
            {
                Rank = 1, Parent = 0, ParentAt = at, Points = pts,
                Strength = character.FaultRankMid,
            });
        }

        // ---- МЕЛКИЕ ГРЯДЫ ОТ ОТРОГОВ ----
        //
        // Третий ярус: короткие гряды, отходящие от отрогов. Они и дают
        // дробность, которой не хватало.
        int spurBase = ridges.Count;
        for (int p = 1; p < spurBase; p++)
        {
            int minor = Math.Max(1, character.SpurCount / 2);
            for (int m = 0; m < minor; m++)
            {
                float at = (m + 0.5f) / minor;
                var (px, py) = PointAt(ridges[p].Points, at);
                float side = (m % 2 == 0) ? 1f : -1f;
                float angle = mainDir + side * (float)(0.5 + rnd.NextDouble() * 1.0);

                var pts = GrowLine(rnd, px, py, angle,
                                   reachKm * character.SpurLength * 0.45f, 3,
                                   character.FaultWiggle * 1.6f, fromMiddle: false);
                ridges.Add(new MountainSystem.Ridge
                {
                    Rank = 2, Parent = p, ParentAt = at, Points = pts,
                    Strength = character.FaultRankLow,
                });
            }
        }

        return new MountainSystem
        {
            CenterXKm = centerXKm, CenterYKm = centerYKm, ReachKm = reachKm,
            MainDirection = mainDir, Character = character, Ridges = ridges,
        };
    }

    /// <summary>
    /// Растит ломаную от точки в заданном направлении, изгибая на каждом звене.
    /// </summary>
    /// <param name="fromMiddle">
    /// Для главного водораздела точка — СЕРЕДИНА линии; для отрога — начало.
    /// </param>
    private static List<(float X, float Y)> GrowLine(Random rnd, float x, float y,
                                                     float dir, float length,
                                                     int links, float wiggle,
                                                     bool fromMiddle)
    {
        links = Math.Max(2, links);
        float step = length / links;
        var pts = new List<(float, float)>();

        float px = x, py = y;
        if (fromMiddle)
        {
            px -= MathF.Cos(dir) * length * 0.5f;
            py -= MathF.Sin(dir) * length * 0.5f;
        }

        pts.Add((px, py));
        float d = dir;
        for (int k = 0; k < links; k++)
        {
            d += (float)(rnd.NextDouble() - 0.5) * wiggle;
            px += MathF.Cos(d) * step;
            py += MathF.Sin(d) * step;
            pts.Add((px, py));
        }
        return pts;
    }

    /// <summary>Точка на ломаной по доле её длины.</summary>
    private static (float X, float Y) PointAt(IReadOnlyList<(float X, float Y)> pts,
                                              float t)
    {
        if (pts.Count == 0) return (0f, 0f);
        if (pts.Count == 1) return pts[0];
        float pos = Math.Clamp(t, 0f, 1f) * (pts.Count - 1);
        int i = Math.Clamp((int)pos, 0, pts.Count - 2);
        float f = pos - i;
        return (pts[i].X + (pts[i + 1].X - pts[i].X) * f,
                pts[i].Y + (pts[i + 1].Y - pts[i].Y) * f);
    }
}
