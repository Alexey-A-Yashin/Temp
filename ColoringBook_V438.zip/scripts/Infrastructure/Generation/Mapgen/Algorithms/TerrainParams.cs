using System;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

/// <summary>
/// Все настраиваемые ручки генерации рельефа в одном месте. Раньше они были
/// разбросаны по const-полям AlpineTerrain, ConditionedErosion и Hydrology, поэтому
/// подбор значений требовал пересборки проекта на каждую пробу. Здесь они собраны,
/// чтобы дебаг-панель могла править их в реальном времени (клавиша T).
///
/// ВАЖНО ПРО ПОДБОР ЗНАЧЕНИЙ. Ручки взаимозависимы, и менять их по одной почти
/// бесполезно: например, расширение долин (ValleyRadiusScale, ValleyEdgeBand,
/// PeakCount) уменьшает число замкнутых котловин и заодно сушит озёра — после такой
/// правки приходится опускать MinLakeDepth. Замер 02.08 показал и обратный перекос:
/// долин 6-9 + радиус x1.5 + пиков 4-7 дали слишком пологий уровень (медианный уклон
/// упал 5.7 -> 2.5, осыпи 1443 -> 681 клеток, горы почти исчезли). Значения ниже —
/// компромисс между этими двумя крайностями, и именно их предполагается крутить.
///
/// Класс НЕ ЗАВИСИТ ОТ GODOT.
/// </summary>
public sealed class TerrainParams
{
    // ---- Форма долин и гор ----

    /// <summary>Минимальное число долин на карту.</summary>
    public int ValleyCountBase = 5;

    /// <summary>Разброс числа долин сверх базового (случайно 0..этого значения).</summary>
    public int ValleyCountRand = 3;

    /// <summary>Множитель к радиусам долин. Больше — шире дно, меньше гор.
    /// 1.0 давало полуширину пологих коридоров 20 мировых единиц (сплошные ущелья),
    /// 1.5 — 35.8, но при этом рельеф стал слишком плоским.</summary>
    public float ValleyRadiusScale = 1.25f;

    /// <summary>Ширина перехода от дна долины к горе, в единицах эллиптической
    /// координаты. Больше — горы поднимаются положе.</summary>
    public float ValleyEdgeBand = 0.70f;

    /// <summary>Минимальное число пиков.</summary>
    public int PeakCountBase = 5;

    /// <summary>Разброс числа пиков сверх базового.</summary>
    public int PeakCountRand = 5;

    /// <summary>Амплитуда горного шума поверх дна долины.</summary>
    public float MountainAmplitude = 0.75f;

    // ---- Эрозия ----

    /// <summary>Шагов эрозии. Каждый заново заливает поверхность и считает сток.</summary>
    public int ErosionIterations = 15;

    /// <summary>Коэффициент врезания K в законе E = K * A^m * S^n.</summary>
    public float ErosionK = 3.0f;

    /// <summary>Потолок снятия материала за шаг.</summary>
    public float MaxErosionPerStep = 0.012f;

    /// <summary>ОСЫПАНИЕ (термическая эрозия): предельная разница высот между
    /// соседями. МЕНЬШЕ — глаже: 0.055 давало «горы из парафина» (p95 уклона падал
    /// с 12.9 до 7.0), 0.12 сохраняет форму гор.</summary>
    public float TalusDiff = 0.12f;

    /// <summary>Проходов осыпания на каждом шаге эрозии.</summary>
    public int TalusPasses = 1;

    // ---- Вода ----

    /// <summary>Насколько глубоко залита впадина, чтобы считаться озером. Прямо
    /// управляет долей воды: на широких долинах 0.05 -> 2.2%, 0.10 -> 0.8%.</summary>
    public float MinLakeDepth = 0.10f;

    /// <summary>Доля регионов, становящихся руслами (густота речной сети).</summary>
    public float RiverFraction = 0.045f;

    // ---- Устье ----

    /// <summary>Полуширина канала устья, доля от размера карты.</summary>
    public float OutletHalfWidth = 0.035f;

    /// <summary>Насколько дно канала опускается к краю карты.</summary>
    public float OutletDrop = 0.05f;

    public TerrainParams Clone() => (TerrainParams)MemberwiseClone();



}
