using System;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

/// <summary>
/// МЕЛКАЯ ПЛИТКА ПОЛЯ ВОКРУГ ИГРОКА.
///
/// ---- ЗАЧЕМ ----
///
/// Поле поднятия и эрозии считается на сетке 241, то есть ячейкой 240 м. Всё, что
/// мельче полукилометра, оно создать не может, а игрок стоит на кольце с ячейкой
/// 30 м — и получает гладкую интерполяцию. Замер кольца 0: средний уклон 13.0°,
/// круче тридцати градусов лишь 4% площади. С глаз это читается как пологая
/// холмистая местность, а не как горы.
///
/// Считать всю территорию мельче нельзя: сетка 721 (ячейка 80 м) занимает
/// 75 секунд против 7. Но игрок за сессию проходит 1.2 км, и подробность нужна
/// только вокруг него.
///
///     вариант                    время   перепад  ср.уклон  круче 30°
///     без плитки                   —      461 м     13.0°      4%
///     плитка 6 км, ячейка 80 м    0.6 с   626 м     22.4°     28%
///     плитка 6 км, ячейка 60 м    1.0 с   639 м     23.9°     32%
///     плитка 10 км, ячейка 80 м   1.7 с   558 м     24.2°     36%
///
/// ---- ПОЧЕМУ НАЛОЖЕНИЕ, А НЕ СШИВКА ----
///
/// Плитки могли бы сшиваться друг с другом, но замер показал, что оба очевидных
/// способа плохи:
///
///   • закрепить края на грубом поле — высота сходится точно, но излом уклона на
///     шве 109.6° при 4.5° внутри плитки: закреплённый край работает базисом
///     эрозии для обеих плиток, и на шве вырастает гребень из ничего;
///   • считать с полем и обрезать — излом уходит (8° при поле в 800 м), но высота
///     перестаёт совпадать: расхождение 239 м, затухает медленно.
///
/// Причина глубже приёма: эрозия с поднятием НЕ ИМЕЕТ МЕСТНОГО РЕШЕНИЯ. Сток
/// собирается со всего водосбора, а водосбор может быть больше плитки.
///
/// Взят приём наложенных сеток (Chimera, overset): мелкое поле НАКЛАДЫВАЕТСЯ на
/// грубое с весом, спадающим к краю. Сшивать нечего — у края работает грубое
/// поле, к центру мелкое. Замер: излом на шве 1.5°, тогда как ВНУТРИ плитки 2.6°,
/// то есть шов лучше обычного рельефа.
///
/// Любопытно, что перекрытие надо брать УЗКОЕ: при 15% излом 1.5°, при 50% — 6.0°.
/// При широком перекрытии на шве складываются две плитки с заметным весом, а они
/// развивались независимо.
/// </summary>
/// <summary>
/// МЕСТНОЕ УТОЧНЕНИЕ ВОКРУГ ИГРОКА.
///
/// ---- ЧТО ЭТО ----
///
/// Тот же счёт эрозии продолжается на мелкой сетке в окне вокруг игрока:
/// начальная высота берётся у поля, края закреплены на нём, внутренность
/// развивается дальше.
///
/// ---- ЧЕМ ОТЛИЧАЕТСЯ ОТ ПРЕЖНЕЙ ПЛИТКИ ----
///
/// Прежняя плитка считалась ОТДЕЛЬНО и складывалась с полем. Её долины не
/// совпадали с долинами поля, отсюда ямы на стыке и «поле для гольфа»: замер
/// показал, что после плитки склона становилось 51.6% при природных 38, а
/// гребней 1.3% при 8.
///
/// Здесь продолжение того же счёта — рассогласоваться нечему.
///
/// ---- ЗАЧЕМ ВООБЩЕ ----
///
/// Ближнее кольцо с ячейкой 30 м выбирает поле с ячейкой 120 м, и гребень
/// шириной в одну ячейку поля растягивается на четыре ячейки кольца, переставая
/// быть гребнем:
///
///     где меряем                   откл  гребень  склон
///     выборка поля на 30 м         54.3    0.1     57.2
///     с местным уточнением         23.8    3.8     42.9
///     природа                       0      8       38
///
/// ---- ДВЕ ПРАВКИ, БЕЗ КОТОРЫХ НЕ РАБОТАЕТ ----
///
/// 1. УДЕРЖАНИЕ УРОВНЯ. Закреплённый край работает базисом эрозии, и весь рельеф
///    окна медленно уходит вниз: расхождение с полем доходило до 511 м. На каждой
///    итерации средний уровень окна возвращается к среднему уровню поля; форма не
///    трогается, сдвигается только уровень целиком.
///
/// 2. ПОЛОСА ПЕРЕХОДА у края. Без неё шов виден стеной, с широкой — переход
///    съедает само уточнение:
///
///     полоса   откл   шов
///      25%     27.5    2 м
///      12%     23.8    9 м    взято
///       6%     21.8   31 м
///       3%     22.0   79 м
/// </summary>
public sealed class DetailTile
{
    /// <summary>Сторона окна, мировые единицы. 4.8 км: покрывает ближнее кольцо
    /// (3.6 км) с запасом на полосу перехода. Больше брать нельзя — на ячейке
    /// 30 м сетка растёт квадратом.</summary>
    public const float TileWorld = 480f;

    /// <summary>
    /// Ячейка окна, метры. РАВНА ЯЧЕЙКЕ БЛИЖНЕГО КОЛЬЦА — иначе растягивание
    /// остаётся: при ячейке 60 м против кольцевых 30 м гребень по-прежнему
    /// размазывался на две ячейки меша, и отклонение падало лишь с 42.3 до 38.7.
    /// </summary>
    public const float CellM = 30f;

    /// <summary>
    /// Итераций уточнения.
    ///
    /// Было 60, и этого не хватало: гребень требует времени, чтобы врез успел
    /// развести соседние долины. Замер по ближнему кольцу:
    ///
    ///     итераций окна  откл  гребень  уклон
    ///          60        38.1    2.1    25.7°
    ///         180        27.9    4.8    37.3°
    ///     природа          0      8
    ///
    /// Особенно это стало важно после удлинения счёта поля: гребни в поле стали
    /// острее, и кольцо размазывало их сильнее, чем прежние пологие формы.
    /// </summary>
    private const int Iterations = 180;

    private readonly float[] _h;
    private readonly int _side;
    private readonly float _originX, _originY;


    public DetailTile(float[] field, int fieldSide, float extentWorld, int seed,
                      in TerrainCharacter character, float atX, float atY)
    {
        _side = (int)(TileWorld / (CellM / 10f)) + 1;
        _originX = atX - TileWorld * 0.5f;
        _originY = atY - TileWorld * 0.5f;

        float cell = TileWorld / (_side - 1), cellM = cell * 10f;
        _h = new float[_side * _side];
        for (int j = 0; j < _side; j++)
        for (int i = 0; i < _side; i++)
            _h[j * _side + i] = FluvialField.Sample(field, fieldSide, extentWorld,
                                                    _originX + i * cell, _originY + j * cell);
        var edge = (float[])_h.Clone();

        var flow = new float[_h.Length];
        var recv = new int[_h.Length];
        var surf = new float[_h.Length];
        var order = new int[_h.Length];
        var lap = new float[_h.Length];
        var done = new bool[_h.Length];
        var heapH = new float[_h.Length + 1];
        var heapI = new int[_h.Length + 1];

        for (int it = 0; it < Iterations; it++)
        {
            for (int j = 1; j < _side - 1; j++)
            for (int i = 1; i < _side - 1; i++) _h[j * _side + i] += character.UpliftM / 10f;

            for (int j = 1; j < _side - 1; j++)
            for (int i = 1; i < _side - 1; i++)
            { int c = j * _side + i; lap[c] = _h[c-1] + _h[c+1] + _h[c-_side] + _h[c+_side] - 4f * _h[c]; }
            for (int c = 0; c < _h.Length; c++) _h[c] += character.Diffusivity * lap[c];

            Array.Copy(_h, surf, _h.Length);
            RidgedMountains.FillDepressions(surf, _side, done, heapH, heapI);
            for (int c = 0; c < _h.Length; c++) { flow[c] = 1f; order[c] = c; recv[c] = -1; }
            Array.Sort(order, (a, b) => surf[b].CompareTo(surf[a]));
            foreach (int c in order)
            {
                int i = c % _side, j = c / _side, best = -1; float drop = 0f;
                for (int dj = -1; dj <= 1; dj++)
                for (int di = -1; di <= 1; di++)
                {
                    if (di == 0 && dj == 0) continue;
                    int x = i + di, y = j + dj;
                    if (x < 0 || y < 0 || x >= _side || y >= _side) continue;
                    float d = surf[c] - surf[y * _side + x];
                    if (d > drop) { drop = d; best = y * _side + x; }
                }
                recv[c] = best;
                if (best >= 0) flow[best] += flow[c];
            }
            for (int c = 0; c < _h.Length; c++)
            {
                int r = recv[c]; if (r < 0) continue;
                float dist = (c % _side == r % _side || c / _side == r / _side) ? cellM : cellM * 1.41421f;
                float sl = MathF.Max((surf[c] - surf[r]) * 10f / dist, 0f);
                float cut = character.Erodibility * MathF.Sqrt(flow[c] * cellM * cellM / 1e6f) * sl / 10f;
                float taken = MathF.Min(cut, MathF.Max(_h[c] - _h[r], 0f) * 0.5f);
                _h[c] -= taken;

                // ---- ОСАЖДЕНИЕ, КАК В ПОЛЕ ----
                //
                // Его здесь не было: окно только резало. Из-за этого ближнее
                // кольцо оставалось щелью (уклон 31.8°, ровных 0.5%), хотя поле
                // после V262 уже раскрылось — а именно ближнее кольцо игрок и
                // видит со сплава.
                if (FluvialField.Deposition > 0f && sl < FluvialField.DepositionSlope)
                    _h[r] += taken * FluvialField.Deposition
                           * (1f - sl / FluvialField.DepositionSlope);

                // ---- ПЕРЕЛИВ, КАК В ПОЛЕ ----
                //
                // Его здесь не было, и ближние кольца остались с замкнутыми
                // впадинами: отклонение форм 44.0 против 27.9, пока поле уже
                // улучшилось до 16.8. Пояснение — при FluvialField.BreachPower.
                float lakeHere = (surf[c] - _h[c]) * 10f;
                float lakeThere = (surf[r] - _h[r]) * 10f;
                if (FluvialField.BreachPower > 0f && lakeHere > 2f && lakeThere <= 2f)
                {
                    float power = MathF.Min(lakeHere / 100f, 10f);
                    float bite = character.Erodibility
                               * MathF.Sqrt(flow[c] * cellM * cellM / 1e6f)
                               * power * FluvialField.BreachPower / 10f;
                    _h[c] -= MathF.Min(bite, MathF.Max(_h[c] - _h[r], 0f) * 0.5f);
                }
            }

            // Удержание уровня: см. пояснение при объявлении класса.
            double sumH = 0, sumE = 0;
            for (int c = 0; c < _h.Length; c++) { sumH += _h[c]; sumE += edge[c]; }
            float shift = (float)((sumE - sumH) / _h.Length);
            for (int c = 0; c < _h.Length; c++) _h[c] += shift;

            for (int i = 0; i < _side; i++)
            {
                _h[i] = edge[i];
                _h[(_side - 1) * _side + i] = edge[(_side - 1) * _side + i];
                _h[i * _side] = edge[i * _side];
                _h[i * _side + _side - 1] = edge[i * _side + _side - 1];
            }
        }

        // ---- ПЕРЕХОД РАСТЯНУТ НА ВСЁ ОКНО ----
        //
        // Была узкая полоса у края (12% стороны), и окно выделялось ЗАПЛАТОЙ:
        // внутри рельеф вдвое шершавее и вдвое круче, чем снаружи. На снимке это
        // читалось квадратом в середине кадра.
        //
        // Причина: окно считает 180 итераций сверх поля, а вокруг их нет. Узкая
        // полоса гасит разрыв только у самой границы.
        //
        // Замер (разрыв — отношение шершавости внутри к наружной, 1.0 — заплаты
        // не видно; отклонение — по формам в середине окна):
        //
        //     переход             разрыв   отклонение
        //     полоса 12%          2.21x      17.9
        //     на всё окно         1.54x      12.3   взято
        //     на всё, квадратом   1.22x      20.0   разрыв меньше, но формы хуже
        //
        // Растянутый переход выиграл ПО ОБЕИМ мерам сразу: и заплата слабее, и
        // формы в середине ближе к природным.
        for (int j = 0; j < _side; j++)
        for (int i = 0; i < _side; i++)
        {
            // доля окна: единица в середине, ноль у края
            float u = Math.Max(Math.Abs(i - (_side - 1) * 0.5f),
                               Math.Abs(j - (_side - 1) * 0.5f)) / ((_side - 1) * 0.5f);
            float t = Math.Clamp(1f - u, 0f, 1f);
            t = t * t * (3f - 2f * t);
            _h[j * _side + i] = edge[j * _side + i] + (_h[j * _side + i] - edge[j * _side + i]) * t;
        }
    }

    /// <summary>Поправка к высоте поля в мировой точке. Вне окна ноль.</summary>
    public float Correction(float[] field, int fieldSide, float extentWorld,
                            float wx, float wy)
    {
        float u = (wx - _originX) / TileWorld, v = (wy - _originY) / TileWorld;
        if (u < 0f || v < 0f || u > 1f || v > 1f) return 0f;
        float gx = u * (_side - 1), gy = v * (_side - 1);
        int i0 = Math.Clamp((int)gx, 0, _side - 2), j0 = Math.Clamp((int)gy, 0, _side - 2);
        float tx = gx - i0, ty = gy - j0;
        // Сглаживание доли: без него на каждой ячейке излом производной, и они
        // выстраиваются диагональной решёткой.
        tx = tx * tx * (3f - 2f * tx);
        ty = ty * ty * (3f - 2f * ty);
        float a = _h[j0 * _side + i0], b = _h[j0 * _side + i0 + 1];
        float c = _h[(j0 + 1) * _side + i0], d = _h[(j0 + 1) * _side + i0 + 1];
        float fine = (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty;
        float baseAt = FluvialField.Sample(field, fieldSide, extentWorld, wx, wy);
        return fine - baseAt;
    }
}
