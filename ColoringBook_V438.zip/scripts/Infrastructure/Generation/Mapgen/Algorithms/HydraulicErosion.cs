using System;
using ColoringBook.Infrastructure.Generation;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

/// <summary>
/// Эрозия карты высот: гидравлическая (частицами) и термическая (осыпание).
///
/// РЕАЛИЗАЦИЯ ПО ОТРАБОТАННОЙ МЕТОДИКЕ, а не изобретена заново.
/// Гидравлическая часть — «снежки» (drop/particle based) по описанию Job Talle,
/// «Simulating hydraulic erosion» (2020). Метод выбран за то, что даёт узнаваемые
/// формы (V-образные долины, сеть водосборов, гребни между ними) при очень низкой
/// цене: частицы, попавшие на плоское место, завершаются сразу, и вся работа уходит
/// туда, где рельеф реально вырезается.
///
/// Термическая часть — классическое ограничение угла естественного откоса: материал,
/// лежащий круче предельного угла, осыпается вниз. Именно она создаёт осыпи под
/// скалами, что нам прямо нужно — биом Scree уже есть.
///
/// Класс НЕ ЗАВИСИТ ОТ GODOT: работает с обычным float[] и проверяется в харнессе
/// без движка.
/// </summary>
public static class HydraulicErosion
{
    /// <summary>Параметры гидравлической эрозии. Значения по умолчанию — из статьи
    /// Job Talle, скорректированные под наш масштаб сетки (см. лог, замеры).</summary>
    public sealed class Settings
    {
        /// <summary>Сколько частиц уронить. У автора 35-50 тыс. на карту сопоставимого
        /// размера; 100 тыс. он прямо называет перебором — гребни становятся слишком
        /// глубокими, а результат перестаёт выглядеть правдоподобно.</summary>
        public int Droplets = 45000;

        /// <summary>Максимум шагов одной частицы.</summary>
        public int MaxIterations = 64;

        /// <summary>Смещение точки, в которой читается наклон. Нужно, чтобы траектории
        /// частиц не сходились в одну колею — иначе вместо сети долин получаются
        /// несколько глубоких прорезей.</summary>
        public float Radius = 0.8f;

        /// <summary>Доля переносимого материала, оседающая на пологом месте.</summary>
        public float DepositionRate = 0.3f;

        /// <summary>Интенсивность размыва на крутизне.</summary>
        public float ErosionRate = 0.04f;

        /// <summary>Разгон размыва по мере движения: только что упавшая частица почти
        /// не размывает, разогнавшаяся — размывает в полную силу.</summary>
        public float IterationScale = 0.04f;

        /// <summary>Трение: сколько скорости сохраняется между шагами.</summary>
        public float Friction = 0.7f;

        /// <summary>Ускорение от наклона.</summary>
        public float Speed = 0.15f;

        /// <summary>Сила финального сглаживания (0 — не сглаживать). На сетке нашего
        /// разрешения без него поверхность получается зернистой.</summary>
        public float FinalBlur = 0.5f;

        /// <summary>
        /// СКОЛЬКО ЯЧЕЕК СЕТКИ «СТОИТ» ЕДИНИЦА ВЫСОТЫ. Без этого коэффициента алгоритм
        /// не работает вовсе, и это не мелочь настройки, а вопрос размерности.
        ///
        /// Высоты у нас нормированы в 0..1, а сетка — 256 ячеек. В координатах сетки
        /// такой рельеф почти плоский: типичный перепад между соседями 0.010 даёт
        /// вертикальную составляющую нормали 0.999975, то есть частица считает место
        /// ровным и завершается на первом же шаге. Замер это подтвердил: результат не
        /// зависел от числа капель вообще.
        ///
        /// Реальное соотношение: карта 1000 единиц = 160 мировых, сетка 256 ячеек,
        /// то есть ячейка 0.625 мировых; высота 0..1 = 0..48 мировых. Значит единица
        /// высоты равна 48 / 0.625 = 76.8 ячейки. При таком масштабе перепад 0.010 даёт
        /// наклон 28.5° — то, что и должно размываться.
        /// </summary>
        public float HeightToCells = 76.8f;

        /// <summary>
        /// Потолок размыва за один шаг частицы. НЕОБХОДИМ для устойчивости.
        /// Без него возникает положительная обратная связь: чем глубже вырыто, тем
        /// круче склон, тем сильнее размыв — и частица роет одну ячейку до дна.
        /// Замер это показал прямо: при усилении эрозии максимальный перепад между
        /// соседями достигал 0.6-3.5 при медиане 0.010, то есть вместо долин
        /// получались одиночные ямы, а асимметрия кривизны подскакивала до 55.
        /// </summary>
        public float MaxErosionPerStep = 0.0015f;

        /// <summary>Потолок переносимого материала. Тот же смысл: частица не может
        /// унести больше, чем физически способна.</summary>
        public float MaxSediment = 0.02f;

        /// <summary>Порог скорости, ниже которого частица считается остановившейся.
        /// Без него застрявшая частица продолжает крутиться на месте и рыть.</summary>
        public float MinSpeed = 0.0008f;
    }

    /// <summary>
    /// Гидравлическая эрозия частицами. Массив изменяется на месте.
    /// </summary>
    /// <param name="height">Карта высот, res*res, значения в нормированных единицах.</param>
    /// <param name="res">Сторона сетки.</param>
    /// <param name="valid">Маска пригодных ячеек (может быть null — тогда все годны).</param>
    /// <param name="seed">Сид: одна и та же карта эродируется одинаково.</param>
    public static void Apply(float[] height, int res, bool[]? valid, int seed, Settings? settings = null)
    {
        var s = settings ?? new Settings();
        var rnd = new SeededRandom(seed);

        for (int d = 0; d < s.Droplets; d++)
        {
            float x = rnd.NextFloat() * (res - 1);
            float y = rnd.NextFloat() * (res - 1);
            Trace(height, res, valid, x, y, s, rnd);
        }

        if (s.FinalBlur > 0f) Blur(height, res, valid, s.FinalBlur);
    }

    private static void Trace(
        float[] h, int res, bool[]? valid, float x, float y, Settings s, SeededRandom rnd)
    {
        // Смещение точки чтения наклона — против схождения траекторий.
        float ox = (rnd.NextFloat() * 2f - 1f) * s.Radius;
        float oy = (rnd.NextFloat() * 2f - 1f) * s.Radius;

        float sediment = 0f;
        float xp = x, yp = y;
        float vx = 0f, vy = 0f;

        for (int i = 0; i < s.MaxIterations; i++)
        {
            // Нормаль поверхности в смещённой точке. ny — вертикальная составляющая:
            // 1 на ровном месте, меньше на крутизне.
            if (!SampleNormal(h, res, valid, x + ox, y + oy, s.HeightToCells, out float nx, out float ny, out float nz))
                break;

            // Ровное место — частица дальше не покатится, симуляция бессмысленна.
            if (ny >= 0.9999f) break;

            float deposit = sediment * s.DepositionRate * ny;
            float erosion = s.ErosionRate * (1f - ny) * MathF.Min(1f, i * s.IterationScale);
            // Ограничители устойчивости — см. пояснения у MaxErosionPerStep.
            if (erosion > s.MaxErosionPerStep) erosion = s.MaxErosionPerStep;
            if (sediment + erosion - deposit > s.MaxSediment)
                erosion = MathF.Max(0f, s.MaxSediment - sediment + deposit);

            // ВАЖНО: правится ПРЕДЫДУЩАЯ позиция, а не текущая. Иначе частица
            // закапывается сама в себя и вместо долины получается яма.
            Change(h, res, valid, xp, yp, deposit - erosion);
            sediment += erosion - deposit;

            vx = s.Friction * vx + nx * s.Speed;
            vy = s.Friction * vy + nz * s.Speed;
            xp = x;
            yp = y;
            x += vx;
            y += vy;

            if (x < 1f || y < 1f || x >= res - 2f || y >= res - 2f) break;
            // Частица остановилась — дальше она будет только рыть на месте.
            if (vx * vx + vy * vy < s.MinSpeed * s.MinSpeed)
            {
                // Осевший груз оставляем на месте, иначе материал исчезает.
                Change(h, res, valid, xp, yp, sediment);
                break;
            }
        }
    }

    /// <summary>Нормаль поверхности в дробной точке. Возвращает false, если точка
    /// вне сетки или попадает на непригодную ячейку.</summary>
    private static bool SampleNormal(
        float[] h, int res, bool[]? valid, float x, float y, float scale,
        out float nx, out float ny, out float nz)
    {
        nx = 0f; ny = 1f; nz = 0f;
        int ix = (int)x, iy = (int)y;
        if (ix < 1 || iy < 1 || ix >= res - 2 || iy >= res - 2) return false;
        if (valid != null && !valid[iy * res + ix]) return false;

        // Центральные разности по высоте: нормаль = (-dh/dx, 1, -dh/dy), нормированная.
        float hL = Sample(h, res, ix - 1, iy);
        float hR = Sample(h, res, ix + 1, iy);
        float hD = Sample(h, res, ix, iy - 1);
        float hU = Sample(h, res, ix, iy + 1);

        // Высота приводится к масштабу сетки — см. пояснение у HeightToCells.
        float dx = (hR - hL) * 0.5f * scale;
        float dy = (hU - hD) * 0.5f * scale;
        float len = MathF.Sqrt(dx * dx + dy * dy + 1f);
        nx = -dx / len;
        ny = 1f / len;
        nz = -dy / len;
        return true;
    }

    private static float Sample(float[] h, int res, int ix, int iy) => h[iy * res + ix];

    /// <summary>Изменить высоту в дробной точке, распределив дельту по четырём
    /// соседним ячейкам (билинейно) — иначе на сетке появляются одиночные пики.</summary>
    private static void Change(float[] h, int res, bool[]? valid, float x, float y, float delta)
    {
        int ix = (int)x, iy = (int)y;
        if (ix < 0 || iy < 0 || ix >= res - 1 || iy >= res - 1) return;
        float fx = x - ix, fy = y - iy;

        void Add(int gx, int gy, float w)
        {
            int idx = gy * res + gx;
            if (valid != null && !valid[idx]) return;
            h[idx] += delta * w;
        }

        Add(ix, iy, (1f - fx) * (1f - fy));
        Add(ix + 1, iy, fx * (1f - fy));
        Add(ix, iy + 1, (1f - fx) * fy);
        Add(ix + 1, iy + 1, fx * fy);
    }

    /// <summary>Сглаживание 3x3 с заданной силой (0 — исходник, 1 — полное среднее).</summary>
    private static void Blur(float[] h, int res, bool[]? valid, float strength)
    {
        var src = (float[])h.Clone();
        for (int gy = 1; gy < res - 1; gy++)
        for (int gx = 1; gx < res - 1; gx++)
        {
            int idx = gy * res + gx;
            if (valid != null && !valid[idx]) continue;
            float sum = 0f;
            int cnt = 0;
            for (int dy = -1; dy <= 1; dy++)
            for (int dx = -1; dx <= 1; dx++)
            {
                int ni = (gy + dy) * res + (gx + dx);
                if (valid != null && !valid[ni]) continue;
                sum += src[ni];
                cnt++;
            }
            if (cnt > 0) h[idx] = src[idx] + (sum / cnt - src[idx]) * strength;
        }
    }

    /// <summary>
    /// Термическая эрозия: осыпание материала круче угла естественного откоса.
    ///
    /// Физика простая и хорошо известная: сыпучий материал не может лежать круче
    /// некоторого предельного угла (для щебня это примерно 30-38°). Всё, что круче,
    /// съезжает вниз. Именно так под скальными стенами образуются конусы осыпи —
    /// то, что нам нужно для биома Scree.
    ///
    /// Обрабатывается за несколько проходов: за один проход материал переносится
    /// только к соседней ячейке, поэтому конус растёт постепенно.
    /// </summary>
    /// <param name="talusAngle">Предельный перепад высоты между соседними ячейками.
    /// Задаётся в тех же единицах, что и высоты, а не в градусах — так проще
    /// согласовать с шагом сетки.</param>
    public static void ApplyThermal(
        float[] height, int res, bool[]? valid, int iterations, float talusAngle, float rate = 0.5f)
    {
        var delta = new float[height.Length];

        for (int it = 0; it < iterations; it++)
        {
            Array.Clear(delta, 0, delta.Length);

            for (int gy = 1; gy < res - 1; gy++)
            for (int gx = 1; gx < res - 1; gx++)
            {
                int idx = gy * res + gx;
                if (valid != null && !valid[idx]) continue;
                float hc = height[idx];

                // Суммарный избыток над соседями и максимальный перепад.
                float totalExcess = 0f;
                float maxDiff = 0f;
                for (int dy = -1; dy <= 1; dy++)
                for (int dx = -1; dx <= 1; dx++)
                {
                    if (dx == 0 && dy == 0) continue;
                    int ni = (gy + dy) * res + (gx + dx);
                    if (valid != null && !valid[ni]) continue;
                    float diff = hc - height[ni];
                    if (diff > talusAngle)
                    {
                        totalExcess += diff - talusAngle;
                        if (diff > maxDiff) maxDiff = diff;
                    }
                }
                if (totalExcess <= 0f) continue;

                // Переносим долю избытка, распределяя пропорционально перепаду.
                float move = (maxDiff - talusAngle) * rate;
                delta[idx] -= move;
                for (int dy = -1; dy <= 1; dy++)
                for (int dx = -1; dx <= 1; dx++)
                {
                    if (dx == 0 && dy == 0) continue;
                    int ni = (gy + dy) * res + (gx + dx);
                    if (valid != null && !valid[ni]) continue;
                    float diff = hc - height[ni];
                    if (diff > talusAngle)
                        delta[ni] += move * ((diff - talusAngle) / totalExcess);
                }
            }

            for (int i = 0; i < height.Length; i++) height[i] += delta[i];
        }
    }
}
