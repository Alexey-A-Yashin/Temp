using System;
using System.Collections.Generic;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// РОСТ ХРЕБТОВ ПО СЛАБЫМ МЕСТАМ — на графе.
///
/// ---- ЗАЧЕМ ----
///
/// В графовом устройстве хребет не растёт, а ВЫТАЧИВАЕТСЯ: разломы задают
/// поднятие полосами, эрозия режет русла, гребни — то, что осталось.
///
/// Оттого гряды выходят однообразными: врез режет по расчёту, и русла
/// похожи одно на другое.
///
/// Рост же даёт ВЕТВЛЕНИЕ, где всякая ветвь непохожа на соседнюю.
///
/// ---- ПРИЁМ ----
///
/// Инвазивная просачиваемость: хребет растёт туда, где сопротивление
/// НАИМЕНЬШЕЕ — как трещина или разряд молнии.
///
/// На графе он ложится естественнее, чем на сетке: там он и ЕСТЬ обход графа
/// по слабым местам.
///
/// ---- СИЛА ВЕТВИ ----
///
/// Число её потомков, как площадь водосбора у реки. У ствола их тысячи, у
/// концевой веточки один.
///
/// Найдено разбором: убывание по числу ВЕТВЛЕНИЙ обнуляло силу, ибо ветвлений
/// на пути оказалось пятьсот, а не десяток.
/// </summary>
public static class GraphRidgeGrowth
{
    /// <summary>
    /// Растит сеть хребтов из зёрен и прибавляет её к поднятию.
    /// </summary>
    /// <param name="seeds">узлы, с которых начинается рост</param>
    public static void Grow(TerrainGraph g, IReadOnlyList<int> seeds,
                            int seed, GraphGrowthSettings s)
    {
        if (s.Share <= 0f || seeds.Count == 0) return;

        int n = g.Count;
        var rnd = new Random(seed + 4457);

        // Сопротивление: мелкая рябь. Гладкий шум даёт пятно — соседи выходят
        // почти равны, и очередь берёт их подряд.
        var res = new float[n];
        for (int k = 0; k < n; k++) res[k] = (float)rnd.NextDouble();

        var grown = new bool[n];
        var parent = new int[n];
        var depth = new int[n];
        for (int k = 0; k < n; k++) parent[k] = -1;

        var queue = new PriorityQueue<int, float>();
        foreach (int s0 in seeds)
        {
            if (s0 < 0 || s0 >= n || grown[s0]) continue;
            grown[s0] = true;
            for (int q = g.NeighbourStart[s0]; q < g.NeighbourStart[s0 + 1]; q++)
            {
                int nb = g.Neighbours[q];
                if (grown[nb] || parent[nb] >= 0) continue;
                parent[nb] = s0;
                queue.Enqueue(nb, res[nb]);
            }
        }

        int placed = 0, limit = (int)(n * Math.Clamp(s.Share, 0.02f, 0.9f));
        while (queue.Count > 0 && placed < limit)
        {
            int c = queue.Dequeue();
            if (grown[c]) continue;

            int i = c % g.Side, j = c / g.Side;
            if (i < 1 || j < 1 || i >= g.Side - 1 || j >= g.Side - 1) continue;

            grown[c] = true; placed++;
            int p = parent[c];
            if (p >= 0) depth[c] = depth[p] + 1;

            for (int q = g.NeighbourStart[c]; q < g.NeighbourStart[c + 1]; q++)
            {
                int nb = g.Neighbours[q];
                if (grown[nb] || parent[nb] >= 0) continue;
                parent[nb] = c;
                queue.Enqueue(nb, res[nb]);
            }
        }

        // ---- СИЛА ВЕТВИ: ЧИСЛО ПОТОМКОВ ----
        //
        // Обход от листьев к корню, по убыванию глубины.
        var weight = new int[n];
        var order = new List<int>(placed);
        for (int k = 0; k < n; k++) if (grown[k]) order.Add(k);
        order.Sort((a, b) => depth[b].CompareTo(depth[a]));

        foreach (int k in order)
        {
            weight[k]++;
            int p = parent[k];
            if (p >= 0 && grown[p]) weight[p] += weight[k];
        }

        int wmax = 1;
        for (int k = 0; k < n; k++) if (weight[k] > wmax) wmax = weight[k];

        // Прибавка к поднятию: ствол выше веточек.
        for (int k = 0; k < n; k++)
        {
            if (!grown[k]) continue;
            float strength = MathF.Pow(weight[k] / (float)wmax, s.WeightExponent);
            g.Uplift[k] += strength * s.Height;
        }
    }
}
