using System;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// ПЕРЕВОД ГРАФА В ПОЛЕ ВЫСОТ.
///
/// ---- ГЛАВНАЯ ТРУДНОСТЬ ПЕРЕХОДА ----
///
/// На графе рельеф выходит верным: пояс, водосборы, дерево стока. А в поле он
/// становится ровным, ибо между узлами нет ничего: узлы стоят через километр,
/// а русло шириной в сотни метров.
///
/// ---- ЧЕТЫРЕ ПУТИ ИЗ ИСТОЧНИКОВ ----
///
///     ядра форм рельефа   Кордоннье: в поле кладутся готовые формы
///     УРАВНЕНИЕ ДИФФУЗИИ  из скелета русел и гребней поле вычисляется
///                         диффузией, что даёт природные переходы
///     врезание русла      сложение компактных изменителей вдоль течения
///     разреженное дерево  сумма первообразов из словаря
///
/// ВЗЯТ ВТОРОЙ: диффузия есть наше осыпание, мы его уже умеем.
///
/// ---- КАК ----
///
///     1. высоты узлов кладутся в поле по местам
///     2. между ними пусто
///     3. диффузия заполняет пустоту, растягивая высоты плавно
///     4. узлы держатся на своих высотах, чтобы не размылись
///
/// Это то же, что «вычисление полного поля высот из скелетных признаков
/// уравнением диффузии» из источников.
/// </summary>
public static class GraphToField
{
    /// <summary>
    /// Переводит граф в поле высот заданной стороны.
    /// </summary>
    /// <param name="extentKm">сторона области, километры</param>
    /// <param name="passes">сколько проходов диффузии</param>
    public static float[] Build(TerrainGraph g, int side, float extentKm,
                                GraphFieldSettings settings)
        => Build(g, g.H, side, extentKm, settings);

    /// <summary>
    /// То же, но укладывается ЛЮБАЯ величина узлов, а не только высота.
    ///
    /// Нужно, чтобы донести до поля уровень воды (g.Water) и площадь
    /// водосбора (g.Area). Прежде поле получало только высоты, а воду и сток
    /// пересчитывали на сетке заново — заливкой впадин и дренажом, ценой
    /// двадцати семи секунд. Считать вторично то, что ядро уже посчитало,
    /// незачем.
    /// </summary>
    public static float[] Build(TerrainGraph g, float[] values, int side,
                                float extentKm, GraphFieldSettings settings)
    {
        int n = side * side;
        var field = new float[n];
        var fixedAt = new bool[n];

        // ---- 1. ВЫСОТЫ УЗЛОВ В ПОЛЕ ----
        //
        // Узел ложится в ближайшую ячейку и закрепляется: диффузия его не
        // сдвинет, и рисунок русел уцелеет.
        float cellKm = extentKm / (side - 1);
        for (int k = 0; k < g.Count; k++)
        {
            int i = (int)MathF.Round(g.X[k] / cellKm);
            int j = (int)MathF.Round(g.Y[k] / cellKm);
            if (i < 0 || j < 0 || i >= side || j >= side) continue;

            int c = j * side + i;
            field[c] = values[k];
            fixedAt[c] = true;
        }

        // ---- 2. ПЕРВОЕ ПРИБЛИЖЕНИЕ ----
        //
        // Незакреплённые ячейки берут высоту ближайшего узла. Без этого
        // диффузии пришлось бы растекаться от нуля, и проходов нужно было бы
        // во много раз больше.
        FillFromNearest(field, fixedAt, side);

        // ---- 3. ДИФФУЗИЯ ----
        //
        // Незакреплённые ячейки усредняются по соседям. Закреплённые стоят.
        var tmp = new float[n];
        for (int pass = 0; pass < settings.DiffusionPasses; pass++)
        {
            Array.Copy(field, tmp, n);
            for (int j = 1; j < side - 1; j++)
            for (int i = 1; i < side - 1; i++)
            {
                int c = j * side + i;
                if (fixedAt[c]) continue;
                field[c] = (tmp[c - 1] + tmp[c + 1] + tmp[c - side] + tmp[c + side]
                          + tmp[c] * 2f) / 6f;
            }
        }

        return field;
    }

    /// <summary>
    /// Заполняет незакреплённые ячейки высотой ближайшего закреплённого.
    ///
    /// Обход волной от закреплённых наружу: за один проход по полю.
    /// </summary>
    private static void FillFromNearest(float[] field, bool[] fixedAt, int side)
    {
        int n = side * side;
        var queue = new int[n];
        var seen = new bool[n];
        int head = 0, tail = 0;

        for (int k = 0; k < n; k++)
            if (fixedAt[k]) { queue[tail++] = k; seen[k] = true; }

        Span<int> off = stackalloc int[4];
        while (head < tail)
        {
            int c = queue[head++];
            int i = c % side, j = c / side;

            off[0] = i > 0 ? c - 1 : -1;
            off[1] = i < side - 1 ? c + 1 : -1;
            off[2] = j > 0 ? c - side : -1;
            off[3] = j < side - 1 ? c + side : -1;

            for (int q = 0; q < 4; q++)
            {
                int nb = off[q];
                if (nb < 0 || seen[nb]) continue;
                seen[nb] = true;
                field[nb] = field[c];
                queue[tail++] = nb;
            }
        }
    }
}
