using System;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// ИСТОЧНИК ПОДНЯТИЯ — единый вход для всех видов рельефа.
///
/// ---- ЗАЧЕМ ----
///
/// Построитель принимает поднятие как отвлечённую величину и не знает, каким
/// устройством оно задано. Так новый вид добавляется, не трогая построителя.
///
/// Это то направление зависимостей, о котором говорит книга: ядро даёт
/// договор, а частности его исполняют.
/// </summary>
public static class GraphUpliftSource
{
    /// <summary>
    /// Даёт вычислитель поднятия для заданного вида рельефа.
    /// </summary>
    public static Func<float, float, float> For(GraphTerrainKind kind,
                                                float extentKm, int seed,
                                                GraphUpliftSettings settings)
        => kind switch
        {
            GraphTerrainKind.Knock =>
                new GraphKnockAndLochan(seed, settings.Knock).UpliftAt,

            GraphTerrainKind.Volcanic =>
                GraphVolcanoes.Build(extentKm, seed, settings.Volcanoes).UpliftAt,

            // Альпийские по умолчанию: пояс разломов.
            _ => GraphFaults.Build(extentKm, seed, settings.Faults).UpliftAt,
        };

    /// <summary>
    /// Врезаемость для вида рельефа.
    ///
    /// Холмам врез слабый: их котловины выскребли ледники, а не реки.
    /// </summary>
    public static float ErodibilityFor(GraphTerrainKind kind,
                                       GraphUpliftSettings settings)
        => kind switch
        {
            GraphTerrainKind.Knock => settings.KnockErodibility,
            GraphTerrainKind.Volcanic => settings.VolcanicErodibility,
            _ => settings.AlpineErodibility,
        };
}
