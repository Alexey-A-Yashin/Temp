using System;
using ColoringBook.Domain.Level;
using ColoringBook.Infrastructure.Generation.Mapgen;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// ВУЛКАНИЧЕСКИЙ КРАЙ — конусы среди лавовых полей.
///
/// ---- ОТКУДА ----
///
/// Исландия и Камчатка. Из источников: Ключевская сопка — «величавый и на
/// диво соразмерный конус»; вокруг Мюватна россыпь ЛОЖНЫХ КРАТЕРОВ, где лава
/// текла по мокрому дну.
///
/// ---- ГЛАВНАЯ ПРИМЕТА: ЛУЧЕВОЙ СТОК ----
///
/// Из источников: «щитовой или слоистый вулкан несёт лучевой сток: ручьи
/// падают со средины во все стороны».
///
///     альпийские   сток ВЕТВИТСЯ по хребтам
///     холмы        сток течёт в КОТЛОВИНЫ
///     вулканы      сток расходится ЗВЕЗДОЙ от вершины
///
/// Третье устройство, а не оттенок прежних.
///
/// ---- ЧТО СТРОИТСЯ ----
///
///     большие конусы  слоистые вулканы: крутые, до 30 км в поперечнике
///     кальдеры        котлы обрушения на месте иных конусов
///     ложные кратеры  россыпь мелких конусов по лавовому полю
///     лавовое поле    ровное основание между ними
/// </summary>
public sealed class GraphVolcanoes
{
    private readonly (float X, float Y, float RadiusKm, float Height,
                      float CalderaKm)[] _cones;
    private readonly SimplexNoise _field;
    private readonly SimplexNoise _small;
    private readonly GraphVolcanoSettings _s;

    private GraphVolcanoes((float, float, float, float, float)[] cones,
                           int seed, GraphVolcanoSettings s)
    {
        _cones = cones;
        _field = new SimplexNoise(seed + 401);
        _small = new SimplexNoise(seed + 809);
        _s = s;
    }

    /// <summary>
    /// Раскладывает конусы по области.
    /// </summary>
    public static GraphVolcanoes Build(float extentKm, int seed,
                                       GraphVolcanoSettings s)
    {
        var rnd = new Random(seed);
        int count = Math.Max(1, (int)(extentKm * extentKm / (s.EveryKm * s.EveryKm)));
        var cones = new (float, float, float, float, float)[count];

        for (int i = 0; i < count; i++)
        {
            float cx = (float)rnd.NextDouble() * extentKm;
            float cy = (float)rnd.NextDouble() * extentKm;

            // Поперечник: слоистые вулканы 15-30 км.
            float radius = s.RadiusKm * (0.6f + (float)rnd.NextDouble() * 0.8f);

            // Высота: часть конусов много ниже прочих.
            float height = rnd.NextDouble() < 0.4 ? 0.45f : 1f;

            // Кальдера: у каждого пятого конуса вершина обрушилась.
            float caldera = rnd.NextDouble() < s.CalderaShare
                ? radius * (0.15f + (float)rnd.NextDouble() * 0.15f) : 0f;

            cones[i] = (cx, cy, radius, height, caldera);
        }

        return new GraphVolcanoes(cones, seed, s);
    }

    /// <summary>
    /// Поднятие в точке.
    /// </summary>
    public float UpliftAt(float xKm, float yKm)
    {
        // ---- ЛАВОВОЕ ПОЛЕ ----
        //
        // Ровное основание, но не гладкое: потоки застыли валами.
        float lava = (_field.Noise2D(xKm / _s.LavaKm, yKm / _s.LavaKm) * 0.5f + 0.5f)
                   * _s.LavaHeight;

        // ---- ЛОЖНЫЕ КРАТЕРЫ ----
        //
        // Россыпь мелких конусов: их сотни, и они дают лавовому полю
        // приметность.
        float sm = _small.Noise2D(xKm / _s.RootlessKm, yKm / _s.RootlessKm);
        float rootless = sm > _s.RootlessThreshold
            ? (sm - _s.RootlessThreshold)
              / MathF.Max(1f - _s.RootlessThreshold, 1e-4f) * _s.RootlessHeight
            : 0f;

        // ---- КОНУСЫ ----
        float cone = 0f;
        foreach (var (cx, cy, radius, height, caldera) in _cones)
        {
            float dx = xKm - cx, dy = yKm - cy;
            float d = MathF.Sqrt(dx * dx + dy * dy);
            if (d > radius) continue;

            // Склон конуса: от края к вершине.
            float v = (1f - d / radius) * height;

            // Кальдера: вершина обрушилась котлом.
            if (caldera > 0f && d < caldera)
            {
                float inner = d / caldera;
                float rim = (1f - caldera / radius) * height;
                v = rim * (_s.CalderaDepth + (1f - _s.CalderaDepth) * inner);
            }

            if (v > cone) cone = v;
        }

        return lava + rootless + cone;
    }
}
