using System;
using System.Collections.Generic;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// ПОСТРОИТЕЛЬ РЕЛЬЕФА НА ГРАФЕ — единая точка сборки.
///
/// ---- ЗАЧЕМ ----
///
/// Прежде порядок вызовов задавался тем, кто строит: сперва поднятие, потом
/// приёмники, потом порядок, потом заливка, потом снова порядок...
///
/// Это ПОВЕДЕНЧЕСКАЯ ЗАВИСИМОСТЬ: всякий вызывающий должен знать порядок, и
/// стоит ему ошибиться — рельеф выйдет негодным без явной ошибки.
///
/// Здесь порядок задан один раз и снаружи не виден. Вызывающий получает
/// готовое поле высот.
///
/// ---- НАПРАВЛЕНИЕ ЗАВИСИМОСТЕЙ ----
///
/// Построитель знает о своих частях; части друг о друге не знают. Настройки
/// приходят снаружи, и всякая часть получает только свои.
/// </summary>
public sealed class GraphTerrainBuilder
{
    private readonly GraphNodeSettings _nodes;
    private readonly GraphIncisionSettings _incision;
    private readonly GraphDiffusionSettings _diffusion;
    private readonly GraphFieldSettings _field;
    private readonly GraphRockSettings _rock;
    private readonly GraphMultigridSettings _multigrid;
    private readonly GraphGrowthSettings _growth;
    private readonly GraphSwellSettings _swell;

    public GraphTerrainBuilder(GraphNodeSettings nodes,
                               GraphIncisionSettings incision,
                               GraphDiffusionSettings diffusion,
                               GraphFieldSettings field,
                               GraphRockSettings rock,
                               GraphMultigridSettings multigrid,
                               GraphGrowthSettings? growth = null,
                               GraphSwellSettings? swell = null)
    {
        _growth = growth ?? GraphGrowthSettings.Default;
        _swell = swell ?? GraphSwellSettings.Default;
        _nodes = nodes;
        _incision = incision;
        _diffusion = diffusion;
        _field = field;
        _rock = rock;
        _multigrid = multigrid;
    }

    /// <summary>
    /// Один уровень цепочки: строит граф и точит его заданное число шагов.
    ///
    /// Начальные высоты берутся с предыдущего, более грубого уровня — это и
    /// есть улучшенное приближение, ускоряющее сходимость.
    /// </summary>
    private TerrainGraph BuildLevel(float extentKm, float stepKm, int iterations,
                                    int seed, Func<float, float, float>? uplift,
                                    Func<float, float, float>? erodibility,
                                    float[]? coarse, float coarseStepKm,
                                    GraphKindMap? kinds = null)
    {
        var nodes = _nodes with { StepKm = stepKm };
        int side = Math.Max(4, (int)(extentKm / stepKm));
        var g = new TerrainGraph(side, seed, nodes);

        var erod = new float[g.Count];

        if (kinds != null)
        {
            // Смешанный уровень: вид, поднятие и врезаемость — одним проходом.
            kinds.FillNodes(g, erod);
        }
        else if (uplift != null)
        {
            for (int k = 0; k < g.Count; k++) g.Uplift[k] = uplift(g.X[k], g.Y[k]);
        }

        // Перенос с грубого уровня: высота узла берётся из ближайшей клетки.
        if (coarse != null && coarseStepKm > 0f)
        {
            int cs = Math.Max(4, (int)(extentKm / coarseStepKm));
            for (int k = 0; k < g.Count; k++)
            {
                int ci = Math.Clamp((int)(g.X[k] / coarseStepKm), 0, cs - 1);
                int cj = Math.Clamp((int)(g.Y[k] / coarseStepKm), 0, cs - 1);
                g.H[k] = coarse[cj * cs + ci];
            }
        }

        // ---- КРУПНЫЕ ПЕРЕПАДЫ ВЫСОТ ----
        //
        // Вне горного пояса уровень выходит плоским: платформа лежит на одной
        // высоте, и раскрашивать там нечего.
        //
        // В природе платформы полого вздымаются и опускаются на сотни метров
        // на десятки километров.
        if (_swell.Height > 0f)
        {
            var swellNoise = new SimplexNoise(seed + 7331);
            var midNoise = new SimplexNoise(seed + 2213);

            // ---- ПЕРЕПАДЫ СИЛЬНЕЕ ВНЕ ПОЯСА ----
            //
            // Прежде они прибавлялись РОВНО ВЕЗДЕ, и дуга пояса на снимке
            // терялась: перепады поднимали всю площадь одинаково.
            //
            // Платформа вздымается полого; горный пояс и без того высок.
            // Оттого прибавка делится на поясное поднятие.
            float topUp = 0f;
            for (int k = 0; k < g.Count; k++)
                if (g.Uplift[k] > topUp) topUp = g.Uplift[k];
            if (topUp < 1e-4f) topUp = 1f;

            for (int k = 0; k < g.Count; k++)
            {
                float big = swellNoise.Noise2D(g.X[k] / _swell.SwellKm,
                                               g.Y[k] / _swell.SwellKm);
                float mid = midNoise.Noise2D(g.X[k] / _swell.MidKm,
                                             g.Y[k] / _swell.MidKm);

                // Вне пояса поднятие мало, и доля перепадов велика.
                float belt = g.Uplift[k] / topUp;
                float outside = 1f - MathF.Min(belt * _swell.BeltDamping, 1f);

                g.Uplift[k] += ((big * 0.5f + 0.5f) * _swell.Height
                              + mid * _swell.MidHeight) * outside;
            }
        }

        // ---- РОСТ ХРЕБТОВ ПО СЛАБЫМ МЕСТАМ ----
        //
        // Хребты не только вытачиваются эрозией, но и РАСТУТ — как трещина
        // или разряд молнии. Это даёт ветвление, которого не даёт врез.
        //
        // Зёрна: узлы с наибольшим поднятием, то есть середины поясов.
        if (_growth.Share > 0f)
        {
            var seeds = new List<int>();
            float top = 0f;
            for (int k = 0; k < g.Count; k++) if (g.Uplift[k] > top) top = g.Uplift[k];
            if (top > 0f)
            {
                float bar = top * 0.75f;
                for (int k = 0; k < g.Count; k += 97)
                    if (g.Uplift[k] >= bar) seeds.Add(k);
            }
            GraphRidgeGrowth.Grow(g, seeds, seed, _growth);
        }

        var hardness = GraphRockField.Build(g, seed, _rock);

        // Слои: твёрдый пласт держится уступом, мягкий вымывается. Так выходят
        // ступенчатые склоны столовых гор.
        GraphRockField.ApplyLayers(g, hardness, _rock);

        // Врезаемость делится на прочность породы.
        if (kinds != null)
        {
            for (int k = 0; k < g.Count; k++) erod[k] /= hardness[k];
        }
        else if (erodibility != null)
        {
            for (int k = 0; k < g.Count; k++)
                erod[k] = erodibility(g.X[k], g.Y[k]) / hardness[k];
        }

        var diff = new float[g.Count];
        for (int k = 0; k < g.Count; k++) diff[k] = _diffusion.Rate;

        var stack = new int[g.Count];
        var childCount = new int[g.Count];
        var basin = new int[g.Count];
        var tmp = new float[g.Count];
        var shares = new GraphFlow.Shares(g.Neighbours.Length, g.Count);
        var buckets = new int[1025];
        var scratch = new float[g.Count];

        float cellArea = stepKm * stepKm;
        var inc = _incision with { Iterations = iterations };

        for (int step = 0; step < iterations; step++)
        {
            GraphErosion.Uplift(g, inc.TimeStep);

            // Впадины устраняются по дереву единственных приёмников.
            GraphErosion.FindReceivers(g);
            GraphErosion.BuildOrder(g, stack, childCount);
            GraphDepressions.Resolve(g, basin);

            // Разбор поменял приёмники — порядок обхода надо построить заново,
            // иначе уровень воды пойдёт по прежнему дереву.
            GraphErosion.BuildOrder(g, stack, childCount);
            GraphDepressions.ComputeWaterLevel(g);

            // Дальше сток идёт во многих направлениях — по УРОВНЮ ВОДЫ.
            GraphFlow.ComputeShares(g, shares, inc.FlowExponent);
            GraphFlow.BuildOrder(g, shares, buckets, scratch);
            GraphFlow.Accumulate(g, shares, cellArea);
            GraphErosion.InciseMulti(g, shares, erod, inc);

            GraphDiffusion.Step(g, diff, inc.TimeStep, tmp, _diffusion);
        }

        return g;
    }

    /// <summary>
    /// Строит уровень, где виды рельефа уложены ПЯТНАМИ.
    ///
    /// ЕДИНСТВЕННЫЙ ВХОД ПОСТРОЕНИЯ. Зовётся из FarBackground.
    ///
    /// Прежде рядом стоял BuildKind — «простейший вход», где вызывающему
    /// довольно было назвать вид рельефа. Он не вызывался ни разу и убран:
    /// два входа к одному счёту — заплатка, а не удобство.
    ///
    /// Игрок идёт и переходит из одного края в другой.
    /// </summary>
    public float[] BuildMixed(float extentKm, int fieldSide, int seed,
                              GraphKindMapSettings kinds,
                              GraphUpliftSettings uplift)
    {
        // ---- ВИД СЧИТАЕТСЯ НА ГРАФЕ ОДНИМ ПРОХОДОМ ----
        //
        // Прежде поднятие и врезаемость запрашивались порознь для каждой
        // точки, и поиск ближайших пятен шёл дважды на узел.
        var map = GraphKindMap.Build(extentKm, seed, kinds, uplift);

        TerrainGraph? g = null;
        float prevStep = 0f;
        float[]? prevHeights = null;

        foreach (var (stepKm, iterations) in _multigrid.Levels)
        {
            g = BuildLevel(extentKm, stepKm, iterations, seed, null, null,
                           prevHeights, prevStep, map);
            prevHeights = g.H;
            prevStep = stepKm;
        }

        if (g == null) throw new InvalidOperationException("цепочка уровней пуста");

        // Последний построенный граф остаётся доступным: по нему меряется, что
        // сделал сам счёт, а что добавила укладка в поле.
        LastGraph = g;

        var field = GraphToField.Build(g, fieldSide, extentKm, _field);
        GraphRidgeSharpen.Apply(field, fieldSide, _field.RidgeSharpen);

        // ---- ВОДА И СТОК ДОНОСЯТСЯ ДО ПОЛЯ ВМЕСТЕ С ВЫСОТАМИ ----
        //
        // Прежде поле получало только высоты, а вода и сток пересчитывались на
        // сетке заново: FillDepressions ~16 с и BuildDrainage ~11 с при уровне
        // 57.6 км и сетке 1921.
        //
        // Оба считают то, что ядро уже посчитало на графе: уровень воды лежит
        // в g.Water (Кордоннье и др., 2019), площадь водосбора — в g.Area.
        //
        // ВАЖНО ПРО УРОВЕНЬ ВОДЫ. Он укладывается как есть, БЕЗ заострения
        // гребней: заострение поднимает вершины, а гладь озера поднимать
        // нельзя — она на то и гладь.
        //
        // Уровень не может быть ниже рельефа: после укладки обеих величин
        // порознь это могло бы нарушиться на ячейку-другую, потому берётся
        // наибольшее из двух.
        LastWaterField = GraphToField.Build(g, g.Water, fieldSide, extentKm, _field);
        for (int i = 0; i < LastWaterField.Length; i++)
            if (LastWaterField[i] < field[i]) LastWaterField[i] = field[i];

        LastFlowField = GraphToField.Build(g, g.Area, fieldSide, extentKm, _field);

        return field;
    }

    /// <summary>
    /// Последний построенный граф — для замеров.
    ///
    /// Поле высот выходит из графа укладкой и заострением гребней, и по полю
    /// нельзя отличить беду СЧЁТА от беды УКЛАДКИ. По графу можно.
    /// </summary>
    public static TerrainGraph? LastGraph;

    /// <summary>
    /// Уровень воды, уложенный в поле: гладь озера, где она выше рельефа.
    ///
    /// Заменяет собой заливку впадин на сетке.
    /// </summary>
    public static float[]? LastWaterField;

    /// <summary>
    /// Площадь водосбора, уложенная в поле.
    ///
    /// Заменяет собой дренаж на сетке. Единица — та же, что у g.Area.
    /// </summary>
    public static float[]? LastFlowField;

    /// <summary>Настройки по умолчанию.</summary>
    public static GraphTerrainBuilder Default => new(
        GraphNodeSettings.Default, GraphIncisionSettings.Default,
        GraphDiffusionSettings.Default, GraphFieldSettings.Default,
        GraphRockSettings.Default, GraphMultigridSettings.Default);

}
