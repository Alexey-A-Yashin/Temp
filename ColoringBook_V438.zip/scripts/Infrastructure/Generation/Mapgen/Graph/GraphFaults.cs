using System;
using System.Collections.Generic;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// РАЗЛОМЫ — резкие линии, вдоль которых растут хребты.
///
/// ---- ЗАЧЕМ ----
///
/// Замер вскрыл: при ГЛАДКОМ поднятии (полоса с шумом) граф даёт 12% мест
/// круче пятнадцати градусов; при разломах — 21%, почти как старое
/// устройство (22%).
///
/// Хребты растут вдоль линий, а не в размытой полосе.
///
/// ---- РАЗДЕЛЕНИЕ СТАРОГО И НОВОГО ----
///
/// Часть НЕ ЗАВИСИТ от старого FaultUplift, хотя делает похожее. Так
/// удаление старого устройства не затронет новое.
///
/// ---- УСТРОЙСТВО ----
///
/// Разлом — отрезок. Поднятие спадает от него по расстоянию, резко: полоса в
/// два-три километра.
///
/// Отрезки кладутся вдоль пояса с разбросом по направлению.
/// </summary>
public sealed class GraphFaults
{
    private readonly (float X1, float Y1, float X2, float Y2, float Rank)[] _lines;
    private readonly float _bandKm;

    private GraphFaults((float, float, float, float, float)[] lines, float bandKm)
    {
        _lines = lines;
        _bandKm = bandKm;
    }

    /// <summary>
    /// Раскладывает разломы по области.
    /// </summary>
    public static GraphFaults Build(float extentKm, int seed, GraphFaultSettings s)
    {
        var rnd = new Random(seed);
        int count = Math.Max(1, (int)(extentKm * extentKm / (s.EveryKm * s.EveryKm)));
        var lines = new (float, float, float, float, float)[count];

        // ---- ПОЯС ИДЁТ ДУГОЙ, А НЕ ПРЯМОЙ ПОЛОСОЙ ----
        //
        // Из источников: горные пояса заметно ИЗОГНУТЫ — Аппалачи в
        // Пенсильвании, Скалистые в Монтане, Боливийские Анды, Кантабрийская
        // дуга.
        //
        // Прежде разломы клались вдоль прямой полосы с разбросом, и на большой
        // площади выходила однообразная «шерсть» из одинаковых гряд.
        //
        // Дуга задаётся тремя точками: начало, середина со сдвигом, конец.
        float arcSag = ((float)rnd.NextDouble() - 0.5f) * 2f * s.ArcSag;
        float baseAcross = extentKm * (0.3f + (float)rnd.NextDouble() * 0.4f);

        for (int i = 0; i < count; i++)
        {
            // Место вдоль дуги.
            float t = (float)rnd.NextDouble();
            float along = t * extentKm;

            // Дуга: середина отклонена от прямой на arcSag.
            float bend = 4f * t * (1f - t) * arcSag * extentKm;

            // Разброс поперёк: пояс имеет ширину, но много меньшую прежней.
            float across = baseAcross + bend
                         + ((float)rnd.NextDouble() - 0.5f) * extentKm * s.BeltWidth;

            // Направление: ВДОЛЬ КАСАТЕЛЬНОЙ к дуге, а не вдоль прямой.
            float slope = 4f * (1f - 2f * t) * arcSag;
            float angle = MathF.Atan(slope)
                        + ((float)rnd.NextDouble() - 0.5f) * s.AngleSpread;

            float half = s.LengthKm * (0.6f + (float)rnd.NextDouble() * 0.8f) * 0.5f;
            float dx = MathF.Cos(angle) * half, dy = MathF.Sin(angle) * half;

            // Разряд: главные разломы поднимают сильнее боковых.
            float rank = i < count / 3 ? 1f : 0.45f + (float)rnd.NextDouble() * 0.3f;

            lines[i] = (along - dx, across - dy, along + dx, across + dy, rank);
        }

        return new GraphFaults(lines, s.BandKm);
    }

    /// <summary>
    /// Поднятие в точке: спадает от ближайшего разлома.
    /// </summary>
    public float UpliftAt(float xKm, float yKm)
    {
        float best = 0f;
        foreach (var (x1, y1, x2, y2, rank) in _lines)
        {
            float dx = x2 - x1, dy = y2 - y1;
            float len2 = dx * dx + dy * dy;
            float t = len2 > 1e-6f
                ? Math.Clamp(((xKm - x1) * dx + (yKm - y1) * dy) / len2, 0f, 1f)
                : 0f;
            float px = x1 + dx * t - xKm, py = y1 + dy * t - yKm;
            float d = MathF.Sqrt(px * px + py * py);

            // Резкий спад: вдали от разлома поднятия нет.
            float v = rank * MathF.Exp(-d / _bandKm);
            if (v > best) best = v;
        }
        return best;
    }
}
