using System;
using ColoringBook.Domain.Level;
using ColoringBook.Infrastructure.Generation.Mapgen;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// ПРОЧНОСТЬ ПОРОДЫ В УЗЛАХ ГРАФА.
///
/// ---- ЗАЧЕМ ----
///
/// Замер показал: при одинаковой прочности рельеф выходит ГЛАДКИМ, и ни
/// врезаемость, ни поднятие, ни осыпание этого не меняют.
///
/// Из источников причина названа прямо: «основная форма равновесного рельефа
/// управляется расстоянием между реками и ПРОЧНОСТЬЮ ПОРОДЫ; получающийся
/// рельеф в основном ОГРАНИЧЕН ПРОЧНОСТЬЮ. Ни рельеф склонов, ни рельеф
/// граней не зависит от скорости сброса или вреза».
///
/// **Гребни держатся не тем, что их не размывает, а тем, что они ПРОЧНЕЕ.**
///
/// ---- КАК ----
///
/// Прочность складывается из трёх частей, как и в старом устройстве:
///
///     пятна пород      крупные области разного вида камня
///     слои             горизонтальные пласты: твёрдый над мягким
///     складки          волны прочности поперёк пояса
///
/// Врезаемость узла делится на прочность: прочное режется медленнее.
/// </summary>
public static class GraphRockField
{
    /// <summary>
    /// Считает прочность в каждом узле.
    /// </summary>
    public static float[] Build(TerrainGraph g, int seed, GraphRockSettings settings)
    {
        var patch = new SimplexNoise(seed + 101);
        var fine = new SimplexNoise(seed + 227);

        var hardness = new float[g.Count];
        for (int k = 0; k < g.Count; k++)
        {
            // Пятна пород: крупные области разного вида камня.
            float p = patch.Noise2D(g.X[k] / settings.PatchKm,
                                    g.Y[k] / settings.PatchKm);

            // Мелкая рябь: даже в одном виде камня прочность неровна.
            float f = fine.Noise2D(g.X[k] / settings.GrainKm,
                                   g.Y[k] / settings.GrainKm);

            float v = p * settings.PatchWeight + f * (1f - settings.PatchWeight);

            // Приведение к разбросу: величина означает, во сколько раз
            // прочнейшее прочнее слабейшего.
            hardness[k] = MathF.Exp(v * MathF.Log(settings.Contrast) * 0.5f);
        }
        return hardness;
    }

    /// <summary>
    /// Прибавляет слои: горизонтальные пласты разной прочности.
    ///
    /// Твёрдый пласт держится уступом, мягкий вымывается — так выходят
    /// ступенчатые склоны столовых гор.
    /// </summary>
    public static void ApplyLayers(TerrainGraph g, float[] hardness,
                                   GraphRockSettings settings)
    {
        if (settings.LayerHeight <= 0f) return;

        for (int k = 0; k < g.Count; k++)
        {
            // Номер пласта по высоте.
            float layer = g.H[k] / settings.LayerHeight;
            float within = layer - MathF.Floor(layer);

            // Чередование: нижняя половина пласта твёрже верхней.
            float mul = within < 0.5f ? settings.LayerContrast
                                      : 1f / settings.LayerContrast;
            hardness[k] *= mul;
        }
    }
}
