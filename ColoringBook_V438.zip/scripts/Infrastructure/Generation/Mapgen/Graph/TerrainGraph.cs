using System;
using System.Collections.Generic;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// ГРАФ РЕЛЬЕФА — новое устройство счёта, взамен плотной сетки.
///
/// ---- ЗАЧЕМ ----
///
/// Разбор большой модели показал: мы считаем на сетке в миллион ячеек там,
/// где отрасль считает на графе в тринадцать тысяч узлов.
///
/// Проба показала разницу в восемьдесят раз: 790 мс против 66 секунд.
///
/// ---- РАЗДЕЛЕНИЕ СТАРОГО И НОВОГО ----
///
/// Всё новое лежит в этой папке (Mapgen/Graph) и НЕ ЗАВИСИТ от старого.
/// Старое (FluvialField, RidgedMountains) остаётся нетронутым.
///
/// Переключение — величиной нрава UseGraphModel. Когда новое устройство
/// будет доведено, старое удаляется целиком, и ни одна его ошибка не
/// затронет новое.
///
/// ---- УСТРОЙСТВО ----
///
/// Узлы: сетка с дрожью — проще триангуляции и даёт то же.
/// Связи: восемь соседей по сетке узлов.
/// Приёмник: наинизший сосед (правило восьми направлений).
/// Порядок: топологический — всякий узел ПЕРЕД своими нижележащими.
/// </summary>
public sealed class TerrainGraph
{
    /// <summary>Число узлов.</summary>
    public int Count { get; }

    /// <summary>Сторона сетки узлов.</summary>
    public int Side { get; }

    /// <summary>Шаг сетки узлов, километры.</summary>
    public float StepKm { get; }

    /// <summary>Место узла, километры от угла области.</summary>
    public float[] X { get; }
    public float[] Y { get; }

    /// <summary>Высота узла, единицы поля.</summary>
    public float[] H { get; }

    /// <summary>Скорость поднятия узла.</summary>
    public float[] Uplift { get; }

    /// <summary>Площадь водосбора: сколько узлов стекает сюда.</summary>
    public float[] Area { get; }

    /// <summary>
    /// УРОВЕНЬ ВОДЫ в узле: гладь озера, если узел под водой, иначе его высота.
    ///
    /// ---- ЗАЧЕМ ----
    ///
    /// Доли стока считались по ВЫСОТАМ: доля соседа берётся из перепада
    /// H[k] - H[nb]. Внутри впадины все соседи выше, перепады отрицательны,
    /// доли нулевые — вода никуда не идёт, водосбор внутри впадины остаётся
    /// пустым, и врезу нечем вскрывать чашу.
    ///
    /// Оттого разбор впадин работал ВХОЛОСТУЮ: он чинил дерево единственных
    /// приёмников, а доли считались заново по высотам и починку выбрасывали.
    /// Замер: правка стратегии разбора не сдвинула ни одной меры.
    ///
    /// Уровень выводится тем же алгоритмом (Кордоннье и др., 2019):
    ///
    ///     w[k] = max(w[приёмник k], H[k])
    ///
    /// в порядке от устьев к верховьям. Внутри чаши он одинаков и равен высоте
    /// порога: вода растекается по глади и уходит через порог.
    ///
    /// Он же — ПОВЕРХНОСТЬ ОЗЁР, ради которой на сетке держалась заливка
    /// впадин ценой пятнадцати секунд.
    /// </summary>
    public float[] Water { get; }

    /// <summary>Приёмник: куда стекает узел; -1 у устья.</summary>
    public int[] Down { get; }

    /// <summary>
    /// Порядок обхода: всякий узел стоит ПЕРЕД своими нижележащими.
    ///
    /// Из работы Брауна и Виллетта: топологическая сортировка ускоряет
    /// накопление стока и разграничение водосборов, превосходя обычные
    /// рекурсивные приёмы на сетках.
    /// </summary>
    public int[] Order { get; }

    /// <summary>Соседи узла: их номера подряд в Neighbours.</summary>
    public int[] NeighbourStart { get; }
    public int[] Neighbours { get; }

    public TerrainGraph(int side, int seed, GraphNodeSettings settings)
    {
        Side = side;
        StepKm = settings.StepKm;
        float stepKm = settings.StepKm;
        float jitter = settings.Jitter;
        Count = side * side;

        X = new float[Count];
        Y = new float[Count];
        H = new float[Count];
        Uplift = new float[Count];
        Area = new float[Count];
        Water = new float[Count];
        Down = new int[Count];
        Order = new int[Count];

        var rnd = new Random(seed);

        // ---- УЗЛЫ: СЕТКА С ДРОЖЬЮ ----
        //
        // Строгая сетка даёт решётчатый рисунок русел: сток идёт по восьми
        // направлениям, и на ровном месте это заметно.
        //
        // Дрожь снимает решётку, а триангуляции не требует. Величина —
        // GraphSettings.NodeJitter.
        for (int j = 0; j < side; j++)
        for (int i = 0; i < side; i++)
        {
            int k = j * side + i;
            X[k] = (i + 0.5f + (float)(rnd.NextDouble() - 0.5) * jitter) * stepKm;
            Y[k] = (j + 0.5f + (float)(rnd.NextDouble() - 0.5) * jitter) * stepKm;
            Down[k] = -1;
        }

        // ---- СВЯЗИ: ВОСЕМЬ СОСЕДЕЙ ----
        //
        // Хранятся подряд, чтобы обход шёл по памяти без прыжков.
        NeighbourStart = new int[Count + 1];
        var list = new List<int>(Count * 8);
        for (int j = 0; j < side; j++)
        for (int i = 0; i < side; i++)
        {
            NeighbourStart[j * side + i] = list.Count;
            for (int dj = -1; dj <= 1; dj++)
            for (int di = -1; di <= 1; di++)
            {
                if (di == 0 && dj == 0) continue;
                int x = i + di, y = j + dj;
                if (x < 0 || y < 0 || x >= side || y >= side) continue;
                list.Add(y * side + x);
            }
        }
        NeighbourStart[Count] = list.Count;
        Neighbours = list.ToArray();

        // Расстояния до соседей: считаются один раз, ибо узлы не двигаются.
        NeighbourDistance = new float[Neighbours.Length];
        for (int k = 0; k < Count; k++)
        for (int q = NeighbourStart[k]; q < NeighbourStart[k + 1]; q++)
        {
            int nb = Neighbours[q];
            float dx = X[k] - X[nb], dy = Y[k] - Y[nb];
            NeighbourDistance[q] = MathF.Sqrt(dx * dx + dy * dy);
        }
    }

    /// <summary>
    /// РАССТОЯНИЯ ДО СОСЕДЕЙ, посчитанные один раз.
    ///
    /// Замер: доли стока, врез и осыпание тратили 63% времени, и все трое
    /// считали корень для каждой пары узлов КАЖДЫЙ ШАГ.
    ///
    /// А узлы не двигаются: расстояния постоянны.
    /// </summary>
    public float[] NeighbourDistance { get; }

}
