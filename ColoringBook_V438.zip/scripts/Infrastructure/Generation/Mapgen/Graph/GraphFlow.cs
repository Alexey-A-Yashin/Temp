using System;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// СТОК ВО МНОГИХ НАПРАВЛЕНИЯХ.
///
/// ---- ЗАЧЕМ ----
///
/// Прежде вода стекала в ОДНОГО соседа — наинизшего. Из источников: «многие
/// модели закона мощности потока страдают зависимостью от разрешения, ибо
/// используют сток в одного соседа».
///
/// Замер подтвердил: при вчетверо гуще узлах размах рельефа выходил в
/// полтора раза выше.
///
/// И там же назван изъян вида: «при стоке в одного соседа рельеф высокого
/// разрешения имеет множественные пики вдоль гребней; эта шероховатость
/// устраняется, если поток распределяется во многих направлениях».
///
/// ---- КАК ----
///
/// Вода делится между ВСЕМИ нижележащими соседями, доля каждого — по
/// крутизне склона к нему.
///
/// Из источника: с такой маршрутизацией рельеф независим от разрешения без
/// дополнительных поправок.
///
/// ---- ЦЕНА ----
///
/// У узла несколько приёмников вместо одного, и накопление идёт по всем.
/// Взамен уходит зависимость от густоты узлов.
/// </summary>
public static class GraphFlow
{
    /// <summary>
    /// Доли стока: сколько воды узел отдаёт каждому соседу.
    ///
    /// Хранятся подряд, как и сами соседи: доля соседа q лежит в Share[q].
    /// </summary>
    public sealed class Shares
    {
        public readonly float[] Share;
        public readonly int[] Order;

        public Shares(int neighbourCount, int nodeCount)
        {
            Share = new float[neighbourCount];
            Order = new int[nodeCount];
        }
    }

    /// <summary>
    /// Считает доли стока по крутизне к каждому нижележащему соседу.
    /// </summary>
    public static void ComputeShares(TerrainGraph g, Shares shares, float exponent)
    {
        for (int k = 0; k < g.Count; k++)
        {
            int s = g.NeighbourStart[k], e = g.NeighbourStart[k + 1];

            // ---- ПЕРЕПАД БЕРЁТСЯ ОТ УРОВНЯ ВОДЫ, А НЕ ОТ ВЫСОТЫ ----
            //
            // Прежде здесь стояло g.H. Внутри впадины все соседи выше, перепады
            // отрицательны, доли нулевые — вода не двигалась вовсе. Разбор
            // впадин чинил дерево приёмников, а этот проход считал заново по
            // высотам и починку ВЫБРАСЫВАЛ.
            //
            // Уровень воды одинаков по всей глади чаши и равен высоте порога,
            // так что вода растекается по озеру и уходит через порог.
            float total = 0f;
            for (int q = s; q < e; q++)
            {
                int nb = g.Neighbours[q];
                float drop = g.Water[k] - g.Water[nb];
                if (drop <= 0f) { shares.Share[q] = 0f; continue; }

                // Расстояние готово: посчитано один раз при построении графа.
                float len = g.NeighbourDistance[q];
                if (len < 1e-5f) { shares.Share[q] = 0f; continue; }

                // ---- СТЕПЕНЬ БЕЗ MathF.Pow ----
                //
                // Замер: доли стока брали пятую часть времени, и почти всё —
                // возведение в степень для каждой пары узлов.
                //
                // При показателе около единицы степень заменяется умножением
                // на корень: x^1.5 = x * sqrt(x). Корень много дешевле
                // общей степени.
                float slope = drop / len;
                float w = exponent <= 1.05f ? slope
                        : exponent >= 1.45f ? slope * MathF.Sqrt(slope)
                        : slope * MathF.Sqrt(MathF.Sqrt(slope));
                shares.Share[q] = w;
                total += w;
            }

            if (total <= 0f)
            {
                // ---- ГЛАДЬ ОЗЕРА: ВОДА ИДЁТ ПО ИСПРАВЛЕННОМУ ПУТИ ----
                //
                // Уровень одинаков у всех соседей, перепада нет, и разделить
                // воду по крутизне нельзя — крутизны не существует.
                //
                // Но путь известен: разбор впадин оставил его в g.Down. Вся
                // вода идёт туда. Это не запасной ход, а единственное место,
                // где многонаправленный сток сведений не имеет, а разбор
                // впадин имеет.
                int d = g.Down[k];
                if (d < 0) continue;
                for (int q = s; q < e; q++)
                    if (g.Neighbours[q] == d) { shares.Share[q] = 1f; break; }
                continue;
            }

            // Приведение к единице: вся вода узла распределяется.
            float inv = 1f / total;
            for (int q = s; q < e; q++) shares.Share[q] *= inv;
        }
    }

    /// <summary>
    /// Порядок обхода по убыванию высоты.
    ///
    /// При стоке во многих направлениях дерева нет — есть направленный граф.
    /// Обход по убыванию высоты даёт верный порядок: всякий узел
    /// обрабатывается прежде тех, куда он стекает.
    /// </summary>
    public static void BuildOrder(TerrainGraph g, Shares shares,
                                  int[] bucketCount, float[] scratch)
    {
        // Сортировка по высоте вёдрами: она дешевле сравнений и даёт
        // линейное время.
        float lo = float.MaxValue, hi = float.MinValue;
        for (int k = 0; k < g.Count; k++)
        {
            if (g.H[k] < lo) lo = g.H[k];
            if (g.H[k] > hi) hi = g.H[k];
        }

        int buckets = bucketCount.Length - 1;
        float span = MathF.Max(hi - lo, 1e-6f);
        float scale = (buckets - 1) / span;

        Array.Clear(bucketCount, 0, bucketCount.Length);
        for (int k = 0; k < g.Count; k++)
        {
            // Ведро от высоты: высокие узлы в начало.
            int b = buckets - 1 - (int)((g.H[k] - lo) * scale);
            if (b < 0) b = 0; else if (b >= buckets) b = buckets - 1;
            scratch[k] = b;
            bucketCount[b + 1]++;
        }

        for (int b = 1; b <= buckets; b++) bucketCount[b] += bucketCount[b - 1];
        for (int k = 0; k < g.Count; k++)
            shares.Order[bucketCount[(int)scratch[k]]++] = k;
    }

    /// <summary>
    /// Накопление стока: вода течёт сверху вниз, деля себя по долям.
    /// </summary>
    public static void Accumulate(TerrainGraph g, Shares shares, float cellArea)
    {
        for (int k = 0; k < g.Count; k++) g.Area[k] = cellArea;

        for (int i = 0; i < g.Count; i++)
        {
            int k = shares.Order[i];
            float a = g.Area[k];
            int s = g.NeighbourStart[k], e = g.NeighbourStart[k + 1];
            for (int q = s; q < e; q++)
            {
                float part = shares.Share[q];
                if (part > 0f) g.Area[g.Neighbours[q]] += a * part;
            }
        }
    }
}
