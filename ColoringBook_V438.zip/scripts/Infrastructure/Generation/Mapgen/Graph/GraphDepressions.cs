using System;
using System.Collections.Generic;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// ВПАДИНЫ НА ГРАФЕ — приём Кордоннье, Бови и Брауна.
///
/// ---- ЗАЧЕМ ----
///
/// Врез создаёт замкнутые впадины: узел ниже всех соседей, воде некуда течь.
/// Без их устранения дерево стока рвётся, и река не доходит до края.
///
/// На сетке мы решали это заливкой ведром — 23% всего времени построения.
///
/// ---- КАК ----
///
/// Приём линейной сложности из работы 2019 года:
///
///     1. найти водосборы: у каждого свой сток (устье или дно впадины)
///     2. построить граф ВОДОСБОРОВ: кто с кем граничит и через какой порог
///     3. найти на нём остовное дерево наименьшего веса
///     4. по дереву назначить, куда сливается каждая впадина
///
/// Вес ребра — высота порога между водосборами. Дерево наименьшего веса даёт
/// сток через НАИНИЗШИЕ пороги, что и верно по природе.
///
/// ---- ЧЕМ ЛУЧШЕ ЗАЛИВКИ ВЕДРОМ ----
///
/// Заливка поднимает дно впадины до уровня порога — озеро выходит плоским.
/// Здесь впадина остаётся впадиной, но получает СТОК: вода уходит через
/// порог, и русло продолжается дальше.
///
/// ---- РАЗДЕЛЕНИЕ ----
///
/// Часть не зависит ни от чего старого.
/// </summary>
public static class GraphDepressions
{
    /// <summary>Ребро между водосборами: порог и его высота.</summary>
    private readonly struct Pass
    {
        public readonly int BasinA, BasinB;
        public readonly int NodeA, NodeB;
        public readonly float Height;

        public Pass(int basinA, int basinB, int nodeA, int nodeB, float height)
        { BasinA = basinA; BasinB = basinB; NodeA = nodeA; NodeB = nodeB; Height = height; }
    }

    /// <summary>
    /// Устраняет впадины, назначая им сток через наинизшие пороги.
    /// </summary>
    /// <param name="basin">рабочее поле: номер водосбора для узла</param>
    public static void Resolve(TerrainGraph g, int[] basin)
    {
        int basinCount = LabelBasins(g, basin);
        if (basinCount <= 1) return;

        var outlet = FindOutlets(g, basin, basinCount);
        var open = MarkOpenBasins(g, outlet, basinCount);
        var passes = CollectPasses(g, basin);
        if (passes.Count == 0) return;

        RouteThroughPasses(g, passes, outlet, open, basinCount);
    }

    /// <summary>
    /// УРОВЕНЬ ВОДЫ ПО ИСПРАВЛЕННОМУ ДЕРЕВУ.
    ///
    ///     w[k] = max(w[приёмник k], H[k])
    ///
    /// в порядке от устьев к верховьям (Кордоннье и др., 2019).
    ///
    /// ВАЖНО: порядок обхода обязан быть ПЕРЕСТРОЕН после Resolve — тот, что
    /// строился до, отвечает прежним приёмникам, а разбор их поменял.
    ///
    /// Узел без приёмника — устье: там вода не поднимается, уровень равен
    /// высоте.
    /// </summary>
    public static void ComputeWaterLevel(TerrainGraph g)
    {
        for (int q = 0; q < g.Count; q++)
        {
            int k = g.Order[q];
            int d = g.Down[k];
            g.Water[k] = d < 0 ? g.H[k]
                       : (g.Water[d] > g.H[k] ? g.Water[d] : g.H[k]);
        }
    }

    /// <summary>
    /// Метит узлы номером их водосбора.
    ///
    /// Идём по топологическому порядку: узел без приёмника начинает свой
    /// водосбор, прочие наследуют водосбор приёмника.
    /// </summary>
    private static int LabelBasins(TerrainGraph g, int[] basin)
    {
        int basinCount = 0;
        for (int q = 0; q < g.Count; q++)
        {
            int k = g.Order[q];
            basin[k] = g.Down[k] < 0 ? basinCount++ : basin[g.Down[k]];
        }
        return basinCount;
    }

    /// <summary>Сток водосбора: узел, с которого он начался.</summary>
    private static int[] FindOutlets(TerrainGraph g, int[] basin, int basinCount)
    {
        var outlet = new int[basinCount];
        for (int k = 0; k < g.Count; k++)
            if (g.Down[k] < 0) outlet[basin[k]] = k;
        return outlet;
    }

    /// <summary>
    /// Водосбор открыт, если его сток лежит на краю области: оттуда вода
    /// уходит с уровня, и заливать его не нужно.
    /// </summary>
    private static bool[] MarkOpenBasins(TerrainGraph g, int[] outlet, int basinCount)
    {
        var open = new bool[basinCount];
        int side = g.Side;
        for (int b = 0; b < basinCount; b++)
        {
            int k = outlet[b];
            int i = k % side, j = k / side;
            open[b] = i == 0 || j == 0 || i == side - 1 || j == side - 1;
        }
        return open;
    }

    /// <summary>
    /// Пороги между соседними водосборами.
    ///
    /// Собираются проходом в список, а не словарём пар: замер показал, что
    /// словарь обходился в 376 мс на вызов против 21 у списка — водосборов
    /// пять тысяч на тринадцать тысяч узлов.
    ///
    /// Повторы не мешают: приём Крускала пропустит рёбра, связывающие уже
    /// связанное.
    /// </summary>
    private static List<Pass> CollectPasses(TerrainGraph g, int[] basin)
    {

        // ---- 2. ПОРОГИ МЕЖДУ ВОДОСБОРАМИ ----
        //
        // Для всякой пары соседних водосборов помнится НАИНИЗШИЙ порог:
        // через него вода и потечёт.
        var edges = new List<Pass>(g.Count / 4);
        for (int k = 0; k < g.Count; k++)
        {
            int ba = basin[k];
            int s = g.NeighbourStart[k], e = g.NeighbourStart[k + 1];
            for (int q = s; q < e; q++)
            {
                int nb = g.Neighbours[q];
                int bb = basin[nb];

                // Только один раз на пару: берём, где номер меньше.
                if (ba >= bb) continue;

                float h = MathF.Max(g.H[k], g.H[nb]);
                edges.Add(new Pass(ba, bb, k, nb, h));
            }
        }
        return edges;
    }

    /// <summary>
    /// Назначает сток впадинам через наинизшие пороги.
    ///
    /// Приём Крускала: рёбра по возрастанию высоты порога, соединяем те, что
    /// связывают ещё не связанные водосборы. Так всякая впадина получает сток
    /// через наинизший доступный порог — это и есть остовное дерево
    /// наименьшего веса.
    /// </summary>
    private static void RouteThroughPasses(TerrainGraph g, List<Pass> edges,
                                           int[] outlet, bool[] open, int basinCount)
    {
        // ---- ОСТОВНОЕ ДЕРЕВО НАИМЕНЬШЕГО ВЕСА ----
        //
        // Приём Крускала: рёбра по возрастанию высоты порога, соединяем те,
        // что связывают ещё не связанные водосборы.
        //
        // Так всякая впадина получает сток через наинизший доступный порог.
        edges.Sort((a, b) => a.Height.CompareTo(b.Height));

        var parent = new int[basinCount];
        for (int b = 0; b < basinCount; b++) parent[b] = b;

        int Find(int b)
        {
            while (parent[b] != b) { parent[b] = parent[parent[b]]; b = parent[b]; }
            return b;
        }

        // Открытые водосборы сливаются в один корень: они уже имеют сток.
        int root = -1;
        for (int b = 0; b < basinCount; b++)
            if (open[b]) { if (root < 0) root = b; else parent[Find(b)] = Find(root); }
        if (root < 0) root = 0;

        // ---- 4. НАЗНАЧЕНИЕ СТОКА: ПРОРЕЗАНИЕ ВПАДИНЫ ----
        //
        // ---- ОТЧЕГО ПРОСТОЙ ПОПРАВКИ НЕ ХВАТАЕТ ----
        //
        // Кордоннье с соавторами (2019) описывают ТРИ способа обновить
        // приёмники: простую поправку, прорезание и заливку. Здесь стояла
        // простая: приёмник низшей точки впадины направлялся сразу к порогу.
        //
        // Она даёт связный сток, но НЕ ДАЁТ ПРОСТРАНСТВЕННОЙ НЕПРЕРЫВНОСТИ:
        // между низшей точкой и порогом нет цепочки узлов, по которой
        // накапливается водосбор. У авторов сказано прямо: разорванный
        // водосбор внутри впадины плох именно для НЕЯВНОЙ схемы вреза
        // (Браун–Виллетт), которую мы и применяем в GraphErosion, — впадины
        // вскрываются эрозией слишком медленно.
        //
        // ЭТО И БЫЛА НАША БЕДА: 33% площади уровня оставалось бессточным,
        // потому что врез не мог пробиться внутрь впадин.
        //
        // ---- ЧТО ДЕЛАЕТ ПРОРЕЗАНИЕ ----
        //
        // Подражает реке, промывающей узкую борозду от дна впадины к порогу.
        // Путь уже есть — это цепочка приёмников ОТ ПОРОГА К ДНУ, посчитанная
        // до вмешательства. Значит довольно пройти по ней и развернуть
        // приёмники на обратные, пока не дойдём до дна.
        //
        // Высоты при этом НЕ МЕНЯЮТСЯ: у авторов прорезание и заливка —
        // только названия, алгоритм правит связность потока, а не рельеф.
        // Борозду вырежет сам врез, когда по ней пойдёт вода.
        foreach (var p in edges)
        {
            int ra = Find(p.BasinA), rb = Find(p.BasinB);
            if (ra == rb) continue;

            // Который из двух уже связан с открытым?
            bool aOpen = ra == Find(root);
            int fromNode = aOpen ? p.NodeB : p.NodeA;
            int toNode = aOpen ? p.NodeA : p.NodeB;
            int fromBasin = aOpen ? p.BasinB : p.BasinA;

            // Разворот цепочки: от порога вниз по прежним приёмникам до дна.
            //
            // Идём от fromNode по старым приёмникам и на каждом шаге ставим
            // приёмником ПРЕДЫДУЩИЙ узел. Так путь «дно -> порог» получает
            // непрерывную цепочку, и водосбор по ней накапливается.
            int prev = toNode;
            int cur = fromNode;
            int pit = outlet[fromBasin];
            int guard = 0;
            while (cur >= 0 && guard++ <= g.Count)
            {
                int next = g.Down[cur];
                g.Down[cur] = prev;
                if (cur == pit) break;      // дно достигнуто
                prev = cur;
                cur = next;
            }

            // Дно могло не лежать на этой цепочке (вложенные впадины): тогда
            // направляем его к порогу напрямую, как делала простая поправка.
            if (g.Down[pit] < 0) g.Down[pit] = fromNode;

            parent[ra] = rb;
        }
    }
}
