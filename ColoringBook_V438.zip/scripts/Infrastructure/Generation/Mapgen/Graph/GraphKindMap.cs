using System;
using ColoringBook.Domain.Level;
using ColoringBook.Infrastructure.Generation.Mapgen;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// УКЛАДКА ВИДОВ РЕЛЬЕФА ПЯТНАМИ.
///
/// ---- ЗАЧЕМ ----
///
/// Прежде вид задавался на ВСЮ область: уровень был либо альпийским, либо
/// холмами, либо вулканами.
///
/// В игре они должны лежать пятнами, как в старом устройстве: игрок идёт и
/// переходит из одного края в другой.
///
/// ---- КАК ----
///
/// Область делится ячейками Вороного: середины разбросаны, всякая точка
/// относится к ближайшей.
///
/// Вид ячейки берётся по её номеру, чередованием: так всякий вид получает
/// свою долю независимо от случая.
///
/// ---- ПЕРЕХОДЫ ----
///
/// На границе двух видов поднятие СМЕШИВАЕТСЯ: доля второго растёт по мере
/// приближения к границе.
///
/// Из патента о слиянии данных о высотах: у каждой области своя высота, а
/// между ними ПОЛОСА ПЕРЕХОДА, где значения плавно сводятся.
///
/// Без неё на стыке выходил бы уступ, и вода в нём стояла бы.
/// </summary>
public sealed class GraphKindMap
{
    private readonly (float X, float Y, GraphTerrainKind Kind)[] _spots;
    private readonly Func<float, float, float>[] _uplift;
    private readonly float[] _erodibility;
    private readonly SimplexNoise _warp;
    private readonly GraphKindMapSettings _s;

    /// <summary>Сторона области, на которой построен вычислитель пятна.</summary>
    private readonly float _spotSpan;

    private GraphKindMap((float, float, GraphTerrainKind)[] spots,
                         Func<float, float, float>[] uplift,
                         float[] erodibility, int seed,
                         GraphKindMapSettings s, float spotSpan)
    {
        _spots = spots;
        _uplift = uplift;
        _erodibility = erodibility;
        _warp = new SimplexNoise(seed + 6113);
        _s = s;
        _spotSpan = spotSpan;
    }

    /// <summary>
    /// Поднятие пятна в своих координатах.
    ///
    /// Вычислитель построен на область стороной _spotSpan с началом в углу;
    /// середина пятна ложится в середину этой области.
    /// </summary>
    private float UpliftOfSpot(int i, float xKm, float yKm)
        => _uplift[i](xKm - _spots[i].X + _spotSpan * 0.5f,
                      yKm - _spots[i].Y + _spotSpan * 0.5f);

    /// <summary>
    /// Раскладывает виды по области.
    /// </summary>
    public static GraphKindMap Build(float extentKm, int seed,
                                     GraphKindMapSettings settings,
                                     GraphUpliftSettings uplift)
    {
        var rnd = new Random(seed + 977);
        var kinds = Enum.GetValues<GraphTerrainKind>();

        // ---- ЧИСЛО ПЯТЕН: НЕ МЕНЬШЕ, ЧЕМ НУЖНО ВИДАМ ----
        //
        // ЗАМЕР, ВСКРЫВШИЙ БЕДУ. При SpotKm = 45 на уровне 57.6 км выходило
        //
        //     57.6² / 45² = 1.6  ->  целочисленно 1  ->  предел поднимал до 2
        //
        // ДВА пятна на весь уровень. Доли по трём зёрнам:
        //
        //     зерно   42:  альпийский 100%, холмы  0%, вулканы 0%
        //     зерно 1055:  альпийский 100%, холмы  0%, вулканы 0%
        //     зерно  777:  альпийский  44%, холмы 56%, вулканы 0%
        //
        // Вулканического края не выпадало НИ РАЗУ, и сплошная проверка
        // объявила мёртвыми все его величины — до счёта они не доходили.
        //
        // Величина SpotKm подбиралась на уровне 231 км, где пятен выходило два
        // десятка. Уровень стал вчетверо меньше по стороне, а величина
        // осталась: свойство зависит от площади и не приведено к ней.
        //
        // Предел ставится не от балды, а по надобности: чтобы всякий вид с
        // ненулевым весом получил хотя бы одно пятно, их нужно не меньше, чем
        // видов. Берём вдвое, иначе единственное пятно вида ляжет в угол.
        int wanted = (int)(extentKm * extentKm / (settings.SpotKm * settings.SpotKm));
        int count = Math.Max(kinds.Length * 2, wanted);
        var spots = new (float, float, GraphTerrainKind)[count];

        // ---- ВИДЫ РАЗДАЮТСЯ ПО ВЕСАМ, А НЕ ЖРЕБИЕМ ----
        //
        // Прежде вид каждого пятна тянулся жребием по весам. При двух десятках
        // пятен это давало примерно нужные доли, при пяти — как повезёт, а при
        // двух не давало третьего вида вовсе.
        //
        // Вес назван ДОЛЕЙ ВИДА, и доля должна быть долей, а не средним по
        // многим розыгрышам. Поэтому пятна раздаются счётом: виду достаётся
        // столько, сколько ему причитается по весу, но не меньше одного.
        //
        // Случайность остаётся там, где ей место: в РАСПОЛОЖЕНИИ пятен.
        var plan = new GraphTerrainKind[count];
        {
            int placed = 0;
            for (int q = 0; q < kinds.Length && placed < count; q++)
            {
                float w = settings.WeightOf(kinds[q]);
                if (w <= 0f) continue;
                int share = (int)MathF.Round(count * w / settings.TotalWeight);
                if (share < 1) share = 1;
                if (placed + share > count) share = count - placed;
                for (int s = 0; s < share; s++) plan[placed++] = kinds[q];
            }
            // Остаток — главному виду: он назван дающим массив рельефа.
            while (placed < count) plan[placed++] = kinds[0];

            // Перемешивание: иначе виды лягут полосами в порядке перечня.
            for (int i = count - 1; i > 0; i--)
            {
                int j = rnd.Next(i + 1);
                (plan[i], plan[j]) = (plan[j], plan[i]);
            }
        }

        for (int i = 0; i < count; i++)
        {
            float x = (float)rnd.NextDouble() * extentKm;
            float y = (float)rnd.NextDouble() * extentKm;
            spots[i] = (x, y, plan[i]);
        }

        // ---- ВЫЧИСЛИТЕЛЬ НА КАЖДОЕ ПЯТНО, А НЕ НА ВИД ----
        //
        // БЕДА, КОТОРУЮ ЭТО ЛЕЧИТ. Прежде поднятие вида строилось НА ВСЮ
        // ОБЛАСТЬ, а спрашивалось только внутри пятен своего вида.
        //
        // ЗАМЕР (57.6 км, три зерна): конусы покрывали 11-26% области, и лишь
        // 15-42% из них попадали на вулканический вид. Остальные считались и
        // ВЫБРАСЫВАЛИСЬ, а вулканическое пятно без конуса оставалось ровным
        // лавовым полем — отсюда «равнины занимают четверть уровня».
        //
        // То же с альпийским поясом: дуга разломов чертилась через весь
        // уровень, а видна была лишь там, куда попали альпийские пятна. Оттого
        // ПОЯС И НЕ ЧИТАЛСЯ — на снимке выходили его обрывки, а не дуга.
        //
        // Теперь у каждого пятна свой вычислитель, построенный на область
        // размером с пятно и спрашиваемый в СВОИХ координатах. Что построено,
        // то и видно.
        float spotSpan = settings.SpotKm * 2f;    // с запасом на перекрытие
        var ups = new Func<float, float, float>[count];
        var erod = new float[count];
        for (int i = 0; i < count; i++)
        {
            ups[i] = GraphUpliftSource.For(spots[i].Item3, spotSpan,
                                           seed + i * 131 + (int)spots[i].Item3 * 7919,
                                           uplift);
            erod[i] = GraphUpliftSource.ErodibilityFor(spots[i].Item3, uplift);
        }

        return new GraphKindMap(spots, ups, erod, seed, settings, spotSpan);
    }

    /// <summary>
    /// Заполняет поднятие и врезаемость СРАЗУ ДЛЯ ВСЕХ УЗЛОВ ГРАФА.
    ///
    /// ---- ЗАЧЕМ ----
    ///
    /// Прежде поднятие и врезаемость запрашивались порознь, и поиск двух
    /// ближайших пятен шёл ДВАЖДЫ на узел.
    ///
    /// Здесь он идёт один раз, и обе величины берутся из одной смеси.
    /// </summary>
    public void FillNodes(TerrainGraph g, float[] erodibility)
    {
        for (int k = 0; k < g.Count; k++)
        {
            float x = g.X[k], y = g.Y[k];
            Nearest(x, y, out int a, out int b, out float share);

            if (share <= 0f)
            {
                g.Uplift[k] = UpliftOfSpot(a, x, y);
                erodibility[k] = _erodibility[a];
                continue;
            }

            g.Uplift[k] = UpliftOfSpot(a, x, y) * (1f - share)
                        + UpliftOfSpot(b, x, y) * share;
            erodibility[k] = _erodibility[a] * (1f - share)
                           + _erodibility[b] * share;
        }
    }

    /// <summary>
    /// Вид в точке области, километры от угла.
    ///
    /// Открыто ради ПРОВЕРКИ: чтобы мерить рельеф по видам, надо знать, где
    /// какой. Прежде проверка брала карту типов у старого устройства
    /// (FaultUplift.LastTypeMap), и при графовом рельефе она была пуста —
    /// меры по видам молча не считались.
    ///
    /// Берётся ближайшее пятно, без смешивания: на границе вид всё равно один
    /// или другой, а доля нужна только полю поднятия.
    /// </summary>
    public GraphTerrainKind KindAt(float xKm, float yKm)
    {
        Nearest(xKm, yKm, out int a, out _, out _);
        return _spots[a].Kind;
    }

    /// <summary>
    /// Два ближайших пятна и доля второго.
    ///
    /// Доля растёт от нуля в середине пятна до половины на границе — там оба
    /// вида смешиваются поровну.
    /// </summary>
    private void Nearest(float xKm, float yKm, out int a, out int b, out float share)
    {
        // Искажение границы: без него ячейки выходят многоугольниками с
        // прямыми рёбрами, и стык виден.
        float wx = xKm + _warp.Noise2D(xKm / _s.WarpKm, yKm / _s.WarpKm) * _s.WarpAmpKm;
        float wy = yKm + _warp.Noise2D(yKm / _s.WarpKm + 31f, xKm / _s.WarpKm - 17f)
                       * _s.WarpAmpKm;

        float d1 = float.MaxValue, d2 = float.MaxValue;
        a = 0; b = 0;

        for (int i = 0; i < _spots.Length; i++)
        {
            float dx = wx - _spots[i].X, dy = wy - _spots[i].Y;
            float d = dx * dx + dy * dy;
            if (d < d1) { d2 = d1; b = a; d1 = d; a = i; }
            else if (d < d2) { d2 = d; b = i; }
        }

        if (_spots[a].Kind == _spots[b].Kind) { share = 0f; return; }

        // Насколько точка близка к границе: там расстояния равны.
        float r1 = MathF.Sqrt(d1), r2 = MathF.Sqrt(d2);
        float gap = r2 - r1;

        share = gap >= _s.BlendKm ? 0f
              : 0.5f * (1f - gap / _s.BlendKm);
    }
}
