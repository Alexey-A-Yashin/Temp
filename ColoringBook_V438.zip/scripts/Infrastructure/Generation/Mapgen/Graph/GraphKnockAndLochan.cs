using System;
using ColoringBook.Domain.Level;
using ColoringBook.Infrastructure.Generation.Mapgen;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// ХОЛМЫ И ОЗЕРЦА — россыпь скальных бугров с водой между ними.
///
/// ---- ОТКУДА ----
///
/// Северо-запад Шотландии и Канадский щит. Из источников:
///
/// «Скальные бугры выступают на низкой болотистой земле, среди которой
/// поднимаются одинокие суровые горы; озерца и водопады усеивают местность».
///
/// «Ледники выскребли ложе, оставив котловины, что ныне держат миллионы озёр,
/// прудов и болот — они и дают этому краю его особый облик».
///
/// ---- ЧЕМ ЦЕННО ДЛЯ ИГРЫ ----
///
/// Множество мелких озёр: всякое — отдельное пятно для раскраски.
///
/// Одинокие горы среди равнины, а не сплошной массив: приметные тела,
/// разбросанные по уровню.
///
/// ---- ЧЕМ ОТЛИЧАЕТСЯ ОТ ПРОЧИХ ----
///
///     альпийские   пояс: хребты вдоль линий
///     столовые     плита: ровный блок с обрывом
///     ХОЛМЫ        РОССЫПЬ: бугры вразброс, между ними котловины
///
/// ---- УСТРОЙСТВО ----
///
/// Поднятие — шум с порогом: выше порога бугор, ниже котловина. Порог задаёт,
/// сколько площади под водой.
/// </summary>
public sealed class GraphKnockAndLochan
{
    private readonly SimplexNoise _knoll;
    private readonly SimplexNoise _grain;
    private readonly SimplexNoise _rise;
    private readonly GraphKnockSettings _s;

    public GraphKnockAndLochan(int seed, GraphKnockSettings settings)
    {
        _knoll = new SimplexNoise(seed + 313);
        _grain = new SimplexNoise(seed + 947);
        _rise = new SimplexNoise(seed + 1571);
        _s = settings;
    }

    /// <summary>
    /// Поднятие в точке.
    /// </summary>
    public float UpliftAt(float xKm, float yKm)
    {
        // Бугры: шум частотой в несколько километров.
        float k = _knoll.Noise2D(xKm / _s.KnollKm, yKm / _s.KnollKm);

        // Мелкая рябь: бугры не должны быть одинаковы.
        float g = _grain.Noise2D(xKm / _s.GrainKm, yKm / _s.GrainKm);

        float v = k * 0.75f + g * 0.25f;

        // Порог: ниже него котловина, воде есть где стоять.
        float above = (v - _s.Threshold) / MathF.Max(1f - _s.Threshold, 1e-4f);
        float knoll = above <= 0f ? 0f : MathF.Min(above, 1f);

        // ---- ОДИНОКИЕ ГОРЫ ----
        //
        // Из источников: «скальные бугры на низкой земле, среди которой
        // поднимаются одинокие суровые горы» — Сюилвен, Куинаг, Стак.
        //
        // Редкие места, где поднятие много выше прочих.
        float r = _rise.Noise2D(xKm / _s.LoneKm, yKm / _s.LoneKm);
        float lone = r > _s.LoneThreshold
            ? (r - _s.LoneThreshold) / MathF.Max(1f - _s.LoneThreshold, 1e-4f)
            : 0f;

        return knoll * _s.KnollHeight + lone * _s.LoneHeight;
    }
}
