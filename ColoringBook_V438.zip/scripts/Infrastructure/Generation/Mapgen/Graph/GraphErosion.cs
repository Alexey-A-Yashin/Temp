using System;
using ColoringBook.Domain.Level;

namespace ColoringBook.Infrastructure.Generation.Mapgen.Graph;

/// <summary>
/// ЭРОЗИЯ НА ГРАФЕ — приём Брауна и Виллетта (FastScape, 2013).
///
/// ---- ЧЕМ ЛУЧШЕ НАШЕГО ----
///
/// У нас ЯВНАЯ схема: высота меняется на малую долю за шаг, и оттого нужно
/// двести шагов. При большем шаге счёт расходится.
///
/// Здесь НЕЯВНАЯ схема: высота узла решается через высоту его приёмника
/// напрямую. Она устойчива при ЛЮБОМ шаге времени, и шагов нужно единицы.
///
/// Из источника: «очень быстрый приём линейной сложности, неявный и
/// распараллеливаемый».
///
/// ---- УСТРОЙСТВО ----
///
/// Уравнение мощности потока:
///
///     dh/dt = U - K * A^m * S^n
///
/// где U — поднятие, A — площадь водосбора, S — уклон к приёмнику.
///
/// При n = 1 оно решается ТОЧНО:
///
///     h = (h_старое + dt * (U + K * A^m * h_приёмника / L))
///         / (1 + dt * K * A^m / L)
///
/// где L — расстояние до приёмника. Это и есть неявное решение.
///
/// ---- РАЗДЕЛЕНИЕ ----
///
/// Часть не зависит ни от чего старого. Удаление старых построителей её не
/// затронет.
/// </summary>
public static class GraphErosion
{
    /// <summary>
    /// Находит приёмники: куда стекает каждый узел.
    ///
    /// Правило восьми направлений: приёмник — наинизший из соседей.
    /// </summary>
    public static void FindReceivers(TerrainGraph g)
    {
        for (int k = 0; k < g.Count; k++)
        {
            float best = g.H[k];
            int down = -1;
            int s = g.NeighbourStart[k], e = g.NeighbourStart[k + 1];
            for (int q = s; q < e; q++)
            {
                int nb = g.Neighbours[q];
                if (g.H[nb] < best) { best = g.H[nb]; down = nb; }
            }
            g.Down[k] = down;
        }
    }

    /// <summary>
    /// Топологический порядок: всякий узел стоит ПЕРЕД своими нижележащими.
    ///
    /// Строится обходом от устьев вверх по дереву стока. Это дешевле
    /// сортировки по высоте и даёт тот же порядок.
    /// </summary>
    public static void BuildOrder(TerrainGraph g, int[] stack, int[] childCount)
    {
        Array.Clear(childCount, 0, g.Count);
        for (int k = 0; k < g.Count; k++)
            if (g.Down[k] >= 0) childCount[g.Down[k]]++;

        int top = 0, put = 0;
        for (int k = 0; k < g.Count; k++)
            if (g.Down[k] < 0) stack[top++] = k;

        while (top > 0)
        {
            int c = stack[--top];
            g.Order[put++] = c;
            int s = g.NeighbourStart[c], e = g.NeighbourStart[c + 1];
            for (int q = s; q < e; q++)
            {
                int nb = g.Neighbours[q];
                if (g.Down[nb] == c) stack[top++] = nb;
            }
        }

        // Узлы, не попавшие в дерево (замкнутые впадины), дописываются в конец.
        if (put < g.Count)
        {
            var seen = new bool[g.Count];
            for (int q = 0; q < put; q++) seen[g.Order[q]] = true;
            for (int k = 0; k < g.Count && put < g.Count; k++)
                if (!seen[k]) g.Order[put++] = k;
        }
    }

    /// <summary>
    /// Площадь водосбора: сколько узлов стекает в каждый.
    ///
    /// Обход в ОБРАТНОМ топологическом порядке — от верховьев к устьям.
    /// </summary>
    public static void Accumulate(TerrainGraph g, float cellArea)
    {
        for (int k = 0; k < g.Count; k++) g.Area[k] = cellArea;

        for (int q = g.Count - 1; q >= 0; q--)
        {
            int k = g.Order[q];
            int d = g.Down[k];
            if (d >= 0) g.Area[d] += g.Area[k];
        }
    }

    /// <summary>
    /// Врез при стоке во многих направлениях.
    ///
    /// Прежний врез решал высоту узла через ОДНОГО приёмника. Здесь их
    /// несколько, и высота решается через средневзвешенную высоту приёмников
    /// с их долями.
    ///
    /// Неявность сохраняется: узел не может опуститься ниже своих приёмников.
    /// </summary>
    public static void InciseMulti(TerrainGraph g, GraphFlow.Shares shares,
                                   float[] erodibility, GraphIncisionSettings settings)
    {
        for (int i = 0; i < g.Count; i++)
        {
            int k = shares.Order[i];
            int s = g.NeighbourStart[k], e = g.NeighbourStart[k + 1];

            // Средневзвешенная высота приёмников и среднее расстояние.
            float hDown = 0f, lenSum = 0f, wsum = 0f, hLowest = float.MaxValue;
            for (int q = s; q < e; q++)
            {
                float part = shares.Share[q];
                if (part <= 0f) continue;
                int nb = g.Neighbours[q];
                hDown += g.H[nb] * part;
                lenSum += g.NeighbourDistance[q] * part;
                wsum += part;
                if (g.H[nb] < hLowest) hLowest = g.H[nb];
            }
            if (wsum <= 0f || lenSum < 1e-5f) continue;

            // Средневзвешенные величины: доли уже приведены к единице, но
            // при малых уклонах сумма может выйти меньше — приводим.
            hDown /= wsum;
            lenSum /= wsum;
            if (lenSum < 1e-5f) continue;

            // ---- ВРЕЗАЕМОСТЬ ПРИВЕДЕНА К РАССТОЯНИЮ ----
            //
            // Множитель неявной схемы f = dt·K·A^m / L обратен расстоянию до
            // приёмника. При густых узлах приёмник ближе, и врез выходит
            // сильнее:
            //
            //     шаг 0.5 км: f = 10.0
            //     шаг 2.0 км: f =  2.5
            //
            // Замер подтверждал: расхождение размаха 1.28 при вчетверо разной
            // густоте, и без вреза оно падало до 1.08.
            //
            // ---- МНОЖИТЕЛЬ ШИРИНЫ РУСЛА К ШАГУ ----
            //
            // Из источников: зависимость от густоты уменьшается включением
            // множителя w/δ в член вреза, где δ — шаг сетки, w — ширина
            // русла.
            //
            // У Пеллетье прямо: мерить надо «площадь на ЕДИНИЦУ ШИРИНЫ потока
            // в господствующем русле, а не саму площадь».
            //
            // Прежде я умножал врезаемость на само расстояние — расхождение
            // выросло с 1.28 до 1.58. Умножать надо на ОТНОШЕНИЕ ширины к
            // шагу, а не на шаг.
            //
            // Ширина растёт с водосбором: w = W · A^WidthExponent.
            //
            // ---- ПОКАЗАТЕЛИ БЕРУТСЯ С ПУЛЬТА, А НЕ ЗАШИТЫ ----
            //
            // Прежде здесь стоял MathF.Sqrt, то есть оба показателя равнялись
            // половине намертво, а AreaExponent и WidthExponent висели на
            // пульте и не читались никем. Это девятый случай одной беды:
            // величина заведена, а счёт берёт своё.
            //
            // Отношение показателя площади к показателю уклона задаёт
            // ВОГНУТОСТЬ РУСЛА, и при 0.5 рельеф не зависит от горизонтального
            // размера — ради этого величина и заводилась.
            //
            // Быстрый путь при половине сохранён: корень вдвое дешевле общей
            // степени, а половина — обычный случай.
            float area = g.Area[k];
            float width = settings.ChannelWidthKm
                        * (settings.WidthExponent == 0.5f ? MathF.Sqrt(area)
                                                          : MathF.Pow(area, settings.WidthExponent));
            float widthFactor = MathF.Min(width / lenSum, 1f);

            float areaTerm = settings.AreaExponent == 0.5f ? MathF.Sqrt(area)
                                                          : MathF.Pow(area, settings.AreaExponent);
            float kk = erodibility[k] * areaTerm * widthFactor;
            float f = settings.TimeStep * kk / lenSum;
            if (!float.IsFinite(f) || f < 0f) continue;

            float h = (g.H[k] + f * hDown) / (1f + f);
            if (!float.IsFinite(h)) continue;

            g.H[k] = h < hLowest ? hLowest : h;
        }
    }

    /// <summary>Поднятие: прибавка к высоте за шаг.</summary>
    public static void Uplift(TerrainGraph g, float dt)
    {
        for (int k = 0; k < g.Count; k++) g.H[k] += g.Uplift[k] * dt;
    }
}
