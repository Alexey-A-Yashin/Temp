using System;

namespace ColoringBook.Infrastructure.Generation.Mapgen;

/// <summary>
/// Детерминированный 2D Simplex noise (seeded).
/// Совместим по смыслу с simplex-noise.js из mapgen2.
/// </summary>
public sealed class SimplexNoise
{
    private readonly int[] _perm = new int[512];

    private static readonly int[] Grad3 =
    {
        1, 1, 0, -1, 1, 0, 1, -1, 0, -1, -1, 0,
        1, 0, 1, -1, 0, 1, 1, 0, -1, -1, 0, -1,
        0, 1, 1, 0, -1, 1, 0, 1, -1, 0, -1, -1
    };

    public SimplexNoise(int seed)
    {
        var rnd = new SeededRandom(seed);
        var p = new int[256];
        for (int i = 0; i < 256; i++) p[i] = i;
        for (int i = 255; i > 0; i--)
        {
            int j = rnd.NextInt(i + 1);
            (p[i], p[j]) = (p[j], p[i]);
        }
        for (int i = 0; i < 512; i++)
            _perm[i] = p[i & 255];
    }

    /// <summary>Возвращает значение в диапазоне примерно [-1, 1].</summary>
    public float Noise2D(float x, float y)
    {
        const float F2 = 0.366025403f; // (sqrt(3)-1)/2
        const float G2 = 0.211324865f; // (3-sqrt(3))/6

        float s = (x + y) * F2;
        int i = FastFloor(x + s);
        int j = FastFloor(y + s);

        float t = (i + j) * G2;
        float X0 = i - t;
        float Y0 = j - t;
        float x0 = x - X0;
        float y0 = y - Y0;

        int i1, j1;
        if (x0 > y0) { i1 = 1; j1 = 0; }
        else { i1 = 0; j1 = 1; }

        float x1 = x0 - i1 + G2;
        float y1 = y0 - j1 + G2;
        float x2 = x0 - 1f + 2f * G2;
        float y2 = y0 - 1f + 2f * G2;

        int ii = i & 255;
        int jj = j & 255;

        float n0 = Corner(ii, jj, x0, y0);
        float n1 = Corner(ii + i1, jj + j1, x1, y1);
        float n2 = Corner(ii + 1, jj + 1, x2, y2);

        return 70f * (n0 + n1 + n2);
    }

    private float Corner(int ii, int jj, float x, float y)
    {
        float t = 0.5f - x * x - y * y;
        if (t < 0f) return 0f;
        int gi = (_perm[ii + _perm[jj]] % 12) * 3;
        t *= t;
        return t * t * (Grad3[gi] * x + Grad3[gi + 1] * y);
    }

    private static int FastFloor(float x) => x > 0 ? (int)x : (int)x - 1;

    /// <summary>FBM как в mapgen2 util.fbm_noise.</summary>
    public float Fbm(float nx, float ny, float[] amplitudes)
    {
        float sum = 0f, sumAmp = 0f;
        for (int octave = 0; octave < amplitudes.Length; octave++)
        {
            float freq = 1 << octave;
            sum += amplitudes[octave] * Noise2D(nx * freq, ny * freq);
            sumAmp += amplitudes[octave];
        }
        return sumAmp > 0 ? sum / sumAmp : 0f;
    }
}
