using System;
using ColoringBook.Domain.Level;
using ColoringBook.Domain.Level.Route;
using ColoringBook.Infrastructure.Generation.Mapgen;
using ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

namespace ColoringBook.Infrastructure.Generation.Routes;

/// <summary>
/// РЕЛЬЕФ ДЛЯ ПРОКЛАДКИ МАРШРУТОВ: две сетки вместо одной.
///
/// ---- ПОЧЕМУ ДВЕ ----
///
/// Планировать на мелкой сетке дорого: граф растёт как квадрат. Планировать на
/// крупной — самообман: уклон, снятый с ячейки 90 м, ЗАНИЖЕН, и трасса, которая
/// на ней выглядит проезжей, на настоящем рельефе оказывается стеной.
///
/// Замер: трасса, спланированная на 90 м и проверенная на 30 м, имела 12.8% пути
/// в гору и 9.0% под гору круче предела, а наибольший уклон 78.6°.
///
/// Поэтому ГРАФ строится на крупной сетке, а СМОТРИТ он на мелкую: уклон шага и
/// глубина срезки считаются по <see cref="FineAt"/>. После этого нарушений 0.0%.
///
/// ---- ПОЧЕМУ С ЗАПАСОМ ----
///
/// Эрозия локальна (V219), но не мгновенна. Замер сходимости при сдвиге окна:
///     запас 24 клетки — расходится 8169 точек из 55696, до 2 см
///     запас 75 клеток (6.7 км) — набор седловин совпадает полностью
/// Запас в километрах не зависит от размера ячейки: он задаётся дальностью, с
/// которой собирается сток, а не сеткой.
///
/// ---- ЧТО ЗДЕСЬ НЕ ДЕЛАЕТСЯ ----
///
/// Поле НЕ пересчитывается. Если территория уже построена, её сеть хранится, а
/// достраиваются только новые рёбра (см. RouteEdge).
/// </summary>
public sealed class RouteField
{
    /// <summary>Ячейка сетки поиска, метры. 90 м — размен между качеством и ценой:
    /// на территорию 58 км это 641×641 узел и около 2.5 с построения против 7.3 с
    /// при 60 м. Разница на трассе не видна: тропа кладётся поверх.</summary>
    public const float SearchCellM = 90f;

    /// <summary>Ячейка сетки правды, метры. Совпадает с ячейкой ближнего кольца —
    /// того рельефа, по которому игрок реально едет.</summary>
    public const float FineCellM = 30f;

    /// <summary>
    /// ЗАПАС ВОКРУГ ОБЛАСТИ УБРАН (V313).
    ///
    /// Он был нужен, пока `RouteField` считал эрозию сам: результат зависел от
    /// того, каким куском её посчитали, и замер сходимости требовал 75 клеток
    /// (6.7 км), чтобы набор седловин совпадал при сдвиге окна.
    ///
    /// Теперь рельеф берётся выборкой из готового поля, посчитанного один раз на
    /// всю территорию. Выборка от окна не зависит по построению: сдвиг окна даёт
    /// ровно те же высоты. Запас стал бесплатным счётом.
    /// </summary>
    private const float MetresPerUnit = WorldScale.MetresPerUnit;

    private readonly float[] _height;      // мировые единицы, сетка поиска
    private readonly float[] _slopeDeg;    // градусы, сетка поиска
    private readonly float[] _frac;        // доля высоты по территории, 0..1
    private readonly float[] _flow;        // накопленный сток, сетка поиска
    private readonly float[] _fine;        // мировые единицы, сетка правды

    private readonly int _fineSide;
    private readonly float _originX, _originY;   // мировые единицы, левый нижний угол

    public int Side { get; }
    public int OriginCellX { get; }
    public int OriginCellY { get; }

    public float Height(int k) => _height[k];
    public float SlopeDeg(int k) => _slopeDeg[k];
    public float Frac(int k) => _frac[k];

    /// <summary>Высота на СЕТКЕ ПРАВДЫ в мировой точке, двулинейно.</summary>
    public float FineAt(float worldX, float worldY)
    {
        float cell = FineCellM / MetresPerUnit;
        float gx = (worldX - _originX) / cell, gy = (worldY - _originY) / cell;
        int i0 = Math.Clamp((int)MathF.Floor(gx), 0, _fineSide - 2);
        int j0 = Math.Clamp((int)MathF.Floor(gy), 0, _fineSide - 2);
        float tx = Math.Clamp(gx - i0, 0f, 1f), ty = Math.Clamp(gy - j0, 0f, 1f);
        float a = _fine[j0 * _fineSide + i0], b = _fine[j0 * _fineSide + i0 + 1];
        float c = _fine[(j0 + 1) * _fineSide + i0], d = _fine[(j0 + 1) * _fineSide + i0 + 1];
        return (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty;
    }

    public float WorldXOf(int k) => _originX + (k % Side) * (SearchCellM / MetresPerUnit);
    public float WorldYOf(int k) => _originY + (k / Side) * (SearchCellM / MetresPerUnit);

    /// <param name="originCellX">Левый край области в клетках МИРОВОЙ сетки поиска.</param>
    /// <param name="side">Сторона области в клетках, включая поля для опор соседа.</param>
    /// <param name="territoryLo">Низ размаха высот ВСЕЙ территории, мировые единицы.</param>
    /// <param name="fluvial">Поле речной эрозии — ТОТ САМЫЙ рельеф, по которому
    /// игрок едет. Обязателен.</param>
    /// <param name="fluvialSide">Сторона поля в узлах.</param>
    /// <param name="fluvialExtent">Сторона поля в мировых единицах.</param>
    public RouteField(int seed, int originCellX, int originCellY, int side,
                      float territoryLo, float territoryHi,
                      float[] fluvial, int fluvialSide, float fluvialExtent)
    {
        // ---- V313: РЕЛЬЕФ БЕРЁТСЯ У ПОЛЯ, А НЕ У СТАРОЙ ШУМОВОЙ ФУНКЦИИ ----
        //
        // Здесь строился свой рельеф: LayeredHeight плюс термическая и водная
        // эрозия. `LayeredHeight` — старая шумовая функция, убранная из
        // FarBackground в V283 именно потому, что она даёт величину, не
        // связанную с нашим полем (раздел 4б-3: «в центре даёт СЛУЧАЙНУЮ
        // величину»).
        //
        // Игра с V230 строит рельеф процессом поднятия и эрозии (FluvialField),
        // с V304 — с базисом в назначенных устьях. Значит маршруты
        // прокладывались по территории, КОТОРОЙ В ИГРЕ НЕТ, и все замеры
        // прототипа сняты на чужом рельефе.
        //
        // Отсюда же и давняя запись «числа не сошлись с прототипом»: сходиться
        // им было не с чем — обе стороны считали по старому шуму.
        //
        // ЗАПАС БОЛЬШЕ НЕ НУЖЕН. Он заводился потому, что эрозия считалась
        // здесь же и зависела от того, каким куском её посчитали. Поле считается
        // один раз на всю территорию, и выборка из него от окна не зависит:
        // сдвиг окна даёт те же высоты. Halo оставлен только в пояснении.
        //
        // СВОЕЙ ЭРОЗИИ ТОЖЕ БОЛЬШЕ НЕТ. Прогонять термическую и водную поверх
        // готового поля значило бы получить третий рельеф — ни поля, ни игры.
        if (fluvial == null || fluvial.Length == 0)
            throw new ArgumentException("RouteField требует поле речной эрозии", nameof(fluvial));

        Side = side; OriginCellX = originCellX; OriginCellY = originCellY;
        float cell = SearchCellM / MetresPerUnit;
        _originX = originCellX * cell;
        _originY = originCellY * cell;

        _height = new float[side * side];
        for (int j = 0; j < side; j++)
        for (int i = 0; i < side; i++)
            _height[j * side + i] = FluvialField.Sample(fluvial, fluvialSide, fluvialExtent,
                _originX + i * cell, _originY + j * cell);

        // ---- СТОК БЕРЁТСЯ У ДРЕНАЖА, А НЕ СЧИТАЕТСЯ ЗАНОВО ----
        //
        // Прежде он приходил побочным выходом собственной водной эрозии. Дренаж
        // считается один раз на всю область по тому же полю, и брать сток
        // откуда-то ещё значило бы завести второй ответ на вопрос «где река».
        // Тот же разъезд уже стоил нам воды в V306.
        var drainage = RidgedMountains.BuildDrainage(DrainageSide, fluvialExtent, seed,
                                                     fluvial, fluvialSide);
        float dcell = fluvialExtent / (DrainageSide - 1);
        _flow = new float[side * side];
        for (int j = 0; j < side; j++)
        for (int i = 0; i < side; i++)
        {
            float wx = _originX + i * cell, wz = _originY + j * cell;
            int di = Math.Clamp((int)((wx + fluvialExtent * 0.5f) / dcell), 0, DrainageSide - 1);
            int dj = Math.Clamp((int)((wz + fluvialExtent * 0.5f) / dcell), 0, DrainageSide - 1);
            _flow[j * side + i] = drainage[dj * DrainageSide + di];
        }

        _slopeDeg = new float[side * side];
        _frac = new float[side * side];
        float span = MathF.Max(territoryHi - territoryLo, 1e-3f);
        for (int j = 0; j < side; j++)
        for (int i = 0; i < side; i++)
        {
            int k = j * side + i;
            _frac[k] = (_height[k] - territoryLo) / span;
            int im = Math.Max(i - 1, 0), ip = Math.Min(i + 1, side - 1);
            int jm = Math.Max(j - 1, 0), jp = Math.Min(j + 1, side - 1);
            float gx = (_height[j * side + ip] - _height[j * side + im]) / ((ip - im) * cell);
            float gy = (_height[jp * side + i] - _height[jm * side + i]) / ((jp - jm) * cell);
            _slopeDeg[k] = MathF.Atan(MathF.Sqrt(gx * gx + gy * gy)) * 180f / MathF.PI;
        }

        // Сетка правды — то же поле, но с ячейкой 30 м, как у ближнего кольца.
        // Своей эрозии здесь нет по той же причине: третьего рельефа быть не
        // должно. Подробность мельче ячейки поля даёт окно уточнения, и когда
        // маршруты станут строиться вокруг игрока, брать её надо будет оттуда.
        float fineCell = FineCellM / MetresPerUnit;
        _fineSide = (int)(side * cell / fineCell) + 1;
        _fine = new float[_fineSide * _fineSide];
        for (int j = 0; j < _fineSide; j++)
        for (int i = 0; i < _fineSide; i++)
            _fine[j * _fineSide + i] = FluvialField.Sample(fluvial, fluvialSide, fluvialExtent,
                _originX + i * fineCell, _originY + j * fineCell);
    }

    /// <summary>Сторона сетки дренажа. Та же, что у фона: сток — одно понятие.</summary>
    private const int DrainageSide = 241;

    /// <summary>
    /// Размах высот ВСЕЙ территории по НАШЕМУ полю.
    ///
    /// Берётся с грубой выборки по всей области, а не по окну: иначе сдвиг окна
    /// сдвигает все пояса, а с ними и выбор опор.
    /// </summary>
    public static void TerritorySpan(float[] fluvial, out float lo, out float hi)
    {
        lo = float.MaxValue; hi = float.MinValue;
        for (int k = 0; k < fluvial.Length; k += 3)
        {
            float v = fluvial[k];
            if (v < lo) lo = v;
            if (v > hi) hi = v;
        }
    }
}
