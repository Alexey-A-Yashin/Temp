using System;

namespace ColoringBook.Infrastructure.Generation.Routes;

/// <summary>
/// ОЦЕНКА ВИДА С ТОЧКИ: доля годных кадров из восьми направлений.
///
/// ---- ПОЧЕМУ ЖИВЁТ ЗДЕСЬ, А НЕ В FarBackground ----
///
/// Эта величина нужна ДВУМ слоям: построителю маршрутов (чтобы опоры стояли
/// там, откуда открывается вид) и выбору точки старта. Правило 7а: величина,
/// которой пользуются два слоя, живёт в одном месте, а не копируется в каждый.
///
/// Список того, чем нам уже обошлось нарушение этого правила, — в разделе 7а
/// файла решений: пороги поясов разошлись между покровом и маршрутами, порог
/// русла жил в трёх местах и вода ложилась там, где ложа нет.
///
/// Слой генерации не зависит от Godot, поэтому высота приходит доводом-функцией,
/// а не берётся у `FarBackground`.
///
/// ---- ЧТО СЧИТАЕТСЯ ГОДНЫМ КАДРОМ ----
///
/// Два условия, оба из литературы и оба уже записаны в проекте:
///
///   СРЕДНЯЯ ОТКРЫТОСТЬ — неба от 15% до 60%. По всем работам о предпочтениях
///   пейзажа предпочтительна именно средняя открытость, а не крайности: закрытый
///   вид не даёт видеть и двигаться, на голом просторе не за что зацепиться.
///
///   ТРИ ПЛАНА — предметы не менее чем в четырёх дальностных полосах из пяти.
///   Freeman, Payne и Kemp сходятся на трёх планах независимо друг от друга.
///
/// ---- ЛУЧЕЙ И ДАЛЬНОСТИ ДОЛЖНО ХВАТАТЬ ----
///
/// Замер на одной и той же точке (перенесён вместе с кодом):
///
///     лучей  дальность  годных видов
///       24      2.5 км       12%
///       24      6.0 км       25%
///       64      2.5 км       37%
///       64      6.0 км       50%
///       64     25.0 км       50%
///
/// Дальше 6 км ничего не меняется — там уже всё видно. А при 24 лучах дальний
/// план не попадает между лучами, и кадр зря считается негодным.
/// </summary>
public static class ViewScore
{
    private const int Rays = 48;
    private const float FovY = 0.55f;
    private const float EyeAbove = 0.17f;      // 1.7 м в мировых единицах
    private const float MaxDist = 600f;        // 6 км: дальше ничего не меняется
    private const float MetresPerUnit = 10f;

    /// <summary>Доля годных кадров из восьми направлений, 0..1.</summary>
    public static double At(Func<float, float, float> heightAt, float camX, float camZ)
    {
        int good = 0;
        for (int a = 0; a < 8; a++)
        {
            float yaw = a * MathF.PI / 4f;
            if (FrameIsGood(heightAt, camX, camZ, yaw)) good++;
        }
        return good / 8.0;
    }

    /// <summary>Годен ли кадр в этом направлении.</summary>
    public static bool FrameIsGood(Func<float, float, float> heightAt,
                                   float camX, float camZ, float yaw)
    {
        float camY = heightAt(camX, camZ) + EyeAbove;
        int sky = 0, nearRays = 0;
        var layerSeen = new bool[5];

        for (int k = 0; k < Rays; k++)
        {
            // Веером по горизонтали и в три яруса по высоте.
            float sx = ((k % 16) / 15f - 0.5f) * 2f * FovY * 1.8f;
            float sy = ((k / 16) - 1) * FovY * 0.6f;
            float dx = MathF.Sin(yaw) + sx * MathF.Cos(yaw);
            float dz = MathF.Cos(yaw) - sx * MathF.Sin(yaw);
            float dl = MathF.Sqrt(dx * dx + dz * dz);
            dx /= dl; dz /= dl;

            float t = 0.5f, step = 1.5f;
            bool hit = false;
            while (t < MaxDist)
            {
                if (camY + sy * t < heightAt(camX + dx * t, camZ + dz * t)) { hit = true; break; }
                t += step;
                step = MathF.Min(step * 1.06f, 20f);
            }
            if (!hit) { sky++; continue; }

            float distM = t * MetresPerUnit;
            int layer = distM < 100f ? 0 : distM < 300f ? 1
                      : distM < 1000f ? 2 : distM < 3000f ? 3 : 4;
            if (layer == 0) nearRays++;
            layerSeen[layer] = true;
        }

        float skyFrac = sky / (float)Rays;
        if (skyFrac < 0.15f || skyFrac > 0.60f) return false;

        // ---- БЛИЖНИЙ ПЛАН НЕ ДОЛЖЕН СЪЕДАТЬ КАДР ----
        //
        // Мера считала, СКОЛЬКО разных слоёв задето, но не КАКУЮ ДОЛЮ кадра
        // занимает каждый. Одного луча, улетевшего вдаль, хватало, чтобы
        // засчитать дальний план.
        //
        // Замер точки, выбранной этой мерой (V325): земля ближе ста метров
        // занимает 33-90% кадра, среднего плана и дали почти нет. До горизонта
        // по восьми направлениям: 3935, 20, 20, 20, 50, 1760, 6000, 6000 —
        // в трёх направлениях гора начинается в ДВАДЦАТИ метрах.
        //
        // Игрок стоял на склоне лицом в гору. У художников крупнейшее пятно
        // 27-32% кадра, у нас выходило 64%: земля под ногами и небо, больше
        // ничего.
        if (nearRays > Rays * 0.45f) return false;
        int layers = 0;
        foreach (var b in layerSeen) if (b) layers++;
        return layers >= 4;
    }
}
