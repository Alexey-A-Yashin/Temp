using System;
using ColoringBook.Domain.Level;
using ColoringBook.Domain.Level.Route;

namespace ColoringBook.Infrastructure.Generation.Routes;

/// <summary>
/// ЦЕНА ОДНОГО ШАГА МАРШРУТА.
///
/// Отрицательная цена означает, что шаг запрещён. Всё остальное — стоимость в
/// «метрах пути»: длина, умноженная на нежелание там ехать.
///
/// ---- ТРИ ВЕЩИ, БЕЗ КОТОРЫХ ЭТО НЕ РАБОТАЕТ ----
///
/// 1. УКЛОН МЕРЯЕТСЯ ВДОЛЬ ШАГА, А НЕ ПО ВЕЛИЧИНЕ ГРАДИЕНТА. Первая редакция
///    запрещала шаг, если место круче предела, — и запрещала ровно траверсы,
///    ради которых заводились маски: серпантин идёт поперёк крутого склона с
///    почти нулевым уклоном по ходу движения. Симптом был красноречивый: сеть
///    падала с 552 до 141 км, а нарушения оставались на месте.
///
/// 2. УКЛОН БЕРЁТСЯ ПО СЕТКЕ ПРАВДЫ (30 м), а не по сетке поиска (90 м).
///    Крупная ячейка занижает уклон, и трасса выходит непроезжей на настоящем
///    рельефе: было 12.8% пути в гору и 9.0% под гору круче предела, стало 0.0%.
///
/// 3. ТРАССА ВРЕЗАЕТСЯ В СКЛОН (Galin и др., 2010). Настоящая тропа не обходит
///    бугор, а срезает его. Нить между концами шага — прямая; рельеф вдоль неё
///    выравнивается. Срезка входит в стоимость, поэтому готовая полка всегда
///    предпочитается рукотворной, но при нужде трасса прорежет полку сама.
/// </summary>
public sealed class RouteCost
{
    private readonly RouteField _f;
    private readonly RouteKind _kind;

    /// <summary>Предел срезки, метры. Глубже трасса не врезается — шаг запрещён.</summary>
    public float CutMaxM { get; init; } = 10f;

    /// <summary>Во сколько метров пути обходится метр средней срезки.</summary>
    public float CutCost { get; init; } = 120f;

    /// <summary>Затяжной подъём для велосипеда, градусы: круче — дороже.</summary>
    public float BikeUpEasy { get; init; } = 12f;

    /// <summary>Предел подъёма короткими участками, градусы.</summary>
    public float BikeUpMax { get; init; } = 20f;

    /// <summary>Предел спуска, градусы.</summary>
    public float BikeDownMax { get; init; } = 30f;

    /// <summary>Предел «ровного» для реки, градусы. Круче — уже подъём, а вода
    /// вверх не течёт. Ходьбы по берегу в игре нет, поэтому подъём не разрешается
    /// вовсе; при пределе 3° главный кусок сети теряет 2.5 км из 42.5, а подъёмы
    /// исчезают: десятый процентиль уклона поднимается с −2.73% до −0.08%.</summary>
    public float RiverUpMax { get; init; } = 3f;

    /// <summary>Предел спуска для реки, градусы.</summary>
    public float RiverDownMax { get; init; } = 20f;

    /// <summary>Во сколько раз дороже идти ВНЕ своей полосы.</summary>
    public float OffBandBike { get; init; } = 2.5f;

    /// <summary>У реки цена выхода со дна выше: уводить дорогу со дна долины
    /// незачем. При велосипедной цене по дну шло лишь 11% маршрута.</summary>
    public float OffBandRiver { get; init; } = 12f;

    public RouteCost(RouteField field, RouteKind kind) { _f = field; _kind = kind; }

    /// <summary>Принадлежит ли клетка полосе своего вида маршрута.</summary>
    public bool InBand(int k)
    {
        float frac = _f.Frac(k), slope = _f.SlopeDeg(k);
        return _kind == RouteKind.River
            ? frac <= RiverTop && slope <= 15f
            : frac >= ShrubFloor && frac <= SnowFloor && slope <= ScreeSlope;
    }

    /// <summary>Голый камень: там маршрута не будет ни при каких условиях.</summary>
    public bool Impassable(int k)
        => _kind != RouteKind.River && (_f.Frac(k) > SnowFloor || _f.SlopeDeg(k) > ScreeSlope);

    // ---- ПОРОГИ БЕРУТСЯ ИЗ ДОМЕНА ----
    //
    // Здесь стояли СВОИ копии: 0.44 / 0.63 / 38. Пока покров пересняли под речной
    // рельеф (0.631 / 0.772), эти остались прежними, и прокладка искала «средний
    // уровень гор» там, где его уже нет — пояс сместился, а планировщик не знал.
    private const float ShrubFloor = CoverBelts.ShrubFloor;
    private const float SnowFloor = CoverBelts.SnowFloor;
    private const float ScreeSlope = CoverBelts.ScreeSlopeDeg;

    /// <summary>Верх «дна долины». Первая редакция требовала ещё и стока выше
    /// порога — но это нитка самого водотока, а дорога идёт низом: по такой полосе
    /// шло 2% маршрута вместо почти всего.</summary>
    private const float RiverTop = 0.30f;

    /// <summary>Цена шага из клетки a в клетку b. Отрицательная — шаг запрещён.</summary>
    public double Step(int a, int b, bool preferBand)
    {
        if (Impassable(b)) return -1;

        int side = _f.Side;
        int ax = a % side, ay = a / side, bx = b % side, by = b / side;
        int dx = bx - ax, dy = by - ay;
        int steps = Math.Max(Math.Abs(dx), Math.Abs(dy));
        double dist = Math.Sqrt((double)dx * dx + (double)dy * dy) * RouteField.SearchCellM;

        // Шаг маски длинный: проверяем ПО ВСЕЙ ДЛИНЕ, иначе путь перепрыгнет
        // промоину, увидев только её берега.
        for (int t = 1; t < steps; t++)
        {
            double f = (double)t / steps;
            int ix = (int)Math.Round(ax + dx * f), iy = (int)Math.Round(ay + dy * f);
            if (Impassable(iy * side + ix)) return -1;
        }

        float axw = _f.WorldXOf(a), ayw = _f.WorldYOf(a);
        float bxw = _f.WorldXOf(b), byw = _f.WorldYOf(b);
        float h0 = _f.FineAt(axw, ayw), h1 = _f.FineAt(bxw, byw);
        double dz = (h1 - h0) * 10;
        double deg = Math.Atan(Math.Abs(dz) / dist) * 180 / Math.PI;

        if (_kind == RouteKind.River)
        {
            if (dz > 0 && deg > RiverUpMax) return -1;
            if (dz < 0 && deg > RiverDownMax) return -1;
        }
        else if (dz > 0 ? deg > BikeUpMax : deg > BikeDownMax) return -1;

        // Срезка под ровную нить между концами шага.
        int fine = Math.Max(1, (int)(dist / RouteField.FineCellM));
        float cutMax = 0, cutSum = 0;
        for (int t = 0; t <= fine; t++)
        {
            float f = (float)t / fine;
            float px = axw + (bxw - axw) * f, py = ayw + (byw - ayw) * f;
            float line = h0 + (h1 - h0) * f;
            float cut = MathF.Abs(_f.FineAt(px, py) - line) * 10;
            if (cut > cutMax) cutMax = cut;
            cutSum += cut;
        }
        if (cutMax > CutMaxM) return -1;

        double w = 1;
        if (_kind == RouteKind.Bike && dz > 0 && deg > BikeUpEasy)
            w += (deg - BikeUpEasy) * 0.15;
        if (preferBand && !InBand(b))
            w += _kind == RouteKind.River ? OffBandRiver : OffBandBike;
        w += cutSum / (fine + 1) * CutCost / Math.Max(dist, 1e-6);
        return dist * w;
    }
}
