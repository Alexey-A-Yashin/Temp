using System;
using System.Collections.Generic;

namespace ColoringBook.Infrastructure.Generation.Routes;

/// <summary>
/// ПОИСК ПУТИ МЕЖДУ ДВУМЯ ОПОРАМИ.
///
/// A* с оценкой в виде прямого расстояния. Оценка допустима: наша стоимость это
/// длина, умноженная на вес не меньше единицы, значит прямая длина никогда не
/// завышает (Galin и др., 2010).
///
/// ---- ПРЕДЕЛ ПОИСКА ----
///
/// Когда пути нет, A* без предела обходит всю область. Замер: 17 перегонов по
/// долине обходились в 29 секунд. Но путь вчетверо длиннее прямой нам и не нужен,
/// его отбрасывает приёмка. Поэтому поиск обрывается, как только оценка превысила
/// бюджет, и отказ становится таким же быстрым, как успех: рёбра стали строиться
/// за 851 мс вместо 4705.
/// </summary>
public sealed class RoutePathfinder
{
    private readonly RouteField _f;
    private readonly RouteCost _cost;
    private readonly (int dx, int dy)[] _mask;

    public RoutePathfinder(RouteField field, RouteCost cost, (int dx, int dy)[] mask)
    {
        _f = field; _cost = cost; _mask = mask;
    }

    /// <summary>Во сколько раз путь может быть длиннее прямой, прежде чем его
    /// перестанут искать и примут за отсутствующий.</summary>
    public double DetourLimit { get; init; } = 4.0;

    /// <summary>Ищет путь. Пустой список — пути нет в пределах бюджета.</summary>
    public List<int> Find(int from, int to, bool preferBand, out double cost)
    {
        int side = _f.Side;
        cost = double.MaxValue;

        double straight = Distance(from, to);
        double budget = straight * DetourLimit;

        var g = new Dictionary<int, double> { { from, 0 } };
        var prev = new Dictionary<int, int>();
        var closed = new HashSet<int>();
        var queue = new PriorityQueue<int, double>();
        queue.Enqueue(from, straight);

        while (queue.TryDequeue(out int c, out double f))
        {
            if (f > budget) break;
            if (!closed.Add(c)) continue;
            if (c == to) { cost = g[c]; break; }

            double gc = g[c];
            int i = c % side, j = c / side;
            foreach (var (dx, dy) in _mask)
            {
                int x = i + dx, y = j + dy;
                if (x < 1 || y < 1 || x >= side - 1 || y >= side - 1) continue;
                int nb = y * side + x;
                if (closed.Contains(nb)) continue;
                double w = _cost.Step(c, nb, preferBand);
                if (w < 0) continue;
                double ng = gc + w;
                if (g.TryGetValue(nb, out double old) && old <= ng + 1e-9) continue;
                g[nb] = ng; prev[nb] = c;
                queue.Enqueue(nb, ng + Distance(nb, to));
            }
        }

        var path = new List<int>();
        if (cost == double.MaxValue) return path;
        for (int c = to; ;)
        {
            path.Add(c);
            if (c == from) break;
            if (!prev.TryGetValue(c, out c)) return new List<int>();
        }
        path.Reverse();
        return path;
    }

    private double Distance(int a, int b)
    {
        int side = _f.Side;
        double dx = (a % side - b % side) * (double)RouteField.SearchCellM;
        double dy = (a / side - b / side) * (double)RouteField.SearchCellM;
        return Math.Sqrt(dx * dx + dy * dy);
    }

    /// <summary>Длина готового пути по поверхности, метры.</summary>
    public float Length(IReadOnlyList<int> path)
    {
        int side = _f.Side;
        double total = 0;
        for (int k = 1; k < path.Count; k++)
        {
            int a = path[k - 1], b = path[k];
            double dx = (a % side - b % side) * (double)RouteField.SearchCellM;
            double dy = (a / side - b / side) * (double)RouteField.SearchCellM;
            double dz = (_f.Height(a) - _f.Height(b)) * 10;
            total += Math.Sqrt(dx * dx + dy * dy + dz * dz);
        }
        return (float)total;
    }
}
