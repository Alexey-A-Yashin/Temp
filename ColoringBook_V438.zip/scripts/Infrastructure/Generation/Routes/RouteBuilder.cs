using System;
using System.Collections.Generic;
using ColoringBook.Domain.Level.Route;

namespace ColoringBook.Infrastructure.Generation.Routes;

/// <summary>
/// СБОРКА СЕТИ МАРШРУТОВ ОДНОЙ ТЕРРИТОРИИ.
///
/// Порядок: опоры от местности -> перевалы -> рёбра поиском пути -> перегоны по
/// долине для распавшихся кусков -> обрезка тупиков.
///
/// ---- ЧЕГО ЗДЕСЬ НАРОЧНО НЕТ ----
///
/// Нет ХОДОКА по локальным правилам. Правило «перевалить, если с той стороны есть
/// продолжение» нелокально, и ходок его знать не может: две написанные редакции
/// либо скатывались в долину и вставали, либо наматывали круги на месте. Граф и
/// поиск дешевейшего пути решают это сами — тупик в маршрут просто не попадает.
///
/// Нет ФИЛЬТРА ПО ВЗАИМНОЙ ДОСТИЖИМОСТИ при выборе опор. Достижимость — свойство
/// глобальное: клетка может быть в связной области большого окна и выпасть из неё
/// в меньшем. С таким фильтром опоры расходились при сдвиге окна (совпадало 31 из
/// 36), без него совпадают полностью. Недостижимые опоры отсеются сами: к ним
/// просто не найдётся рёбер, и обрезка тупиков их уберёт.
///
/// Нет ПОГОНИ ЗА СВЯЗНОСТЬЮ. Не все горы должны быть проезжими; места без троп —
/// это то, на что смотрят с трассы. Значение имеет не число кусков, а длина
/// трассы в том куске, где стоит игрок: при медианной сессии 1.2 км кусок в 80 км
/// это семьдесят сидений на одной территории.
/// </summary>
public sealed class RouteBuilder
{
    private readonly RouteField _field;
    private readonly RouteCost _cost;
    private readonly RoutePathfinder _finder;
    private readonly RouteKind _kind;

    /// <summary>Шаг решётки опор, метры. Задаёт, как часто игрок упирается в выбор.
    /// Медианная мобильная сессия 5-6 минут, при скорости около 3.4 м/с это 1.2 км,
    /// и развилка должна приходиться примерно на неё: реже — игрок не узнает, что
    /// выбор вообще есть; чаще — постоянный выбор ломает состояние потока.
    /// Замер: решётка 1200 м даёт медиану перегона между развилками 1.4 км.</summary>
    public float HubLatticeM { get; init; } = 1200f;

    /// <summary>Наименьшее расстояние между опорами, метры. Решётка не спасает от
    /// того, что две опоры садятся вплотную по разные стороны границы клетки: на
    /// всех шагах решётки десятая часть перегонов выходила короче 300 м.</summary>
    public float HubMinDistM { get; init; } = 500f;

    /// <summary>Решётка перевалов относительно решётки опор. Вдвое мельче давало
    /// 359 перевалов против 87 опор склона — сеть превращалась в частую сетку,
    /// а перевал должен быть событием.</summary>
    public float PassLatticeMul { get; init; } = 2f;

    /// <summary>К скольким ближайшим опорам тянуть ребро.</summary>
    public int Neighbours { get; init; } = 3;

    /// <summary>Сколько попыток связать кусок сети перегоном по долине на опору.
    /// Без предела перебор всех пар обходился в 29 секунд при 27 найденных
    /// перегонах; с пределом — полторы секунды при 21 найденном.</summary>
    public int ValleyTries { get; init; } = 3;

    public RouteBuilder(RouteField field, RouteKind kind, (int dx, int dy)[] mask)
    {
        _field = field; _kind = kind;
        _cost = new RouteCost(field, kind);
        _finder = new RoutePathfinder(field, _cost, mask);
    }

    /// <summary>Промежуточные счётчики — для сверки с прототипом. Ставится извне.</summary>
    public Action<string, int>? Trace { get; set; }

    public RouteNetwork Build()
    {
        int side = _field.Side;
        int bandCells = 0;
        for (int k = 0; k < side * side; k++) if (_cost.InBand(k)) bandCells++;
        Trace?.Invoke("клеток полосы", bandCells);

        var thickness = Thickness();
        int thickCells = 0;
        foreach (int t in thickness) if (t > 10) thickCells++;
        Trace?.Invoke("клеток с толщиной больше 10", thickCells);

        var hubs = PickHubs(thickness);
        Trace?.Invoke("опор по решётке", hubs.Count);
        int slopeHubs = hubs.Count;
        if (_kind != RouteKind.River)
        {
            var passes = PickPasses(hubs);
            Trace?.Invoke("перевалов по решётке", passes.Count);
            // Перевалам вид считается тем же прибором: иначе половина опор сети
            // осталась бы без оценки, и выбор старта снова считал бы её сам.
            foreach (int k in passes)
                _hubView[k] = (float)ViewScore.At(ViewHeight, _field.WorldXOf(k), _field.WorldYOf(k));
            hubs.AddRange(passes);
        }
        hubs = ApplyMinDistance(hubs, thickness, slopeHubs, out slopeHubs);
        Trace?.Invoke("опор после отсева по расстоянию", hubs.Count);

        var edges = new List<RouteEdge>();
        var used = new HashSet<(int, int)>();
        for (int a = 0; a < hubs.Count; a++)
        {
            foreach (int b in NearestHubs(hubs, a, Neighbours))
            {
                var key = (Math.Min(a, b), Math.Max(a, b));
                if (!used.Add(key)) continue;
                var path = _finder.Find(hubs[a], hubs[b], true, out _);
                if (path.Count == 0) { used.Remove(key); continue; }
                edges.Add(MakeEdge(a, b, path));
            }
        }

        ConnectPieces(hubs, edges, used);

        var result = new List<RouteHub>(hubs.Count);
        for (int k = 0; k < hubs.Count; k++)
            result.Add(new RouteHub(_field.OriginCellX + hubs[k] % side,
                                    _field.OriginCellY + hubs[k] / side,
                                    k < slopeHubs ? RouteHubKind.Slope : RouteHubKind.Pass,
                                    _hubView.TryGetValue(hubs[k], out float v) ? v : 0f));
        return new RouteNetwork(_kind, result, edges);
    }

    // ---- ОПОРЫ ----

    /// <summary>Толщина полосы в окне 11x11: где склон широк, там по нему и есть
    /// чем ехать.</summary>
    private int[] Thickness()
    {
        int side = _field.Side;
        var thick = new int[side * side];
        for (int j = 6; j < side - 6; j++)
        for (int i = 6; i < side - 6; i++)
        {
            int k = j * side + i;
            if (_cost.Impassable(k) || !_cost.InBand(k)) continue;
            int c = 0;
            for (int b = -5; b <= 5; b++)
            for (int a = -5; a <= 5; a++)
            {
                int m = (j + b) * side + (i + a);
                if (!_cost.Impassable(m) && _cost.InBand(m)) c++;
            }
            thick[k] = c;
        }
        return thick;
    }

    /// <summary>
    /// По одной опоре на клетку решётки, привязанной к МИРУ.
    ///
    /// Жадный выбор по толщине кучковал опоры там, где склон широк, и сеть садилась
    /// в один угол: размах падал до 40-49% квадратов против 62% при раздаче по
    /// решётке. Гора по-прежнему диктует, но диктует в каждом углу.
    /// </summary>
    /// <summary>
    /// ---- V315: ОПОРА ВЫБИРАЕТСЯ ПО ВИДУ, А НЕ ТОЛЬКО ПО ТОЛЩИНЕ ПОЛОСЫ ----
    ///
    /// Прежде на клетку решётки бралась одна точка — самая толстая по полосе.
    /// Толщина отвечает на вопрос «есть ли тут чем ехать», и это верно, но игра
    /// не про езду: прогулки продают раскраску, и опора должна стоять там,
    /// ОТКУДА ОТКРЫВАЕТСЯ ВИД.
    ///
    /// Прогон V314 показал, чем это оборачивается: старт встал на голом плече в
    /// редколесье, кадры дали пятен 2-4 при коридоре 7-15 и крупнейшее пятно
    /// 61-64% при коридоре 15-35. Проезжаемо — да; смотреть не на что.
    ///
    /// Записано в плане 9.2: `ViewScore` переезжает в построитель маршрутов.
    ///
    /// ---- КАК ИМЕННО ----
    ///
    /// Оценка вида дорогая: восемь направлений по 48 лучей. Считать её для
    /// каждой клетки полосы нельзя — их десятки тысяч.
    ///
    /// Поэтому отбор в два этапа, тем же приёмом, что и выбор точки старта:
    /// сперва отбираются кандидаты по толщине (дёшево, чистая арифметика), затем
    /// у нескольких лучших считается вид, и берётся лучший по нему.
    ///
    /// Кандидатов на клетку — <see cref="ViewCandidates"/>. При решётке 1200 м и
    /// ячейке 90 м в клетке 178 узлов; брать больше пяти значит платить за вид
    /// там, где полоса уже тонка.
    ///
    /// Среди РАВНЫХ по виду берётся более толстый: вид отвечает, стоит ли тут
    /// стоять, толщина — можно ли отсюда уехать.
    /// </summary>
    /// <summary>Лес ли в мировой точке. Ставится снаружи: построитель маршрутов
    /// о поясах покрова не знает и знать не должен.</summary>
    public static Func<float, float, bool>? IsForestAt;

    /// <summary>Насколько лесная опора предпочтительнее при равном виде.
    /// Величина того же порядка, что разброс вида между кандидатами.</summary>
    public const double ForestPreference = 0.25;

    private List<int> PickHubs(int[] thick)
    {
        int side = _field.Side;
        int lattice = Math.Max(1, (int)(HubLatticeM / RouteField.SearchCellM));

        // Первый этап: несколько лучших по толщине на клетку решётки.
        var pool = new Dictionary<(int, int), List<int>>();
        for (int k = 0; k < thick.Length; k++)
        {
            if (thick[k] <= 10) continue;
            var cell = (FloorDiv(_field.OriginCellX + k % side, lattice),
                        FloorDiv(_field.OriginCellY + k / side, lattice));
            if (!pool.TryGetValue(cell, out var list)) { list = new List<int>(); pool[cell] = list; }
            list.Add(k);
        }

        var best = new Dictionary<(int, int), int>();
        int scored = 0;
        foreach (var (cell, list) in pool)
        {
            // Сортировка по толщине, затем по тому же правилу, что и прежде:
            // `Better` держит устойчивость выбора при сдвиге окна.
            list.Sort((a, b) => Better(thick[a], a, thick[b], b) ? -1 : 1);
            int take = Math.Min(ViewCandidatesOverride > 0 ? ViewCandidatesOverride : ViewCandidates, list.Count);

            int pick = list[0];
            double pickView = -1;
            for (int t = 0; t < take; t++)
            {
                // Равномерно по клетке — значит с шагом по всему списку, а не
                // первые несколько подряд: первые все лежат на одном плече.
                int k = SpreadCandidates
                    ? list[(int)((long)t * list.Count / take)]
                    : list[t];
                float wx = _field.WorldXOf(k), wz = _field.WorldYOf(k);
                double view = ViewScore.At(ViewHeight, wx, wz);

                // ---- ЛЕСНАЯ ОПОРА ПРЕДПОЧТИТЕЛЬНЕЕ ПРИ РАВНОМ ВИДЕ ----
                //
                // Опоры отбираются по ТОЛЩИНЕ проходимой полосы, а толще всего
                // она там, где склон переходит в плато — то есть ВЫШЕ ЛЕСА.
                // Вид считался уже среди отобранных, и лесных среди них не было.
                //
                // Замер: вид у лесных точек даже ЛУЧШЕ (67% против 63% выше
                // границы леса), то есть лес ничего не отнимает. Но в кандидаты
                // он не попадал по построению.
                //
                // Надбавка в конечном выборе старта (FarBackground.ForestBonus)
                // не помогала: к тому времени лесных опор в сети уже нет.
                //
                // Зачем лес: без него в кадре нет вертикалей — самого тёмного из
                // четырёх тонов по Carlson. Замер V328: пятен 2 при живописных
                // 4-13, крупнейшее 66% при 27-32%.
                if (IsForestAt != null && IsForestAt(wx, wz)) view += ForestPreference;

                scored++;
                if (view > pickView + 1e-6) { pickView = view; pick = k; }
            }
            best[cell] = pick;
            _hubView[pick] = (float)Math.Max(pickView, 0);
        }
        Trace?.Invoke("оценок вида", scored);

        var res = new List<int>(best.Values);
        res.Sort();
        return res;
    }

    /// <summary>Сколько лучших по толщине точек в клетке решётки оценивать видом.
    /// Пять: при решётке 1200 м и ячейке 90 м в клетке 178 узлов, и брать больше
    /// значит платить за вид там, где полоса уже тонка.</summary>
    private const int ViewCandidates = 5;

    /// <summary>Оценка вида на опору, по индексу клетки. Заполняется при отборе
    /// и уезжает в `RouteHub.View`: пересчитывать её другим рельефом нельзя.</summary>
    private readonly Dictionary<int, float> _hubView = new();

    /// <summary>Подмена числа кандидатов для замера на стенде. В игре не
    /// задаётся: величина подобрана и живёт в одном месте.</summary>
    public int ViewCandidatesOverride { get; init; } = 0;

    /// <summary>
    /// ---- V318: КАНДИДАТЫ БЕРУТСЯ РАВНОМЕРНО ПО КЛЕТКЕ ----
    ///
    /// Пять самых толстых точек клетки лежат на одном плече: толщина полосы —
    /// это её ширина, а широка она там, где склон переходит в плато. То есть
    /// отбор ПО ПОСТРОЕНИЮ ставил игрока на плоскогорье.
    ///
    /// Замер захода 33 это и показал: силуэт над горизонтом с точки старта 2.0°
    /// при 10-30° в горах из долины, а в четырёх направлениях из восьми он ВНИЖЕ
    /// горизонта — земля падает на 268-922 м, и видны макушки, а не склоны.
    ///
    /// Замер выбора (сид 42, окно 20 км):
    ///
    ///     кандидаты        опор  рёбер  сеть км  вид сред  силуэт
    ///     5 по толщине      165    293    402.0     0.235    2.0°
    ///     5 равномерно      183    320    418.6     0.283    4.5°   ВЗЯТО
    ///     12 равномерно     176    309    405.1     0.327    2.8°
    ///
    /// Силуэт вдвое выше, средний вид с опоры тоже лучше, сеть не пострадала.
    ///
    /// Двенадцать кандидатов дают вид ещё выше, а силуэт — хуже: оценка вида не
    /// знает про силуэт и, получив больше выбора, уводит на открытые места.
    /// Взято пять.
    ///
    /// Поле оставлено переключаемым: величина подобрана замером, и стенд должен
    /// уметь повторить сравнение, не пересобирая проект.
    /// </summary>
    public static bool SpreadCandidates = true;

    /// <summary>Высота для оценки вида — с СЕТКИ ПРАВДЫ, то есть с той, по
    /// которой игрок реально едет. Брать с сетки поиска (90 м) значило бы
    /// оценивать вид по рельефу, которого игрок не увидит.</summary>
    private float ViewHeight(float worldX, float worldY) => _field.FineAt(worldX, worldY);

    /// <summary>
    /// Седловины: точки, вокруг которых более высокие соседи образуют ДВА и более
    /// отдельных участка кольца — с двух сторон гора, с двух других спуск в разные
    /// долины. Это и есть место, где хребет можно перевалить.
    ///
    /// Сравнение огрублено до сантиметра: высоты, посчитанные разными окнами,
    /// побитово не равны, и строгое «сосед выше» переворачивалось от шума.
    /// </summary>
    private List<int> PickPasses(List<int> existing)
    {
        int side = _field.Side;
        const float eps = 0.001f;                       // мировых единиц = 1 см
        var ring = new (int dx, int dy)[]
            { (1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1) };

        int lattice = Math.Max(1,
            (int)(HubLatticeM * PassLatticeMul / RouteField.SearchCellM));
        var best = new Dictionary<(int, int), int>();
        for (int j = 2; j < side - 2; j++)
        for (int i = 2; i < side - 2; i++)
        {
            int k = j * side + i;
            if (_cost.Impassable(k)) continue;
            float frac = _field.Frac(k);
            if (frac < 0.36f || frac > 0.63f) continue;
            bool[] higher = new bool[8];
            for (int t = 0; t < 8; t++)
                higher[t] = _field.Height((j + ring[t].dy) * side + i + ring[t].dx)
                          > _field.Height(k) + eps;
            int runs = 0;
            for (int t = 0; t < 8; t++) if (higher[t] && !higher[(t + 7) % 8]) runs++;
            if (runs < 2) continue;

            var cell = (FloorDiv(_field.OriginCellX + i, lattice),
                        FloorDiv(_field.OriginCellY + j, lattice));
            if (!best.TryGetValue(cell, out int cur)) { best[cell] = k; continue; }
            // ниже — ценнее: низкая перемычка проезжается легче
            int cmp = Quant(_field.Frac(cur)).CompareTo(Quant(_field.Frac(k)));
            if (cmp == 0) cmp = WorldKey(cur).CompareTo(WorldKey(k));
            if (cmp > 0) best[cell] = k;
        }
        var list = new List<int>(best.Values);
        list.Sort();
        return list;

        static int Quant(float v) => (int)(v * 10000);
    }

    /// <summary>Опора остаётся, если рядом нет никого старше. Правило МЕСТНОЕ,
    /// а не жадный обход: порядок обхода зависел бы от окна.</summary>
    private List<int> ApplyMinDistance(List<int> hubs, int[] thick, int slopeCount,
                                       out int newSlopeCount)
    {
        int side = _field.Side;
        float dmin = HubMinDistM / RouteField.SearchCellM;
        var keep = new List<int>();
        newSlopeCount = 0;
        for (int a = 0; a < hubs.Count; a++)
        {
            int k = hubs[a];
            bool ok = true;
            for (int b = 0; b < hubs.Count && ok; b++)
            {
                if (a == b) continue;
                int q = hubs[b];
                double dx = k % side - q % side, dy = k / side - q / side;
                if (dx * dx + dy * dy >= dmin * dmin) continue;
                if (Better(thick[q], q, thick[k], k)) ok = false;
            }
            if (!ok) continue;
            keep.Add(k);
            if (a < slopeCount) newSlopeCount++;
        }
        return keep;
    }

    // ---- РЁБРА ----

    private IEnumerable<int> NearestHubs(List<int> hubs, int a, int count)
    {
        int side = _field.Side;
        var order = new List<int>();
        for (int b = 0; b < hubs.Count; b++) if (b != a) order.Add(b);
        order.Sort((x, y) =>
        {
            long dx1 = hubs[x] % side - hubs[a] % side, dy1 = hubs[x] / side - hubs[a] / side;
            long dx2 = hubs[y] % side - hubs[a] % side, dy2 = hubs[y] / side - hubs[a] / side;
            return (dx1 * dx1 + dy1 * dy1).CompareTo(dx2 * dx2 + dy2 * dy2);
        });
        for (int t = 0; t < count && t < order.Count; t++) yield return order[t];
    }

    /// <summary>Куски сети, не связанные по полосе, соединяются низом: спуститься и
    /// ехать долиной до следующей горы. Предпочтения полосы здесь нет.</summary>
    private void ConnectPieces(List<int> hubs, List<RouteEdge> edges, HashSet<(int, int)> used)
    {
        int side = _field.Side;
        var parent = new int[hubs.Count];
        for (int k = 0; k < parent.Length; k++) parent[k] = k;
        int Find(int x) { while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; }
        foreach (var e in edges) { int a = Find(e.FromHub), b = Find(e.ToHub); if (a != b) parent[a] = b; }

        var candidates = new List<(double d, int a, int b)>();
        for (int a = 0; a < hubs.Count; a++)
        for (int b = a + 1; b < hubs.Count; b++)
        {
            if (Find(a) == Find(b)) continue;
            double dx = hubs[a] % side - hubs[b] % side, dy = hubs[a] / side - hubs[b] / side;
            double d = Math.Sqrt(dx * dx + dy * dy) * RouteField.SearchCellM;
            if (d > 6000) continue;
            candidates.Add((d, a, b));
        }
        candidates.Sort((x, y) => x.d.CompareTo(y.d));

        var tries = new int[hubs.Count];
        foreach (var (d, a, b) in candidates)
        {
            if (Find(a) == Find(b)) continue;
            if (tries[a] >= ValleyTries || tries[b] >= ValleyTries) continue;
            tries[a]++; tries[b]++;
            var path = _finder.Find(hubs[a], hubs[b], false, out _);
            if (path.Count == 0) continue;
            parent[Find(a)] = Find(b);
            used.Add((Math.Min(a, b), Math.Max(a, b)));
            edges.Add(MakeEdge(a, b, path));
        }
    }


    private RouteEdge MakeEdge(int a, int b, List<int> path)
    {
        int side = _field.Side;
        var pts = new List<(int, int)>(path.Count);
        foreach (int k in path)
            pts.Add((_field.OriginCellX + k % side, _field.OriginCellY + k / side));
        return new RouteEdge(a, b, pts, _finder.Length(path));
    }

    // ---- МЕЛОЧИ, ОТ КОТОРЫХ ЗАВИСИТ ВОСПРОИЗВОДИМОСТЬ ----

    /// <summary>Старшинство: сперва толщина полосы, при равенстве — мировые
    /// координаты. Без второго порядок обхода решал бы ничьи, а он зависит от
    /// окна.</summary>
    private bool Better(int thickA, int a, int thickB, int b)
    {
        if (thickA != thickB) return thickA > thickB;
        return WorldKey(a) < WorldKey(b);
    }

    private long WorldKey(int k)
    {
        int side = _field.Side;
        return (long)(_field.OriginCellY + k / side) * 1000000
             + (_field.OriginCellX + k % side);
    }

    /// <summary>Деление ЦЕЛОЕ ВНИЗ. При обычном делении в C# -10/33 и 10/33 дают
    /// ноль, и клетка решётки вокруг начала координат выходит вдвое шире.</summary>
    private static int FloorDiv(int a, int b) => a >= 0 ? a / b : -(((-a) + b - 1) / b);
}
