using System;
using Godot;

namespace ColoringBook.Application;

/// <summary>
/// МАРШРУТИЗАТОР СЦЕН.
///
/// Единственное место, знающее, какая сцена сейчас активна и как между ними
/// переключаться. Раньше режим уровня и витрина растений переключались прямо внутри
/// GameBootstrap флагом — пока сцен было две, это работало, но с появлением стартового
/// экрана, галереи и раскраски такой подход превратился бы в тот самый «божественный
/// метод», о котором предупреждает книга (5.1.1).
///
/// Слои по книге (4.1.2): маршрутизатор относится к слою представления и НЕ принимает
/// решений по правилам игры. Он умеет ровно одно — показать нужную сцену. Никакой
/// сцене при этом не нужно знать о существовании других: они просят маршрутизатор
/// «покажи галерею», а не создают её сами. Так между сценами нет прямых ссылок,
/// и любую можно открыть первой — в том числе галерею сразу при запуске, минуя уровень.
/// </summary>
public sealed partial class SceneRouter : Node
{
    public enum Screen
    {
        Start = 0,
        Level = 1,
        Gallery = 2,
        Painting = 3,
    }

    /// <summary>Текущий экран. Только для чтения снаружи: менять — через Go*.</summary>
    public Screen Current { get; private set; } = Screen.Start;

    /// <summary>
    /// Факт смены экрана. Именно ФАКТ, а не команда: подписчики узнают, что экран
    /// сменился, и обновляют себя. Книга, 4.1.2: слой правил публикует факт, слой
    /// представления на него реагирует.
    /// </summary>
    public event Action<Screen>? ScreenChanged;

    /// <summary>Какой снимок открыт на раскраске. Пусто вне режима раскраски.</summary>
    public string ActiveSketchId { get; private set; } = "";

    private Node? _startScene;
    private Node? _levelScene;
    private Node? _galleryScene;
    private Node? _paintScene;

    public void Register(Node? start, Node? level, Node? gallery, Node? paint)
    {
        _startScene = start;
        _levelScene = level;
        _galleryScene = gallery;
        _paintScene = paint;
        Apply();
    }

    public void GoStart() => Switch(Screen.Start, "");
    public void GoLevel() => Switch(Screen.Level, "");
    public void GoGallery() => Switch(Screen.Gallery, "");

    /// <summary>Открыть раскраску конкретного снимка.</summary>
    /// <summary>
    /// Запрос на раскраску снимка. Именно ЗАПРОС, а не переход: у снимка может ещё
    /// не быть контуров, и их надо сперва построить. Кто умеет это делать —
    /// подписывается на PaintingRequested и вызывает GoPainting, когда готов.
    /// </summary>
    public event Action<string>? PaintingRequested;

    public void RequestPainting(string sketchId)
    {
        if (string.IsNullOrWhiteSpace(sketchId)) return;
        PaintingRequested?.Invoke(sketchId);
    }

    public void GoPainting(string sketchId)
    {
        if (string.IsNullOrWhiteSpace(sketchId)) return;
        Switch(Screen.Painting, sketchId);
    }

    private void Switch(Screen screen, string sketchId)
    {
        if (Current == screen && ActiveSketchId == sketchId) return;
        Current = screen;
        ActiveSketchId = sketchId;
        Apply();
        ScreenChanged?.Invoke(screen);
    }

    /// <summary>
    /// Показ и скрытие. Сцены не выгружаются, а прячутся: уровень несёт сгенерированные
    /// чанки, и его пересборка при каждом заходе в галерею стоила бы сотни миллисекунд.
    /// </summary>
    private void Apply()
    {
        SetVisible(_startScene, Current == Screen.Start);
        SetVisible(_levelScene, Current == Screen.Level);
        SetVisible(_galleryScene, Current == Screen.Gallery);
        SetVisible(_paintScene, Current == Screen.Painting);
    }

    private static void SetVisible(Node? node, bool visible)
    {
        switch (node)
        {
            case null: return;
            // CanvasLayer ПЕРВЫМ и отдельной веткой: он не наследуется ни от
            // CanvasItem, ни от Node3D. Без этой ветки экраны интерфейса вообще не
            // скрывались — все три висели одновременно, и фон сцены раскраски
            // (добавлена последней, значит поверх) закрывал собой стартовое меню.
            // Снаружи это выглядело как чёрный экран при запуске.
            case CanvasLayer cl: cl.Visible = visible; break;
            case CanvasItem ci: ci.Visible = visible; break;
            case Node3D n3: n3.Visible = visible; break;
        }
        // Обработка ввода отключается вместе с показом, иначе спрятанная сцена
        // продолжала бы ловить клавиши и, например, уровень регенерировался бы
        // по R из галереи.
        node.SetProcessInput(visible);
        node.SetProcessUnhandledInput(visible);
        node.SetProcess(visible);
    }
}
