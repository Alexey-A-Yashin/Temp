using System;
using System.Collections.Generic;
using ColoringBook.Domain.Level;
using ColoringBook.Domain.Level.Season;

namespace ColoringBook.Application;

/// <summary>
/// Application-сервис. Оркестрирует создание/загрузку уровней.
/// </summary>
public sealed class LevelService
{
    private readonly ILevelSaveRepository _repository;

    /// <summary>
    /// Хранение уровней. Генератор больше не принимается: уровень строится из
    /// колец (FarBackground), а старый MapgenLevelGenerator удалён.
    /// </summary>
    public LevelService(ILevelSaveRepository repository)
    {
        _repository = repository ?? throw new ArgumentNullException(nameof(repository));
    }

    // ---- СОЗДАНИЕ И ЗАГРУЗКА УРОВНЯ УБРАНЫ ----
    //
    // Оба метода звали ILevelGenerator.Generate — старый генератор, которого
    // больше нет. Уровень строится из колец: GameBootstrap собирает LevelData
    // сам (BuildLevelDataFromRings), а рельеф делает FarBackground.
    //
    // Служба осталась хранилищем описаний уровней, и это верно: хранение к
    // генерации отношения не имеет.

}
