namespace ColoringBook.Domain.Level;

/// <summary>
/// Точка на карте (seed-точка для Voronoi/Delaunay).
/// </summary>
public readonly struct MapPoint
{
    public float X { get; }
    public float Y { get; }

    public MapPoint(float x, float y)
    {
        X = x;
        Y = y;
    }

    public override string ToString() => $"({X:F1}, {Y:F1})";
}
