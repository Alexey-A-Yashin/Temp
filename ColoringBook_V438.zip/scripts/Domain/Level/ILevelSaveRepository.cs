using System;
using System.Collections.Generic;

namespace ColoringBook.Domain.Level;

/// <summary>
/// Контракт хранилища дескрипторов уровней.
/// Domain не знает, JSON это, SQLite или Godot Resource.
/// </summary>
public interface ILevelSaveRepository
{
    void Save(LevelDescriptor descriptor);
    LevelDescriptor? Load(Guid id);
    IReadOnlyList<LevelDescriptor> LoadAll();
    bool Exists(Guid id);
    void Delete(Guid id);
}
