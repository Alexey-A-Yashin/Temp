using System;
using System.Collections.Generic;
using ColoringBook.Domain.Level.River;
using ColoringBook.Domain.Level.Season;

namespace ColoringBook.Domain.Level;

/// <summary>
/// Результат генерации уровня / чанка реки.
/// </summary>
public sealed class LevelData
{
    public Guid DescriptorId { get; }
    public int Seed { get; }
    public SeasonState SeasonState { get; }

    public IReadOnlyList<MapPoint> Points { get; }
    public IReadOnlyList<RegionData> Regions { get; }
    public int PolygonCount { get; }
    public string DebugInfo { get; }
    public IReadOnlyList<VegetationInstance> Vegetation { get; }

    /// <summary>Индекс чанка вдоль реки; null для legacy одиночной карты.</summary>
    public int? ChunkIndex { get; }

    /// <summary>World seed непрерывной реки; null для legacy.</summary>
    public int? WorldSeed { get; }

    public RiverSeam? InletSeam { get; }
    public RiverSeam? OutletSeam { get; }

    public LevelData(
        Guid descriptorId,
        int seed,
        SeasonState seasonState,
        IReadOnlyList<MapPoint> points,
        IReadOnlyList<RegionData> regions,
        int polygonCount,
        string debugInfo,
        IReadOnlyList<VegetationInstance>? vegetation = null,
        int? chunkIndex = null,
        int? worldSeed = null,
        RiverSeam? inletSeam = null,
        RiverSeam? outletSeam = null)
    {
        DescriptorId = descriptorId;
        Seed = seed;
        SeasonState = seasonState;
        Points = points;
        Regions = regions;
        PolygonCount = polygonCount;
        DebugInfo = debugInfo;
        Vegetation = vegetation ?? Array.Empty<VegetationInstance>();
        ChunkIndex = chunkIndex;
        WorldSeed = worldSeed;
        InletSeam = inletSeam;
        OutletSeam = outletSeam;
    }
}
