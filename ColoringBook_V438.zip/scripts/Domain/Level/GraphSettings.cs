namespace ColoringBook.Domain.Level;

/// <summary>
/// НАСТРОЙКИ ПОСТРОЕНИЯ УЗЛОВ ГРАФА.
///
/// Их получает TerrainGraph и никто более.
/// </summary>
public sealed record GraphNodeSettings
{
    /// <summary>
    /// ДРОЖЬ УЗЛОВ: доля шага, на которую узел смещается от своего места.
    ///
    /// Ноль — строгая сетка, и русла идут решёткой: сток по восьми
    /// направлениям заметен на ровном месте.
    ///
    /// Треть шага снимает решётку, а триангуляции не требует.
    /// </summary>
    public float Jitter { get; init; } = 0.7f;

    /// <summary>
    /// ШАГ СЕТКИ УЗЛОВ, километры.
    ///
    /// Замер: при шаге 1 км узлы занимают 1.4% ячеек поля 961; при 0.25 км —
    /// 22.8%, но время растёт с 703 мс до 9393, а русел не прибавляется.
    ///
    /// Значит подробность русел задаётся НЕ густотой узлов.
    /// </summary>
    public float StepKm { get; init; } = 1f;

    public static readonly GraphNodeSettings Default = new();
}

/// <summary>
/// НАСТРОЙКИ ВРЕЗА по закону мощности потока.
///
/// Их получает GraphErosion и никто более.
/// </summary>
public sealed record GraphIncisionSettings
{
    /// <summary>
    /// ПОКАЗАТЕЛЬ ПЛОЩАДИ в законе мощности потока.
    ///
    /// В равновесии крутизна русла S = (U/K) · A^(-m/n).
    ///
    /// Из источников: при m/n = 0.5 рельеф становится НЕЗАВИСИМЫМ от
    /// горизонтального размера. У нас n = 1, потому m = 0.5.
    /// </summary>
    public float AreaExponent { get; init; } = 0.5f;

    /// <summary>
    /// ЧИСЛО ШАГОВ ЭРОЗИИ.
    ///
    /// У старого устройства их двести: явная схема требует малого шага.
    /// Здесь схема НЕЯВНАЯ, устойчивая при любом шаге, и хватает единиц.
    /// </summary>
    public int Iterations { get; init; } = 12;

    /// <summary>
    /// ШАГ ВРЕМЕНИ. При неявной схеме может быть любым.
    /// </summary>
    public float TimeStep { get; init; } = 1f;

    /// <summary>
    /// ПОКАЗАТЕЛЬ КРУТИЗНЫ при делении стока между соседями.
    ///
    /// Единица — вода делится соразмерно уклону. Больше — сильнее сходится к
    /// наикрутейшему; при бесконечности выходит сток в одного соседа.
    /// </summary>
    public float FlowExponent { get; init; } = 1.1f;

    /// <summary>
    /// ШИРИНА РУСЛА при единичной площади водосбора, километры.
    ///
    /// ---- ЗАЧЕМ ----
    ///
    /// Из источников: зависимость от густоты узлов «уменьшается включением
    /// множителя w/δ в член вреза», где δ — шаг сетки, w — ширина русла.
    ///
    /// И у Пеллетье прямо: мерить надо «площадь на ЕДИНИЦУ ШИРИНЫ потока в
    /// господствующем русле, а не саму площадь».
    ///
    /// ---- ОТЧЕГО ЭТО ВАЖНО ----
    ///
    /// Русло уже шага сетки: при шаге 2 км русло шириной 50 м занимает
    /// сороковую часть ячейки, при шаге 0.5 км — десятую. Вода в узле
    /// «размазана» по-разному, и врез выходит разным.
    ///
    /// Ширина растёт с водосбором: w = WidthKm · A^WidthExponent.
    /// Показатель 0.5 взят из природы — ширина реки соразмерна корню из
    /// водосбора.
    /// </summary>
    public float ChannelWidthKm { get; init; } = 0.02f;

    /// <summary>Показатель роста ширины русла с водосбором.</summary>
    public float WidthExponent { get; init; } = 0.5f;

    public static readonly GraphIncisionSettings Default = new();
}

/// <summary>
/// НАСТРОЙКИ ОСЫПАНИЯ на графе.
///
/// Их получает GraphDiffusion и никто более.
/// </summary>
public sealed record GraphDiffusionSettings
{
    /// <summary>
    /// СКОРОСТЬ ОСЫПАНИЯ.
    ///
    /// ПОДБОР (115 км, 12 шагов):
    ///
    ///     осыпание   врез ниже соседей
    ///        0.35        0.023
    ///        0.08        0.053
    ///        0.02        0.15
    ///        0           0.224
    ///
    /// На сетке осыпание нужно сильное: соседи близко. На графе узлы
    /// вдесятеро дальше, и та же величина сглаживает вдесятеро сильнее —
    /// долины выходят мелкими.
    /// </summary>
    /// ПОДБОР при многосеточности (115 км):
    ///
    ///     осыпание   местный рельеф / размах
    ///       0.02          0.0569
    ///       0.001         0.0828
    ///
    /// Из источников: врез усиливает возмущения, осыпание их гасит; ОБА нужны
    /// для гребней и долин. Но осыпание должно быть много слабее вреза, иначе
    /// оно съедает расчленение.
    public float Rate { get; init; } = 0.001f;

    /// <summary>
    /// ДОЛЯ ПРЕДЕЛА УСТОЙЧИВОСТИ.
    ///
    /// Явная схема расходится, если узел за шаг переходит среднюю высоту
    /// соседей. Шаг ограничивается этой долей от разности.
    /// </summary>
    public float StabilityShare { get; init; } = 0.5f;

    public static readonly GraphDiffusionSettings Default = new();
}

/// <summary>
/// НАСТРОЙКИ ПЕРЕВОДА ГРАФА В ПОЛЕ ВЫСОТ.
///
/// Их получает GraphToField и никто более.
/// </summary>
public sealed record GraphFieldSettings
{
    /// <summary>
    /// ПРОХОДОВ ДИФФУЗИИ.
    ///
    /// Узлы закрепляются, между ними диффузия растягивает высоты плавно.
    /// Мало проходов — видны ступени, много — размывается рисунок русел.
    /// </summary>
    public int DiffusionPasses { get; init; } = 24;

    /// <summary>
    /// СИЛА ЗАОСТРЕНИЯ ГРЕБНЕЙ.
    ///
    /// Ноль — не трогать. Больше — вершины поджимаются, склоны круче.
    ///
    /// Приём из источников: «преобразование по модулю создаёт V-образные
    /// долины». Нужен затем, что в графовом устройстве поднятие гладкое, и
    /// гребни выходят округлыми, а в старом они шли из дерева звеньев.
    /// </summary>
    /// ПОДБОР (115 км, альпийский):
    ///
    ///     сила   круче 15°
    ///      0        16%
    ///      1        25%
    ///      3        27%
    ///
    /// Старое устройство даёт 22%. При единице граф его ДОГОНЯЕТ.
    public float RidgeSharpen { get; init; } = 1f;

    public static readonly GraphFieldSettings Default = new();
}

/// <summary>
/// НАСТРОЙКИ ПРОЧНОСТИ ПОРОДЫ.
///
/// Их получает GraphRockField и никто более.
/// </summary>
public sealed record GraphRockSettings
{
    /// <summary>
    /// РАЗБРОС ПРОЧНОСТИ: во сколько раз прочнейшая порода прочнее слабейшей.
    ///
    /// Единица — порода однородна, и рельеф выходит гладким: замер показал,
    /// что при этом ни врезаемость, ни поднятие, ни осыпание расчленения не
    /// дают.
    ///
    /// Из источников: рельеф «в основном ограничен прочностью».
    /// </summary>
    public float Contrast { get; init; } = 6f;

    /// <summary>Размер пятна одной породы, километры.</summary>
    public float PatchKm { get; init; } = 12f;

    /// <summary>Размер мелкой ряби прочности, километры.</summary>
    public float GrainKm { get; init; } = 2.5f;

    /// <summary>Доля крупных пятен против мелкой ряби.</summary>
    public float PatchWeight { get; init; } = 0.65f;

    /// <summary>
    /// ТОЛЩИНА ПЛАСТА, единицы высоты. Ноль — пластов нет.
    ///
    /// Твёрдый пласт держится уступом, мягкий вымывается: так выходят
    /// ступенчатые склоны столовых гор.
    /// </summary>
    public float LayerHeight { get; init; } = 0f;

    /// <summary>Во сколько раз твёрдый пласт прочнее мягкого.</summary>
    public float LayerContrast { get; init; } = 2f;

    public static readonly GraphRockSettings Default = new();
}

/// <summary>
/// НАСТРОЙКИ МНОГОСЕТОЧНОСТИ.
///
/// ---- ЗАЧЕМ ----
///
/// Из источников: «сведения путешествуют на одну ячейку за итерацию, и для
/// сходимости им надо пройти всю область несколько раз».
///
/// Оттого шагов нужно столько, сколько узлов по стороне: при 115 узлах — сто
/// с лишним шагов.
///
/// Лечение (Брандт, 1977): грубый граф даёт улучшенное начальное приближение
/// для мелкого. «Низкочастотные составляющие ошибки на мелкой сетке
/// становятся высокочастотными на грубых и последовательно гасятся».
///
/// ---- ЗАМЕР ----
///
///     напрямую 200 шагов      9678 мс, рельеф 0.0748
///     многосеточно 40+30+70   3271 мс, рельеф 0.0757
///
/// Втрое быстрее при том же рельефе.
/// </summary>
public sealed record GraphMultigridSettings
{
    /// <summary>
    /// Уровни цепочки: шаг узлов в километрах и число шагов эрозии.
    ///
    /// Идут от грубого к мелкому. Последний задаёт подробность итога.
    /// </summary>
    public (float StepKm, int Iterations)[] Levels { get; init; } =
    [
        (4f, 40),   // крупный рисунок: пояс, главные водоразделы
        (2f, 30),   // средние долины
        (1f, 70),   // подробности: притоки, гребни
    ];

    public static readonly GraphMultigridSettings Default = new();
}

/// <summary>
/// НАСТРОЙКИ РАЗЛОМОВ.
///
/// Их получает GraphFaults и никто более.
/// </summary>
public sealed record GraphFaultSettings
{
    /// <summary>
    /// Один разлом на клетку такого размера, километры.
    /// </summary>
    public float EveryKm { get; init; } = 28f;

    /// <summary>Длина разлома, километры.</summary>
    public float LengthKm { get; init; } = 30f;

    /// <summary>
    /// ШИРИНА ПОЛОСЫ ПОДНЯТИЯ вокруг разлома, километры.
    ///
    /// Замер: при гладком поднятии граф даёт 12% мест круче 15°, при резком —
    /// 21%. Хребты растут ВДОЛЬ ЛИНИЙ, а не в размытой полосе.
    /// </summary>
    public float BandKm { get; init; } = 2.5f;

    /// <summary>Разброс направлений разломов вокруг пояса, радианы.</summary>
    public float AngleSpread { get; init; } = 0.9f;

    /// <summary>
    /// ШИРИНА ПОЯСА как доля стороны области.
    ///
    /// Прежде 0.55 — пояс занимал больше половины уровня, и разломы
    /// покрывали всю площадь однообразной «шерстью».
    ///
    /// Пояс должен быть УЗКИМ, а вне его — платформа. Из источников: деление
    /// первого порядка — континентальные ядра (платформы) и орогенические
    /// зоны.
    /// </summary>
    public float BeltWidth { get; init; } = 0.16f;

    /// <summary>
    /// ИЗГИБ ДУГИ ПОЯСА как доля стороны области.
    ///
    /// Из источников: горные пояса заметно изогнуты — Аппалачи, Скалистые,
    /// Боливийские Анды, Кантабрийская дуга.
    ///
    /// Ноль — прямая полоса, и на большой площади она однообразна.
    /// </summary>
    public float ArcSag { get; init; } = 0.22f;

    public static readonly GraphFaultSettings Default = new();
}



/// <summary>
/// НАСТРОЙКИ ХОЛМОВ И ОЗЕРЕЦ.
///
/// Их получает GraphKnockAndLochan и никто более.
/// </summary>
public sealed record GraphKnockSettings
{
    /// <summary>Размер скального бугра, километры.</summary>
    public float KnollKm { get; init; } = 3.5f;

    /// <summary>Размер мелкой ряби, километры.</summary>
    public float GrainKm { get; init; } = 1.2f;

    /// <summary>
    /// ПОРОГ: ниже него котловина, где стоит вода.
    ///
    /// Больше — больше воды и меньше суши.
    /// </summary>
    public float Threshold { get; init; } = 0.15f;

    /// <summary>Высота бугра.</summary>
    public float KnollHeight { get; init; } = 0.5f;

    /// <summary>Размер области, где поднимается одинокая гора, километры.</summary>
    public float LoneKm { get; init; } = 22f;

    /// <summary>
    /// ПОРОГ ОДИНОКИХ ГОР: чем выше, тем реже они встают.
    ///
    /// Из источников: «одинокие суровые горы» среди низкой земли — Сюилвен,
    /// Куинаг, Стак.
    /// </summary>
    public float LoneThreshold { get; init; } = 0.55f;

    /// <summary>Высота одинокой горы.</summary>
    public float LoneHeight { get; init; } = 1f;

    public static readonly GraphKnockSettings Default = new();
}

/// <summary>
/// НАСТРОЙКИ ИСТОЧНИКА ПОДНЯТИЯ: все виды рельефа в одном месте.
///
/// Их получает GraphUpliftSource и раздаёт по частям.
/// </summary>
public sealed record GraphUpliftSettings
{
    public GraphFaultSettings Faults { get; init; } = GraphFaultSettings.Default;
    public GraphKnockSettings Knock { get; init; } = GraphKnockSettings.Default;
    public GraphVolcanoSettings Volcanoes { get; init; } = GraphVolcanoSettings.Default;

    /// <summary>Врезаемость альпийских: средняя.</summary>
    public float AlpineErodibility { get; init; } = 0.6f;

    /// <summary>
    /// Врезаемость холмов: СЛАБАЯ — их котловины выскребли ледники, а не реки.
    /// </summary>
    public float KnockErodibility { get; init; } = 0.35f;

    /// <summary>
    /// Врезаемость вулканического края: СИЛЬНАЯ.
    ///
    /// Пепел и рыхлая лава размываются быстро — оттого лучевой сток режет
    /// склоны конуса глубокими ложбинами.
    /// </summary>
    public float VolcanicErodibility { get; init; } = 1.2f;

    public static readonly GraphUpliftSettings Default = new();
}

/// <summary>
/// НАСТРОЙКИ ВУЛКАНИЧЕСКОГО КРАЯ.
///
/// Их получает GraphVolcanoes и никто более.
/// </summary>
public sealed record GraphVolcanoSettings
{
    /// <summary>Один конус на клетку такого размера, километры.</summary>
    public float EveryKm { get; init; } = 22f;

    /// <summary>
    /// ПОПЕРЕЧНИК КОНУСА, километры.
    ///
    /// Из источников: слоистые вулканы 15-30 км в поперечнике, щитовые много
    /// больше.
    /// </summary>
    public float RadiusKm { get; init; } = 9f;

    /// <summary>Доля конусов, у которых вершина обрушилась кальдерой.</summary>
    public float CalderaShare { get; init; } = 0.22f;

    /// <summary>
    /// ГЛУБИНА КАЛЬДЕРЫ: доля от высоты края, до которой опускается дно.
    /// </summary>
    public float CalderaDepth { get; init; } = 0.55f;

    /// <summary>Размер валов застывшей лавы, километры.</summary>
    /// Валы застывшей лавы: КРУПНЫЕ, чтобы читались на снимке.
    public float LavaKm { get; init; } = 14f;

    /// <summary>Высота лавового поля.</summary>
    public float LavaHeight { get; init; } = 0.18f;

    /// <summary>Размер россыпи ложных кратеров, километры.</summary>
    public float RootlessKm { get; init; } = 1.6f;

    /// <summary>Порог, выше которого встаёт ложный кратер.</summary>
    public float RootlessThreshold { get; init; } = 0.72f;

    /// <summary>Высота ложного кратера.</summary>
    /// ПОДБОР И ОТКАЗ: ложные кратеры покрывали ВСЁ поле рябью и забивали
    /// конусы — это видно было уже в поднятии, до всякой эрозии.
    ///
    /// Причина: у Мюватна они величиной в десятки метров, а наша ячейка 240 м.
    /// Изобразить их нельзя — выходит рябь, а не кратеры.
    ///
    /// Выключены. Приём написан и оставлен на случай мелкой сетки.
    public float RootlessHeight { get; init; } = 0f;

    public static readonly GraphVolcanoSettings Default = new();
}

/// <summary>
/// НАСТРОЙКИ УКЛАДКИ ВИДОВ РЕЛЬЕФА.
///
/// Их получает GraphKindMap и никто более.
/// </summary>
public sealed record GraphKindMapSettings
{
    /// <summary>
    /// РАЗМЕР ПЯТНА одного вида, километры.
    ///
    /// Мало — виды мельтешат и не читаются; много — на уровень попадает
    /// один-два, и разнообразия нет.
    ///
    /// ---- ПОЧЕМУ 18, А НЕ 45 ----
    ///
    /// Сорок пять подбиралось на уровне 231 км: пятен выходило два десятка.
    /// На нынешнем уровне 57.6 км те же сорок пять давали ОДНО пятно, и
    /// уровень получал один вид рельефа на всю площадь.
    ///
    ///     сторона   SpotKm 45   SpotKm 18
    ///      231 км      26           164
    ///       57.6 км     1            10
    ///
    /// Восемнадцать даёт десяток пятен: каждый вид представлен, и рисунок не
    /// дробится.
    ///
    /// ЧЕСТНАЯ ОГОВОРКА. В природе горная страна много больше 57 километров:
    /// Альпы тянутся на тысячу, Ассинт на полсотни. На уровне такого размера
    /// три вида рядом — условность в пользу разнообразия, а не подражание
    /// природе. Если размер уровня вырастет, величину надо ПЕРЕСЧИТАТЬ, а не
    /// оставлять как есть: это уже случилось однажды.
    /// </summary>
    public float SpotKm { get; init; } = 18f;

    /// <summary>
    /// ШИРИНА ПОЛОСЫ ПЕРЕХОДА между видами, километры.
    ///
    /// Из патента о слиянии данных о высотах: между областями разной высоты
    /// нужна полоса, где значения плавно сводятся. Без неё на стыке уступ, и
    /// вода в нём стоит.
    /// </summary>
    public float BlendKm { get; init; } = 6f;

    /// <summary>Размер искажения границы, километры.</summary>
    public float WarpKm { get; init; } = 18f;

    /// <summary>Насколько граница искажается, километры.</summary>
    public float WarpAmpKm { get; init; } = 7f;

    /// <summary>
    /// ДОЛЯ АЛЬПИЙСКИХ: главный вид, даёт массив рельефа.
    /// </summary>
    public float AlpineWeight { get; init; } = 5f;

    /// <summary>ДОЛЯ ХОЛМОВ И ОЗЕРЕЦ: россыпь с водой.</summary>
    public float KnockWeight { get; init; } = 3f;

    /// <summary>
    /// ДОЛЯ ВУЛКАНИЧЕСКОГО: он даёт РОВНЫЕ лавовые поля между конусами.
    ///
    /// При ровной трети уровень выходил пустым: четверть площади без
    /// рельефа. Доля убавлена.
    /// </summary>
    public float VolcanicWeight { get; init; } = 2f;

    /// <summary>Вес вида.</summary>
    public float WeightOf(Infrastructure.Generation.Mapgen.Graph.GraphTerrainKind kind)
        => kind switch
        {
            Infrastructure.Generation.Mapgen.Graph.GraphTerrainKind.Knock => KnockWeight,
            Infrastructure.Generation.Mapgen.Graph.GraphTerrainKind.Volcanic => VolcanicWeight,
            _ => AlpineWeight,
        };

    /// <summary>Сумма весов.</summary>
    public float TotalWeight => AlpineWeight + KnockWeight + VolcanicWeight;

    public static readonly GraphKindMapSettings Default = new();
}

/// <summary>
/// НАСТРОЙКИ РОСТА ХРЕБТОВ.
///
/// Их получает GraphRidgeGrowth и никто более.
/// </summary>
public sealed record GraphGrowthSettings
{
    /// <summary>
    /// ДОЛЯ УЗЛОВ, которую занимает сеть хребтов. Ноль — роста нет.
    /// </summary>
    public float Share { get; init; } = 0.3f;

    /// <summary>
    /// ВЫСОТА ПРИБАВКИ от роста, в долях основного поднятия.
    /// </summary>
    public float Height { get; init; } = 0.55f;

    /// <summary>
    /// ПОКАЗАТЕЛЬ СИЛЫ ВЕТВИ.
    ///
    /// Сила есть число потомков, приведённое к наибольшему. Малый показатель
    /// поднимает и слабые ветви, большой оставляет один ствол.
    /// </summary>
    public float WeightExponent { get; init; } = 0.28f;

    public static readonly GraphGrowthSettings Default = new();
}

/// <summary>
/// НАСТРОЙКИ КРУПНЫХ ПЕРЕПАДОВ ВЫСОТ.
///
/// ---- ЗАЧЕМ ----
///
/// Уровень вне горного пояса выходит плоским: платформа лежит на одной
/// высоте, и раскрашивать там нечего.
///
/// В природе платформы не плоски: они полого вздымаются и опускаются на
/// сотни метров на десятки километров.
/// </summary>
public sealed record GraphSwellSettings
{
    /// <summary>Размер вздутия, километры.</summary>
    public float SwellKm { get; init; } = 90f;

    /// <summary>Высота вздутия в долях основного поднятия.</summary>
    public float Height { get; init; } = 0.5f;

    /// <summary>Размер средней волны, километры.</summary>
    public float MidKm { get; init; } = 30f;

    /// <summary>Высота средней волны.</summary>
    public float MidHeight { get; init; } = 0.18f;

    /// <summary>
    /// НАСКОЛЬКО ПЕРЕПАДЫ ГАСЯТСЯ В ПОЯСЕ.
    ///
    /// Ноль — прибавляются ровно везде, и дуга пояса теряется. Единица —
    /// в середине пояса перепадов нет вовсе.
    /// </summary>
    public float BeltDamping { get; init; } = 0.9f;

    public static readonly GraphSwellSettings Default = new();
}
