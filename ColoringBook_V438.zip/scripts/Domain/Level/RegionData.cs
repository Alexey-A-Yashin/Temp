using System.Collections.Generic;

namespace ColoringBook.Domain.Level;

public sealed class RegionData
{
    public int Index { get; }
    public MapPoint Position { get; }
    public TerrainType Terrain { get; }
    public BiomeType Biome { get; }
    public float Elevation { get; }
    public float Moisture { get; }
    public IReadOnlyList<int> Neighbors { get; }
    public float Flux { get; }
    public bool IsRiver { get; }

    /// <summary>
    /// Судоходный ствол главной реки (и озёра-расширения на стволе).
    /// Лодка / дрейф / гребля разрешены только здесь.
    /// Притоки: IsRiver &amp;&amp; !IsMainStem — только визуал.
    /// </summary>
    public bool IsMainStem { get; }

    /// <summary>
    /// Пеший коридор (отдельный режим ходьбы): берег main stem, седла между
    /// горными массивами, стыки N/S. Крупные растения сюда не сажаются.
    /// </summary>
    public bool IsWalkPath { get; }

    /// <summary>
    /// Крутизна склона: изменение нормированной высоты на единицу нормированного
    /// горизонтального расстояния (безразмерная). 0 — ровная площадка, чем больше,
    /// тем круче. Нужна и для выбора биома (на крутизне держится голая порода/осыпь,
    /// а не луг), и для расстановки покрытий/мелкой растительности.
    /// </summary>
    public float Slope { get; }

    /// <summary>
    /// НОРМИРОВАННАЯ ВЫСОТА ПОВЕРХНОСТИ ВОДЫ для клеток озера, иначе -1.
    /// Берётся из Hydrology.Filled — уровня, до которого priority-flood залил
    /// котловину, то есть отметки порога стока. В пределах одного озера он
    /// ПОСТОЯНЕН, и именно это делает поверхность озера плоской.
    ///
    /// Раньше это значение вычислялось и выбрасывалось, а LevelView3D выводил
    /// поверхность воды из рельефа дна плюс глубина врезки — из-за чего озеро
    /// повторяло неровности дна и шло многогранниками.
    /// </summary>
    public float WaterLevel { get; }

    public RegionData(
        int index,
        MapPoint position,
        TerrainType terrain,
        BiomeType biome,
        float elevation,
        float moisture,
        IReadOnlyList<int> neighbors,
        float flux = 0f,
        bool isRiver = false,
        float slope = 0f,
        float waterLevel = -1f,
        bool isMainStem = false,
        bool isWalkPath = false)
    {
        Index = index;
        Position = position;
        Terrain = terrain;
        Biome = biome;
        Elevation = elevation;
        Moisture = moisture;
        Neighbors = neighbors;
        Flux = flux;
        IsRiver = isRiver;
        Slope = slope;
        WaterLevel = waterLevel;
        IsMainStem = isMainStem;
        IsWalkPath = isWalkPath;
    }
}
