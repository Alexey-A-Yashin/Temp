using System.Collections.Generic;

namespace ColoringBook.Domain.Level.Route;

/// <summary>Для чего прокладывается маршрут. От этого зависят и полоса, по которой
/// он идёт, и допустимые уклоны, и кривая скорости.</summary>
public enum RouteKind
{
    /// <summary>Горный велосипед: средний уровень гор — выше леса в долине, но не
    /// выходя на голый камень. Подъём до 20° короткими участками, спуск до 30°.</summary>
    Bike = 0,

    /// <summary>Сплав. У нас река — это ДОРОГА ПО ДНУ ДОЛИН, а не водоток: лодка
    /// моторка и едет только вперёд, гидрология не нужна. В гору не идёт вовсе —
    /// вода вверх не течёт, а ходьбы по берегу в игре нет.</summary>
    River = 1
}

/// <summary>Вид опоры сети.</summary>
public enum RouteHubKind
{
    /// <summary>Широкое место полосы: там, где по склону есть чем ехать.</summary>
    Slope = 0,

    /// <summary>Седловина — место, где хребет можно перевалить в соседнюю долину.
    /// Понятие велосипедное; у реки таких опор нет.</summary>
    Pass = 1
}

/// <summary>Опора сети. Координаты — в клетках МИРОВОЙ сетки планирования, а не
/// окна: только так две соседние территории выбирают одни и те же опоры.</summary>
public readonly struct RouteHub
{
    public readonly int WorldX;
    public readonly int WorldY;
    public readonly RouteHubKind Kind;

    /// <summary>
    /// ОЦЕНКА ВИДА С ЭТОЙ ОПОРЫ, посчитанная построителем, 0..1.
    ///
    /// ---- ПОЧЕМУ ХРАНИТСЯ, А НЕ СЧИТАЕТСЯ ЗАНОВО ----
    ///
    /// Прогон V315 показал, чем оборачивается пересчёт. Построитель оценивал вид
    /// по СЕТКЕ ПРАВДЫ (поле с ячейкой 30 м) и поднял лучшую опору с 0.625 до
    /// 0.875. А выбор старта пересчитывал ту же величину по
    /// `SampleHeightStatic` — поле ПЛЮС поправка окна уточнения, — и получил для
    /// той же опоры 50%, выбрав ту же точку, что и до правки.
    ///
    /// Одна величина, два рельефа. Тот же разъезд уже стоил нам воды (три
    /// определения реки, V306) и ложа русла (три порога, V226).
    ///
    /// Считает построитель, потому что он же по этой оценке и отбирает.
    /// </summary>
    public readonly float View;

    public RouteHub(int worldX, int worldY, RouteHubKind kind, float view = 0f)
    {
        WorldX = worldX; WorldY = worldY; Kind = kind; View = view;
    }
}

/// <summary>
/// Ребро сети: путь от опоры к опоре ломаной по клеткам мировой сетки.
///
/// Хранится ЦЕЛИКОМ и никогда не пересчитывается. Замер показал, почему: стоит
/// посчитать ту же местность другим окном, и пути расходятся не у края, а везде —
/// 105 изменившихся рёбер из 222, причём изменения доходили до 16 км от границы.
/// Причина в том, что эрозия идёт по массиву другого размера, высоты сдвигаются в
/// последних битах, и поиск кратчайшего пути перебрасывает почти каждый маршрут.
/// Поэтому существующее только хранится, а достраивается лишь то, чего ещё нет.
/// </summary>
public sealed class RouteEdge
{
    public int FromHub { get; }
    public int ToHub { get; }

    /// <summary>Ломаная в клетках мировой сетки, включая обе опоры.</summary>
    public IReadOnlyList<(int x, int y)> Points { get; }

    /// <summary>Длина по поверхности, метры.</summary>
    public float LengthM { get; }

    public RouteEdge(int fromHub, int toHub, IReadOnlyList<(int x, int y)> points, float lengthM)
    {
        FromHub = fromHub; ToHub = toHub; Points = points; LengthM = lengthM;
    }
}

/// <summary>Сеть маршрутов одной территории. Пассивные данные: строит её
/// RouteBuilder, а хранит и отдаёт — уровень.</summary>
public sealed class RouteNetwork
{
    public RouteKind Kind { get; }
    public IReadOnlyList<RouteHub> Hubs { get; }
    public IReadOnlyList<RouteEdge> Edges { get; }

    public RouteNetwork(RouteKind kind, IReadOnlyList<RouteHub> hubs, IReadOnlyList<RouteEdge> edges)
    {
        Kind = kind; Hubs = hubs; Edges = edges;
    }
}
