namespace ColoringBook.Domain.Level.River;

/// <summary>
/// Параметры генерации одного чанка непрерывной реки.
/// Inlet задаётся выходом предыдущего чанка (или DefaultInlet для первого).
/// Outlet вычисляется spine'ом и возвращается генератором для следующего чанка.
/// </summary>
public sealed class RiverChunkContext
{
    public int WorldSeed { get; }
    public ChunkCoord Coord { get; }
    public RiverSeam Inlet { get; }
    public float MapSize { get; }

    /// <summary>
    /// Локальная ось чанка: Y = 0 — верх по течению (inlet), Y = MapSize — низ (outlet).
    /// Поток всегда +Y в локальных координатах.
    /// </summary>
    public RiverChunkContext(int worldSeed, ChunkCoord coord, RiverSeam inlet, float mapSize)
    {
        WorldSeed = worldSeed;
        Coord = coord;
        Inlet = inlet;
        MapSize = mapSize;
    }
}
