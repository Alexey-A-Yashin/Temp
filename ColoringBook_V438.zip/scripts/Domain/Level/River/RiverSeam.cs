namespace ColoringBook.Domain.Level.River;

/// <summary>
/// Контракт стыка двух чанков вдоль реки.
/// Выход чанка i обязан совпасть со входом чанка i+1:
/// грань, положение на грани, полуширина, отметка дна.
/// Lateral — координата вдоль грани (0..MapSize):
///   South/North → X, West/East → Y.
/// </summary>
public readonly struct RiverSeam
{
    /// <summary>Положение оси русла на кромке, 0..MapSize (вдоль грани).</summary>
    public float Lateral { get; }

    /// <summary>Полуширина судоходного ствола на стыке.</summary>
    public float HalfWidth { get; }

    /// <summary>Нормированная отметка дна (0..1), монотонно убывает вниз по течению.</summary>
    public float BedElev { get; }

    /// <summary>Грань чанка, на которой лежит шов.</summary>
    public RiverFace Face { get; }

    public RiverSeam(float lateral, float halfWidth, float bedElev, RiverFace face = RiverFace.South)
    {
        Lateral = lateral;
        HalfWidth = halfWidth;
        BedElev = bedElev;
        Face = face;
    }


}
