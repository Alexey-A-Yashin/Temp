namespace ColoringBook.Domain.Level.River;

/// <summary>
/// Грань чанка, на которой лежит inlet или outlet main stem.
/// Локальные координаты генерации: X вправо, Y вверх по карте.
/// По умолчанию поток идёт South → North (Y: 0 → MapSize).
/// </summary>
public enum RiverFace : byte
{
    South = 0, // Y ≈ 0
    North = 1, // Y ≈ MapSize
    West  = 2, // X ≈ 0
    East  = 3, // X ≈ MapSize
}

public static class RiverFaceUtil
{

    /// <summary>
    /// Точка на грани: lateral ∈ [0, mapSize] — координата вдоль грани.
    /// South/North: lateral = X; West/East: lateral = Y.
    /// </summary>
    public static (float x, float y) PointOnFace(RiverFace face, float lateral, float mapSize)
    {
        lateral = System.Math.Clamp(lateral, 0f, mapSize);
        return face switch
        {
            RiverFace.South => (lateral, 0f),
            RiverFace.North => (lateral, mapSize),
            RiverFace.West  => (0f, lateral),
            RiverFace.East  => (mapSize, lateral),
            _ => (lateral, 0f),
        };
    }

    /// <summary>Нормаль, указывающая наружу из чанка.</summary>
    public static (float nx, float ny) OutwardNormal(RiverFace face) => face switch
    {
        RiverFace.South => (0f, -1f),
        RiverFace.North => (0f, 1f),
        RiverFace.West  => (-1f, 0f),
        RiverFace.East  => (1f, 0f),
        _ => (0f, 1f),
    };
}
