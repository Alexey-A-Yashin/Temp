namespace ColoringBook.Domain.Level.River;

/// <summary>
/// Индекс чанка вдоль судоходной оси мира.
/// ChunkIndex растёт вниз по течению (лодка плывёт к большим индексам при дрейфе).
/// </summary>
public readonly struct ChunkCoord : System.IEquatable<ChunkCoord>
{
    public int Index { get; }

    public ChunkCoord(int index) => Index = index;

    public ChunkCoord Next => new(Index + 1);


    public bool Equals(ChunkCoord other) => Index == other.Index;
    public override bool Equals(object? obj) => obj is ChunkCoord c && Equals(c);
    public override int GetHashCode() => Index;
    public override string ToString() => $"Chunk[{Index}]";
}
