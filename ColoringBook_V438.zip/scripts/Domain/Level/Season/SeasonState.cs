using System;

namespace ColoringBook.Domain.Level.Season;

/// <summary>
/// Текущее состояние сезона на уровне.
/// Immutable value object.
/// </summary>
public sealed class SeasonState
{
    public SeasonType Current { get; }
    public float Progress { get; }          // 0..1 внутри текущего сезона
    public SeasonMode Mode { get; }

    public SeasonState(SeasonType current, float progress, SeasonMode mode)
    {
        Current = current;
        Progress = Math.Clamp(progress, 0f, 1f);
        Mode = mode;
    }

    public static SeasonState CreateFixed(SeasonType season)
        => new SeasonState(season, 0f, SeasonMode.Fixed);

}
