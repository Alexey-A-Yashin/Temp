namespace ColoringBook.Domain.Level.Season;

/// <summary>
/// Времена года. Используются как в Fixed-режиме, так и в Progressing.
/// </summary>
public enum SeasonType
{
    Spring = 0,
    Summer = 1,
    Autumn = 2,
    Winter = 3
}
