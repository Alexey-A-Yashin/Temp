namespace ColoringBook.Domain.Level.Season;

/// <summary>
/// Режим поведения сезона на уровне.
/// Fixed  — сезон никогда не меняется (например, «вечная зима»).
/// Progressing — плавная смена времён года.
/// </summary>
public enum SeasonMode
{
    Fixed = 0,
    Progressing = 1
}
