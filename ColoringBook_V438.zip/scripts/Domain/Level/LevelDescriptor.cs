using System;
using ColoringBook.Domain.Level.Season;

namespace ColoringBook.Domain.Level;

/// <summary>
/// Описание уровня, которое сохраняется на диск.
/// Позволяет гарантированно воспроизвести тот же самый уровень + режим сезона.
/// </summary>
public sealed class LevelDescriptor
{
    public Guid Id { get; }
    public int Seed { get; }
    public SeasonMode SeasonMode { get; }
    public SeasonType FixedSeason { get; }      // имеет смысл только при SeasonMode.Fixed
    public DateTime CreatedUtc { get; }

    // Позже добавим LevelGenerationParams
    // public LevelGenerationParams Params { get; }

    public LevelDescriptor(
        Guid id,
        int seed,
        SeasonMode seasonMode,
        SeasonType fixedSeason,
        DateTime createdUtc)
    {
        Id = id;
        Seed = seed;
        SeasonMode = seasonMode;
        FixedSeason = fixedSeason;
        CreatedUtc = createdUtc;
    }

}
