namespace ColoringBook.Domain.Level;

public enum TerrainType
{
    Ocean = 0,
    Lake = 1,
    Land = 2,
    Coast = 3,
    MountainRing = 4   // внешнее кольцо гор
}
