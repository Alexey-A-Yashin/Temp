namespace ColoringBook.Domain.Level;

/// <summary>
/// Один экземпляр растения на карте (чистый C#).
/// Координаты — в map-space (как RegionData.Position).
/// VariantIndex выбирает форму из PlantCatalog; Yaw даёт разный ракурс одной формы.
/// </summary>
public readonly struct VegetationInstance
{
    public float X { get; }
    public float Z { get; }
    public float Elevation { get; }
    public VegetationKind Kind { get; }
    public float Scale { get; }
    public float Yaw { get; }
    /// <summary>Индекс варианта формы в каталоге (0..N-1 для данного Kind).</summary>
    public int VariantIndex { get; }

    public VegetationInstance(
        float x, float z, float elevation,
        VegetationKind kind, float scale, float yaw,
        int variantIndex = 0)
    {
        X = x;
        Z = z;
        Elevation = elevation;
        Kind = kind;
        Scale = scale;
        Yaw = yaw;
        VariantIndex = variantIndex < 0 ? 0 : variantIndex;
    }
}
