namespace ColoringBook.Domain.Common;

/// <summary>
/// Текущие настройки графики. Влияют на плотность генерации и детализацию меша.
/// </summary>
public sealed class GraphicsSettings
{
    public GraphicsQuality Quality { get; private set; }
    public bool IsAutoDetected { get; private set; }

    public GraphicsSettings(GraphicsQuality quality, bool isAutoDetected = false)
    {
        Quality = quality;
        IsAutoDetected = isAutoDetected;
    }



    /// <summary>
    /// Разрешение heightmap-сетки для 3D-меша.
    /// </summary>
    public int GetGridResolution() => Quality switch
    {
        GraphicsQuality.Low => 128,
        GraphicsQuality.Medium => 192,
        GraphicsQuality.High => 256,
        _ => 192
    };
}
