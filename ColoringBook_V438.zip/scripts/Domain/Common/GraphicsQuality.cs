namespace ColoringBook.Domain.Common;

/// <summary>
/// Уровень графики. Влияет на плотность точек генерации,
/// детализацию мешей, эффекты и т.д.
/// </summary>
public enum GraphicsQuality
{
    Low = 0,
    Medium = 1,
    High = 2
}
