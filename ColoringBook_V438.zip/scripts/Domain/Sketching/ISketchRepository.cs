using System;
using System.Collections.Generic;

namespace ColoringBook.Domain.Sketching;

/// <summary>
/// КОНТРАКТ ХРАНИЛИЩА СНИМКОВ.
///
/// Интерфейс объявлен В ДОМЕНЕ, а реализация лежит в инфраструктуре — это инверсия
/// зависимостей из главы 4.5 книги: «ядро не должно знать о периферии». Домен
/// говорит, ЧТО ему нужно (сохрани, дай список, дай изображение), а КАК это
/// устроено — на диске, в облаке, в памяти для тестов — его не касается.
///
/// Изображения передаются сырыми байтами PNG, а не типами движка: иначе домен
/// потянул бы за собой Godot и перестал бы тестироваться отдельно.
/// </summary>
public interface ISketchRepository
{
    /// <summary>Сохранить новый снимок вместе с исходником и контурами.</summary>
    void Create(Sketch sketch, byte[] sourcePng, byte[] outlinePng);

    /// <summary>Сохранить продвижение работы: закрашенный слой и состояние.</summary>
    void SavePainting(Sketch sketch, byte[] paintedPng);

    /// <summary>Все снимки, новые первыми. Изображения НЕ читаются — только описания,
    /// иначе открытие галереи упиралось бы в диск.</summary>
    IReadOnlyList<Sketch> List();

    bool TryLoad(SketchId id, out Sketch sketch);

    /// <summary>Байты слоя. Отдельный вызов, потому что галерее нужны превью,
    /// а сцене раскраски — полные изображения.</summary>
    byte[]? ReadLayer(SketchId id, SketchLayer layer);

    void Delete(SketchId id);
}

public enum SketchLayer
{
    /// <summary>Цветной кадр — то, что игрок видел.</summary>
    Source = 0,

    /// <summary>Белый лист с контурами — заготовка.</summary>
    Outline = 1,

    /// <summary>Закрашенное игроком.</summary>
    Painted = 2,
}
