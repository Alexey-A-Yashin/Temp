using System;

namespace ColoringBook.Domain.Sketching;

/// <summary>
/// СНИМОК — доменная сущность механики зарисовок.
///
/// Игрок находит пейзаж и делает «снимок». Из него получается пара:
///   • ИСХОДНИК — цветной кадр, каким игрок его видел;
///   • КОНТУР — белый лист с линиями по границам объектов, заготовка для раскраски.
/// Плюс третье, появляющееся позже: РАБОТА — то, что игрок закрасил.
///
/// АРХИТЕКТУРНАЯ ГРАНИЦА (Казанцев, Гнайберг, 4.1.2). Слой правил не знает, откуда
/// берутся изображения и куда сохраняются: «инфраструктура обслуживает домен, а не
/// определяет его». Поэтому здесь нет ни путей к файлам, ни типов Godot — только
/// идентификатор, время, происхождение и состояние работы. Загрузку и запись
/// выполняет ISketchRepository, а рендер контуров — инфраструктурный захват.
///
/// Класс НЕ ЗАВИСИТ ОТ GODOT.
/// </summary>
public sealed class Sketch
{
    public SketchId Id { get; }

    /// <summary>Когда сделан. Нужен для сортировки в галерее.</summary>
    public DateTime CreatedUtc { get; }

    /// <summary>Откуда сделан — чтобы позже можно было вернуться на то же место.</summary>
    public SketchOrigin Origin { get; }

    /// <summary>
    /// Состояние работы. Игрок может начать раскрашивать сегодня, бросить и вернуться
    /// через месяц, поэтому состояние — часть сущности, а не эфемерное свойство сцены.
    /// </summary>
    public SketchProgress Progress { get; private set; }

    /// <summary>Название. По умолчанию пустое — игрок может дать своё.</summary>
    public string Title { get; private set; }

    public Sketch(SketchId id, DateTime createdUtc, SketchOrigin origin,
                  SketchProgress progress, string title = "")
    {
        Id = id;
        CreatedUtc = createdUtc;
        Origin = origin;
        Progress = progress;
        Title = title ?? string.Empty;
    }

    /// <summary>Только что сделанный снимок: контуры есть, работа не начата.</summary>
    public static Sketch NewCapture(SketchId id, DateTime utcNow, SketchOrigin origin)
        => new(id, utcNow, origin, SketchProgress.NotStarted);

    /// <summary>
    /// Отметить, что игрок работал над раскраской.
    ///
    /// Переход только вперёд: начатую работу нельзя «разначать». Инвариант живёт
    /// здесь, а не в UI, иначе кнопка «выйти без сохранения» смогла бы откатить
    /// состояние в обход правил.
    /// </summary>
    public void MarkPainted(float completion)
    {
        completion = Math.Clamp(completion, 0f, 1f);
        Progress = completion >= 0.999f
            ? SketchProgress.Finished
            : SketchProgress.InProgress;
        Completion = MathF.Max(Completion, completion);
    }

    /// <summary>Доля закрашенного, 0..1. Монотонно не убывает.</summary>
    public float Completion { get; private set; }

}

/// <summary>
/// Идентификатор снимка. Отдельный тип, а не голая строка: перепутать его с названием
/// или путём к файлу становится невозможно.
///
/// Значение ДЕТЕРМИНИРОВАННОЕ — собирается из времени и сида, а не из Guid. Это нужно
/// для воспроизводимости в тестах и для того, чтобы имя папки было читаемым.
/// </summary>
public readonly record struct SketchId(string Value)
{
    public static SketchId FromCapture(DateTime utc, int worldSeed, int chunkIndex)
        => new($"{utc:yyyyMMdd_HHmmss}_{unchecked((uint)worldSeed):x8}_{chunkIndex}");

    public override string ToString() => Value;

    /// <summary>Пригодность как имени папки — проверяется при загрузке чужих данных.</summary>
    public bool IsValid()
    {
        if (string.IsNullOrWhiteSpace(Value)) return false;
        foreach (char c in Value)
            if (!char.IsLetterOrDigit(c) && c != '_' && c != '-') return false;
        return true;
    }
}

/// <summary>Откуда сделан снимок: чтобы вернуть игрока на это место.</summary>
public readonly record struct SketchOrigin(
    int WorldSeed,
    int ChunkIndex,
    float CameraX, float CameraY, float CameraZ,
    float Yaw, float Pitch,
    string SeasonName);

public enum SketchProgress
{
    NotStarted = 0,
    InProgress = 1,
    Finished = 2,
}
