using System;
using System.Collections.Generic;
using System.Linq;
using Godot;
using ColoringBook.Application;
using ColoringBook.Domain.Common;
using ColoringBook.Domain.Level;
using ColoringBook.Domain.Level.River;
using ColoringBook.Domain.Level.Season;
using ColoringBook.Infrastructure.Generation;
using ColoringBook.Infrastructure.Generation.Plants;
using ColoringBook.Infrastructure.Generation.Mapgen;
using ColoringBook.Presentation.Debug;
using ColoringBook.Infrastructure.Persistence;
using ColoringBook.Presentation.Level;

using ColoringBook.Domain.Sketching;
using ColoringBook.Infrastructure.Sketching;
using ColoringBook.Presentation.Menu;
using ColoringBook.Presentation.Sketching;
using ColoringBook.Presentation.Diagnostics;

namespace ColoringBook.Bootstrap;

/// <summary>
/// 3D-превью. R=уровень, P=растения, G=галерея форм, 1–4/S=сезон.
/// </summary>
public partial class GameBootstrap : Node3D
{
    /// <summary>Что показывается на экране.</summary>
    private enum ViewMode
    {
        /// <summary>Основная сцена: карта игрового уровня (горы, долины, реки).</summary>
        Level,
        /// <summary>Тестовая сцена: витрина форм растений на пустом фоне.</summary>
        PlantGallery
    }

    /// <summary>
    /// Тестовая сцена с растениями ВРЕМЕННО ОТКЛЮЧЕНА (запрос пользователя 31.07 —
    /// перегрев видеокарты). Витрина строит все 6 видов рядом крупным планом, это самая
    /// тяжёлая сцена в проекте. Код витрины сохранён целиком: чтобы включить обратно,
    /// поставьте true — клавиша P снова заработает.
    /// </summary>
    // Витрина растений включена обратно: вернулись к работе над растениями, и удобно
    // смотреть все виды рядом, не выискивая их на уровне. Открывается клавишей P.
    private const bool PlantGalleryEnabled = true;

    /// <summary>
    /// Режим при запуске. ЕДИНСТВЕННОЕ место, которое надо править, чтобы поменять
    /// стартовый экран — раньше режим задавался неявно тем, какой метод вызван в конце
    /// _Ready, и это было легко перепутать. Переключение во время работы — клавиша P
    /// (пока витрина отключена флагом выше, переключение не работает).
    /// </summary>
    private const ViewMode StartupMode = ViewMode.Level;

    /// <summary>Построен ли уровень. На мобильном он строится не при запуске, а при
    /// первом переходе на экран уровня.</summary>
    private bool _levelBuilt;

    private ViewMode _viewMode = StartupMode;

    /// <summary>Активна ли витрина растений. Берётся из собственного поля режима, а не
    /// из состояния LevelView3D — так режим ввода не может разойтись с тем, что показано.</summary>
    private bool IsGalleryMode => _viewMode == ViewMode.PlantGallery;

    private LevelService _levelService = null!;
    private LevelView3D _view = null!;
    private Camera3D _camera = null!;
    private DirectionalLight3D _sun = null!;
    private WorldEnvironment _env = null!;
    /// <summary>false = ровный свет для осмотра (по умолчанию), true = солнце с
    /// тенями для оценки формы рельефа. Переключается клавишей L.</summary>
    private bool _reliefLighting;
    private GenerationDebugPanel? _debugPanel;

    /// <summary>
    /// Мир старого генератора. ВСЕГДА ПУСТ: генератор больше не запускается,
    /// данные собираются из наших колец (см. BuildLevelDataFromRings).
    ///
    /// Ветки дрейфа лодки понадобятся, когда сплав будет делаться по НАШЕМУ
    /// руслу; сам мир старого генератора удалён вместе с ним.
    /// </summary>
    /// <summary>
    /// true — непрерывная река (RiverWorld + MainChannel + маркеры ствола).
    /// false — legacy одиночная карта (Outlet к краю). Переключение: клавиша M.
    /// </summary>
    /// <summary>
    /// Непрерывная река старого генератора. ВЫКЛЮЧЕНО: генератор удалён, а река
    /// у нас своя — по дренажу поля.
    ///
    /// Поле оставлено, чтобы не выкорчёвывать ветки дрейфа лодки: они понадобятся,
    /// когда сплав будет делаться по нашему руслу.
    ///
    /// НЕ readonly: значение переключается клавишей (см. обработчик ввода).
    /// </summary>
    // V301: поле _useRiverWorld убрано. Оно переключало два режима СТАРОГО
    // генератора чанка; генератор удалён, и флаг навсегда остался ложью, а
    // ветки под ним — недостижимыми.
    private Label _infoLabel = null!;
    private Label _camInfoLabel = null!;
    private Label _perfLabel = null!;
    private GraphicsSettings _graphics = null!;
    // Периодический семпл нагрузки (HUD + лог).
    private double _perfHudAcc;
    private double _perfLogAcc;
    private const double PerfHudInterval = 0.5;
    private const double PerfLogInterval = 3.0;
    private int _currentSeed = 42;
    private SeasonType _currentSeason = SeasonType.Summer;
    private int _plantSeed = 0xC01A7;

    private float _yaw = 0.55f;

    /// <summary>
    /// Наклон камеры при запуске: −1.35 радиана, то есть 77° ВНИЗ. Уровень
    /// виден сверху целиком, как карта.
    ///
    /// ---- ПРО ЗНАК ----
    ///
    /// Направление взгляда считается как `forward.Y = sin(_pitch)`:
    ///
    ///     _pitch = +1.35  ->  forward.Y = +0.98  ->  камера смотрит ВВЕРХ
    ///     _pitch = −1.35  ->  forward.Y = −0.98  ->  ВНИЗ
    ///
    /// Я поставил +1.35, и камера смотрела в небо из-под уровня. Знак здесь
    /// обратный привычному: положительный наклон — это взгляд вверх.
    /// </summary>
    private float _pitch = -1.35f;
    /// <summary>Наибольшее удаление орбитальной камеры, мировые единицы.
    /// Полтора размера области фона: 24 км это 2400 единиц.</summary>
    /// <summary>
    /// Наибольшее удаление камеры.
    ///
    /// Было 3600 при территории 11520 — в кадр входила ТРЕТЬ уровня, и осмотреть
    /// его целиком было нельзя.
    ///
    /// Чтобы сторона вошла при обзоре 75°: 11520 / 2 / tg(37.5°) = 7508.
    /// Берём 8000 с запасом на перспективу.
    /// </summary>
    private const float MaxOrbitDistance = 8000f;

    private float _distance = 120f; // closer default — more landscape, less "table"
    private Vector3 _target = Vector3.Zero;

    /// <summary>
    /// Середина уровня в мировых единицах.
    ///
    /// Уровень строится от нуля в обе стороны, значит середина — нуль по
    /// горизонтали, а по высоте берётся сама земля.
    ///
    /// Без этого камера вращалась вокруг точки на нулевой высоте, то есть
    /// под землёй при высоких горах.
    /// </summary>
    private Vector3 LevelCenter()
        => new Vector3(0f, _view?.SampleWorldY(0f, 0f) ?? 0f, 0f);
    private bool _dragging;

    // 0 = orbit overview, 1 = low ridge, 2 = player-eye in valley
    // V41: старт в overview — временно без лодки, чтобы оценить rim/дыры горизонта.
    private int _camMode = 0;
    /// <summary>
    /// Высота глаз над землёй, в мировых единицах.
    ///
    /// V88: было 1.65 «рост взрослого в единицах» — но единица мира это не метр, а
    /// около десяти метров (LevelView3D.MetresPerUnit). Игрок ростом 1.65 единицы
    /// был шестнадцатиметровым, то есть выше сосны, и смотрел на макушки крон.
    /// Теперь рост считается из метров, как и высоты растений.
    /// </summary>
    // Значение одно на весь проект: обход уровня в LevelView3D ставит наблюдателя
    // на ту же высоту, что и настоящая пешая камера, иначе телеметрия мерила бы не тот
    // кадр, который увидит игрок.
    private const float PlayerEyeMetres = LevelView3D.PlayerEyeMetresStatic;
    private static float PlayerEyeOffset => PlayerEyeMetres / LevelView3D.MetresPerUnit;
    // Walk constraints (player-eye mode): stay on land, avoid peaks & map edge void
    private const float MaxWalkRadius = 58f;   // world units from map centre
    private const float MaxWalkTerrainY = 20f; // don't climb above mid-slopes
    private Vector3 _lastGoodTarget = Vector3.Zero;

    // ---- Лодка / дрейф по main stem (только RiverWorld) ----
    // V55 (audit V-1): станция — длина дуги вдоль spine (map units), не параметр t.
    // _boatArcInChunk ∈ [0, _boatPathLen]; t = ArcLengthToT(_boatArcTable, arc).
    // Раньше localT = station/mapSize давал скачки скорости ×2.5 на длинных сегментах
    // и среднюю скорость ×2.3 от заданной (путь Horseshoe длиннее mapSize).
    private float _boatStation;             // кумулятивная длина дуги от старта (HUD)
    private float _boatArcInChunk;          // длина дуги внутри текущего чанка
    private float _boatPathLen = 1f;        // длина spine текущего чанка
    private float[]? _boatArcTable;         // кумулятивные длины → t
    private float _boatSpeed = 5f;           // map-units / sec вдоль дуги
    private const float BoatSpeedMin = 0f;
    private const float BoatSpeedMax = 60f;
    private const float BoatSpeedStep = 2.5f;
    private int _boatChunk = -1;            // какой чанк сейчас показан
    // V41: лодка ВЫКЛ по умолчанию. B — включить/выключить дрейф.
    private bool _boatActive;
    private const float BoatEyeHeight = 1.35f;  // V47: сидя в лодке, ниже крон деревьев (~3.6–4.4)
    private const float WorldScaleBoat = 0.16f; // = LevelView3D.WorldScale
    /// <summary>Смещение взгляда относительно направления течения (мышь).</summary>
    private float _lookYawOffset;
    // Плавность / «медитация»
    private Vector3 _camSmoothPos;
    private float _camSmoothYaw;
    private float _camRoll;
    private float _boatPhase;
    private float _prevFlowYaw;
    private bool _camSmoothInit;
    private const float CamPosLerp = 3.2f;
    private const float CamYawLerp = 2.4f;
    private const float BobAmp = 0.18f;
    private const float BobHz = 0.22f;
    private const float SpeedBreathAmp = 0.08f;
    private const float MaxBankRad = 0.09f;

    /// <summary>
    /// СТАТИЧЕСКИЙ конструктор: каталог логов назначается здесь, а не в _Ready.
    ///
    /// Причина. Статистика роста растений пишется из PlantCatalog, который строит
    /// меши один раз при первом обращении. Если каталог логов назначать в _Ready,
    /// результат зависит от того, что выполнилось раньше, — и файл _plants.json
    /// уходил в профиль пользователя вместо res://logs. Полагаться на порядок строк
    /// в таких случаях ненадёжно: достаточно кому-то тронуть PlantCatalog чуть
    /// раньше, и всё снова разъедется. Статический конструктор отрабатывает при
    /// первом же обращении к типу GameBootstrap, то есть заведомо до любой генерации.
    /// </summary>
    static GameBootstrap()
    {
        // ---- КУДА ПИШЕТСЯ ЖУРНАЛ ----
        //
        // На НАСТОЛЬНОМ — в res://logs, то есть прямо в каталог проекта: так
        // журналы под рукой и их удобно забирать.
        //
        // На ТЕЛЕФОНЕ res:// доступен только для чтения, и первый запуск дал
        // «Read-only file system: /logs» и 43 ошибки подряд. Там пишем в user://
        // — внутреннюю папку приложения.
        string logDir = ProjectSettings.GlobalizePath(RunMode.LogPath);
        try { System.IO.Directory.CreateDirectory(logDir); }
        catch (System.Exception e) { GD.PushWarning($"[журнал] каталог не создан: {e.Message}"); }
        ColoringBook.Infrastructure.Generation.Diagnostics.GenerationLog.OverrideDirectory = logDir;
    }

    /// <summary>
    /// Сделать снимок текущего кадра.
    ///
    /// Асинхронно, потому что служебные проходы требуют дождаться кадра. Кнопка при
    /// этом не блокируется намертво: повторное нажатие во время захвата игнорируется
    /// флагом, иначе два захвата подрались бы за материалы-переопределения.
    /// </summary>
    private bool _capturing;

    /// <summary>
    /// Числа по снимку: доля неба и связные пятна после сведения к трём тонам.
    ///
    /// Повторяет то, что меряет стенд (Paintable), чтобы числа можно было
    /// сверять напрямую. «Прищур» — размытие перед сведением, иначе мелкая рябь
    /// даёт сотни пятен там, где глаз их не видит.
    /// </summary>
    /// <summary>
    /// ЦВЕТ НЕБА — ОДНО МЕСТО НА ПРОЕКТ.
    ///
    /// Он же цвет фона окна, он же признак пустоты для меры кадра. Разведись эти
    /// три употребления по разным местам — и мера пустоты замолчит при первой же
    /// смене оттенка, ничем этого не показав. Второй пункт чек-листа
    /// рефакторинга: одно понятие, вычисляемое в двух местах, расходится.
    /// </summary>
    private static readonly Color SkyColor = new Color(0.72f, 0.82f, 0.93f);

    /// <summary>Доля кадра, залитая цветом фона, — то есть где геометрии нет.
    /// И то же по нижней половине кадра, куда настоящее небо почти не попадает.</summary>
    private static float _lastVoidShare, _lastVoidLower;

    private static (float sky, int regions, float largest) FrameStats(Image img)
    {        int w = img.GetWidth() / 4, h = img.GetHeight() / 4;   // вчетверо мельче: хватает
        var lum = new float[w * h];
        for (int j = 0; j < h; j++)
        for (int i = 0; i < w; i++)
        {
            var c = img.GetPixel(i * 4, j * 4);
            lum[j * w + i] = (c.R + c.G + c.B) / 3f;
        }

        // прищур
        var tmp = new float[lum.Length];
        for (int pass = 0; pass < 2; pass++)
        {
            for (int j = 0; j < h; j++)
            for (int i = 0; i < w; i++)
            {
                float sum = 0; int n = 0;
                for (int dj = -1; dj <= 1; dj++)
                for (int di = -1; di <= 1; di++)
                {
                    int x = i + di, y = j + dj;
                    if (x < 0 || y < 0 || x >= w || y >= h) continue;
                    sum += lum[y * w + x]; n++;
                }
                tmp[j * w + i] = sum / n;
            }
            System.Array.Copy(tmp, lum, lum.Length);
        }

        // ---- V299: ПУСТОТА СЧИТАЕТСЯ ОТДЕЛЬНО ОТ НЕБА ----
        //
        // Там, где геометрии нет, окно заливается цветом фона. Прежде фон был
        // чёрным, и пустота считалась «тёмным рельефом»: на V298 нижние 45%
        // кадров с глаз были пусты, а мера этого не показывала ни одним числом.
        //
        // Мера неба по яркости на этот вопрос не отвечает: со светлым небом
        // пустота попадёт в неё и будет засчитана небом, что ещё хуже прежнего.
        // Поэтому считается ИМЕННО цвет фона, с допуском на сглаживание края.
        //
        // Отдельно — доля пустоты в НИЖНЕЙ ПОЛОВИНЕ кадра: настоящее небо туда
        // почти не попадает, а дыра под ногами попадает целиком.
        int voidCount = 0, voidLower = 0, lowerTotal = 0;
        {
            var bg = SkyColor;
            for (int j = 0; j < h; j++)
            for (int i = 0; i < w; i++)
            {
                var c = img.GetPixel(i * 4, j * 4);
                bool isVoid = MathF.Abs(c.R - bg.R) < 0.02f
                           && MathF.Abs(c.G - bg.G) < 0.02f
                           && MathF.Abs(c.B - bg.B) < 0.02f;
                if (isVoid) voidCount++;
                if (j >= h / 2) { lowerTotal++; if (isVoid) voidLower++; }
            }
        }
        _lastVoidShare = voidCount / (float)lum.Length;
        _lastVoidLower = lowerTotal > 0 ? voidLower / (float)lowerTotal : 0f;

        // небо: самые светлые точки сверху кадра
        int skyCount = 0;
        for (int k = 0; k < lum.Length; k++) if (lum[k] > 0.80f) skyCount++;

        // три тона по квантилям
        var sorted = new List<float>(lum); sorted.Sort();
        float t1 = sorted[sorted.Count / 3], t2 = sorted[sorted.Count * 2 / 3];
        var band = new int[lum.Length];
        for (int k = 0; k < lum.Length; k++) band[k] = lum[k] > t2 ? 2 : lum[k] > t1 ? 1 : 0;

        var seen = new bool[band.Length];
        var stack = new Stack<int>();
        int big = 0, largest = 0;
        int minUseful = band.Length / 100;
        for (int start = 0; start < band.Length; start++)
        {
            if (seen[start]) continue;
            int v = band[start], n = 0;
            stack.Push(start); seen[start] = true;
            while (stack.Count > 0)
            {
                int c = stack.Pop(); n++;
                int i = c % w, j = c / w;
                for (int dj = -1; dj <= 1; dj++)
                for (int di = -1; di <= 1; di++)
                {
                    if (di != 0 && dj != 0) continue;
                    int x = i + di, y = j + dj;
                    if (x < 0 || y < 0 || x >= w || y >= h) continue;
                    int t = y * w + x;
                    if (seen[t] || band[t] != v) continue;
                    seen[t] = true; stack.Push(t);
                }
            }
            if (n >= minUseful) big++;
            if (n > largest) largest = n;
        }
        return (skyCount / (float)lum.Length, big, largest / (float)lum.Length);
    }

    private async System.Threading.Tasks.Task TakeSketchAsync()
    {
        if (_capturing || _sketchCapture == null || _previewScreen == null) return;
        _capturing = true;
        try
        {
            // HUD прячем ДО снимка, иначе отладочная строка попадёт в кадр.
            bool hudWas = _levelHud?.Visible ?? false;
            if (_levelHud != null) _levelHud.Visible = false;

            // Ждём ИМЕННО ОТРИСОВКУ, а не следующий шаг обработки.
            // Прежде здесь стоял ProcessFrame, и на снимке всё равно оказывалась
            // отладочная строка: смена видимости успевала примениться, а текстура
            // вьюпорта отдавала ещё прошлый, уже отрисованный кадр.
            await ToSignal(RenderingServer.Singleton, RenderingServer.SignalName.FramePostDraw);

            var cam = GetViewport().GetCamera3D();
            if (cam == null) return;

            // УРОВНИ ДЕТАЛИЗАЦИИ НА ВРЕМЯ СНИМКА НЕ ТРОГАЕМ.
            //
            // Прежняя версия переводила дальние чанки с импостора на настоящую
            // геометрию, чтобы проход идентификаторов не превратил карточки в
            // прямоугольники. Побочный эффект оказался хуже: на снимке вдали
            // ПОЯВЛЯЛИСЬ деревья, которых игрок на экране не видел, и кадр переставал
            // соответствовать тому, что он снимал. Теперь силуэт импостора
            // сохраняется самим шейдером (см. id_mode в impostor.gdshader), а сцена
            // снимается ровно в том виде, в каком она на экране.

            // ОБА изображения за один заход, с ОДНОЙ И ТОЙ ЖЕ камерой.
            // Прежде контуры строились позже и требовали восстановления ракурса, а
            // восстановить его точно было нельзя: орбитальная камера задаётся целью,
            // дистанцией, поворотом и наклоном, а сохранялись только два последних.
            // Служебные проходы кладём рядом со снимком: без них следующая ошибка
            // снова диагностировалась бы угадыванием.
            _sketchCapture.DebugDir = $"{FileSketchRepository.RootPath}/_debug";
            var shot = await _sketchCapture.CaptureBothAsync(this, GetViewport(), cam);

            if (_levelHud != null) _levelHud.Visible = hudWas;
            if (shot == null) return;

            _pendingSource = shot.Value.source;
            _pendingOutline = shot.Value.outline;
            _pendingCamera = cam;
            _previewScreen.ShowShot(shot.Value.source);
        }
        catch (System.Exception ex)
        {
            GD.PrintErr($"[sketch] снимок не удался: {ex.Message}");
        }
        finally
        {
            _capturing = false;
        }
    }

    /// <summary>
    /// СЕРИЯ ЗАМЕРОВ ПО ГРУППАМ ВИТРИНЫ.
    ///
    /// Проходит план (хвойные в двух возрастах, лиственные в трёх, мелочь один раз),
    /// на каждом шаге оставляет видимой только свою группу и снимает её со всех
    /// дистанций LOD. Так одно нажатие даёт полную картину по всем растениям, а
    /// снимков выходит шесть шагов вместо перебора по одному виду.
    ///
    /// Возраст и видимость восстанавливаются в конце: витрина остаётся в том же
    /// состоянии, в каком была до нажатия.
    /// </summary>
    private async System.Threading.Tasks.Task CaptureGallerySeriesAsync(float fov, Vector2 size)
    {
        if (_view == null || _sketchCapture == null) return;
        int ageBefore = ColoringBook.Infrastructure.Generation.Plants.PlantGenerator.AgeLevel;
        int qBefore = ColoringBook.Infrastructure.Generation.Plants.PlantGenerator.QualityLevel;
        // Режим детализации теперь тоже меняется по ходу серии, поэтому и он
        // запоминается. Без этого витрина после серии осталась бы в компактном режиме,
        // то есть показывала бы не тот меш, ради которого её открывают, — и заметить
        // это было бы нечем: подмена каталога уже однажды пряталась именно так.
        var detailBefore = ColoringBook.Infrastructure.Generation.Plants.PlantGenerator.Detail;

        var plan = LevelView3D.GallerySweepPlan();
        var sb = new System.Text.StringBuilder();
        sb.Append("{\"stamp\":\"").Append(LevelView3D.BuildStamp).Append("\",\"steps\":[");

        string dir = "";
        for (int step = 0; step < plan.Count; step++)
        {
            var (group, age, quality, detail, label) = plan[step];
            _view.GalleryShowGroup(group, age, quality, detail);
            // Два кадра: раскладка пересобирается, и меши должны попасть в дерево сцены.
            await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
            await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);

            string json = _view.BuildGallerySweepJson(fov, size);
            if (step > 0) sb.Append(',');
            sb.Append("{\"label\":\"").Append(label).Append("\",\"sweep\":").Append(json).Append('}');

            if (step == 0)
            {
                string path = ColoringBook.Infrastructure.Generation.Diagnostics.GenerationLog
                    .WriteRaw("{}", _currentSeed, "gallery");
                dir = path.Replace(".json", "_shots");
                DirAccess.MakeDirRecursiveAbsolute(dir);
                _galleryJsonPath = path;
            }

            var poses = _view.BuildGallerySweepPoses();
            // ШАБЛОНЫ СНИМАЮТСЯ ТОЛЬКО С ИГРОВОГО МЕША.
            //
            // Шаблон подробного меша отвечает на вопрос о дереве, которого в игре нет:
            // на уровень едет компактный. Прошлый прогон это и показал — правка
            // компактного режима изменила замер импосторов, а шаблоны витрины остались
            // побайтно прежними, потому что снимались с подробного меша.
            //
            // Цветные кадры при этом делаются на КАЖДОМ шаге: подробный меш остаётся
            // инструментом разглядывания геометрии, просто судить по нему о раскраске
            // нельзя.
            bool wantOutline = detail == ColoringBook.Infrastructure.Generation.Plants
                .PlantGenerator.FoliageDetail.Compact;
            for (int i = 0; i < poses.Count; i++)
            {
                var (pos, fwd, plabel) = poses[i];
                var img = await _sketchCapture.RenderViewAsync(_view, pos, fwd, fov, new Vector2I(1280, 720));
                if (img == null) continue;
                string tag = plabel.Split('—').Length > 1 ? plabel.Split('—')[1].Trim() : $"d{i}";
                string stem = $"{dir}/{step}{i}_{label.Replace(' ', '_')}_{tag.Replace(' ', '_')}";
                img.SavePng($"{stem}.png");

                // ---- ЧИСЛА ПО КАДРУ РЯДОМ СО СНИМКОМ ----
                //
                // Без них сверять числа стенда с картинкой приходится на глаз.
                // Считаем то же, что стенд: долю неба и число связных пятен после
                // сведения к трём тонам («чёрно-белый план» по Macpherson,
                // «прищур» по Szabo).
                //
                // По 60 репродукциям из книг: пятен 7-15 в четвертях, крупнейшее
                // около 29% кадра.
                var stat = FrameStats(img);
                SessionLog.Print($"[кадр] {label}: неба {stat.sky * 100:F0}%, "
                    + $"пятен {stat.regions}, крупнейшее {stat.largest * 100:F0}%, "
                    + $"ПУСТОТЫ {_lastVoidShare * 100:F0}% (в нижней половине {_lastVoidLower * 100:F0}%)");

                if (!wantOutline) continue;
                var outline = await _sketchCapture.BuildOutlineFromPoseAsync(
                    _view, pos, fwd, fov, new Vector2I(1280, 720));
                if (outline == null) continue;
                using var f = FileAccess.Open($"{stem}_outline.png", FileAccess.ModeFlags.Write);
                f?.StoreBuffer(outline);
                // Отчёт печатается с меткой шага: без неё двадцать семь одинаковых
                // строк в консоли не отнести к породам.
                SessionLog.Print($"[sketch] витрина {label}, {tag}: {_sketchCapture.LastReport}");
            }
        }
        // ---- ВТОРАЯ ЧАСТЬ СЕРИИ: СТУПЕНИ ЗАТЕНЁННОСТИ ----
        //
        // Один тип за шаг, три ступени: открытый рост, средний лес, чаща. Отвечает на
        // вопрос, который обычные шаги не задают, — как меняется силуэт ОДНОЙ породы
        // в зависимости от соседей. На уровне это пришлось бы искать пешком.
        var crowdPlan = LevelView3D.GalleryCrowdingPlan();
        for (int step = 0; step < crowdPlan.Count; step++)
        {
            var (kind, level, age, label) = crowdPlan[step];
            _view.GalleryShowKindAtCrowding(kind, level, age);
            await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
            await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);

            var poses2 = _view.BuildGallerySweepPoses();
            for (int i = 0; i < poses2.Count; i++)
            {
                var (pos, fwd, plabel) = poses2[i];
                var img = await _sketchCapture.RenderViewAsync(_view, pos, fwd, fov, new Vector2I(1280, 720));
                if (img == null) continue;
                string tag = plabel.Split('—').Length > 1 ? plabel.Split('—')[1].Trim() : $"d{i}";
                string stem = $"{dir}/c{step}{i}_{label.Replace(' ', '_')}_{tag.Replace(' ', '_')}";
                img.SavePng($"{stem}.png");

                // ---- ЧИСЛА ПО КАДРУ РЯДОМ СО СНИМКОМ ----
                //
                // Без них сверять числа стенда с картинкой приходится на глаз.
                // Считаем то же, что стенд: долю неба и число связных пятен после
                // сведения к трём тонам («чёрно-белый план» по Macpherson,
                // «прищур» по Szabo).
                //
                // По 60 репродукциям из книг: пятен 7-15 в четвертях, крупнейшее
                // около 29% кадра.
                var stat = FrameStats(img);
                SessionLog.Print($"[кадр] {label}: неба {stat.sky * 100:F0}%, "
                    + $"пятен {stat.regions}, крупнейшее {stat.largest * 100:F0}%, "
                    + $"ПУСТОТЫ {_lastVoidShare * 100:F0}% (в нижней половине {_lastVoidLower * 100:F0}%)");

                var outline = await _sketchCapture.BuildOutlineFromPoseAsync(
                    _view, pos, fwd, fov, new Vector2I(1280, 720));
                if (outline == null) continue;
                using var f2 = FileAccess.Open($"{stem}_outline.png", FileAccess.ModeFlags.Write);
                f2?.StoreBuffer(outline);
                SessionLog.Print($"[sketch] витрина {label}, {tag}: {_sketchCapture.LastReport}");
            }
        }

        sb.Append("]}");
        if (_galleryJsonPath != null)
            FileAccess.Open(_galleryJsonPath, FileAccess.ModeFlags.Write)?.StoreString(sb.ToString());

        // Возврат витрины в исходное состояние.
        ColoringBook.Infrastructure.Generation.Plants.PlantGenerator.Detail = detailBefore;
        ColoringBook.Infrastructure.Generation.Plants.PlantGenerator.AgeLevel = ageBefore;
        ColoringBook.Infrastructure.Generation.Plants.PlantGenerator.QualityLevel = qBefore;
        // Каталог пересобирается ПОСЛЕ возврата режима: GalleryShowAll перестраивает
        // ряд из того, что лежит в каталоге, а он собран последним шагом серии.
        ColoringBook.Infrastructure.Generation.Plants.PlantCatalog.RegenerateAll(_currentSeed);
        _view.GalleryShowAll();
        SessionLog.Print($"[telemetry] серия витрины записана: {_galleryJsonPath}, шагов {plan.Count}");
    }

    private string? _galleryJsonPath;

    /// <summary>
    /// СНИМКИ С ТОЧЕК ОБХОДА.
    ///
    /// Телеметрия отвечает, СКОЛЬКО чего в кадре и какого размера; снимок отвечает,
    /// КАК это выглядит — с тенями, шейдером рельефа и настоящими импосторами, чего
    /// в числах нет и чего не даёт внешняя отрисовка на стенде.
    ///
    /// Позы берутся ровно те же, что у телеметрии (LevelView3D.BuildSweepPoses), —
    /// иначе картинки и числа описывали бы разные места. Кладутся рядом с JSON, в
    /// папку с тем же именем.
    ///
    /// V113: снимаются ВСЕ позы обхода (не каждый 4-й). Иначе «под ноги» и боковые
    /// ракурсы есть только в JSON, а в галерее снимков — одна картинка на точку,
    /// часто не самый показательный азимут. Время обхода растёт, зато выборка
    /// совпадает с телеметрией один к одному.
    /// </summary>
    private async System.Threading.Tasks.Task CaptureSweepShotsAsync(string jsonPath, bool gallery = false)
    {
        if (_view == null || _sketchCapture == null) return;
        var poses = gallery ? _view.BuildGallerySweepPoses() : _view.BuildSweepPoses();
        if (poses.Count == 0) return;

        string dir = jsonPath.Replace(".json", "_shots");
        DirAccess.MakeDirRecursiveAbsolute(dir);

        var size = new Vector2I(1280, 720);
        float fov = GetViewport()?.GetCamera3D()?.Fov ?? 75f;
        int saved = 0;
        // ---- V298: РЕЖИМ ОСВЕЩЕНИЯ СТАВИТСЯ ЯВНО ----
        //
        // Обход наследовал режим, в котором оказался запуск. А режимы разводятся
        // сильно: рельефный ставит рассеянный свет 0.10 ради размаха светотени,
        // обзорный — 1.30 ради читаемости. Кадры, снятые в разных режимах, между
        // собой НЕСРАВНИМЫ, а обход для того и нужен, чтобы их сравнивать.
        //
        // Замер по снимкам V297 показал, чем это обернулось: доля точек темнее 0.10
        // составила 45.5% в среднем и 58.9% на кадрах с глаз, при том что замер
        // V262 тем же способом давал 0.4% и это считалось нормой. Половина кадра
        // проваливалась в чёрное, и мера пятен считала эту черноту одним пятном —
        // отсюда крупнейшее 0.45 при живописных 0.29.
        //
        // Берётся ОБЗОРНЫЙ режим: игрок видит уровень именно в нём, а рельефный —
        // рабочий, для разглядывания формы.
        bool lightingBefore = _reliefLighting;
        _reliefLighting = false;
        ApplyLightingMode();
        // Заморозка на весь цикл, а не на снимок: между снимками тоже проходят кадры.
        // try/finally обязателен — при исключении внутри цикла разморозить больше
        // некому, и игрок остался бы в мире с корзинами последней точки съёмки.
        // По той же причине в finally возвращается и режим освещения.
        _vegLodFrozen = true;
        try
        {
            for (int i = 0; i < poses.Count; i++)
            {
                var (pos, fwd, label) = poses[i];

                // ---- ПОЛОЖЕНИЕ КАМЕРЫ В ЖУРНАЛ ----
                //
                // Правки камеры делались вслепую: увидеть кадр без Godot нельзя,
                // и ошибку показывал только снимок пользователя.
                //
                // Здесь печатается высота камеры и земля под ней. Если камера
                // ниже земли — она под уровнем, и это видно ЧИСЛОМ.
                {
                    float ground = FarBackground.SampleHeightStatic(pos.X, pos.Z)
                                 + FarBackground.LiftStatic;
                    float above = (pos.Y - ground) * FarBackground.MetresPerUnit;
                    // ---- ОЖИДАЕМЫЙ ОХВАТ ----
                    //
                    // Прежде я считал высоту камеры на глазок и не проверял,
                    // войдёт ли снимаемое в кадр. Четверть попала вчетверо
                    // мельче нужного — клином посреди неба.
                    //
                    // Здесь печатается, сколько километров захватывает кадр при
                    // этой высоте: ошибка в разы видна БЕЗ снимка.
                    float coverKm = 2f * above / FarBackground.MetresPerUnit
                                  * Mathf.Tan(Mathf.DegToRad(fov * 0.5f))
                                  * FarBackground.MetresPerUnit / 1000f;
                    SessionLog.Print($"[кадр {i:D3}] {label}: камера "
                        + $"({pos.X * FarBackground.MetresPerUnit / 1000f:F1}, "
                        + $"{pos.Z * FarBackground.MetresPerUnit / 1000f:F1}) км, "
                        + $"над землёй {above:F0} м, взгляд вниз "
                        + $"{-fwd.Y * 100f:F0}%"
                        + $", охват {coverKm:F1} км"
                        + (above < 0 ? "   <-- ПОД УРОВНЕМ" : ""));
                }

                // ---- V128: СНИМАЮТСЯ НЕ ВСЕ ПОЗЫ ----
                //
                // Позы дают по четыре вида на точку: вперёд, назад, под ноги и бок. Числа
                // нужны со всех — они дёшевы и показывают разброс. А снимок весит около
                // полумегабайта, и архив логов раздувается настолько, что его тяжело
                // передавать.
                //
                // Для глаз достаточно двух видов на точку, и они разные по назначению:
                //   «вперёд» — общий план, состав и плотность растительности;
                //   «под ноги» — покрытие земли, прижим куртин к склону, колея тропы.
                //
                // ---- V165: «БОК» ДОБАВЛЕН, И ЭТО НЕ ПРИХОТЬ ----
                //
                // Довод «бок повторяет вперёд соседней точки» оказался неверен, и это
                // выяснилось дорого. Позы прогулки строятся вдоль КАСАТЕЛЬНОЙ к тропе,
                // поэтому «вперёд» и «назад» смотрят ВДОЛЬ колеи, а «под ноги» — прямо
                // в неё. На колее покрытий нет по решению V118, и все двадцать снимков
                // обхода оказались фотографиями голой тропы: за все сорок видов ни одна
                // куртина не была ближе 7.7 м.
                //
                // Замер по азимутам, куртин крупнее 50 точек экрана за весь обход:
                //   вперёд 1, под ноги 0  — снимались
                //   назад  5, бок      8  — не снимались
                // То есть в архив не попадали ровно те два вида, где земля живая.
                // ---- СНИМАЮТСЯ ВСЕ ПОЗЫ ----
                //
                // Прежний отбор шёл по именам «вперёд», «под ноги», «бок» — их
                // больше нет: позы переписаны под сверку с числами стенда и
                // называются «глаз 45°», «шар 90°», «обзор». Отбор давал НОЛЬ
                // снимков.
                //
                // Теперь поз тринадцать (восемь с высоты глаз, четыре с шара,
                // один обзорный), и снимаются все: сверять надо каждую, иначе
                // числа стенда не с чем сопоставить.

                // КОРЗИНЫ ПЕРЕСОБИРАЮТСЯ ПОД ТОЧКУ СНИМКА.
                //
                // Без этого разбор экземпляров остаётся посчитанным вокруг настоящей
                // камеры игрока: покрытия за шесть единиц от неё скрыты, и на каждом
                // снимке земля выходит голой независимо от того, сколько там травы.
                // Первый же обход со снимками это и показал.
                _view.ForceVegetationResort(pos);
                var img = await _sketchCapture.RenderViewAsync(_view, pos, fwd, fov, size);
                if (img == null) continue;
                // Полная подпись позы в имени: тропа_3__под_ноги, берег_2__вперёд_40
                // V113 fix: string.Replace для удаления "°" — char '' в C# недопустим (CS1011)
                string safe = label
                    .Replace(",", "_")
                    .Replace(" ", "_")
                    .Replace("°", "");
                string stem = $"{dir}/{i:D3}_{safe}";
                img.SavePng($"{stem}.png");

                // ---- ЧИСЛА ПО КАДРУ РЯДОМ СО СНИМКОМ ----
                //
                // Без них сверять числа стенда с картинкой приходится на глаз.
                // Считаем то же, что стенд: долю неба и число связных пятен после
                // сведения к трём тонам («чёрно-белый план» по Macpherson,
                // «прищур» по Szabo).
                //
                // По 60 репродукциям из книг: пятен 7-15 в четвертях, крупнейшее
                // около 29% кадра.
                var stat = FrameStats(img);
                SessionLog.Print($"[кадр] {label}: неба {stat.sky * 100:F0}%, "
                    + $"пятен {stat.regions}, крупнейшее {stat.largest * 100:F0}%, "
                    + $"ПУСТОТЫ {_lastVoidShare * 100:F0}% (в нижней половине {_lastVoidLower * 100:F0}%)");
                saved++;

                // ---- V165: ШАБЛОН РАСКРАСКИ И ДЛЯ УРОВНЯ ----
                //
                // Витрина строит шаблоны с V153, а уровень — нет, хотя продукт игры
                // это именно шаблон. Все решения об уровне (ширина тропы, покрытие
                // земли, геология) до сих пор принимались по цветным кадрам и
                // расчётам, то есть по промежуточному представлению.
                //
                // Отчёт печатается с меткой позы: без неё тридцать одинаковых строк
                // в консоли не отнести к точкам.
                var outline = await _sketchCapture.BuildOutlineFromPoseAsync(
                    _view, pos, fwd, fov, size);
                if (outline == null) continue;
                using var fo = FileAccess.Open($"{stem}_outline.png", FileAccess.ModeFlags.Write);
                fo?.StoreBuffer(outline);
                SessionLog.Print($"[sketch] обход {label}: {_sketchCapture.LastReport}");
            }
        }
        finally
        {
            _vegLodFrozen = false;
            _reliefLighting = lightingBefore;
            ApplyLightingMode();
        }
        // Вернуть корзины к настоящей камере: иначе после обхода игрок окажется в
        // мире, разобранном вокруг последней точки съёмки, и вокруг него не будет
        // ни травы, ни подробных мешей до следующего смещения.
        var real = GetViewport()?.GetCamera3D();
        if (real != null) _view.ForceVegetationResort(real.GlobalPosition);

        SessionLog.Print($"[telemetry] снимков сохранено: {saved} в {dir}");
    }

    /// <summary>Кадр, ожидающий решения игрока на экране предпросмотра.</summary>
    private byte[]? _pendingSource;
    private byte[]? _pendingOutline;
    private Camera3D? _pendingCamera;

    /// <summary>
    /// Решение игрока на предпросмотре. Здесь же выполняется то, что экран
    /// намеренно не делает сам: сохранение и построение контуров.
    /// </summary>
    private void OnPreviewAction(SketchPreviewScreen.PreviewAction action)
    {
        if (_previewScreen == null || _sketchRepo == null) return;

        if (action == SketchPreviewScreen.PreviewAction.Discard)
        {
            _pendingSource = null; _pendingOutline = null;
            _previewScreen.HideShot();
            return;
        }
        if (_pendingSource == null) { _previewScreen.HideShot(); return; }

        // Контуры построены вместе со снимком, поэтому «Сохранить» и «Редактировать»
        // отличаются только тем, куда уходит игрок.
        var sketch = BuildSketchEntity();
        _sketchRepo.Create(sketch, _pendingSource, _pendingOutline ?? System.Array.Empty<byte>());
        SessionLog.Print($"[sketch] сохранён: {sketch.Id}");

        _pendingSource = null; _pendingOutline = null;
        _previewScreen.HideShot();

        if (action == SketchPreviewScreen.PreviewAction.Edit)
            _router?.GoPainting(sketch.Id.Value);
    }

    /// <summary>
    /// Открыть раскраску. Контуры теперь всегда построены в момент съёмки, поэтому
    /// восстанавливать ракурс и перерисовывать сцену не требуется — вместе с этим
    /// исчез целый класс ошибок несовпадения кадра и контура.
    /// </summary>
    private void OnPaintingRequested(string sketchId) => _router?.GoPainting(sketchId);


    private Sketch BuildSketchEntity()
    {
        var now = System.DateTime.UtcNow;
        int seed = _currentSeed;
        int chunk = 0;      // чанков больше нет: уровень один
        var cam = _pendingCamera;
        var origin = new SketchOrigin(
            seed, chunk,
            cam?.GlobalPosition.X ?? 0f, cam?.GlobalPosition.Y ?? 0f, cam?.GlobalPosition.Z ?? 0f,
            _yaw, _pitch,
            _currentSeason.ToString());
        return Sketch.NewCapture(SketchId.FromCapture(now, seed, chunk), now, origin);
    }

    private SketchPreviewScreen? _previewScreen;
    private CanvasLayer? _levelHud;
    private SceneRouter? _router;
    private FileSketchRepository? _sketchRepo;
    private SketchCapture? _sketchCapture;
    private StartScreen? _startScreen;
    private GalleryScreen? _galleryScreen;
    private PaintingScreen? _paintingScreen;

    public override void _Ready()
    {
        // Подстраховка на случай, если статический конструктор по какой-то причине
        // ещё не отработал, плюс печать пути: чтобы не гадать, куда легли логи.
        // ---- КУДА ПИШЕТСЯ ЖУРНАЛ ----
        //
        // На НАСТОЛЬНОМ — в res://logs, то есть прямо в каталог проекта: так
        // журналы под рукой и их удобно забирать.
        //
        // На ТЕЛЕФОНЕ res:// доступен только для чтения, и первый запуск дал
        // «Read-only file system: /logs» и 43 ошибки подряд. Там пишем в user://
        // — внутреннюю папку приложения.
        string logDir = ProjectSettings.GlobalizePath(RunMode.LogPath);
        try { System.IO.Directory.CreateDirectory(logDir); }
        catch (System.Exception e) { GD.PushWarning($"[журнал] каталог не создан: {e.Message}"); }
        ColoringBook.Infrastructure.Generation.Diagnostics.GenerationLog.OverrideDirectory = logDir;
        SessionLog.Print("[bootstrap] каталог логов: "
                 + ColoringBook.Infrastructure.Generation.Diagnostics.GenerationLog.LogDirectory);

        // Растительность строит RingVegetationPlacer; старый VegetationPlacer с
        // его выключателем удалён.
        {
            PlantCatalog.EnsureGamePool();
            // Строка о состоянии самоорганизации печатается НЕ ЗДЕСЬ.
            //
            // Здесь она стояла в V161 и показала «выращено 0, осталось 0»: лиственные
            // собираются отложенно, при первом обращении, и на момент готовности
            // каталога счётчики ещё нулевые. Пометка «РОСТ ОБОРВАН» из-за этого не
            // появилась, хотя обрыв был — семь деревьев из девяти.
            //
            // Перенесена в LevelView3D, в точку, где выпечены все импосторы: к ней
            // лиственные заведомо построены.
            SessionLog.Print($"PlantCatalog ready: {PlantCatalog.VariantsPerKind} variants x kinds");
        }
        // Метка версии исходников. МЕНЯЕТСЯ С КАЖДОЙ ВЫДАЧЕЙ — по ней сразу видно, какая
        // версия реально лежит на диске и собирается. Раньше здесь был неизменный баннер
        // "Step 77", из-за чего рассинхрон между присланным архивом и файлами проекта
        // никак не проявлялся в консоли.
        SessionLog.Print("=== ColoringBook Bootstrap | BUILD STAMP: 2026-08-27-V438 (основание по воде: осадки, сток, проницаемость, сезоны)");
        LevelView3D.BuildStamp = "2026-08-27-V438";
        LevelView3D.LogShaderInventory();

        DisplayServer.WindowSetSize(new Vector2I(1400, 900));
        DisplayServer.WindowSetTitle("ColoringBook — Level Preview");

        // V37: медитативный потолок 30 fps.
        // V-Sync ВЫКЛЮЧЕН: при Enabled монитор часто держит 60 Hz и MaxFps игнорируется
        // (отсюда HUD показывал 60 при желаемых 10/30). Disabled + MaxFps даёт стабильный
        // потолок и для редактора, и для экспорта.
        DisplayServer.WindowSetVsyncMode(DisplayServer.VSyncMode.Disabled);
        // Потолок кадров. На телефоне замер дал время кадра 7-12 мс, то есть
        // устройство тянет 80-140 — потолок в 40 был искусственным.
        // Шестьдесят: плавно и не жжёт батарею зря.
        Engine.MaxFps = 60;
        SessionLog.Print($"[bootstrap] MaxFps={Engine.MaxFps}, VSync={DisplayServer.WindowGetVsyncMode()}");

        // ---- ПОДСИСТЕМА НАБРОСКОВ ----
        //
        // Собирается ЗДЕСЬ и только здесь: это композиционный корень. Дальше каждая
        // сцена получает уже готовые зависимости через Bind и не создаёт их сама —
        // иначе галерея знала бы про файловую систему, а раскраска про генерацию
        // уровня (книга, 4.5: направление зависимостей).
        _sketchRepo = new FileSketchRepository();

        _router = new SceneRouter { Name = "SceneRouter" };
        AddChild(_router);

        _sketchCapture = new SketchCapture { Name = "SketchCapture" };
        // Запас дальней плоскости обычного вида — полная диагональ области плюс
        // немного. Берётся у фона, а не задваивается числом: размер области
        // задают кольца.
        _sketchCapture.RenderFarMargin = FarBackground.OuterHalfDiagonalWorld * 2f + 400f;
        AddChild(_sketchCapture);

        // Layer выше, чем у HUD уровня (там значение по умолчанию 1): при
        // одинаковом слое порядок решался бы очерёдностью в дереве, а HUD
        // создаётся позже и оказался бы поверх меню.
        _startScreen = new StartScreen { Name = "StartScreen", Layer = 10 };
        AddChild(_startScreen);
        _startScreen.Bind(_router);

        _galleryScreen = new GalleryScreen { Name = "GalleryScreen", Layer = 10 };
        AddChild(_galleryScreen);
        _galleryScreen.Bind(_router, _sketchRepo);

        _previewScreen = new SketchPreviewScreen { Name = "SketchPreview" };
        AddChild(_previewScreen);
        _previewScreen.ActionChosen += OnPreviewAction;
        _router.PaintingRequested += OnPaintingRequested;

        _paintingScreen = new PaintingScreen { Name = "PaintingScreen", Layer = 10 };
        AddChild(_paintingScreen);
        _paintingScreen.Bind(_router, _sketchRepo);

        // ---- ОБЛЕГЧЁННОЕ ПОСТРОЕНИЕ НА МОБИЛЬНОМ ----
        //
        // Полное построение уровня занимает 28 секунд настольных. Телефон
        // примерно впятеро медленнее — две с половиной минуты, и игрок уйдёт
        // раньше, чем что-то увидит.
        //
        // На мобильном берём сетку поля 241 вместо 481, 180 итераций вместо 365
        // и не считаем окно уточнения. Замер: 3.7 с настольных вместо 28, то есть
        // около 18 на телефоне. Качество ниже (отклонение форм 31.5 против 16.8),
        // но задача этой сборки — узнать, ЗАПУСКАЕТСЯ ЛИ игра вообще.
        FarBackground.LiteBuild = RunMode.LiteBuild;
        TerrainCharacter.LiteIterations = RunMode.LiteIterations;
        SessionLog.Print($"[устройство] {RunMode.Describe()}");

        var graphics = new GraphicsSettings(
            RunMode.IsMobile ? GraphicsQuality.Low : GraphicsQuality.Medium, isAutoDetected: true);
        _graphics = graphics;
        // ---- ГЕНЕРАТОР УРОВНЯ БОЛЬШЕ НЕ НУЖЕН ----
        //
        // MapgenLevelGenerator удалён вместе со старым генератором: уровень
        // строится из наших колец (см. BuildLevelDataFromRings).
        //
        // LevelService оставлен: он хранит уровни, и это к генерации отношения
        // не имеет.
        ILevelSaveRepository repository = new JsonLevelSaveRepository();
        _levelService = new LevelService(repository);

        // ---- ОСВЕЩЕНИЕ ----
        // Режим ОСМОТРА (по умолчанию): ровный рассеянный свет по всей поверхности,
        // чтобы был виден ВЕСЬ результат генерации без затенённых участков. Тени
        // выключены, солнце ослаблено, а вместо одного заполняющего источника стоят
        // три — с разных сторон и сверху, чтобы ни один склон не оказался тёмным
        // независимо от его ориентации.
        //
        // ВАЖНАЯ ОГОВОРКА: форма поверхности читается глазом ТОЛЬКО через разницу
        // яркости между склонами. Ровный свет эту разницу убирает, поэтому рельеф в
        // этом режиме выглядит площе, чем он есть — это цена за отсутствие теней, а
        // не свойство генерации. Чтобы оценить настоящую форму гор, есть второй
        // режим (клавиша L) — низкое солнце с тенями и низким ambient.
        // ---- V83: ОДНО СОЛНЦЕ С ТЕНЯМИ ВМЕСТО ЧЕТЫРЁХ ИСТОЧНИКОВ ----
        //
        // Было: солнце плюс три заливающих источника, у всех тени выключены. В
        // Forward Mobile каждый DirectionalLight обсчитывается для КАЖДОГО фрагмента,
        // то есть при 1080x1920 три лишних источника стоили около 6 млн расчётов
        // освещения на кадр — и всё это ради того, чтобы заменить тени равномерной
        // засветкой со всех сторон.
        //
        // Стало: одно солнце с тенями плюс окружающий свет из WorldEnvironment.
        // Форма рельефа и объём крон читаются именно тенью, а не заливкой, поэтому
        // картинка выигрывает и по выразительности, и по стоимости.
        var light = new DirectionalLight3D
        {
            Name = "Sun",
            // Наклон 40°: достаточно низко, чтобы тени лепили рельеф, но не настолько,
            // чтобы половина долины ушла в темноту.
            RotationDegrees = new Vector3(-40, 40, 0),
            // ---- СВЕТ ПРИГЛУШЁН ----
            //
            // Было 1.05 от солнца при 1.30 рассеянного — вместе больше двойного.
            // Замер по снимку: 12.6% кадра ЯРЧЕ САМОГО СВЕТЛОГО ЦВЕТА ПАЛИТРЫ
            // (снега, 0.98), склоны выгорали добела, снег не отличался от
            // освещённого камня.
            //
            // Прежние величины подбирались на пологом рельефе, где склон редко
            // смотрел прямо на солнце. После досчитывания процесса (V253) уклоны
            // выросли вдвое, и подсветка стала бить в упор.
            // ---- СВЕТОТЕНЬ, А НЕ ПРОСТО ЯРКОСТЬ ----
            //
            // Замер по снимку уровня: размах светотени на земле 0.123, тогда как
            // на тех же высотах в стенде 0.429 — втрое меньше. Форма есть, но
            // светом не проявлена, и рельеф читается как бумага.
            //
            // Виноват не солнечный свет, а РАССЕЯННЫЙ: он добавляется ко всему
            // одинаково, независимо от наклона, и потому съедает тени. При
            // альбедо 0.70 склон в тени получал почти столько же, сколько
            // освещённый.
            //
            // Солнце поднято, рассеянный опущен. Подбор при альбедо 0.70:
            //
            //     солнце  рассеян | освещ.  тень  размах
            //       0.85    0.75  |   1.12  0.61    0.51   было
            //       1.35    0.25  |   1.12  0.29    0.83   пробивает потолок
            //       1.20    0.10  |   0.91  0.17    0.74   взято
            //       1.15    0.20  |   0.94  0.24    0.71
            //
            // Освещённый склон не должен доходить до единицы, иначе света снова
            // не хватит на разницу между ним и вершиной.
            LightEnergy = 1.20f,
            ShadowEnabled = true,
            ShadowBlur = 1.0f,

            // ---- V95: СМЕЩЕНИЯ ТЕНИ ПЕРЕСЧИТАНЫ ПОД МАСШТАБ МИРА ----
            //
            // Было ShadowNormalBias = 2.0 и ShadowBias = 0.055. Эти значения
            // подбирались, когда единица мира считалась метром. Сейчас в единице
            // около десяти метров (LevelView3D.MetresPerUnit): дерево — три единицы,
            // рост игрока — 0.17. Смещение по нормали в 2.0 при таком масштабе
            // сдвигает выборку тени почти на две высоты дерева, и тень отрывается от
            // ствола — тот самый эффект «тени лежат не на уровне, а под ним».
            // Оба смещения уменьшены примерно в десять раз, как и всё остальное.
            ShadowNormalBias = 0.22f,
            ShadowBias = 0.005f,

            // Дальность теней. Было 150 — это вся сторона чанка целиком, и
            // разрешение карты теней размазывалось на полтора километра. Тень от
            // дерева при этом занимала считаные тексели и расплывалась в пятно,
            // непохожее на крону. Шестьдесят единиц покрывают ближний и средний
            // план, где тени и читаются.
            DirectionalShadowMaxDistance = 60f,
            // Комментарий здесь говорил про три каскада, а в коде стояло два. Два и
            // оставляем — на мобильном рендерере это верный выбор, — но теперь
            // подпись совпадает с делом.
            DirectionalShadowMode = DirectionalLight3D.ShadowMode.Parallel2Splits,
            // ---- ТЁПЛОЕ СОЛНЦЕ ПРОТИВ ХОЛОДНОЙ ТЕНИ (Rowell) ----
            //
            // «Дважды в день холодный синий свет ночи взаимодействует с тёплыми
            // тонами дня... тёплый прямой свет падает на части земли, которые
            // освещены и холодным отражённым светом вечера.»
            //
            // Было солнце (1.00, 0.97, 0.90) при рассеянном (0.86, 0.88, 0.92) —
            // разница по синеве всего 0.02, то есть свет почти нейтральный и
            // разведения тёплого с холодным не даёт.
            //
            // Разводим заметнее: солнце к янтарному, тень к синему. Это и есть
            // то, ради чего снимают в «волшебный час».
            LightColor = new Color(1.0f, 0.92f, 0.78f)
        };
        _sun = light;
        AddChild(light);

        // V40: туман убран — чёрный фон даёт контраст с рельефом.
        // «Дыры» горизонта закрываем inset ствола + rim-горами, а не fog.
        var ambient = new WorldEnvironment
        {
            Name = "Env",
            Environment = new Godot.Environment
            {
                BackgroundMode = Godot.Environment.BGMode.Color,
                // ---- V299: НЕБО СВЕТЛОЕ, А НЕ ЧЁРНОЕ ----
                //
                // Чёрное небо ставилось ради контраста с уровнем, и для
                // разглядывания формы оно и правда удобнее. Но у него две цены,
                // и обе вскрылись замером.
                //
                // ПЕРВАЯ: пустота неотличима от рельефа. Там, где геометрии нет,
                // окно заливается цветом фона. На V298 нижние 45% кадров с глаз
                // оказались пустыми, и разглядеть это удалось только тем, что
                // точки там ровно нулевые, — при рассеянном свете 1.30 такого не
                // бывает. Со светлым небом дыра видна сразу и глазом, и мерой.
                //
                // ВТОРАЯ: мера неба ищет точки ярче 0.80 (GameBootstrap.FrameStats).
                // Фон кадров с глаз был (44,51,68), яркость 0.21, и порог не
                // брался никогда: журнал писал «неба 0%» во всех тринадцати
                // кадрах при том, что неба в них треть. Замер по снимкам V297 и
                // V298 это подтвердил.
                //
                // Цвет: светлый холодный, яркость 0.82 — выше порога с запасом, и
                // от воды отличается: у той поверхность тёмная и с бликом.
                // По Carlson небо и обязано быть самым светлым из четырёх
                // первичных плоскостей.
                BackgroundColor = SkyColor,
                AmbientLightSource = Godot.Environment.AmbientSource.Color,
                // Тень холодная: отражённый свет неба синий (см. LightColor выше).
                AmbientLightColor = new Color(0.62f, 0.72f, 0.95f),
                // Окружение заменяет три убранных заливающих источника: оно даёт
                // тот же мягкий свет со всех сторон, но считается один раз, а не
                // отдельным проходом освещения на каждый фрагмент.
                //
                // V84: поднято с 0.75 до 1.30. Подсчёт суммарной светимости показал,
                // что при замене четырёх источников на один она упала на 35%
                // (2.75 -> 1.80), причём сильнее всего пострадали склоны, отвёрнутые
                // от солнца: три заливки покрывали их со всех сторон, а одно солнце
                // не покрывает вовсе. Уровень стал заметно темнее — это и было видно.
                // Рассеянный свет тоже понижен: вместе с солнцем он давал больше
                // двойной яркости и съедал весь цвет.
                // ---- РАССЕЯННЫЙ СВЕТ ПОДНЯТ С 0.10 ДО 0.55 ----
                //
                // При 0.10 тени проваливались в черноту, и ЧЁРНЫЙ ПИГМЕНТ
                // забирал 58% расхода при цели не более трети. Осветление
                // самого леса не помогало: 60% против 58%.
                //
                // Подбор по трём мерам сразу, на настоящем освещении игры:
                //
                //     рассеянный  ходовой        светотень  насыщ  пятен
                //        0.10     чёрная  58%      0.61      0.13   7.2
                //        0.40     чёрная  37%      0.56      0.20   7.0
                //        0.55     зелёная 29%      0.53      0.22   9.8  взято
                //        0.70     зелёная 36%      0.51      0.25   9.0
                //     живопись    не более 33%   0.40-0.57 0.11-0.22 4-13
                //
                // Опасение V256 («рассеянный съедает тени») было верным для
                // РАВНОМЕРНОГО белого света. Здесь тень ХОЛОДНАЯ и синяя, а
                // солнце тёплое: разведение по теплоте держит светотень даже
                // при сильном рассеянном. Это ровно то, о чём Rowell.
                AmbientLightEnergy = 0.55f,
                FogEnabled = false
            }
        };
        _env = ambient;
        AddChild(ambient);

        _view = new LevelView3D { Name = "LevelView3D" };
        AddChild(_view);

        _camera = new Camera3D
        {
            Name = "Camera3D",
            // ---- ДАЛЬНЯЯ ПЛОСКОСТЬ: ДО УГЛА, А НЕ ДО КРАЯ ----
            //
            // Было MaxOrbitDistance + 1000 = 4600. Я считал запас от предела орбиты,
            // забыв, что область фона КВАДРАТНАЯ: до её угла ещё полудиагональ.
            //
            //     полуширина внешнего кольца 2880, полудиагональ 4073
            //     камера на пределе орбиты    3600
            //     до дальнего угла            7673  — на 3073 дальше плоскости
            //
            // Угол отсекался конусом видимости, и на снимках пропадал тем сильнее,
            // чем дальше отлетала камера.
            Far = MaxOrbitDistance + FarBackground.OuterHalfDiagonalWorld + 400f,
            // Ближняя плоскость поднята с 0.1: при дальней в восемь тысяч отношение
            // 80000 к одному съедает точность буфера глубины, и дальние грани
            // начинают мерцать друг сквозь друга.
            Near = 0.5f,
        };
        AddChild(_camera);
        _camera.MakeCurrent();
        UpdateCamera();

        // Единый стиль надписей HUD задаётся ниже одним методом, а не тремя разными
        // цветами вразнобой, как было.
        var canvas = new CanvasLayer { Name = "UI" };
        // HUD уровня — отдельный CanvasLayer, поэтому маршрутизатор не спрячет его
        // вместе с 3D-сценой автоматически. Запоминаем, чтобы гасить вручную.
        _levelHud = canvas;
        AddChild(canvas);
        _infoLabel = new Label
        {
            Name = "InfoLabel",
            Position = new Vector2(16, 16),
            Text = "Up=new gen | LMB orbit | Wheel zoom"
        };
        _infoLabel.AddThemeFontSizeOverride("font_size", 18);
        ApplyHudTextStyle(_infoLabel);
        canvas.AddChild(_infoLabel);

        // Отдельная строка с текущим положением камеры (позиция/углы/дистанция) —
        // обновляется из UpdateCamera() при КАЖДОМ изменении камеры (орбита, зум, панорама),
        // а не только по отдельным клавишам, чтобы всегда показывать актуальный ракурс.
        _camInfoLabel = new Label
        {
            Name = "CameraInfoLabel",
            Position = new Vector2(16, 40),
            Text = ""
        };
        _camInfoLabel.AddThemeFontSizeOverride("font_size", 15);
        ApplyHudTextStyle(_camInfoLabel);
        canvas.AddChild(_camInfoLabel);

        // Строка нагрузки: FPS / frame ms / draw calls / примитивы / LOD растительности.
        // Обновляется раз в ~0.5 с из _Process, в лог пишется реже (~3 с).
        _perfLabel = new Label
        {
            Name = "PerfLabel",
            Position = new Vector2(16, 62),
            Text = "perf: …"
        };
        _perfLabel.AddThemeFontSizeOverride("font_size", 14);
        ApplyHudTextStyle(_perfLabel);
        canvas.AddChild(_perfLabel);

        // ---- ПАНЕЛЬ НАСТРОЙКИ ГЕНЕРАЦИИ УБРАНА ----
        //
        // Она правила настройки СТАРОГО генератора, которого больше нет. Ветки,
        // показывающие её по клавише, проверяют поле на пустоту и просто ничего
        // не делают.
        _debugPanel = null;

        // Стартовый режим задаётся константой StartupMode выше (сейчас — карта уровня).
        // Переключение в любой момент — клавиша P.
        // ---- НА МОБИЛЬНОМ УРОВЕНЬ НЕ СТРОИТСЯ ПРИ ЗАПУСКЕ ----
        //
        // ApplyViewMode(StartupMode) строит уровень ЗДЕСЬ, в _Ready, до того как
        // маршрутизатор покажет стартовый экран. На настольном это незаметно —
        // полминуты и готово. На телефоне построение идёт в главном потоке
        // десятки секунд, и приложение выглядит зависшим: первый запуск на
        // устройстве показал именно это.
        //
        // Стартовый экран всё равно откроется ниже вызовом GoStart(), поэтому на
        // мобильном достаточно НЕ СТРОИТЬ уровень заранее — он построится при
        // нажатии кнопки «Открыть игровой уровень», когда игрок этого ждёт.
        if (RunMode.BuildLevelOnStartup)
        {
            SessionLog.Print($"[bootstrap] StartupMode = {StartupMode}");
            ApplyViewMode(StartupMode);
            _levelBuilt = true;
        }
        else
            SessionLog.Print("[bootstrap] уровень строится по кнопке, не при запуске");
        // Регистрация в маршрутизаторе — ПОСЛЕДНИМ шагом _Ready, когда 3D-сцена уже
        // построена: иначе он спрятал бы ещё не созданные узлы.
        _router?.Register(_startScreen, this, _galleryScreen, _paintingScreen);
        if (_router != null)
            _router.ScreenChanged += screen =>
            {
                if (_levelHud != null)
                    _levelHud.Visible = screen == SceneRouter.Screen.Level;

                // ---- ПОСТРОЕНИЕ ПО ТРЕБОВАНИЮ ----
                //
                // GoLevel() только переключает экран, построения не запускает. На
                // настольном это работало, потому что уровень строился заранее в
                // _Ready. На мобильном мы это убрали (иначе приложение выглядит
                // зависшим при запуске), и без этой ветки кнопка «Открыть игровой
                // уровень» открывала бы пустоту.
                if (screen == SceneRouter.Screen.Level && !_levelBuilt)
                {
                    _levelBuilt = true;
                    SessionLog.Print("[bootstrap] построение уровня по нажатию кнопки");
                    ApplyViewMode(ViewMode.Level);
                }
            };
        if (_levelHud != null) _levelHud.Visible = false;
        _router?.GoStart();

    }

    /// <summary>
    /// Единая точка переключения между картой уровня и витриной растений. Обе ветки
    /// ЯВНО приводят сцену в нужное состояние (видимость рельефа/рек/растительности,
    /// камера, HUD), чтобы режим не зависел от того, что осталось от предыдущего.
    /// </summary>
    /// <summary>
    /// Освещение под режим. Ландшафту нужен контраст: сильное солнце с тенями и низкая
    /// заливка, иначе форма склонов не читается («парафин»). Витрине растений — наоборот,
    /// мягкий равномерный свет: там важен силуэт отдельного растения на пустом фоне,
    /// и жёсткие тени только мешают.
    /// </summary>
    private void ApplyLighting(ViewMode mode)
    {
        // ОСВЕЩЕНИЕ ВОЗВРАЩЕНО К ПРЕЖНЕМУ по просьбе пользователя (31.07): вариант с
        // жёстким солнцем и тенями картинку не улучшил. Метод остаётся точкой входа,
        // если к освещению вернёмся.
        _ = mode;
    }

    private void ApplyViewMode(ViewMode mode)
    {
        _viewMode = mode;
        ApplyLighting(mode);
        if (mode == ViewMode.PlantGallery)
        {
            _boatActive = false;
            // V55b: маркеры русла/троп — только на уровне, не на витрине растений.
            _view!.SetStemMarkersVisible(false);
            _camMode = 0;
            // Сначала раскладка (считает bbox → GalleryFocusHeight / GalleryCameraDistance),
            // потом камера к актуальному центру. Раньше target Y брался до раскладки
            // из устаревшей константы 11.2 — сверху всегда оставался «воздух».
            _view!.EnterPlantGallery();
            _pitch = 0.28f;
            _yaw = 0.35f;
            SyncGalleryCamera();
            _infoLabel.Text = "[PLANTS]  " + _view!.GalleryStatus();
            SessionLog.Print("[bootstrap] mode=PlantGallery (test scene). P = switch to level map.");
        }
        else
        {
            // Явно возвращаем рельеф/реки/растительность в видимое состояние и убираем
            // ряд растений витрины — не полагаемся на то, что витрина не была активна.
            _view!.ExitPlantGallery();
            _camMode = 0;

            // ---- ЦЕЛЬ КАМЕРЫ — СЕРЕДИНА УРОВНЯ, А НЕ НУЛЬ ----
            //
            // Прежде здесь стояло Vector3.Zero. При уровне 115 км нуль лежал
            // близко к середине, и разница не бросалась в глаза.
            //
            // При 231 км нуль — это УГОЛ уровня, и камера вращалась вокруг
            // угла. Замечено пользователем в прогоне.
            _target = LevelCenter();
            _distance = 120f;
            _pitch = 0.55f;
            _yaw = 0.55f;
            GenerateAndShow(_currentSeed);
            // Прежде здесь печаталось «mode=Level», а строкой выше уже стояло
            // «StartupMode = Level» — дубль. Осталась лишь подсказка о клавише.
            SessionLog.Print("[bootstrap] P — переключиться в galleryPlants");
            SessionLog.Print("[bootstrap] " + _view.DescribeSceneState());
        }
    }

    public override void _UnhandledInput(InputEvent @event)
    {
        if (@event is InputEventKey key && key.Pressed && !key.Echo)
        {
            // ---- W = СКРЫТЬ ВОДУ (опыт, а не правка) ----
            //
            // За четыре сборки сделано пять правок в погоне за тонкими синими
            // линиями, и каждая трогала свою подсистему: уровень ленты, подпор,
            // два шейдера, цвет, край территории. Часть были настоящими
            // исправлениями, найденными замером, но ПРИЧИНА ЛИНИЙ так и не
            // установлена — я чинил то, что попадалось по дороге, и одну правку
            // уже пришлось откатить.
            //
            // Опыт закрывает вопрос одним прогоном: скрыть меш воды. Если линии
            // исчезнут — это лента, и дальше чинить её предметно. Если останутся —
            // это рельеф или что-то третье, и все правки воды были мимо.
            if (key.Keycode == Key.W)
            {
                _view.ToggleWaterVisible();
                _infoLabel.Text = _view.WaterVisibilityStatus();
                return;
            }

            // H = скрыть РЕЛЬЕФ. Вместе с W это делит картинку на слои: если
            // линии остаются и без воды, и без рельефа — их рисует что-то третье.
            // Клавиша T занята обходом уровня, поэтому H.
            if (key.Keycode == Key.H && !IsGalleryMode)
            {
                _view.ToggleTerrainVisible();
                return;
            }

            // R = новый уровень (новый seed). В ВИТРИНЕ — новый набор растений:
            // раньше клавиша там просто ничего не делала, хотя пересобрать формы для
            // сравнения — ровно то, зачем витрина и нужна.
            if (key.Keycode == Key.R)
            {
                if (IsGalleryMode)
                {
                    _plantSeed = unchecked(_plantSeed * 1103515245 + 12345);
                    if (_plantSeed == 0) _plantSeed = 1;
                    PlantCatalog.RegenerateAll(_plantSeed);
                    _view.GalleryRefresh();
                    _infoLabel.Text = _view.GalleryStatus();
                    SessionLog.Print($"[bootstrap] витрина: новый plantSeed = {_plantSeed}");
                    return;
                }
                _currentSeed = unchecked(_currentSeed * 1103515245 + 12345);
                if (_currentSeed == 0) _currentSeed = 1;
                GenerateAndShow(_currentSeed);
                return;
            }

            // P = переключение между картой уровня и витриной растений.
            // PlantGalleryEnabled — константа, поэтому компилятор заранее знает, какая
            // ветка исполнится, и помечает вторую как недостижимую (CS0162). Это
            // ожидаемо и безвредно: смысл флага именно в том, чтобы витрину можно было
            // включить обратно правкой одной константы, не трогая логику. Подавляем
            // предупреждение точечно, только на этот блок.
            // F — СНИМОК. Работает только на уровне: в галерее и на раскраске
            // фотографировать нечего.
            if (key.Keycode == Key.F && _router?.Current == SceneRouter.Screen.Level)
            {
                _ = TakeSketchAsync();
                return;
            }

            // T — ТЕЛЕМЕТРИЯ КАДРА.
            //
            // Пишет JSON с тем, что реально попало на экран: по каждому виду и корзине
            // LOD число экземпляров В ПИРАМИДЕ ВИДИМОСТИ, гистограмма их экранного
            // размера и стоимость в треугольниках. Счётчики HUD отвечают на вопрос
            // «сколько их», телеметрия — на вопрос «видно ли их», а расходились эти
            // два вопроса на порядки: 383 куртины травы в радиусе скрытия при пустой
            // на вид земле.
            if (key.Keycode == Key.T && _router?.Current == SceneRouter.Screen.Level)
            {
                var vp = GetViewport();
                float fov = vp?.GetCamera3D()?.Fov ?? 75f;
                var size = vp?.GetVisibleRect().Size ?? new Vector2(1920, 1080);
                // В ВИТРИНЕ — ОБХОД ПО ДИСТАНЦИЯМ, а не по местам уровня.
                //
                // Витрина ставит все виды в ряд, поэтому серия кадров с разных
                // дистанций показывает все растения во всех уровнях детализации разом.
                // Это и есть удобный стенд для отладки геометрии: дефект вроде
                // «прореженный меш превратился в плоские доски» виден сразу и по всем
                // породам, а не вылавливается по одному в кадрах прогулки.
                if (_view.IsGalleryActive)
                {
                    _ = CaptureGallerySeriesAsync(fov, size);
                    return;
                }

                // Телеметрия пересобирает корзины под каждую позу (см. BuildSweepJson),
                // поэтому после неё мир разобран вокруг последней точки обхода, а не
                // вокруг игрока. Возвращаем сразу: иначе до следующего смещения камеры
                // вокруг игрока не будет ни травы, ни подробных мешей.
                string json = _view.BuildLevelSweepJson(fov, size);
                if (_camera != null) _view.ForceVegetationResort(_camera.GlobalPosition);
                string path = ColoringBook.Infrastructure.Generation.Diagnostics.GenerationLog
                    .WriteRaw(json, _currentSeed, "sweep");
                SessionLog.Print($"[telemetry] обход уровня записан: {path}");
                // Снимки идут отдельной задачей: каждый требует двух кадров ожидания,
                // и удерживать ввод на время двадцати восьми снимков нельзя.
                _ = CaptureSweepShotsAsync(path);
                return;
            }

            // I — отладочная заливка импосторов сплошным пурпурным.
            if (key.Keycode == Key.I && _router?.Current == SceneRouter.Screen.Level)
            {
                bool on = _view.ToggleImpostorDebug();
                SessionLog.Print(on
                    ? "[impostor] отладка: карточки залиты пурпурным. Видны — геометрия верна, дело в атласе; не видны — карточка не доходит до экрана."
                    : "[impostor] отладка выключена.");
                return;
            }

            // G — галерея из любого места уровня.
            if (key.Keycode == Key.G && _router?.Current == SceneRouter.Screen.Level)
            {
                _router.GoGallery();
                return;
            }

            if (key.Keycode == Key.P)
            {
#pragma warning disable CS0162
                if (!PlantGalleryEnabled)
                {
                    SessionLog.Print("[bootstrap] Витрина растений отключена (PlantGalleryEnabled = false).");
                    return;
                }
                ApplyViewMode(_viewMode == ViewMode.Level ? ViewMode.PlantGallery : ViewMode.Level);
#pragma warning restore CS0162
                return;
            }

            // G зарезервирован. Вход в витрину растений — на P (см. обработчик выше).
            if (key.Keycode == Key.G)
            {
                return;
            }

            // T — панель параметров генерации.
            if (key.Keycode == Key.T)
            {
                if (IsGalleryMode) return;
                if (_debugPanel != null)
                {
                    _debugPanel.Visible = !_debugPanel.Visible;
                    SessionLog.Print(_debugPanel.Visible
                        ? "[debug] панель генерации показана"
                        : "[debug] панель генерации скрыта");
                }
                return;
            }

            // L — переключение режима освещения.
            // Ровный свет удобен для ОСМОТРА (виден весь уровень, нет тёмных мест),
            // но он же скрадывает форму рельефа: объём читается только через разницу
            // яркости склонов. Поэтому второй режим — низкое солнце с тенями.
            if (key.Keycode == Key.L)
            {
                _reliefLighting = !_reliefLighting;
                ApplyLightingMode();
                SessionLog.Print(_reliefLighting
                    ? "[light] режим РЕЛЬЕФ: солнце с тенями, низкий ambient"
                    : "[light] режим ОСМОТР: ровный рассеянный свет");
                return;
            }

            // V301: клавиша M убрана. Она переключала RiverWorld ↔ legacy —
            // два режима СТАРОГО генератора чанка. Генератора нет, режим один,
            // и переключатель только перестраивал уровень тем же способом.

            if (key.Keycode == Key.S)
            {
                // skeleton-debug для SCA-скелета растений (см. PlantGenerator).
                PlantGenerator.SkeletonDebugMode = !PlantGenerator.SkeletonDebugMode;
                if (IsGalleryMode)
                {
                    _view.GalleryRefresh();
                    _infoLabel.Text = _view.GalleryStatus();
                    SyncGalleryCamera(preserveZoom: true);
                }
                return;
            }

            // Клавиши-цифры зависят от режима: в витрине это вкл/выкл ПОРОДЫ дерева
            // (1-9 по порядку записей витрины: 3 ели, 3 сосны, 3 лиственных), на карте
            // уровня — выбор сезона (1-4).
            //
            // Раньше цифры переключали ТИП растения (Pine/Fir/.../Reed). Теперь пород
            // по три на каждое дерево, и сравнивать нужно именно их, поэтому единицей
            // переключения стала порода.
            if (key.Keycode >= Key.Key1 && key.Keycode <= Key.Key9)
            {
                if (IsGalleryMode)
                {
                    // Godot.Key имеет базовый тип long, поэтому разность нужно явно
                    // привести к int (CS0266).
                    int idx = (int)(key.Keycode - Key.Key1);
                    if (idx < LevelView3D.GalleryEntryCount) ToggleGalleryEntry(idx);
                }
                else if (key.Keycode <= Key.Key4)
                {
                    _currentSeason = key.Keycode switch
                    {
                        Key.Key1 => SeasonType.Spring,
                        Key.Key2 => SeasonType.Summer,
                        Key.Key3 => SeasonType.Autumn,
                        _ => SeasonType.Winter
                    };
                    GenerateAndShow(_currentSeed);
                }
                return;
            }

            // Клавиша V (отладочная отрисовка растительности примитивами) УДАЛЕНА.
            // Она подменяла растения цветными кубами и шарами, и после случайного
            // нажатия выглядело так, будто растения пропали. Данные, ради которых она
            // была нужна, теперь пишутся в лог (_plants.json), смотреть глазами не надо.
            // Сам флаг LevelView3D.DebugPrimitiveVegetation оставлен и по умолчанию
            // выключен — вернуть переключатель можно одной строкой.

            if (key.Keycode == Key.C)
            {
                if (IsGalleryMode) return;
                // V122: C только Orbit ↔ Player (режим Low убран из цикла — путал отладку).
                if (_boatActive)
                {
                    _boatActive = false;
                    _view?.SetStemMarkersVisible(true);
                    SessionLog.Print("[bootstrap] boat OFF (via C)");
                }
                if (_camMode == 2)
                {
                    _camMode = 0; // → орбита
                    ApplyCameraMode();
                    SessionLog.Print("[bootstrap] camera: Orbit");
                }
                else
                {
                    _camMode = 2; // → игрок (прогулка)
                    ApplyCameraMode();
                    PlaceInValley();
                    SessionLog.Print("[bootstrap] camera: Player");
                }
                UpdateCamera();
                RefreshCamModeHud(); // V123: строка HUD иначе навсегда cam:Orbit с генерации
                return;
            }

            // B — вкл/выкл дрейф по main stem (только RiverWorld).
            if (key.Keycode == Key.B)
            {
                if (IsGalleryMode) return;
                _boatActive = !_boatActive;
                if (_boatActive)
                {
                    _camMode = 2;
                    _camSmoothInit = false;
                    _view?.SetStemMarkersVisible(false);
                    ApplyCameraMode();
                    if (_boatChunk < 0) _boatChunk = 0;
                    // ---- СПЛАВ ОТКЛЮЧЁН ----
                    //
                    // Он шёл по руслу СТАРОГО генератора, разбитому на чанки.
                    // Генератор удалён; сплав вернётся, когда лодку поведём по
                    // нашему руслу — по дренажу поля.
                    SessionLog.Print($"[bootstrap] boat ON  speed={_boatSpeed:F0} ch={_boatChunk} pathLen={_boatPathLen:F0}");
                }
                else
                {
                    _view?.SetStemMarkersVisible(true);
                    _camMode = 0;
                    ApplyCameraMode();
                    SessionLog.Print("[bootstrap] boat OFF → overview");
                }
                UpdateCamera();
                RefreshCamModeHud();
                return;
            }

            // Arrow keys: move relative to look direction (Up = forward into the view)
            // ШАГ ПЕРЕМЕЩЕНИЯ. В режиме игрока — в метрах: 4 единицы это сорок метров,
            // то есть не шаг, а прыжок через полполяны, и «неспешная прогулка»
            // превращалась в телепортацию. Восемь метров на нажатие — примерно
            // пять секунд ходьбы, при удержании клавиши получается ровное движение.
            // Орбитальная камера остаётся крупношаговой: она обозревает долину.
            float pan = _camMode == 2 ? 8f / LevelView3D.MetresPerUnit : 10f;
            float fx = -Mathf.Sin(_yaw), fz = -Mathf.Cos(_yaw);
            float rx =  Mathf.Cos(_yaw), rz = -Mathf.Sin(_yaw);
            // Up: в витрине — новое поколение растений; на карте уровня — шаг вперёд.
            if (key.Keycode == Key.Up)
            {
                if (IsGalleryMode)
                {
                    // РАЗДЕЛЕНО НА ДВЕ КЛАВИШИ. Раньше одно нажатие меняло СРАЗУ ДВЕ
                    // вещи: и сид растений, и уровень качества (gen N -> quality N-1).
                    // Сравнивать формы так невозможно: непонятно, изменилась форма от
                    // нового сида или от другой детализации.
                    //   Shift+Up — новый сид при том же качестве
                    //   Ctrl+Up / Ctrl+Down — качество вверх/вниз при том же сиде
                    if (key.AltPressed)
                    {
                        _view.GalleryChangeAge(+1);
                    }
                    else if (key.CtrlPressed)
                    {
                        _view.GalleryChangeQuality(+1);
                    }
                    else if (key.ShiftPressed)
                    {
                        _view.GalleryNewSeed();
                    }
                    else
                    {
                        // Голая стрелка оставлена как прежде — новый сид, чтобы
                        // привычный сценарий не сломался.
                        _view.GalleryNewSeed();
                    }
                    _infoLabel.Text = _view.GalleryStatus();
                    // Age/quality/seed: обновляем только target, зум пользователя сохраняем.
                    SyncGalleryCamera(preserveZoom: true);
                }
                else
                {
                    TryPan(new Vector3(fx, 0, fz) * pan);
                }
                return;
            }

            if (key.Keycode == Key.Down && IsGalleryMode && (key.CtrlPressed || key.AltPressed))
            {
                if (key.AltPressed) _view.GalleryChangeAge(-1);
                else _view.GalleryChangeQuality(-1);
                _infoLabel.Text = _view.GalleryStatus();
                SyncGalleryCamera(preserveZoom: true);
                return;
            }
            if (key.Keycode == Key.Down)
            {
                if (!IsGalleryMode) TryPan(new Vector3(-fx, 0, -fz) * pan);
                return;
            }

            // Left / Right — в витрине лёгкий поворот вокруг ряда, на карте — шаг вбок.
            if (key.Keycode == Key.Left)
            {
                if (IsGalleryMode) { _yaw -= 0.12f; UpdateCamera(); }
                else TryPan(new Vector3(-rx, 0, -rz) * pan);
                return;
            }
            if (key.Keycode == Key.Right)
            {
                if (IsGalleryMode) { _yaw += 0.12f; UpdateCamera(); }
                else TryPan(new Vector3(rx, 0, rz) * pan);
                return;
            }
        }

        if (@event is InputEventMouseButton mb)
        {
            if (mb.ButtonIndex == MouseButton.Left)
                _dragging = mb.Pressed;

            if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelUp)
            {
                if (_boatActive)
                {
                    _boatSpeed = Mathf.Min(BoatSpeedMax, _boatSpeed + BoatSpeedStep);
                    SessionLog.Print($"[boat] speed={_boatSpeed:F0} map-u/s");
                    return;
                }
                if (_camMode == 2)
                {
                    float wfx = -Mathf.Sin(_yaw), wfz = -Mathf.Cos(_yaw);
                    TryPan(new Vector3(wfx, 0, wfz) * 3f);
                    return;
                }
                else
                    _distance = Mathf.Max(IsGalleryMode ? 3f : 40f, _distance * 0.9f);
                UpdateCamera();
            }
            else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelDown)
            {
                if (_boatActive)
                {
                    _boatSpeed = Mathf.Max(BoatSpeedMin, _boatSpeed - BoatSpeedStep);
                    SessionLog.Print($"[boat] speed={_boatSpeed:F0} map-u/s");
                    return;
                }
                if (_camMode == 2)
                {
                    float wfx2 = -Mathf.Sin(_yaw), wfz2 = -Mathf.Cos(_yaw);
                    TryPan(new Vector3(-wfx2, 0, -wfz2) * 3f);
                    return;
                }
                else
                    // ---- V180: ОТЛЁТ ДО ВСЕГО УРОВНЯ ----
                    //
                    // Было 380 единиц = 3.8 км при области фона в 24 км: увидеть
                    // уровень целиком не получалось. Предел поднят до полутора
                    // размеров области, чтобы она помещалась в кадр с запасом.
                    _distance = Mathf.Min(MaxOrbitDistance, _distance * 1.1f);
                UpdateCamera();
            }
        }

        if (@event is InputEventMouseMotion mm && _dragging)
        {
            if (_boatActive)
            {
                // На лодке мышь крутит взгляд ОТНОСИТЕЛЬНО течения; базовый yaw
                // каждый кадр берётся из касательной русла в PlaceBoatOnStem.
                _lookYawOffset -= mm.Relative.X * 0.005f;
                _lookYawOffset = Mathf.Clamp(_lookYawOffset, -1.2f, 1.2f);
                _pitch -= mm.Relative.Y * 0.004f;
                _pitch = Mathf.Clamp(_pitch, -0.15f, 0.45f);
            }
            else
            {
                _yaw -= mm.Relative.X * 0.005f;
                if (_camMode == 2)
                {
                    _pitch -= mm.Relative.Y * 0.004f;
                    _pitch = Mathf.Clamp(_pitch, -0.12f, 0.50f);
                }
                else
                {
                    _pitch += mm.Relative.Y * 0.005f;
                    _pitch = Mathf.Clamp(_pitch, -Mathf.Pi / 4f, 1.45f);
                }
            }
            UpdateCamera();
        }
    }

    private void ApplyCameraMode()
    {
        switch (_camMode)
        {
            case 0: // обзор
                // ---- ЦЕЛЬ НЕ СБРАСЫВАЕТСЯ В НОЛЬ ----
                //
                // Было `_target = Vector3.Zero` — и это затирало точку, выбранную
                // по качеству вида. В отладочной строке было видно: журнал писал
                // «обзор на (-1920, 1320)», а камера стояла в нуле с наклоном
                // 60.2° (это и есть 1.05 радиана отсюда).
                //
                // Ноль координат — середина карты поднятия, то есть ВЕРШИНА.
                // Оттуда кадр пустой: камера смотрит вниз на снежный склон.
                //
                // Наклон тоже смягчён: 1.05 радиана это 60°, при котором кадр
                // превращается в карту. Замер запаса над рельефом показал, что
                // 35° достаточно — камера в километре над склоном.
                // ---- ЧИСЛА ПЕРЕСЧИТАНЫ ПОД НЫНЕШНЮЮ ТЕРРИТОРИЮ ----
                //
                // Было 35° и 220 единиц. Пояснение выше писалось, когда фон
                // занимал 24 км: тогда 220 давали камеру в километре над
                // склоном.
                //
                // Сейчас территория 115.2 км, и те же 220 дают вид впритык к
                // земле: на снимке пользователя `dist=220.00`, а рельеф закрывал
                // весь кадр снизу.
                //
                // Расчёт: чтобы сторона вошла при обзоре 75°,
                //     11520 / 2 / tg(37.5°) = 7508
                // Берём 7600 с малым запасом.
                //
                // Наклон: −75° почти отвесно вниз. Знак ОБРАТНЫЙ привычному —
                // направление взгляда считается как sin(_pitch), и при
                // положительном наклоне камера смотрит ВВЕРХ.
                _pitch = Mathf.DegToRad(-75f);
                _distance = 7600f;
                // Высота цели — по рельефу, а не ноль. Камера считается как
                // `_target.Y + удаление * sin(наклон)`, и при нулевой цели она
                // оказывалась НИЖЕ склона: на снимке было pos.Y=126 при рельефе 250.
                _target = new Vector3(_target.X,
                    _view?.SampleWorldY(_target.X, _target.Z) ?? 0f, _target.Z);
                break;
            case 1: // low ridge / dramatic silhouette
                _pitch = 0.18f;
                _distance = 90f;
                _target = new Vector3(_target.X, 0f, _target.Z);
                break;
            case 2: // true FPS player-eye
                _pitch = 0.05f; // slight look-up from horizon
                _distance = 0f; // unused in FPS
                // Y will be set from terrain sample in UpdateCamera
                break;
        }
    }

    /// <summary>Переключить видимость одной ПОРОДЫ в витрине (клавиши 1-9) и обновить
    /// статус-строку — см. LevelView3D.ToggleEntryVisibility.</summary>
    private void ToggleGalleryEntry(int index)
    {
        var (nowVisible, label) = _view.ToggleEntryVisibility(index);
        _infoLabel.Text = _view.GalleryStatus();
        // Раскладка могла смениться 2 ряда → 1 ряд (или наоборот) — пересчитываем
        // фокус и дистанцию, иначе сверху остаётся пустое место от старого bbox.
        SyncGalleryCamera();
        SessionLog.Print($"{label}: {(nowVisible ? "показана" : "скрыта")}");
    }

    /// <summary>
    /// Подтянуть _target.Y к актуальному bbox витрины.
    /// <paramref name="preserveZoom"/> = true: не трогать _distance (age/quality/seed/skeleton) —
    /// иначе при каждом Alt+↑ зум сбрасывался на «весь ряд в кадр», что ломало осмотр.
    /// false: пересчитать дистанцию (вход в витрину, toggle 1-9 — могла смениться
    /// раскладка 2 ряда ↔ 1 ряд).
    /// </summary>
    private void SyncGalleryCamera(bool preserveZoom = false)
    {
        if (!IsGalleryMode) return;
        _target = new Vector3(0f, LevelView3D.GalleryFocusHeight, 0f);
        if (!preserveZoom)
            _distance = LevelView3D.GalleryCameraDistance;
        UpdateCamera();
    }

    /// <summary>
    /// КОРЗИНЫ ЗАМОРОЖЕНЫ — ИДЁТ СЪЁМКА ОБХОДА.
    ///
    /// Съёмка ставит закадровую камеру в точку обхода и перед каждым кадром
    /// пересобирает корзины под неё (ForceVegetationResort). Но снимок требует
    /// ожидания двух кадров, а в каждом из них отрабатывает _Process и разбирает всё
    /// заново — вокруг НАСТОЯЩЕЙ камеры игрока. Для покрытий это фатально: ранний
    /// выход в UpdateVegetationLod гасит все группы дальше cover_hide от игрока
    /// одним проходом, без бюджета и без проверки смещения. Точки обхода от игрока
    /// как раз дальше — и вся трава гаснет в том самом кадре, который снимается.
    ///
    /// Так и вышло: во всех двадцати снимках последнего обхода ближняя земля пуста
    /// при телеметрии в сотни куртин. Дефект не уровня, а инструмента, причём
    /// ForceVegetationResort вводился ровно против него — и оказался бесполезен,
    /// потому что его результат затирался следующим же кадром.
    ///
    /// Отсюда флаг: на время съёмки покадровый разбор выключается целиком. Игровой
    /// путь не затронут — вне съёмки флаг всегда false.
    /// </summary>
    private bool _vegLodFrozen;

    public override void _Process(double delta)
    {
        // LOD растительности по расстоянию до камеры. Вызывается каждый кадр, но
        // фактическую работу делает только при СМЕНЕ уровня у конкретного чанка
        // (см. LevelView3D.UpdateVegetationLod) — это замена ссылки на меш, не пересчёт.
        if (_view == null || _camera == null) return;
        if (!_vegLodFrozen)
            _view.UpdateVegetationLod(_camera.GlobalPosition, _boatActive);

        // Ход лодки отключён вместе со старым руслом (см. клавишу B).

        _perfHudAcc += delta;
        _perfLogAcc += delta;
        if (_perfHudAcc >= PerfHudInterval)
        {
            _perfHudAcc = 0;
            UpdatePerfHud(logToConsole: false);
        }
        if (_perfLogAcc >= PerfLogInterval)
        {
            _perfLogAcc = 0;
            UpdatePerfHud(logToConsole: true);
        }
    }

    /// <summary>
    /// Снимает Godot Performance monitors + LOD растительности.
    /// На экран — всегда; в консоль — по флагу (раз в PerfLogInterval).
    /// </summary>
    private void UpdatePerfHud(bool logToConsole)
    {
        if (_perfLabel == null) return;

        double fps = Performance.GetMonitor(Performance.Monitor.TimeFps);
        double frameMs = Performance.GetMonitor(Performance.Monitor.TimeProcess) * 1000.0;
        double drawCalls = Performance.GetMonitor(Performance.Monitor.RenderTotalDrawCallsInFrame);
        double primitives = Performance.GetMonitor(Performance.Monitor.RenderTotalPrimitivesInFrame);
        double objects = Performance.GetMonitor(Performance.Monitor.RenderTotalObjectsInFrame);
        double vramMb = Performance.GetMonitor(Performance.Monitor.RenderVideoMemUsed) / (1024.0 * 1024.0);
        double texMb = Performance.GetMonitor(Performance.Monitor.RenderTextureMemUsed) / (1024.0 * 1024.0);

        int chunks = 0, full = 0, lod1 = 0, hidden = 0, instVis = 0, instHid = 0, imp = 0;
        if (_view != null)
            _view.GetVegetationLodStats(out chunks, out full, out lod1, out hidden, out instVis, out instHid, out imp);

        _perfLabel.Text =
            // Ориентиры прямо в строке: 150 вызовов отрисовки и 400 тысяч примитивов
            // при 16.7 мс. Без них по числам не видно, далеко ли до цели.
            $"perf: {fps:F0} fps | {frameMs:F1}/16.7 ms | draw:{drawCalls:F0}/150 prim:{primitives / 1000.0:F0}k/400k obj:{objects:F0} | " +
            $"vram:{vramMb:F0}MB tex:{texMb:F0}MB | veg LOD f/l1/imp/h={full}/{lod1}/{imp}/{hidden} (inst {instVis}+{instHid}, chunks {chunks}, atlas {(_view?.BakedImpostorCount ?? 0)})";

        if (logToConsole)
        {
            SessionLog.Print(
                $"[PERF] fps={fps:F1} frame={frameMs:F2}ms " +
                $"draw={drawCalls:F0} prim={primitives:F0} obj={objects:F0} " +
                $"vram={vramMb:F1}MB tex={texMb:F1}MB | " +
                $"veg: full={full} lod1={lod1} hide={hidden} instVis={instVis} instHide={instHid} chunks={chunks}");
        }
    }

    private void UpdateCamera()
    {
        if (_camMode == 2)
        {
            if (_boatActive)
            {
                // Высота/позиция уже выставлены PlaceBoatOnStem (сглаживание + bob).
                _camera.Position = _target;
            }
            else
            {
                // Sample ground under feet + a step ahead so we don't clip into slopes
                float groundY = _view.SampleWorldY(_target.X, _target.Z);
                float fx = -Mathf.Sin(_yaw), fz = -Mathf.Cos(_yaw);
                float aheadY = _view.SampleWorldY(_target.X + fx * 2f, _target.Z + fz * 2f);
                float solidY = Math.Max(groundY, aheadY * 0.35f + groundY * 0.65f);

                // БРОД. С тех пор как вода перестала быть стеной (см. TryPan), опора
                // считается по зеркалу, а не по дну: иначе на русле камера уходила бы
                // под воду ровно на глубину реки. Берётся максимум из двух, поэтому на
                // суше поведение не меняется.
                float? waterY = _view.SampleWaterY(_target.X, _target.Z);
                if (waterY.HasValue && waterY.Value > solidY) solidY = waterY.Value;

                float eyeY = solidY + PlayerEyeOffset;
                // НИЖНИЕ ОГРАНИЧИТЕЛИ ТОЖЕ В МЕТРАХ.
                //
                // Раньше здесь стояли 1.5 и 2.0 «единицы» — то есть пятнадцать и
                // двадцать метров. Они перекрывали любую высоту глаз и держали камеру
                // над кронами независимо от PlayerEyeOffset: именно они, а не сам
                // рост, и поднимали игрока на уровень макушек.
                float minAboveGround = 1.2f / LevelView3D.MetresPerUnit;
                if (eyeY < solidY + minAboveGround) eyeY = solidY + minAboveGround;

                _target = new Vector3(_target.X, eyeY, _target.Z);
                _camera.Position = _target;
            }

            float cp = Mathf.Cos(_pitch);
            float sp = Mathf.Sin(_pitch);
            var forward = new Vector3(
                -Mathf.Sin(_yaw) * cp,
                sp,
                -Mathf.Cos(_yaw) * cp);
            if (_boatActive && MathF.Abs(_camRoll) > 1e-4f)
            {
                // LookAt, затем лёгкий крен вокруг forward (банкинг в поворотах).
                var up = Vector3.Up.Rotated(forward.Normalized(), _camRoll);
                if (up.LengthSquared() < 1e-6f) up = Vector3.Up;
                _camera.LookAt(_camera.Position + forward, up.Normalized());
            }
            else
            {
                _camera.LookAt(_camera.Position + forward, Vector3.Up);
            }
        }
        else
        {
            float x = _target.X + _distance * Mathf.Cos(_pitch) * Mathf.Sin(_yaw);
            float y = _target.Y + _distance * Mathf.Sin(_pitch);
            float z = _target.Z + _distance * Mathf.Cos(_pitch) * Mathf.Cos(_yaw);
            // Было: жёсткий пол "if (y < 2f) y = 2f" — он держал камеру всегда выше цели
            // и тем самым сводил на нет отрицательный pitch (смотреть вверх было невозможно
            // даже после расширения диапазона pitch в _UnhandledInput). В галерее (плоская
            // сцена без рельефа под камерой) опускаться ниже безопасно, поэтому пол применяем
            // только вне галереи, где он всё ещё защищает от проваливания камеры под рельеф.
            if (!IsGalleryMode && y < 2f) y = 2f;
            _camera.Position = new Vector3(x, y, z);
            _camera.LookAt(_target, Vector3.Up);
        }
        UpdateCameraInfoLabel();
    }

    /// <summary>
    /// HUD-строка с текущим положением камеры — по просьбе: нужно понимать, из какой
    /// точки сцены сделан конкретный скриншот. Вызывается из UpdateCamera() при любом
    /// изменении (орбита, зум, панорама), не только по отдельным клавишам.
    /// </summary>
    /// <summary>
    /// Стиль текста HUD: оранжевый с белой окантовкой.
    ///
    /// ЗАЧЕМ. Прежние цвета — светло-серый, голубой и салатовый — терялись на кадре:
    /// заголовок на снежной вершине, строка камеры на небе, строка нагрузки на
    /// травяном склоне. Оранжевый не встречается ни в одном биоме сцены (снег, скала,
    /// трава, вода, листва), поэтому не сливается ни с чем; белая окантовка держит
    /// читаемость на светлом фоне, где сам оранжевый теряет контраст.
    ///
    /// Окантовка в Godot 4 задаётся ДВУМЯ переопределениями сразу: цветом
    /// font_outline_color и РАЗМЕРОМ outline_size. Без размера цвет не даёт ничего —
    /// толщина по умолчанию нулевая, и обводки просто не видно.
    /// </summary>
    private static void ApplyHudTextStyle(Label label)
    {
        label.AddThemeColorOverride("font_color", new Color(1.00f, 0.55f, 0.10f));
        label.AddThemeColorOverride("font_outline_color", new Color(1f, 1f, 1f));
        label.AddThemeConstantOverride("outline_size", 4);
    }

    /// <summary>
    /// V123: cam: в верхней строке писался один раз при генерации и не обновлялся.
    /// Из‑за этого после C всегда оставалось cam:Orbit, хотя режим уже Player.
    /// </summary>
    private void RefreshCamModeHud()
    {
        if (_infoLabel == null) return;
        string name = _camMode == 2 ? "Player" : "Orbit";
        string text = _infoLabel.Text ?? "";
        // заменяем cam:Orbit|Player|Low|?
        text = System.Text.RegularExpressions.Regex.Replace(
            text, @"cam:(Orbit|Player|Low|\?)", "cam:" + name);
        if (!text.Contains("cam:" + name) && text.Length > 0)
            text = text.TrimEnd() + " | cam:" + name;
        _infoLabel.Text = text;
    }

    private void UpdateCameraInfoLabel()
    {
        if (_camInfoLabel == null) return;
        var p = _camera.Position;
        string mode = _camMode == 2 ? "Player" : "Orbit";
        _camInfoLabel.Text =
            $"cam:{mode}  pos=({p.X:F2}, {p.Y:F2}, {p.Z:F2})  yaw={Mathf.RadToDeg(_yaw):F1}°  " +
            $"pitch={Mathf.RadToDeg(_pitch):F1}°  dist={_distance:F2}  target=({_target.X:F2}, {_target.Y:F2}, {_target.Z:F2})";
    }


    private void UpdateInfoLabelPlants()
    {
        string camName = _camMode switch { 0 => "Orbit", 1 => "Orbit", 2 => "Player", _ => "?" };
        _infoLabel.Text =
            $"Seed: {_currentSeed}  |  {_currentSeason}  |  plantSeed: {_plantSeed}  |  cam:{camName}  |  P=back to level  R=new plants";
    }

    /// <summary>
    /// Собирает LevelData из НАШИХ данных, без старого генератора.
    ///
    /// Области пусты: их потребители заменены (выбор места игрока, проверка воды,
    /// маркеры). Растительность ставит LevelView3D своим расстановщиком, поэтому
    /// здесь она тоже пуста.
    ///
    /// Остаются: сид, время года и признак «данные есть».
    /// </summary>
    private LevelData BuildLevelDataFromRings(int seed)
    {
        var season = SeasonState.CreateFixed(_currentSeason);
        return new LevelData(
            descriptorId: Guid.NewGuid(),
            seed: seed,
            seasonState: season,
            points: Array.Empty<MapPoint>(),
            regions: Array.Empty<RegionData>(),
            polygonCount: 0,
            debugInfo: $"уровень из колец, сид {seed}",
            vegetation: Array.Empty<VegetationInstance>(),
            chunkIndex: 0,
            worldSeed: seed);
    }

    private void GenerateAndShow(int seed)
    {
        LevelData data;
        // ---- СТАРЫЙ ГЕНЕРАТОР УДАЛЁН ----
        //
        // Прежде здесь работал RiverWorld: строил области, русла, тропы и
        // растительность на карте 1000 единиц. В игре не было видно НИЧЕГО из
        // этого — «terrain: mesh=null, vegRoot: children=0», — а стоил он 1350 мс
        // на каждое построение.
        //
        // Он остался только ради LevelData, который принимает SetData. Теперь
        // LevelData собирается из наших данных.
        //
        // ---- ЧЕМ ОН ЛОМАЛ РАБОТУ, ПОКА БЫЛ ----
        //
        // Шесть заходов подряд его остатки молча портили результат:
        //   лента воды красилась не тем материалом;
        //   растительность лежала в координатах чужой карты;
        //   выбор места игрока искал в карте 1000 единиц и давал центр — вершину;
        //   проверка воды спрашивала чужие области;
        //   высота бралась из его сетки, которой уже не было;
        //   пороги поясов брались чужие.
        //
        // Каждый раз механизм считал, а выход не доходил до экрана.
        data = BuildLevelDataFromRings(seed);

        var swView = System.Diagnostics.Stopwatch.StartNew();
        _view!.SetData(data, MapMetrics.MapSize, _graphics.GetGridResolution());
        swView.Stop();
        SessionLog.Print($"[время] рельеф и меш: {swView.ElapsedMilliseconds} мс");

        SessionLog.Print($"--- Seed {seed} | Season {_currentSeason} ---");
        SessionLog.Print(data.DebugInfo);

        // ---- КАМЕРА СТАВИТСЯ ТУДА, ГДЕ ЕСТЬ ЧТО СМОТРЕТЬ ----
        //
        // Прежде PlaceInValley() вызывалась ТОЛЬКО при переключении камеры на
        // прогулку клавишей, а при запуске камера обзорная и смотрит в начало
        // координат. А начало координат — это середина карты поднятия, то есть
        // ВЕРШИНА: замер дал 2946 м, вокруг 58% снега и 39% скалы.
        //
        // Теперь точка выбирается сразу после построения: крупная река, пояс
        // леса, умеренная высота. По трём мирам это 2256-2409 м в 21-27 км от
        // центра.
        //
        // НО НЕ ЧЕРЕЗ PlaceInValley(): она написана для камеры ПРОГУЛКИ и ставит
        // наклон 0.05, то есть почти горизонтально на уровне глаз. При запуске
        // камера ОБЗОРНАЯ, и с таким наклоном она оказывается на высоте самой
        // точки — то есть внутри рельефа. Отсюда ощущение, что смотришь снизу.
        //
        // Берём только точку, а наклон и расстояние оставляем обзорными.
        //
        // В режиме оценки рельефа место игрока не ищется вовсе: FindStartPosition
        // перебирает поле в поисках крупной реки и пояса леса, а смотрим мы на
        // устройство территории — для этого верна её середина.
        if (FarBackground.TerrainOnly)
            AimOrbitAt(LevelCenter());
        else
            AimOrbitAt(_view.FindValleyWorldPos());
        foreach (var g in data.Regions.GroupBy(r => r.Biome).OrderBy(g => g.Key.ToString()))
            SessionLog.Print($"  {g.Key}: {g.Count()}");

        int rivers = data.Regions.Count(r => r.IsRiver);
        // V301: счётчики stem/trib/lakes убраны. Они считали области СТАРОГО
        // генератора и после его удаления всегда давали ноль — а ноль в надписи
        // читается как показание прибора, а не как отключённый прибор.

        // V41: лодка ВЫКЛ. Старт в высоком overview, чтобы видеть rim/дыры.
        // B — дрейф по реке; C — Orbit ↔ Player.
        _boatActive = false;
        _boatChunk = 0;
        _boatArcInChunk = 0f;
        _boatStation = 0f;
        // Таблица дуг строилась по руслу старого генератора; сплав отключён.
        _boatArcInChunk = _boatPathLen * 0.05f;
        _boatStation = _boatArcInChunk;
        _camSmoothInit = false;
        _boatPhase = 0f;
        _camRoll = 0f;
        _view.SetStemMarkersVisible(true);
        _camMode = 0;
        ApplyCameraMode();
        // LogSpineRimMetrics убран вместе со старым генератором.
        UpdateCamera();

        string camName = _camMode switch { 0 => "Orbit", 1 => "Orbit", 2 => "Player", _ => "?" };
        int veg = data.Vegetation.Count;

        // ---- V301: НАДПИСЬ ОЧИЩЕНА ОТ СЛЕДОВ СТАРОГО ГЕНЕРАТОРА ----
        //
        // Показывала «[LEGACY] … pts:0 stem:0 trib:0 lakes:0 … boat:OFF …
        // M=mode B=boat» — метку режима, счётчики русла и лодку. Всё это
        // принадлежало старому генератору чанка: генератора нет, счётчики
        // всегда нули, режим один, лодка ведёт по руслу, которого нет.
        //
        // Нули в надписи хуже отсутствия: они выглядят как показания прибора и
        // читаются как «русел ноль», хотя прибор просто отключён.
        //
        // Взамен показывается то, что у нас есть на самом деле: сид, время года,
        // растительность и камера.
        _infoLabel.Text =
            $"Seed:{seed} | {_currentSeason} | veg:{veg} | cam:{camName} | "
            + "R=regen C=cam W=water H=terrain Wheel=speed";

        // ---- ЦЕЛЬ КАМЕРЫ — СЕРЕДИНА УРОВНЯ ----
        //
        // Правка стояла только при СБРОСЕ, а при построении цель оставалась
        // нулём координат — и камера вращалась вокруг УГЛА уровня.
        //
        // Ставится в конце: высота середины берётся из готового вида.
        _target = LevelCenter();

    }

    // Метод LogSpineRimMetrics убран: он печатал показатели русла СТАРОГО
    // генератора. Наше русло идёт по дренажу поля.


    private static void CopyTerrainParams(
        ColoringBook.Infrastructure.Generation.Mapgen.Algorithms.TerrainParams src,
        ColoringBook.Infrastructure.Generation.Mapgen.Algorithms.TerrainParams dst)
    {
        dst.ValleyCountBase = src.ValleyCountBase;
        dst.ValleyCountRand = src.ValleyCountRand;
        dst.ValleyRadiusScale = src.ValleyRadiusScale;
        dst.ValleyEdgeBand = src.ValleyEdgeBand;
        dst.PeakCountBase = src.PeakCountBase;
        dst.PeakCountRand = src.PeakCountRand;
        dst.MountainAmplitude = src.MountainAmplitude;
        dst.ErosionIterations = src.ErosionIterations;
        dst.ErosionK = src.ErosionK;
        dst.MaxErosionPerStep = src.MaxErosionPerStep;
        dst.TalusDiff = src.TalusDiff;
        dst.TalusPasses = src.TalusPasses;
        dst.MinLakeDepth = src.MinLakeDepth;
        dst.RiverFraction = src.RiverFraction;
        dst.OutletHalfWidth = src.OutletHalfWidth;
        dst.OutletDrop = src.OutletDrop;
    }

    /// <summary>
    /// Player-eye pan with constraints: map radius, valid land, max climb height.
    /// Orbit/Low modes move freely.
    /// </summary>
    private void TryPan(Vector3 delta)
    {
        if (_camMode != 2)
        {
            _target += delta;
            UpdateCamera();
            return;
        }

        var proposed = _target + delta;
        float distSq = proposed.X * proposed.X + proposed.Z * proposed.Z;
        if (distSq > MaxWalkRadius * MaxWalkRadius)
        {
            float dist = MathF.Sqrt(distSq);
            float s = MaxWalkRadius / dist;
            proposed = new Vector3(proposed.X * s, proposed.Y, proposed.Z * s);
        }

        float ground = _view.SampleWorldY(proposed.X, proposed.Z);
        if (float.IsNaN(ground) || ground < 0.5f)
        {
            _target = _lastGoodTarget;
            UpdateCamera();
            return;
        }

        // ПРЕГРАДЫ У ДЕРЕВЬЕВ. Только в режиме игрока: орбитальная камера обозревает
        // долину и внутри крон не оказывается, а лодка идёт по руслу, где деревьев нет.
        //
        // При отказе пробуем СКОЛЬЖЕНИЕ вдоль препятствия по каждой оси отдельно —
        // иначе игрок, упёршийся в ствол наискось, застревал бы намертво, а обойти
        // дерево вслепую в чаще не так просто.
        if (_camMode == 2 && _view.IsBlockedByTree(proposed.X, proposed.Z))
        {
            var slideX = new Vector3(proposed.X, proposed.Y, _target.Z);
            var slideZ = new Vector3(_target.X, proposed.Y, proposed.Z);
            if (!_view.IsBlockedByTree(slideX.X, slideX.Z)) proposed = slideX;
            else if (!_view.IsBlockedByTree(slideZ.X, slideZ.Z)) proposed = slideZ;
            else
            {
                _target = _lastGoodTarget;
                UpdateCamera();
                return;
            }
        }

        // ВОДА БОЛЬШЕ НЕ СТЕНА.
        //
        // Раньше здесь стоял возврат к последней хорошей точке: русло и озёра были
        // непроходимы, и на узкой долине игрок упирался в реку, не имея обхода —
        // движение просто прекращалось без всякого объяснения на экране.
        //
        // Теперь переход разрешён вброд: точка принимается, а высота глаз ниже
        // подхватывается от поверхности воды, а не от дна, поэтому камера не ныряет
        // под зеркало. Лодка остаётся отдельным режимом и от этого не зависит.
        //
        // Ограничения по радиусу карты и по высоте подъёма сохранены: они защищают от
        // выхода за пределы сгенерированного чанка, а это уже не вопрос вкуса.

        // Max climb height — no peak walking / no seeing unloaded void beyond ridges
        if (ground > MaxWalkTerrainY)
        {
            _target = _lastGoodTarget;
            UpdateCamera();
            return;
        }

        _target = proposed;
        _lastGoodTarget = new Vector3(proposed.X, 0f, proposed.Z);
        UpdateCamera();
    }

    /// <summary>Place FPS camera on the lowest suitable valley floor.</summary>
    /// <summary>
    /// Дрейф по main stem: двигаем станцию, при смене чанка подгружаем следующий,
    /// камеру сажаем на ось spine над водой.
    /// </summary>
    // Метод убран вместе со старым генератором: он работал с его чанками.
    // Было: private void TickBoat(float dt)

    // Метод убран вместе со старым генератором: он работал с его чанками.
    // Было: private void RebuildBoatArcTable(int chunk)

    // Метод убран вместе со старым генератором: он работал с его чанками.
    // Было: private void PlaceBoatOnStem(bool applyYaw, float dt = 0f)

    private void UpdateBoatHud()
    {
        if (_infoLabel == null || !_boatActive) return;
        int chunk = Math.Max(0, _boatChunk);
        // Не перетирать весь текст — обновляем через короткий хвост, если нет полного rebuild.
        // Полный статус пишет GenerateAndShow; здесь только скорость/станция.
        string baseText = _infoLabel.Text;
        int cut = baseText.IndexOf(" | boat:", StringComparison.Ordinal);
        if (cut < 0) cut = baseText.IndexOf(" | R=regen", StringComparison.Ordinal);
        if (cut < 0) return;
        _infoLabel.Text = baseText[..cut]
            + $" | boat:ch{chunk} s={_boatStation:F0} v={_boatSpeed:F0}u/s"
            + " | R=regen M=mode C=cam Wheel=speed";
    }

    /// <summary>
    /// Наводит ОБЗОРНУЮ камеру на точку, не трогая её наклон и расстояние.
    ///
    /// Отличается от PlaceInValley тем, что не ставит наклон уровня глаз: у
    /// обзорной камеры он должен смотреть на долину сверху, иначе камера
    /// оказывается внутри склона.
    /// </summary>
    private void AimOrbitAt(Vector3 pos)
    {
        // ---- ВЫСОТА ЦЕЛИ БЕРЁТСЯ ПО РЕЛЬЕФУ ----
        //
        // Было `new Vector3(pos.X, 0f, pos.Z)` — то есть цель на уровне моря.
        // А высота камеры считается как `_target.Y + удаление * sin(наклон)`,
        // и при нулевой цели камера оказывалась на 126 единицах, тогда как
        // рельеф в этом месте на 250. Камера утыкалась в склон вплотную.
        //
        // На снимке это было видно: target=(-840, 0.00, 2184), pos.Y=126.19.
        _target = new Vector3(pos.X, pos.Y, pos.Z);
        _lastGoodTarget = _target;
        // ---- НАКЛОН 35° ПРИ УДАЛЕНИИ 2.2 КМ ----
        //
        // Замер запаса камеры над рельефом от точки старта:
        //
        //     наклон  удаление  запас
        //        3°    1.2 км    -45 м   ВНУТРИ склона — так и было
        //       20°    1.2 км    320 м
        //       35°    2.2 км   1138 м   взято
        //       50°    3.0 км   2079 м   вид сверху, кадр как карта
        //
        // Прежние 3° брались из PlaceInValley, где это уровень глаз пешехода.
        // Для обзорной камеры это означало положение НИЖЕ поверхности.
        // Те же числа, что при запуске: территория 115.2 км требует удаления
        // 7600, иначе камера стоит впритык к земле. Знак наклона обратный —
        // направление считается как sin(_pitch).
        _pitch = Mathf.DegToRad(-75f);
        _distance = 7600f;
        // Смотрим к середине карты: там горы, а значит есть дальний план.
        float dx = -pos.X, dz = -pos.Z;
        if (dx * dx + dz * dz > 1e-4f)
            _yaw = Mathf.Atan2(-dx, -dz);
        SessionLog.Print($"[камера] обзор на ({pos.X:F0}, {pos.Z:F0}), "
            + $"наклон 35°, удаление {_distance * 10f / 1000f:F1} км");
    }

    private void PlaceInValley()
    {
        var pos = _view.FindValleyWorldPos();
        _target = new Vector3(pos.X, 0f, pos.Z); // Y set in UpdateCamera from terrain
        _lastGoodTarget = _target;
        _pitch = 0.05f;
        // Face roughly toward map centre so first view is interesting
        float dx = -pos.X, dz = -pos.Z;
        if (dx * dx + dz * dz > 1e-4f)
            _yaw = Mathf.Atan2(-dx, -dz);
    }

    /// <summary>
    /// Переключает освещение между режимом ОСМОТРА (ровный рассеянный свет, ничего
    /// не в тени) и режимом РЕЛЬЕФА (низкое солнце с тенями). Разделено на два
    /// режима намеренно: это взаимоисключающие требования — тени мешают видеть
    /// весь уровень, но без них не читается форма гор.
    /// </summary>
    private void ApplyLightingMode()
    {
        // Заливающих источников больше нет, поэтому режимы различаются только
        // положением солнца и силой окружающего света.
        if (_reliefLighting)
        {
            // Рельеф: низкое солнце, длинные тени, тёмное окружение.
            _sun.LightEnergy = 1.25f;
            _sun.RotationDegrees = new Vector3(-28, 40, 0);
            // Тот же уровень, что при запуске: два источника одной величины
            // расходятся, это случалось одиннадцать раз.
            if (_env.Environment != null) _env.Environment.AmbientLightEnergy = 0.55f;
        }
        else
        {
            // Обзор: солнце выше, тени короче, окружение сильнее — видно всю долину,
            // но объём при этом не теряется, потому что тени остались включены.
            _sun.LightEnergy = 1.05f;
            _sun.RotationDegrees = new Vector3(-40, 40, 0);
            if (_env.Environment != null) _env.Environment.AmbientLightEnergy = 1.30f;
        }
    }
}
