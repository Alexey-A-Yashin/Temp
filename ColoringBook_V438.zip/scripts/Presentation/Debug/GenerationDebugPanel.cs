using System;
using System.Collections.Generic;
using Godot;
using ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

namespace ColoringBook.Presentation.Debug;

/// <summary>
/// Панель настройки генерации в реальном времени (клавиша T).
///
/// ЗАЧЕМ. Ручки генерации взаимозависимы, и подбирать их по одному прогону вслепую
/// не работает — проверено на практике: расширение долин (радиус x1.5, долин 6-9,
/// пиков 4-7) дало вдвое более широкое дно, но заодно уронило медианный уклон с 5.7
/// до 2.5 и почти убрало горы, а ещё осушило озёра, из-за чего пришлось отдельно
/// опускать порог озера. Такие перекосы видно только глазами и только сразу.
///
/// Панель правит ЖИВОЙ объект TerrainParams у генератора, поэтому перегенерация
/// подхватывает значения без пересборки проекта.
///
/// Сид при перегенерации СОХРАНЯЕТСЯ — иначе меняются сразу две вещи (и параметры,
/// и рельеф), и понять, что дала правка, невозможно. Новый сид — по-прежнему R.
/// </summary>
public sealed partial class GenerationDebugPanel : PanelContainer
{
    private readonly List<Action> _refreshers = new();
    private Action? _onChanged;
    private TerrainParams _params = null!;

    /// <summary>Создаёт панель. onChanged вызывается после отпускания ползунка.</summary>
    public static GenerationDebugPanel Create(TerrainParams parameters, Action onChanged)
    {
        var panel = new GenerationDebugPanel
        {
            Name = "GenerationDebugPanel",
            _params = parameters,
            _onChanged = onChanged,
        };
        panel.Build();
        return panel;
    }

    private void Build()
    {
        // Правый верхний угол, фиксированная ширина, прокрутка на случай малого экрана.
        SetAnchorsPreset(LayoutPreset.TopRight);
        OffsetLeft = -360;
        OffsetTop = 8;
        OffsetRight = -8;
        OffsetBottom = 936;   // 720 * 1.3 — чтобы панель влезала без прокрутки

        var style = new StyleBoxFlat
        {
            BgColor = new Color(0.08f, 0.09f, 0.11f, 0.88f),
            BorderColor = new Color(0.35f, 0.40f, 0.48f),
            ContentMarginLeft = 10,
            ContentMarginRight = 10,
            ContentMarginTop = 8,
            ContentMarginBottom = 8,
        };
        style.SetBorderWidthAll(1);
        style.SetCornerRadiusAll(4);
        AddThemeStyleboxOverride("panel", style);

        var scroll = new ScrollContainer { CustomMinimumSize = new Vector2(340, 910) };
        AddChild(scroll);

        var box = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        scroll.AddChild(box);

        AddTitle(box, "ГЕНЕРАЦИЯ  (T — скрыть)");

        AddHeader(box, "Долины и горы");
        AddInt(box, "Долин (мин)", () => _params.ValleyCountBase, v => _params.ValleyCountBase = v, 1, 14);
        AddInt(box, "Долин (разброс)", () => _params.ValleyCountRand, v => _params.ValleyCountRand = v, 1, 8);
        AddFloat(box, "Радиус долин", () => _params.ValleyRadiusScale, v => _params.ValleyRadiusScale = v, 0.5f, 2.5f, 0.05f);
        AddFloat(box, "Полоса склона", () => _params.ValleyEdgeBand, v => _params.ValleyEdgeBand = v, 0.2f, 1.5f, 0.05f);
        AddInt(box, "Пиков (мин)", () => _params.PeakCountBase, v => _params.PeakCountBase = v, 1, 16);
        AddInt(box, "Пиков (разброс)", () => _params.PeakCountRand, v => _params.PeakCountRand = v, 1, 10);
        AddFloat(box, "Высота гор", () => _params.MountainAmplitude, v => _params.MountainAmplitude = v, 0.2f, 1.4f, 0.05f);

        AddHeader(box, "Эрозия");
        AddInt(box, "Шагов", () => _params.ErosionIterations, v => _params.ErosionIterations = v, 0, 60);
        AddFloat(box, "Сила K", () => _params.ErosionK, v => _params.ErosionK = v, 0f, 10f, 0.1f);
        AddFloat(box, "Потолок за шаг", () => _params.MaxErosionPerStep, v => _params.MaxErosionPerStep = v, 0.001f, 0.04f, 0.001f);

        AddHeader(box, "Осыпание (термическая)");
        AddFloat(box, "Порог осыпи", () => _params.TalusDiff, v => _params.TalusDiff = v, 0.02f, 0.30f, 0.005f);
        AddInt(box, "Проходов", () => _params.TalusPasses, v => _params.TalusPasses = v, 0, 5);

        AddHeader(box, "Вода");
        AddFloat(box, "Порог озера", () => _params.MinLakeDepth, v => _params.MinLakeDepth = v, 0.01f, 0.30f, 0.005f);
        AddFloat(box, "Густота рек", () => _params.RiverFraction, v => _params.RiverFraction = v, 0.005f, 0.12f, 0.005f);

        AddHeader(box, "Устье долины");
        AddFloat(box, "Ширина канала", () => _params.OutletHalfWidth, v => _params.OutletHalfWidth = v, 0.01f, 0.10f, 0.005f);
        AddFloat(box, "Спад к краю", () => _params.OutletDrop, v => _params.OutletDrop = v, 0.01f, 0.20f, 0.005f);

        box.AddChild(new HSeparator());
        var reset = new Button { Text = "Сбросить к значениям по умолчанию" };
        reset.Pressed += () =>
        {
            var d = new TerrainParams();
            foreach (var f in typeof(TerrainParams).GetFields())
                f.SetValue(_params, f.GetValue(d));
            foreach (var r in _refreshers) r();
            _onChanged?.Invoke();
        };
        box.AddChild(reset);
    }

    private static void AddTitle(Control parent, string text)
    {
        var l = new Label { Text = text };
        l.AddThemeFontSizeOverride("font_size", 15);
        l.AddThemeColorOverride("font_color", new Color(0.95f, 0.95f, 0.75f));
        parent.AddChild(l);
    }

    private static void AddHeader(Control parent, string text)
    {
        parent.AddChild(new HSeparator());
        var l = new Label { Text = text };
        l.AddThemeFontSizeOverride("font_size", 13);
        l.AddThemeColorOverride("font_color", new Color(0.60f, 0.78f, 0.95f));
        parent.AddChild(l);
    }

    private void AddFloat(
        Control parent, string label, Func<float> get, Action<float> set,
        float min, float max, float step)
    {
        var row = new VBoxContainer();
        var caption = new Label();
        caption.AddThemeFontSizeOverride("font_size", 12);
        row.AddChild(caption);

        var slider = new HSlider
        {
            MinValue = min,
            MaxValue = max,
            Step = step,
            Value = get(),
            CustomMinimumSize = new Vector2(0, 16),
        };
        row.AddChild(slider);
        parent.AddChild(row);

        void Refresh() { caption.Text = $"{label}: {get():0.###}"; slider.Value = get(); }
        Refresh();
        _refreshers.Add(Refresh);

        // Пишем значение на каждое движение (подпись обновляется живьём), а
        // перегенерацию запускаем только по ОТПУСКАНИЮ: она занимает сотни
        // миллисекунд, и делать её на каждый пиксель перетаскивания нельзя.
        slider.ValueChanged += v => { set((float)v); caption.Text = $"{label}: {get():0.###}"; };
        slider.DragEnded += _ => _onChanged?.Invoke();
    }

    private void AddInt(
        Control parent, string label, Func<int> get, Action<int> set, int min, int max)
    {
        var row = new VBoxContainer();
        var caption = new Label();
        caption.AddThemeFontSizeOverride("font_size", 12);
        row.AddChild(caption);

        var slider = new HSlider
        {
            MinValue = min,
            MaxValue = max,
            Step = 1,
            Value = get(),
            CustomMinimumSize = new Vector2(0, 16),
        };
        row.AddChild(slider);
        parent.AddChild(row);

        void Refresh() { caption.Text = $"{label}: {get()}"; slider.Value = get(); }
        Refresh();
        _refreshers.Add(Refresh);

        slider.ValueChanged += v => { set((int)v); caption.Text = $"{label}: {get()}"; };
        slider.DragEnded += _ => _onChanged?.Invoke();
    }
}
