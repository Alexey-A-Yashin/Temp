using System;
using System.IO;
using System.Text;
using Godot;
using ColoringBook.Infrastructure.Generation.Diagnostics;

// ВНИМАНИЕ ПРО Environment. В Godot есть свой тип Environment — окружение сцены
// (небо, туман, тонирование). При `using Godot;` простое имя Environment
// становится неоднозначным, и сборка падает с CS0104. Поэтому ниже везде
// System.Environment.NewLine с полным именем.

namespace ColoringBook.Presentation.Diagnostics;

/// <summary>
/// ЕДИНЫЙ ФАЙЛ ЖУРНАЛА: то же, что уходит в консоль Godot, пишется рядом с логами.
///
/// ---- ЗАЧЕМ ----
///
/// Разбор шёл по консоли, которую приходилось копировать вручную и присылать
/// отдельным файлом. Данных, доступных ТОЛЬКО в консоли, нет: всё, что печатает
/// GD.Print, можно так же положить в файл.
///
/// Строки пишутся сразу, без буфера: если игра упадёт, журнал останется полным до
/// последней строки. Скорость тут не важна — таких строк за запуск десятки.
///
/// ---- ЧТО НЕ ПОПАДАЕТ ----
///
/// Сообщения самого движка (загрузка шейдеров, предупреждения Godot) идут мимо:
/// они печатаются не нашим кодом. Если понадобятся, в Godot есть собственная
/// запись консоли в файл, включается в настройках проекта.
/// </summary>
public static class SessionLog
{
    private static string? _path;
    private static readonly object Lock = new();

    /// <summary>Путь к файлу журнала текущего запуска.</summary>
    public static string Path => _path ?? Begin();

    /// <summary>Начать новый файл. Зовётся сама при первой записи.</summary>
    public static string Begin()
    {
        lock (Lock)
        {
            if (_path != null) return _path;
            string dir = GenerationLog.LogDirectory;
            Directory.CreateDirectory(dir);
            _path = System.IO.Path.Combine(dir,
                DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_session.log");
            File.WriteAllText(_path,
                "ColoringBook — журнал запуска " +
                DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + System.Environment.NewLine,
                Encoding.UTF8);
            return _path;
        }
    }

    /// <summary>Напечатать в консоль И записать в файл.</summary>
    public static void Print(string line)
    {
        GD.Print(line);
        Write(line);
    }

    /// <summary>Только в файл — для длинных таблиц, которые в консоли мешают.</summary>
    public static void Write(string line)
    {
        try
        {
            lock (Lock)
            {
                File.AppendAllText(Path, line + System.Environment.NewLine, Encoding.UTF8);
            }
        }
        catch (Exception e)
        {
            // Журнал не должен ронять игру: если писать некуда, довольствуемся
            // консолью.
            GD.PushWarning($"[журнал] не удалось записать: {e.Message}");
        }
    }
}
