using System;
using System.Collections.Generic;
using System.Linq;
using ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;
using ColoringBook.Presentation.Diagnostics;

namespace ColoringBook.Presentation.Level;

/// <summary>
/// ПРОВЕРКА УРОВНЯ В ИГРЕ.
///
/// ---- ЗАЧЕМ ----
///
/// Цель, поставленная пользователем: журнал должен быть достаточным источником,
/// чтобы понять, как уровень выглядит — без снимков, пометок и описаний.
///
/// Прежде журнал давал общие доли (вода 5.1%, озёр 29), по которым нельзя
/// отличить озеро с узким берегом от лужи на дне широкой чаши. Пользователь
/// каждый раз обнаруживал беду сам и присылал снимок.
///
/// ---- ЧТО ЗДЕСЬ ----
///
/// Тот же набор из семнадцати замеров, что на стенде (tools/bench/gentest/
/// Audit.cs), плюс разбивка по областям: уровень делится на клетки, и по каждой
/// печатаются высоты, вода, покров.
///
/// ---- ПРАВИЛО ----
///
/// Всякая беда, найденная пользователем, добавляется сюда замером. Тогда она
/// больше не повторится незамеченной.
/// </summary>
public static class LevelAudit
{
    private readonly record struct Check(string Group, string Name, double Value,
                                         string Unit, double Lo, double Hi, string Note)
    {
        public bool Ok => Value >= Lo && Value <= Hi;
    }

    /// <summary>На сколько клеток делится сторона уровня при разбивке.</summary>
    private const int RegionGrid = 8;

    /// <summary>
    /// Направление как угол от нуля до семи по кругу. Нужно мере резких
    /// поворотов: перенесено со стенда, чтобы меры совпадали.
    /// </summary>
private static int DirAngle(int dir)
    {
        int di = dir % 3 - 1, dj = dir / 3 - 1;
        if (di == 1 && dj == 0) return 0;
        if (di == 1 && dj == 1) return 1;
        if (di == 0 && dj == 1) return 2;
        if (di == -1 && dj == 1) return 3;
        if (di == -1 && dj == 0) return 4;
        if (di == -1 && dj == -1) return 5;
        if (di == 0 && dj == -1) return 6;
        return 7;
    }
    /// <param name="filled">поверхность ОЗЁР: заливка, поправленная объёмом воды</param>
    /// <param name="bowlSurface">поверхность ЧАШ: заливка до порога, без поправки.
    /// Считается один раз в FarBackground и передаётся сюда. Прежде здесь
    /// стоял свой FillDepressions — на сетке 1921 он стоил 16 секунд, и это
    /// был один из ПЯТИ вызовов, считавших одно и то же.</param>
    public static void Run(float[] field, float[] filled, float[] bowlSurface, float[] drainage,
                           int side, float extentWorld, float heightScale, float lift,
                           float lakeMinDepthM, float mainChannelFlow, float metresPerUnit)
    {
        var checks = new List<Check>();

        // ---- МЕРЫ, ЗАВИСЯЩИЕ ОТ ПЛОЩАДИ ----

        //

        // Объём озёр, число чаш, обрывки русел — все растут с площадью уровня.

        // Нормы задавались для 115 км; на 231 км они давали ложные нарушения,

        // хотя рельеф тот же.

        //

        // То же исправлено на стенде: там разрыв был шесть мер.

        double areaRatio = (extentWorld * extentWorld) / (11520.0 * 11520.0);
        float cellKm = extentWorld / (side - 1) * metresPerUnit / 1000f;
        float cell = extentWorld / (side - 1);

        var full = bowlSurface;

        float D(int k) => (filled[k] - field[k]) * heightScale * metresPerUnit;
        float B(int k) => (full[k] - field[k]) * heightScale * metresPerUnit;
        bool IsLake(int k) => D(k) > lakeMinDepthM;
        bool IsRiver(int k) => drainage != null && drainage[k] >= mainChannelFlow;

        // ---- ВЫСОТЫ ----
        var hs = new List<float>(field.Length / 7);
        for (int k = 0; k < field.Length; k += 7)
            hs.Add((field[k] * heightScale + lift) * metresPerUnit);
        hs.Sort();
        checks.Add(new("рельеф", "разница высот p10-p90",
                       hs[hs.Count * 9 / 10] - hs[hs.Count / 10], " м", 2000, 2500,
                       "альпийская норма"));
        checks.Add(new("рельеф", "медиана высоты", hs[hs.Count / 2], " м", 1500, 2800,
                       "в Альпах около 1800"));

        // ---- УКЛОН НА ЯЧЕЙКЕ ПОЛЯ ----
        //
        // Норма 18-28 взята из замеров Альп по SRTM и ASTER с разрешением
        // 30-90 м — для МЕЛКОГО шага. На шаге 900 м всякий рельеф выглядит
        // вдвое положе, и шесть сборок я гнался за числом по неверной мере.
        double slopeSum = 0; int slopeN = 0;
        for (int j = 1; j < side - 1; j++)
        for (int i = 1; i < side - 1; i++)
        {
            double gx = (field[j * side + i + 1] - field[j * side + i - 1]) / (2 * cell);
            double gz = (field[(j + 1) * side + i] - field[(j - 1) * side + i]) / (2 * cell);
            slopeSum += Math.Atan(Math.Sqrt(gx * gx + gz * gz) * heightScale) * 180 / Math.PI;
            slopeN++;
        }
        checks.Add(new("рельеф", "уклон на ячейке поля", slopeSum / slopeN, "°", 18, 28, ""));

        var g = TerrainMetrics.Geomorphons(field, side, cell, 4);
        checks.Add(new("рельеф", "отклонение форм",
                       TerrainMetrics.GeomorphonDeviation(g), "", 0, 18, ""));
        checks.Add(new("рельеф", "гребни", g[1], "%", 6, 10, ""));
        checks.Add(new("рельеф", "ровные места", g[4], "%", 33, 43, ""));

        // ---- ВОДА ----
        int water = 0, lakeCells = 0, riverCells = 0, riverInLake = 0, rim = 0;
        for (int k = 0; k < field.Length; k++)
        {
            bool lake = IsLake(k), river = IsRiver(k);
            // Русло «поверх озера» — только если игра ВПРАВДУ его так рисует.
            // В покрове озеро проверяется ПЕРВЫМ: ячейка с водой красится
            // озером, и река по ней не рисуется.
            if (lake) { lakeCells++; }
            if (river) riverCells++;
            if (lake || river) water++;
        }
        for (int j = 2; j < side - 2; j++)
        for (int i = 2; i < side - 2; i++)
        {
            int k = j * side + i;
            if (IsLake(k) || B(k) <= lakeMinDepthM) continue;
            bool nearWater = false;
            for (int dj = -2; dj <= 2 && !nearWater; dj++)
            for (int di = -2; di <= 2; di++)
                if (IsLake((j + dj) * side + i + di)) { nearWater = true; break; }
            if (!nearWater) rim++;
        }
        checks.Add(new("вода", "доля площади", 100.0 * water / field.Length, "%", 1.5, 6, ""));

        // ---- НЕПРЕРЫВНЫЕ МЕРЫ ВОДЫ ----
        //
        // Число озёр — мера разрывная: 46 чаш стоит под порогом 25 м, 43 над
        // ним, и сдвиг рельефа на доли процента переводит десятки через
        // границу.
        //
        // Норма объёма выведена СЧЁТОМ по площади уровня 13 271 км²: типичное
        // горное озеро 1-5 км² глубиной 30-80 м даёт 0.03-0.4 км³; таких на
        // территории 20-40, итого 2-20 км³.
        {
            double lakeVolume = 0, bowlArea = 0;
            for (int k = 0; k < field.Length; k++)
            {
                double d = D(k);
                if (d > 0) lakeVolume += d;
                if (B(k) > 0) bowlArea++;
            }
            double volKm3 = lakeVolume / 1000.0 * cellKm * cellKm;
            checks.Add(new("вода", "объём озёр", volKm3 / areaRatio, " км³ на 115 км", 2, 20,
                           "выведено счётом: 20-40 озёр по 0.03-0.4 км³"));
            checks.Add(new("вода", "площадь чаш",
                           100.0 * bowlArea / field.Length, "%", 2, 12,
                           "где вода может стоять"));
        }
        checks.Add(new("вода", "русло ПОВЕРХ озера",
                       100.0 * riverInLake / Math.Max(lakeCells, 1), "%", 0, 1,
                       "река не должна рисоваться по глади"));
        checks.Add(new("вода", "сухая кайма дальше 240 м от воды",
                       100.0 * rim / field.Length, "%", 0, 2, "берег должен быть узким"));

        // ---- ОЗЁРА ----
        var lakes = Blobs(IsLake, side, false);
        var big = lakes.Where(l => l.count * cellKm * cellKm > 0.05).ToList();
        big.Sort((a, b) => b.count.CompareTo(a.count));
        checks.Add(new("озёра", "число крупнее 0.05 км²", big.Count, "", 5, 60, ""));
        checks.Add(new("озёра", "крупнейшее",
                       big.Count > 0 ? big[0].count * cellKm * cellKm : 0, " км²", 0, 50,
                       "горные озёра 0.01-20 км²"));
        checks.Add(new("озёра", "вытянутых втрое и более",
                       big.Count(l => l.elong > 3), "", 0, 3, "признак натяжки по сетке"));
        int chained = big.Count(a => big.Count(b =>
            (b.x != a.x || b.z != a.z) &&
            Math.Sqrt((b.x - a.x) * (b.x - a.x) + (b.z - a.z) * (b.z - a.z)) * cellKm < 12) >= 2);
        checks.Add(new("озёра", "в вереницах", chained / areaRatio, " на 115 км", 0, Math.Max(big.Count / 3, 1),
                       "цепочки естественны, но не для половины"));

        // ---- РУСЛА ----
        var runs = ChannelRuns(drainage, side, mainChannelFlow);
        if (runs.Count > 0)
        {
            runs.Sort();
            checks.Add(new("русла", "прямой участок p90",
                           runs[(int)(runs.Count * 0.9)] * cellKm * 1000, " м", 0, 2000,
                           "в природе до 1-2 км"));
            checks.Add(new("русла", "наибольший прямой",
                           runs[^1] * cellKm * 1000, " м", 0, 4000, ""));

            // ---- РЕЗКИЕ ПОВОРОТЫ РУСЕЛ ----
            //
            // Меры игры и стенда должны совпадать. Этой не хватало: на стенде
            // двадцать пять мер, в игре двадцать четыре.
            //
            // Река должна вилять плавно, а не идти лесенкой. Считается доля
            // поворотов на девяносто градусов и круче.
            {
                int turns = 0, sharp = 0;
                var seenT = new bool[side * side];
                for (int s0 = 0; s0 < side * side; s0++)
                {
                    if (seenT[s0] || drainage[s0] < 1500f) continue;
                    int c = s0, prevDir = -1, guard = 0;
                    while (guard++ < 4000)
                    {
                        seenT[c] = true;
                        int i2 = c % side, j2 = c / side, next = -1, dir = -1;
                        float bf = drainage[c];
                        for (int dj = -1; dj <= 1; dj++)
                        for (int di = -1; di <= 1; di++)
                        {
                            if (di == 0 && dj == 0) continue;
                            int x = i2 + di, y = j2 + dj;
                            if (x < 0 || y < 0 || x >= side || y >= side) continue;
                            int t = y * side + x;
                            if (drainage[t] > bf)
                            { bf = drainage[t]; next = t; dir = (dj + 1) * 3 + (di + 1); }
                        }
                        if (next < 0 || seenT[next]) break;
                        if (prevDir >= 0 && dir >= 0)
                        {
                            turns++;
                            int a1 = DirAngle(prevDir), a2 = DirAngle(dir);
                            int diff = Math.Abs(a1 - a2);
                            if (diff > 4) diff = 8 - diff;
                            if (diff >= 2) sharp++;      // 90° и больше
                        }
                        prevDir = dir; c = next;
                    }
                }
                checks.Add(new("русла", "резких поворотов",
                               100.0 * sharp / Math.Max(turns, 1), "%", 0, 15,
                               "река должна вилять плавно, а не идти лесенкой"));
            }
        }
        checks.Add(new("русла", "доля площади",
                       100.0 * riverCells / field.Length, "%", 0.5, 3, ""));

        // ---- СВЯЗНОСТЬ РЕЧНОЙ СЕТИ ----
        //
        // Этой меры не было вовсе, а пользователь видел на снимках русла,
        // расположенные отрезками. Замер подтвердил: сеть распадалась на 118
        // кусков, из них 42 короче трёх километров.
        //
        // В природе река — единая нить от истока к устью: обрывков быть не
        // должно.
        // ---- МЕРА ИСПРАВЛЕНА: ВОДА СЧИТАЕТСЯ ЦЕЛИКОМ ----
        //
        // Прежде куски считались по СУШЕ: русло, входящее в озеро, обрывалось,
        // и продолжение за озером шло отдельным куском. Журнал показывал
        // 44 куска при норме 20.
        //
        // Замер на стенде: из 77 кусков 74 примыкают к ОЗЕРУ, обрывов в никуда
        // НОЛЬ. Сеть не рвётся — она входит в озёра и выходит.
        // ---- СЧИТАЮТСЯ КУСКИ, В КОТОРЫХ ЕСТЬ РУСЛО ----
        //
        // Прежде считались все куски воды разом, и ОТДЕЛЬНЫЕ ОЗЁРА без реки
        // шли разрывами: из 134 кусков 128 были озёрами без стока, а речной
        // сети — ОДИН кусок.
        //
        // Озеро без реки не разрыв: это стоячая вода.
        var netParts = Blobs(k => IsRiver(k) || IsLake(k), side, false);
        int withRiver = netParts.Count(p => p.cells.Any(IsRiver));
        int stubs = netParts.Count(p => p.count * cellKm < 3
                                        && p.count * cellKm * cellKm < 0.05);
        checks.Add(new("русла", "кусков сети", withRiver, "", 1, 20,
                       "река должна быть единой нитью"));
        // Приведено к площади: обрывков тем больше, чем больше уровень.
        checks.Add(new("русла", "обрывков короче 3 км", stubs / areaRatio,
                       " на 115 км", 0, 5, ""));

        // ---- ИЗВИЛИСТОСТЬ РУСЛА ----
        //
        // Пользователь: уровень напоминает схему распайки на плате. Мера
        // прямизны этого не ловила — она считает длину отрезков МЕЖДУ
        // поворотами, а путь может оставаться прямым в целом.
        //
        // Извилистость — длина пути к прямому расстоянию между концами. У
        // природной реки 1.3-3.0, у прямой единица.
        {
            var seenSin = new bool[side * side];
            var vals = new List<double>();
            for (int s0 = 0; s0 < side * side; s0++)
            {
                if (seenSin[s0] || !IsRiver(s0)) continue;
                int c = s0, guard = 0; double len = 0;
                int i0 = s0 % side, j0 = s0 / side, li = i0, lj = j0;
                while (guard++ < 4000)
                {
                    seenSin[c] = true;
                    int i = c % side, j = c / side, next = -1;
                    float bf = drainage[c];
                    for (int dj = -1; dj <= 1; dj++)
                    for (int di = -1; di <= 1; di++)
                    {
                        if (di == 0 && dj == 0) continue;
                        int x = i + di, y = j + dj;
                        if (x < 0 || y < 0 || x >= side || y >= side) continue;
                        int t = y * side + x;
                        if (drainage[t] > bf) { bf = drainage[t]; next = t; }
                    }
                    if (next < 0 || seenSin[next]) break;
                    int ni = next % side, nj = next / side;
                    len += (ni != i && nj != j) ? 1.41421356 : 1.0;
                    li = ni; lj = nj; c = next;
                }
                if (len < 20) continue;
                double straight = Math.Sqrt((li - i0) * (li - i0) + (lj - j0) * (lj - j0));
                if (straight < 1) continue;
                vals.Add(len / straight);
            }
            if (vals.Count > 0)
            {
                vals.Sort();
                checks.Add(new("русла", "извилистость", vals[vals.Count / 2], "", 1.3, 3.0,
                               "у природной реки 1.3-3.0, у прямой единица"));
            }
        }

        // ---- ПАРАЛЛЕЛЬНЫЕ РУСЛА ----
        //
        // Две нити рядом, идущие вниз по склону. В природе притоки СХОДЯТСЯ.
        {
            int pairs = 0, riverCells2 = 0;
            for (int j = 2; j < side - 2; j++)
            for (int i = 2; i < side - 5; i++)
            {
                int k = j * side + i;
                if (!IsRiver(k)) continue;
                riverCells2++;
                for (int d = 2; d <= 4; d++)
                {
                    int k2 = j * side + i + d;
                    if (!IsRiver(k2)) continue;
                    bool landBetween = true;
                    for (int m = 1; m < d; m++)
                        if (IsRiver(j * side + i + m)) landBetween = false;
                    if (!landBetween) continue;
                    if (field[k] > field[(j + 1) * side + i]
                        && field[k2] > field[(j + 1) * side + i + d])
                    { pairs++; break; }
                }
            }
            checks.Add(new("русла", "параллельные пары",
                           100.0 * pairs / Math.Max(riverCells2, 1), "%", 0, 0.1,
                           "притоки должны сходиться, а не идти рядом"));
        }

        // ---- ОСТРОВА ----
        checks.Add(new("острова", "число",
                       Blobs(k => IsLake(k) || IsRiver(k), side, true).Count, "", 1, 30, ""));

        // ---- ПЕЧАТЬ ----
        // ---- ПЕЧАТЬ ПЕРЕНЕСЕНА В КОНЕЦ ----
        //
        // Она стояла ЗДЕСЬ, а мера «чаш залито меньше половины» добавлялась
        // ниже — и в журнал не попадала. Оттого в игре выходило двадцать
        // четыре меры против двадцати пяти на стенде.

        // ---- ЧАШИ ПОШТУЧНО ----
        //
        // ---- ПРЕЖНЯЯ МЕРА ЛГАЛА ----
        //
        // Я обходил ячейки САМОГО ОЗЕРА и спрашивал, какая доля из них — чаша.
        // Ответ всегда сто процентов: озеро внутри чаши по определению. Чаша
        // ВОКРУГ воды в счёт не входила вовсе.
        //
        // Оттого журнал показывал «залито 100%» там, где вода лежала пятном на
        // дне широкой зелёной чаши — что пользователь и видел на снимках.
        //
        // Здесь обход идёт ПО ЧАШАМ: сколько чаши под водой.
        var bowls = Blobs(k => B(k) > lakeMinDepthM, side, false);
        bowls.Sort((a, b) => b.count.CompareTo(a.count));
        SessionLog.Print("[чаши-поштучно] чаша км² | под водой % | глубина м | вытянут");
        int halfEmpty = 0;
        foreach (var bowl in bowls)
        {
            double areaKm = bowl.count * cellKm * cellKm;
            if (areaKm < 0.5) continue;
            int wet = 0; double depth = 0;
            foreach (var k in bowl.cells)
            {
                if (IsLake(k)) wet++;
                if (D(k) > depth) depth = D(k);
            }
            double pct = 100.0 * wet / bowl.count;
            if (pct < 50) halfEmpty++;
            if (areaKm >= 0.5 && bowls.IndexOf(bowl) < 12)
                SessionLog.Print($"  {areaKm,8:F1} | {pct,11:F0} | {depth,9:F0} | {bowl.elong,7:F1}"
                    + (pct < 50 ? "   <- ПОЛУПУСТАЯ" : ""));
        }
        int bigBowls = bowls.Count(x => x.count * cellKm * cellKm >= 0.5);
        checks.Add(new("озёра", "чаш залито меньше половины", halfEmpty / areaRatio, " на 115 км", 0,
                       Math.Max(bigBowls / 5, 1), "вода лежит пятном на дне чаши"));

        // ---- РАЗБИВКА ПО ОБЛАСТЯМ ----
        //
        // Уровень делится на клетки. По каждой: высоты, вода, покров. Так видно,
        // где именно беда, а не только что она есть.
        SessionLog.Print($"[области] сетка {RegionGrid}x{RegionGrid}, "
            + $"клетка {extentWorld / RegionGrid * metresPerUnit / 1000f:F1} км");
        SessionLog.Print("  клетка | высота м | уклон | вода% | озёр | русло%");
        int rs = side / RegionGrid;
        for (int rj = 0; rj < RegionGrid; rj++)
        for (int ri = 0; ri < RegionGrid; ri++)
        {
            int n = 0, wcells = 0, rcells = 0;
            double hsum = 0, slsum = 0;
            for (int j = rj * rs + 1; j < Math.Min((rj + 1) * rs, side - 1); j++)
            for (int i = ri * rs + 1; i < Math.Min((ri + 1) * rs, side - 1); i++)
            {
                int k = j * side + i;
                n++;
                hsum += (field[k] * heightScale + lift) * metresPerUnit;
                double gx = (field[k + 1] - field[k - 1]) / (2 * cell);
                double gz = (field[k + side] - field[k - side]) / (2 * cell);
                slsum += Math.Atan(Math.Sqrt(gx * gx + gz * gz) * heightScale) * 180 / Math.PI;
                if (IsLake(k)) wcells++;
                if (IsRiver(k)) rcells++;
            }
            if (n == 0) continue;
            SessionLog.Print($"  {ri},{rj}    | {hsum / n,8:F0} | {slsum / n,5:F1} | "
                + $"{100.0 * wcells / n,5:F1} | {LakesIn(big, ri, rj, rs),4} | "
                + $"{100.0 * rcells / n,6:F1}");
        }
    
        var bad = checks.Where(c => !c.Ok).ToList();
        SessionLog.Print($"[проверка] {checks.Count - bad.Count} из {checks.Count} в норме");
        foreach (var c in bad)
            SessionLog.Print($"  НАРУШЕНО [{c.Group}] {c.Name}: {c.Value:F1}{c.Unit} "
                + $"(норма {c.Lo:F1}..{c.Hi:F1})"
                + (c.Note.Length > 0 ? $" — {c.Note}" : ""));
        foreach (var c in checks.Where(c => c.Ok))
            SessionLog.Print($"  годно [{c.Group}] {c.Name}: {c.Value:F1}{c.Unit}");
}

    private static int LakesIn(List<(int count, double elong, double x, double z, List<int> cells)> lakes,
                               int ri, int rj, int rs)
        => lakes.Count(l => (int)(l.x / rs) == ri && (int)(l.z / rs) == rj);

    private static List<(int count, double elong, double x, double z, List<int> cells)>
        Blobs(Func<int, bool> mask, int side, bool invert)
    {
        var seen = new bool[side * side];
        var stack = new Stack<int>();
        var result = new List<(int, double, double, double, List<int>)>();
        for (int s0 = 0; s0 < side * side; s0++)
        {
            bool want = invert ? !mask(s0) : mask(s0);
            if (seen[s0] || !want) { seen[s0] = true; continue; }
            var cells = new List<int>();
            bool edge = false;
            long sx = 0, sz = 0;
            int minI = side, maxI = 0, minJ = side, maxJ = 0;
            stack.Push(s0); seen[s0] = true;
            while (stack.Count > 0)
            {
                int c = stack.Pop(); cells.Add(c); sx += c % side; sz += c / side;
                int i = c % side, j = c / side;
                if (i == 0 || j == 0 || i == side - 1 || j == side - 1) edge = true;
                if (i < minI) minI = i; if (i > maxI) maxI = i;
                if (j < minJ) minJ = j; if (j > maxJ) maxJ = j;
                for (int dj = -1; dj <= 1; dj++)
                for (int di = -1; di <= 1; di++)
                {
                    int x = i + di, y = j + dj;
                    if (x < 0 || y < 0 || x >= side || y >= side) continue;
                    int t = y * side + x;
                    bool wt = invert ? !mask(t) : mask(t);
                    if (seen[t] || !wt) continue;
                    seen[t] = true; stack.Push(t);
                }
            }
            if (invert && (edge || cells.Count >= side * side / 40)) continue;
            int w = maxI - minI + 1, h = maxJ - minJ + 1;
            result.Add((cells.Count, (double)Math.Max(w, h) / Math.Max(1, Math.Min(w, h)),
                        (double)sx / cells.Count, (double)sz / cells.Count, cells));
        }
        return result;
    }

    /// <summary>Длины прямых участков русла. Идёт ВДОЛЬ русла, а не по строкам
    /// сетки: построчная мера считала прямым всё, что тянется вдоль строки.</summary>
    private static List<int> ChannelRuns(float[] drainage, int side, float minFlow)
    {
        var runs = new List<int>();
        if (drainage == null) return runs;
        var seen = new bool[side * side];
        for (int s0 = 0; s0 < side * side; s0++)
        {
            if (seen[s0] || drainage[s0] < minFlow) continue;
            int c = s0, run = 1, prevDir = -1, guard = 0;
            while (guard++ < 4000)
            {
                seen[c] = true;
                int i = c % side, j = c / side, next = -1, dir = -1;
                float bf = drainage[c];
                for (int dj = -1; dj <= 1; dj++)
                for (int di = -1; di <= 1; di++)
                {
                    if (di == 0 && dj == 0) continue;
                    int x = i + di, y = j + dj;
                    if (x < 0 || y < 0 || x >= side || y >= side) continue;
                    int t = y * side + x;
                    if (drainage[t] > bf) { bf = drainage[t]; next = t; dir = (dj + 1) * 3 + (di + 1); }
                }
                if (next < 0 || seen[next]) break;
                if (dir == prevDir) run++;
                else { if (run > 1) runs.Add(run); run = 1; prevDir = dir; }
                c = next;
            }
            if (run > 1) runs.Add(run);
        }
        return runs;
    }
}
