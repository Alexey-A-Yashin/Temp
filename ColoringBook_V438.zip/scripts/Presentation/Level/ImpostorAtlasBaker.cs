using System;
using System.Collections.Generic;
using Godot;
using ColoringBook.Domain.Level;
using ColoringBook.Infrastructure.Generation.Plants;

namespace ColoringBook.Presentation.Level;

/// <summary>
/// АТЛАС ИМПОСТОРОВ: предрендеренные виды растения с нескольких углов.
///
/// ЗАЧЕМ ЗАМЕНА. Прежний дальний уровень — две скрещённые карточки с текстурой
/// листа. На скриншоте это читалось как зелёные прямоугольники, торчащие из склона:
/// крестовина из двух прямоугольников и выглядит как крестовина из двух
/// прямоугольников, никакой ракурс этого не спасает.
///
/// Здесь дерево один раз рендерится с восьми направлений вокруг оси, кадры
/// складываются в горизонтальный атлас, а на уровне рисуется ОДНА карточка,
/// повёрнутая к камере, с выбором кадра по углу обзора.
///
/// БЮДЖЕТ. Одна карточка — 2 треугольника вместо 4 у крестовины, то есть замена
/// ещё и дешевле. Память: 8 ракурсов по 128 точек — 0.5 МБ на породу, около 9 МБ
/// на все 18 древесных пород. Шаг по углу 45°, максимальная ошибка ракурса 22.5° —
/// на дистанции свыше 20 единиц, где импостор и применяется, это незаметно.
///
/// Выпекание идёт ОДИН РАЗ при построении каталога, а не в кадре.
/// </summary>
public sealed partial class ImpostorAtlasBaker : Node
{
    /// <summary>Сколько направлений вокруг оси. 8 — компромисс между памятью и
    /// точностью ракурса (шаг 45°).</summary>
    public int AngleCount { get; set; } = 8;

    /// <summary>Разрешение одного кадра. 128 хватает: импостор виден с дистанции
    /// свыше 20 единиц, где дерево занимает меньше 60 точек экрана.</summary>
    public int FrameSize { get; set; } = 128;

    public sealed class Atlas
    {
        public required ImageTexture Texture;
        public required int Angles;
        /// <summary>Отношение высоты растения к ширине — только для лога.</summary>
        public required float AspectHeightOverWidth;

        /// <summary>Сторона кадра В ЛОКАЛЬНЫХ ЕДИНИЦАХ МЕША растения.
        ///
        /// Ключевая величина. Карточка раньше строилась единичной высоты, а матрица
        /// экземпляра несёт масштаб s = targetH / LocalHeight, рассчитанный для меша
        /// высотой LocalHeight (у лиственного это около восьми). Единичная карточка
        /// получала тот же множитель и выходила примерно в восемь раз мельче дерева —
        /// на отладочной заливке это были пурпурные квадратики размером с траву.
        /// Здесь размер задан в тех же единицах, что и меш, поэтому масштаб экземпляра
        /// приводит карточку ровно к габаритам растения.</summary>
        public required float FrameLocalSize;

        /// <summary>Высота центра кадра над основанием растения, в тех же единицах.
        /// Камера при выпекании смотрела именно в эту точку, поэтому и карточку надо
        /// поднять на неё — иначе силуэт окажется наполовину под землёй.</summary>
        public required float FrameLocalCentreY;
        /// <summary>Доля непрозрачных точек. Ноль означает пустой снимок: атлас создан,
        /// но рисовать по нему нечего.</summary>
        public required float OpaqueFraction;

        /// <summary>ЗАПОЛНЕННОСТЬ СИЛУЭТА: доля непрозрачных точек внутри самого
        /// силуэта, а не внутри кадра атласа. OpaqueFraction для этого не годится —
        /// он делит на площадь КВАДРАТНОГО кадра, и у сосны с отношением сторон 3.46
        /// даже сплошное дерево дало бы 29%. Именно поэтому «5% непрозрачных» ничего
        /// не говорило о плотности кроны.</summary>
        public required float CrownFill;

        /// <summary>Доля площади силуэта, приходящаяся на МЕЛКИЕ дырки — те, во что
        /// нельзя попасть кистью. Учебники рисунка требуют, чтобы просвет в кроне был
        /// либо крупным «листовым окном», либо отсутствовал; сыпь мельче порога — это
        /// дефект, и на шаблоне она превращается в чёрные кляксы.</summary>
        public required float SmallHoleFraction;
    }

    /// <summary>
    /// Выпечь атлас для готового меша растения.
    ///
    /// Рендерится в SubViewport с прозрачным фоном и плоским освещением: тени и
    /// блики на импосторе неуместны, потому что он всегда повёрнут к камере и
    /// освещённые стороны иначе «поедут» при повороте.
    /// </summary>
    public async System.Threading.Tasks.Task<Atlas?> BakeAsync(Mesh mesh, Material material)
    {
        if (mesh == null) return null;

        var aabb = mesh.GetAabb();
        float w = MathF.Max(MathF.Max(aabb.Size.X, aabb.Size.Z), 1e-3f);
        float hgt = MathF.Max(aabb.Size.Y, 1e-3f);

        var vp = new SubViewport
        {
            Size = new Vector2I(FrameSize, FrameSize),
            RenderTargetUpdateMode = SubViewport.UpdateMode.Always,
            TransparentBg = true,
            Msaa3D = Viewport.Msaa.Disabled,
            OwnWorld3D = true,   // своя сцена: рендерим только это растение
        };
        AddChild(vp);

        var holder = new Node3D();
        vp.AddChild(holder);

        var inst = new MeshInstance3D
        {
            Mesh = mesh,
            MaterialOverride = material,
            CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
        };
        holder.AddChild(inst);

        // Плоский свет: импостор не должен нести собственную светотень, иначе при
        // повороте карточки к камере освещение будет противоречить сцене.
        var lightNode = new DirectionalLight3D
        {
            RotationDegrees = new Vector3(-35, 25, 0),
            LightEnergy = 1.0f,
            ShadowEnabled = false,
        };
        vp.AddChild(lightNode);

        // ФОН. Прежде здесь стоял WorldEnvironment с BackgroundMode = Canvas. Для
        // SubViewport с собственным миром и прозрачным фоном это лишняя сущность:
        // холста в этом мире нет, а режим фона влияет на то, что попадёт в альфа-канал
        // снимка. Оставлен только источник окружающего света — ради него окружение и
        // заводилось, чтобы дерево не выпекалось наполовину чёрным.
        var env = new WorldEnvironment
        {
            Environment = new Godot.Environment
            {
                BackgroundMode = Godot.Environment.BGMode.ClearColor,
                AmbientLightSource = Godot.Environment.AmbientSource.Color,
                AmbientLightColor = new Color(1f, 1f, 1f),
                AmbientLightEnergy = 0.9f,
            }
        };
        vp.AddChild(env);

        // Ортогональная камера: у импостора не должно быть перспективного искажения,
        // иначе кадр не совпадёт с плоской карточкой на уровне.
        var cam = new Camera3D
        {
            Projection = Camera3D.ProjectionType.Orthogonal,
            Size = MathF.Max(hgt, w) * 1.05f,
            Near = 0.01f,
            Far = MathF.Max(hgt, w) * 6f,
        };
        vp.AddChild(cam);

        float dist = MathF.Max(hgt, w) * 2.2f;
        float centreY = aabb.Position.Y + aabb.Size.Y * 0.5f;

        var frames = new List<Image>(AngleCount);
        for (int a = 0; a < AngleCount; a++)
        {
            float ang = MathF.Tau * a / AngleCount;
            cam.Position = new Vector3(MathF.Sin(ang) * dist, centreY, MathF.Cos(ang) * dist);
            cam.LookAt(new Vector3(0, centreY, 0), Vector3.Up);

            await ToSignal(RenderingServer.Singleton, RenderingServer.SignalName.FramePostDraw);
            var img = vp.GetTexture()?.GetImage();
            if (img == null) { vp.QueueFree(); return null; }
            frames.Add(img);
        }

        // Склейка в горизонтальную ленту.
        var atlas = Image.CreateEmpty(FrameSize * AngleCount, FrameSize, false, Image.Format.Rgba8);
        atlas.Fill(new Color(0, 0, 0, 0));
        for (int a = 0; a < frames.Count; a++)
        {
            // ФОРМАТ ПРИВОДИТСЯ ЯВНО. BlitRect копирует байты и требует совпадения
            // форматов источника и приёмника; при расхождении копирования просто не
            // происходит, молча, и атлас остаётся полностью прозрачным — а значит
            // шейдер импостора отбрасывает по альфе каждый его фрагмент, и на дальнем
            // плане не видно ничего. Формат текстуры SubViewport зависит от настроек
            // рендера, поэтому полагаться на совпадение нельзя.
            if (frames[a].GetFormat() != Image.Format.Rgba8)
                frames[a].Convert(Image.Format.Rgba8);
            atlas.BlitRect(frames[a],
                new Rect2I(0, 0, FrameSize, FrameSize),
                new Vector2I(a * FrameSize, 0));
        }

        vp.QueueFree();

        // ПРОВЕРКА РЕЗУЛЬТАТА ДО ЕГО ПРИМЕНЕНИЯ.
        //
        // Пустой атлас неотличим от рабочего по всем внешним признакам: объект создан,
        // счётчик в HUD увеличился, ошибок в логе нет — а на экране дальний план пуст.
        // Поэтому доля непрозрачных точек считается здесь и возвращается наружу;
        // вызывающий код отказывается от такого атласа и оставляет запасную геометрию.
        float opaque = OpaqueFraction(atlas);
        SilhouetteStats(frames, out float crownFill, out float smallHoles);

        return new Atlas
        {
            Texture = ImageTexture.CreateFromImage(atlas),
            Angles = AngleCount,
            AspectHeightOverWidth = hgt / w,
            FrameLocalSize = MathF.Max(hgt, w) * 1.05f,
            FrameLocalCentreY = centreY,
            OpaqueFraction = opaque,
            CrownFill = crownFill,
            SmallHoleFraction = smallHoles,
        };
    }

    /// <summary>
    /// ЗАПОЛНЕННОСТЬ СИЛУЭТА И МЕЛКИЕ ДЫРКИ — мера пригодности кроны.
    ///
    /// Считается по тем же кадрам, что уже отрисованы для атласа: восемь ракурсов
    /// каждого растения, то есть готовый стенд, за который не надо платить ни новой
    /// сценой, ни нажатием клавиши. Раньше эти кадры давали только ответ «пусто или
    /// нет».
    ///
    /// Силуэт = маска непрозрачного, замкнутая заливкой внутренних дырок. Дырка мелкая,
    /// если в неё не вписывается круг радиусом MinHoleRadiusPx — тот же порог
    /// закрашиваемости, что в конвейере шаблона, приведённый к размеру кадра.
    ///
    /// Замеры на прежней сборке для сравнения: хвойные давали 5-17% «непрозрачных
    /// точек кадра», и по этому числу нельзя было понять ничего — оно делится на
    /// площадь квадратного кадра. Настоящая заполненность силуэта и доля сыпи внутри
    /// него — это и есть то, что определяет, станет ли дерево пятном на раскраске.
    /// </summary>
    private const float MinHoleRadiusPx = 3.0f;

    private void SilhouetteStats(List<Image> frames, out float crownFill, out float smallHoles)
    {
        crownFill = 0f;
        smallHoles = 0f;
        if (frames.Count == 0) return;

        double fillSum = 0, holeSum = 0;
        int counted = 0;
        foreach (var f in frames)
        {
            int w = f.GetWidth(), h = f.GetHeight();
            if (w <= 2 || h <= 2) continue;
            int n = w * h;
            var opaque = new bool[n];
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                opaque[y * w + x] = f.GetPixel(x, y).A >= 0.5f;

            // СИЛУЭТ — ЗАМЫКАНИЕ МАСКИ, А НЕ ЗАЛИВКА ОТ КРАЯ.
            //
            // Первая версия брала силуэт заливкой прозрачного от кромки кадра: всё,
            // куда снаружи не добраться, считалось внутренностью. На сплошной фигуре
            // это верно, а на КРОНЕ бессмысленно: просветы между карточками почти все
            // сообщаются с небом, заливка проходит сквозь них насквозь, и метрика
            // выродилась бы в «заполненность 100%, дырок 0%» для любого дерева, каким
            // бы рыхлым оно ни было. Проверка на ячейках атласа это и показала — там
            // вышло 87-100% там, где счёт по проекции даёт 60-90%.
            //
            // Силуэт кроны — то, что художник обвёл бы одной линией, то есть маска,
            // замкнутая по масштабу просветов. Радиус замыкания привязан к размеру
            // кадра, чтобы мера не зависела от разрешения выпекания.
            int closeR = Math.Max(2, FrameSize / 20);
            var hullMask = Close(opaque, w, h, closeR);
            FillHoles(hullMask, w, h);

            int hull = 0, opaqueN = 0;
            for (int i = 0; i < n; i++)
            {
                if (hullMask[i]) hull++;
                if (opaque[i]) opaqueN++;
            }
            if (hull == 0) continue;

            // Дырки: внутри силуэта, но прозрачные. Мелкие — те, в которые не
            // вписывается круг порогового радиуса (чемфер 3-4, как в конвейере шаблона).
            var hole = new bool[n];
            for (int i = 0; i < n; i++) hole[i] = hullMask[i] && !opaque[i];
            var dist = ChamferInside(hole, w, h);
            int smallN = 0, holeN = 0;
            var lab = new int[n];
            int labels = 0;
            var st2 = new Stack<int>();
            for (int start = 0; start < n; start++)
            {
                if (!hole[start] || lab[start] != 0) continue;
                labels++;
                st2.Push(start); lab[start] = labels;
                int area = 0; float maxR = 0f;
                while (st2.Count > 0)
                {
                    int i = st2.Pop();
                    area++;
                    if (dist[i] > maxR) maxR = dist[i];
                    int x = i % w, y = i / w;
                    void Push(int j) { if (hole[j] && lab[j] == 0) { lab[j] = labels; st2.Push(j); } }
                    if (x > 0) Push(i - 1);
                    if (x < w - 1) Push(i + 1);
                    if (y > 0) Push(i - w);
                    if (y < h - 1) Push(i + w);
                }
                holeN += area;
                if (maxR < MinHoleRadiusPx) smallN += area;
            }

            fillSum += (double)opaqueN / hull;
            holeSum += (double)smallN / hull;
            counted++;
        }
        if (counted == 0) return;
        crownFill = (float)(fillSum / counted);
        smallHoles = (float)(holeSum / counted);
    }

    /// <summary>Морфологическое замыкание квадратом: расширение, затем сжатие.
    /// Разделимое по осям — O(n·r) вместо O(n·r²).</summary>
    private static bool[] Close(bool[] src, int w, int h, int r)
    {
        var a = Morph(src, w, h, r, dilate: true);
        return Morph(a, w, h, r, dilate: false);
    }

    private static bool[] Morph(bool[] src, int w, int h, int r, bool dilate)
    {
        var tmp = new bool[w * h];
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            bool acc = !dilate;
            for (int dx = -r; dx <= r; dx++)
            {
                bool v = src[y * w + Math.Clamp(x + dx, 0, w - 1)];
                acc = dilate ? (acc || v) : (acc && v);
            }
            tmp[y * w + x] = acc;
        }
        var outp = new bool[w * h];
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            bool acc = !dilate;
            for (int dy = -r; dy <= r; dy++)
            {
                bool v = tmp[Math.Clamp(y + dy, 0, h - 1) * w + x];
                acc = dilate ? (acc || v) : (acc && v);
            }
            outp[y * w + x] = acc;
        }
        return outp;
    }

    /// <summary>Замкнуть внутренние пустоты маски: всё, что не достижимо от кромки.</summary>
    private static void FillHoles(bool[] mask, int w, int h)
    {
        int n = w * h;
        var outside = new bool[n];
        var st = new Stack<int>();
        void Seed(int i) { if (!mask[i] && !outside[i]) { outside[i] = true; st.Push(i); } }
        for (int x = 0; x < w; x++) { Seed(x); Seed((h - 1) * w + x); }
        for (int y = 0; y < h; y++) { Seed(y * w); Seed(y * w + w - 1); }
        while (st.Count > 0)
        {
            int i = st.Pop();
            int x = i % w, y = i / w;
            if (x > 0) Seed(i - 1);
            if (x < w - 1) Seed(i + 1);
            if (y > 0) Seed(i - w);
            if (y < h - 1) Seed(i + w);
        }
        for (int i = 0; i < n; i++) if (!outside[i]) mask[i] = true;
    }

    /// <summary>Чемферное расстояние 3-4 до ближайшей точки вне маски, в точках.</summary>
    private static float[] ChamferInside(bool[] mask, int w, int h)
    {
        int n = w * h;
        const int Inf = 1 << 24;
        var d = new int[n];
        for (int i = 0; i < n; i++) d[i] = mask[i] ? Inf : 0;
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            int i = y * w + x, v = d[i];
            if (x > 0) v = Math.Min(v, d[i - 1] + 3);
            if (y > 0) v = Math.Min(v, d[i - w] + 3);
            if (x > 0 && y > 0) v = Math.Min(v, d[i - w - 1] + 4);
            if (x < w - 1 && y > 0) v = Math.Min(v, d[i - w + 1] + 4);
            d[i] = v;
        }
        for (int y = h - 1; y >= 0; y--)
        for (int x = w - 1; x >= 0; x--)
        {
            int i = y * w + x, v = d[i];
            if (x < w - 1) v = Math.Min(v, d[i + 1] + 3);
            if (y < h - 1) v = Math.Min(v, d[i + w] + 3);
            if (x < w - 1 && y < h - 1) v = Math.Min(v, d[i + w + 1] + 4);
            if (x > 0 && y < h - 1) v = Math.Min(v, d[i + w - 1] + 4);
            d[i] = v;
        }
        var res = new float[n];
        for (int i = 0; i < n; i++) res[i] = d[i] / 3f;
        return res;
    }

    /// <summary>
    /// Доля точек с альфой не ниже порога отсечения шейдера. Считается по сетке с шагом
    /// 4 точки: полный проход по 8 кадрам 128×128 — это 131 тысяча выборок на породу,
    /// а для ответа «пусто или нет» хватает шестнадцатой части.
    /// </summary>
    private static float OpaqueFraction(Image img)
    {
        int w = img.GetWidth(), h = img.GetHeight();
        if (w <= 0 || h <= 0) return 0f;
        int hit = 0, total = 0;
        for (int y = 0; y < h; y += 4)
            for (int x = 0; x < w; x += 4)
            {
                total++;
                if (img.GetPixel(x, y).A >= 0.5f) hit++;
            }
        return total > 0 ? (float)hit / total : 0f;
    }

    /// <summary>
    /// Карточка импостора: один четырёхугольник в плоскости XY.
    ///
    /// КВАДРАТ, А НЕ ПРЯМОУГОЛЬНИК ПО ПРОПОРЦИЯМ КРОНЫ. Кадр атласа выпекается
    /// ортогональной камерой с квадратным полем зрения (Size = max(h, w) · 1.05),
    /// то есть силуэт лежит внутри квадрата с полями. Прежняя карточка строилась по
    /// отношению высоты к ширине и растягивала этот квадрат — силуэт сплющивался
    /// поперёк.
    ///
    /// Размеры — В ЛОКАЛЬНЫХ ЕДИНИЦАХ МЕША растения, чтобы масштаб экземпляра
    /// (targetH / LocalHeight) привёл карточку к тем же габаритам, что и само дерево.
    ///
    /// UV покрывает ПЕРВЫЙ кадр атласа; нужный кадр выбирает шейдер по углу между
    /// направлением на камеру и осью экземпляра.
    /// </summary>
    public static ArrayMesh BuildCardMesh(float frameLocalSize, float frameLocalCentreY, int angles)
    {
        float half = MathF.Max(frameLocalSize, 1e-3f) * 0.5f;
        float y0 = frameLocalCentreY - half;
        float y1 = frameLocalCentreY + half;
        var verts = new[]
        {
            new Vector3(-half, y0, 0f),
            new Vector3( half, y0, 0f),
            new Vector3( half, y1, 0f),
            new Vector3(-half, y1, 0f),
        };
        float u1 = 1f / MathF.Max(angles, 1);
        var uvs = new[]
        {
            new Vector2(0f, 1f),
            new Vector2(u1, 1f),
            new Vector2(u1, 0f),
            new Vector2(0f, 0f),
        };
        var normals = new[] { Vector3.Back, Vector3.Back, Vector3.Back, Vector3.Back };
        var idx = new[] { 0, 1, 2, 0, 2, 3 };

        var arrays = new Godot.Collections.Array();
        arrays.Resize((int)Mesh.ArrayType.Max);
        arrays[(int)Mesh.ArrayType.Vertex] = verts;
        arrays[(int)Mesh.ArrayType.Normal] = normals;
        arrays[(int)Mesh.ArrayType.TexUV] = uvs;
        arrays[(int)Mesh.ArrayType.Index] = idx;

        var m = new ArrayMesh();
        m.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, arrays);
        return m;
    }
}
