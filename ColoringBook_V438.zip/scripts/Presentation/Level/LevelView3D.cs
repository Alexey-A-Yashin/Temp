using System;
using System.Collections.Generic;
using System.Linq;
using Godot;
using ColoringBook.Domain.Level;
using ColoringBook.Domain.Level.Season;
using ColoringBook.Infrastructure.Generation;
using ColoringBook.Infrastructure.Generation.Plants;
using ColoringBook.Infrastructure.Generation.Mapgen;
using ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;
using ColoringBook.Presentation.Diagnostics;

namespace ColoringBook.Presentation.Level;

/// <summary>
/// Heightmap-mesh:
/// - IDW по 3 ближайшим RegionData
/// - мягкая маска суши + 1 проход dilation → сглаженный контур
/// - реки вырезаются в heightmap (каналы) + отдельный широкий меш
/// </summary>
public partial class LevelView3D : Node3D
{
    private ShaderMaterial? _terrainMat;

    /// <summary>
    /// Какая доля радиуса кроны становится преградой, и её нижняя граница в метрах.
    ///
    /// ЗАМЕР, КОТОРЫЙ ОПРЕДЕЛИЛ ЭТИ ЧИСЛА. Среднее расстояние до ближайшего соседа
    /// у деревьев — 4.8 метра, а радиус кроны 10.5–14.9 метра. То есть кроны
    /// перекрываются кратно, и преграда «диаметром с крону» сделала бы лес
    /// непроходимым сплошь: игрок упирался бы в невидимую стену в шести метрах от
    /// ближайшего ствола.
    ///
    /// Поэтому преграда сделана по стволу с подлеском, а не по кроне. Само же
    /// расхождение — отдельная задача: у настоящей ели радиус кроны относится к
    /// высоте примерно как 1 к 8, у нас 1 к 2, и именно поэтому лес выглядит
    /// сплошной зелёной массой вместо отдельных деревьев.
    /// </summary>
    private const float TreeBlockerCrownFraction = 0.12f;
    private const float TreeBlockerMinMetres = 0.8f;

    /// <summary>Сторона ячейки поиска преград, мировые единицы. Подобрана так, чтобы
    /// в ячейке оказывалось несколько деревьев: перебор идёт по 3×3 ячейкам вокруг
    /// точки, и при слишком мелкой сетке словарь распухает, при слишком крупной
    /// перебор становится линейным.</summary>
    private const float BlockerCellSize = 4f;

    private readonly List<(float x, float z, float r)> _treeBlockers = new();
    private readonly Dictionary<(int, int), List<int>> _blockerGrid = new();

    private static bool IsTreeKind(VegetationKind k) =>
        k == VegetationKind.Pine || k == VegetationKind.Fir || k == VegetationKind.Deciduous;

    /// <summary>Разложить преграды по сетке. Вызывается один раз после укладки.</summary>
    private void RebuildBlockerGrid()
    {
        _blockerGrid.Clear();
        for (int i = 0; i < _treeBlockers.Count; i++)
        {
            var b = _treeBlockers[i];
            var cell = ((int)MathF.Floor(b.x / BlockerCellSize), (int)MathF.Floor(b.z / BlockerCellSize));
            if (!_blockerGrid.TryGetValue(cell, out var l))
            {
                l = new List<int>();
                _blockerGrid[cell] = l;
            }
            l.Add(i);
        }
    }

    /// <summary>
    /// Попадает ли точка внутрь преграды дерева. Используется пешим передвижением,
    /// чтобы игрок не входил внутрь ствола и кроны.
    /// </summary>
    public bool IsBlockedByTree(float worldX, float worldZ)
    {
        if (_blockerGrid.Count == 0) return false;
        int cx0 = (int)MathF.Floor(worldX / BlockerCellSize);
        int cz0 = (int)MathF.Floor(worldZ / BlockerCellSize);
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++)
            {
                if (!_blockerGrid.TryGetValue((cx0 + dx, cz0 + dz), out var l)) continue;
                for (int k = 0; k < l.Count; k++)
                {
                    var b = _treeBlockers[l[k]];
                    float ddx = worldX - b.x, ddz = worldZ - b.z;
                    if (ddx * ddx + ddz * ddz < b.r * b.r) return true;
                }
            }
        return false;
    }



    /// <summary>
    /// Перестроить градиентные полосы под текущий сезон и передать их в материал.
    /// Вызывается при построении уровня и при смене сезона — второе теперь стоит
    /// двух текстур 256×1 вместо перезаписи всего массива цветов вершин.
    /// </summary>
    private void UpdateTerrainGradients()
    {
        if (_terrainMat == null) return;
        _terrainMat.SetShaderParameter("grad_height", TerrainGradient.BuildHeightRamp(_season, HeightScale));
        _terrainMat.SetShaderParameter("grad_rock", TerrainGradient.BuildRockRamp(_season, HeightScale));
        _terrainMat.SetShaderParameter("height_max", HeightScale);
    }

    private const float WorldScale = 0.16f;

    /// <summary>
    /// РЕЖИМ ПРОВЕРКИ НОВОГО РЕЛЬЕФА.
    ///
    /// Включённым он отключает всё, что построено на старом генераторе: подробный
    /// чанк AlpineTerrain, воду, реки и растительность. В кадре остаётся только
    /// рельеф гребневого мультифрактала, покрывающий всю область без дыры под чанк.
    ///
    /// Нужно это, чтобы настраивать новый генератор по игровому кадру, а не по виду
    /// сверху: восемь попыток настройки фона делались по картинкам прототипа, и
    /// каждый раз оказывалось, что с земли всё выглядит иначе.
    ///
    /// Обход по клавише T в этом режиме идёт по СВОИМ позам — вдоль линии через
    /// область, на высоте глаз над новым рельефом.
    /// </summary>
    /// ПОЛЕ, А НЕ КОНСТАНТА. При const компилятор сворачивает ветки на этапе
    /// разбора и объявляет весь код за ними недостижимым: сборка дала CS0162 в трёх
    /// местах и пять CS8602 о разыменовании возможного null — анализ потока
    /// «терял» проверки, стоявшие после свёрнутого возврата. Со static readonly
    /// ветвление остаётся настоящим.
    public static readonly bool NewTerrainPreview = true;

    /// <summary>Строить дальний фон за краем чанка. Выключение возвращает прежний
    /// вид с чернотой за краем — для сравнения «до и после».</summary>
    private const bool FarBackgroundEnabled = true;

    private FarBackground? _farBackground;
    private bool _farBackgroundBuilt;

    /// <summary>Смещение фона по высоте — нужно позам обхода, чтобы камера встала
    /// над рельефом, а не под ним.</summary>
    private float _farBackgroundLift;

    /// <summary>
    /// Сколько МЕТРОВ в одной мировой единице.
    ///
    /// Раньше масштаба не существовало как понятия: высота игрока подбиралась «под
    /// рост взрослого» в единицах, высоты деревьев — отдельно и под вид сверху, ширина
    /// реки — отдельно. В итоге игрок ростом 1.65 единицы ходил среди сосен ростом
    /// 1.52. Один явный коэффициент связывает всё: от него считаются и высоты растений,
    /// и высота глаз, и пороги LOD.
    ///
    /// Значение выведено из двух независимых замеров: ширина русла 4.16 единицы при
    /// типичной альпийской реке 30–50 м и сторона чанка 147 единиц при долине около
    /// полутора километров. Оба дают примерно десять метров на единицу.
    /// </summary>
    public const float MetresPerUnit = 10f;
    /// <summary>
    /// Размах высот, на который натягиваются градиенты рельефа (height_max в
    /// шейдере).
    ///
    /// ЧИСЛО УСТАРЕЛО И БОЛЬШЕ НЕ ОПИСЫВАЕТ РЕЛЬЕФ. Оно верно для мира высотой
    /// в полсотни единиц; нынешнее поле лежит на 110..475 единицах, то есть
    /// доля высоты зажата в единицу по всей территории и градиент всюду отдаёт
    /// верхнюю запись.
    ///
    /// На цвет это уже не влияет: с biome_tint_weight = 1 albedo берётся у
    /// вершины, а градиенты не участвуют. До V308 они участвовали в одном месте
    /// — гасили ковёр дёрна через greenness, и потому дёрна не было нигде.
    ///
    /// Оставлено как есть НАМЕРЕННО: править надо не число, а решать, нужны ли
    /// градиенты вообще. Сейчас они мёртвый груз, и чинить размах у мёртвого
    /// груза — заплатка. Вынесено на решение.
    /// </summary>
    private const float HeightScale = 48f;

    /// <summary>
    /// Размер тайла текстуры рельефа в мировых единицах. UV = мировые X/Z, делённые на
    /// это число, поэтому текстура повторяется каждые TerrainUvTile единиц. Величина
    /// подобрана под масштаб сцены: карта 1000 * WorldScale(0.16) = 160 мировых единиц
    /// в поперечнике, при тайле 8 это 20 повторов на всю карту — достаточно мелко, чтобы
    /// деталь читалась вблизи, и достаточно крупно, чтобы не рябить вдали.
    /// </summary>
    private const float TerrainUvTile = 8f;

    /// <summary>
    /// Включение эрозии рельефа. СЕЙЧАС ВЫКЛЮЧЕНА — она в этом месте конвейера
    /// почти не даёт эффекта, и это подтверждено замером (см. лог, раздел 22.4).
    ///
    /// Коротко: рельеф здесь получен IDW-интерполяцией по ~6900 регионам, то есть уже
    /// гладкий на масштабе около 3 ячеек сетки. Частица эрозии за всю жизнь проходит
    /// единицы ячеек и физически не может прорезать долину в почти плоском поле.
    /// Замер: 71% изменения приходится на низкочастотный сдвиг (рельеф равномерно
    /// просел на 0.6 мировых единицы), и лишь 0.36 единицы — на детали формы, при
    /// высоте гор в десятки единиц. Увеличение числа шагов, скорости, трения и радиуса
    /// детализацию НЕ поднимает — упирается в гладкость исходного поля.
    ///
    /// Эродировать надо РАНЬШЕ — на уровне высот регионов в AlpineTerrain, до
    /// интерполяции. Это отдельная задача, см. лог.
    /// </summary>
    private const bool ErosionEnabled = false;

    /// <summary>
    /// Число частиц. Подобрано ЗАМЕРОМ по величине, которая определяет видимость:
    /// среднеквадратичное изменение рельефа в МИРОВЫХ единицах. Изменение меньше
    /// ~0.3 единиц глазом незаметно на горах высотой 48.
    ///
    /// Первая версия (45 тыс. частиц, слабые параметры) давала RMS всего 0.76 —
    /// поэтому на экране ничего и не поменялось. Замер это показывал сразу (рост
    /// резкости 1.10x), но я принял за успех другую метрику.
    ///
    /// | частиц | RMS, мир. ед. | рост резкости | время |
    /// |--------|---------------|---------------|-------|
    /// | 45 000 (было) | 0.76 | 1.10x | 132 мс |
    /// | 60 000 | 1.53 | 1.23x | 354 мс |
    /// | 90 000 | 2.24 | 1.38x | 525 мс |
    /// | 120 000 | 2.60 | 1.50x | 681 мс |
    /// </summary>
    private const int ErosionDroplets = 90000;

    /// <summary>Интенсивность размыва.</summary>
    private const float ErosionRate = 0.02f;

    /// <summary>
    /// Дальнобойность частиц. Терминальная скорость = наклон * Speed / (1 - Friction).
    /// При прежних 0.15/0.7 частица проходила всего ~13 ячеек из 256 и не успевала
    /// вырезать долину — материал просто перемешивался на месте.
    /// </summary>
    private const float ErosionSpeed = 0.6f;
    private const float ErosionFriction = 0.88f;
    private const int ErosionSteps = 200;

    /// <summary>Проходы термической эрозии и предельный перепад (угол откоса).</summary>
    private const int ThermalIterations = 6;
    private const float ThermalTalus = 0.006f;
    // V40: уже soft-edge (16→10), чтобы rim-горы у края карты не схлопывались
    // почти в ноль и продолжали закрывать горизонт с лодки.
    private const float SoftEdgeWidth = 10f;
    // Segment-based carve: radius covers inter-cell gaps (~region spacing)
    private const float RiverCarveRadius = 13f;

    // ---- V71: вид протоптанной тропы ----
    /// <summary>Полуширина утоптанного ядра тропы, единицы карты.
    /// Тропа должна быть заметно уже реки (полуширина 13), иначе читается как дорога.</summary>
    private const float TrailCoreRadius = 4.5f; // V112: ядро колеи шире травы

    /// <summary>Внешний радиус вместе с красной кромкой.</summary>
    private const float TrailEdgeRadius = 7.0f;

    /// <summary>Насколько ярко проступает красная кромка.</summary>
    private const float TrailEdgeStrength = 0.38f; // V111: меньше «красной наклейки»

    /// <summary>Цвет утоптанного грунта.</summary>
    // V111: сухой альпийский грунт (тирольский реф) — теплее и контрастнее зелени
    private const float TrailR = 0.62f, TrailG = 0.46f, TrailB = 0.26f; // V112 контрастнее
    /// <summary>
    /// Глубина врезки русла.
    ///
    /// V71: поднята с 0.15 до 0.26. Русло было расширено вдвое (полуширина 6.5 -> 13),
    /// а глубина осталась прежней — при профиле (1 - d/R)² вода растеклась вдвое шире
    /// на прежней глубине, и получилось широкое мелкое зеркало ВРОВЕНЬ С БЕРЕГОМ.
    /// На скриншоте это читалось как вода, поднявшаяся над поверхностью.
    ///
    /// Глубина масштабируется вместе с шириной, чтобы поперечный профиль русла
    /// сохранил прежнюю крутизну берегов.
    /// </summary>
    private const float RiverCarveDepth = 0.26f;

    /// <summary>Какую долю локальной отметки разрешено срезать под русло.
    /// Без этого ограничения врезка упиралась в нижний предел и давала каньон.</summary>
    private const float RiverCarveMaxFraction = 0.45f;
    private const float LakeCarveRadius = 16f;
    private const float LakeCarveDepth = 0.08f;

    private int _gridRes = 240;

    /// <summary>
    /// Шум микрорельефа поверхности. Детерминирован по сиду уровня — рельеф одного
    /// и того же уровня всегда одинаков.
    /// </summary>
    private SimplexNoise _detailNoise = new(1);

    /// <summary>Октавы микрорельефа: крупная неровность + средняя + мелкая рябь.</summary>
    private static readonly float[] DetailAmps = { 1.0f, 0.5f, 0.25f, 0.12f };

    /// <summary>
    /// Параметры эрозионных гребней. Подобраны замером крутизны рёбер сетки, а не на
    /// глаз: амплитуда 7 давала уклон 77° на ребре (иглы), 1.4 даёт 34° при 66° у
    /// существующих складок рельефа. Базовая частота и число октав ограничены так, чтобы
    /// самая мелкая октава была не короче ~3 ячеек сетки — иначе алиасинг.
    /// </summary>
    /// Амплитуда поднята 1.4 -> 3.0 после замера: p95 крутизны ребра при 3.0 составляет
    /// 56°, тогда как у существующих складок рельефа (визуально приемлемых) — 66°.
    /// То есть запас ещё остаётся. При 1.4 гребни давали лишь 35° и терялись на фоне
    /// общей гладкости — отсюда «горы как из парафина».
    /// <summary>
    /// Гребневой шум рельефа. ПАРАМЕТРЫ ПЕРЕСЧИТАНЫ ПО МАСШТАБУ (см. лог, раздел 25).
    ///
    /// Прежняя настройка (base=20, 3 октавы, амплитуда 3.0) работала только в диапазоне
    /// длин волн 2-8 мировых единиц — при высоте гор около 43. То есть шум добавлял
    /// мелкую шероховатость, а КРУПНЫХ ФОРМ (контрфорсы, кулуары, скальные пояса
    /// масштаба 20-50 единиц) не было вообще: их не даёт ни шум — слишком мелкий, ни
    /// регионы — между ними идёт интерполяция. Именно нехватка среднего масштаба и
    /// читается как «горы из парафина»: у настоящих гор рельеф есть на ВСЕХ масштабах.
    ///
    /// Стало: базовая длина волны около 42 мировых единиц, 4 октавы — покрывают
    /// диапазон 42 / 20 / 10 / 5, то есть от крупных форм до шероховатости.
    /// Амплитуда 9.0 распределяется по октавам с убыванием вдвое.
    ///
    /// Проверка крутизны: каждая октава даёт около 37° на ребро, при сложении со
    /// случайными фазами p95 выходит около 56° — ниже эталонных 66° у существующих
    /// складок рельефа, то есть иглы не появятся.
    /// </summary>
    /// ОТКАТ к 3.0 (31.07). Попытки усилить гребни (9, затем 20 вместе со снижением
    /// HeightScale) улучшения не дали: при 9 разницы не было видно, при 20 на горизонте
    /// появились острые зубцы — стало хуже. Метрика, по которой я подбирал (медианная
    /// крутизна склона), зубчатость НЕ ЛОВИТ: она определяется общей формой чаши, а
    /// гребневой шум создаёт локальные пики, в медиану не попадающие.
    private const float RidgeAmpMetres = 3.0f;

    /// <summary>Амплитуда складок рельефа, мировые единицы. Была 3.5 — при гейте по
    /// уклону это давало на дне p95 крутизны рёбер 38.5°, при 2.2 — 31.0°.</summary>
    private const float FoldAmpMetres = 2.2f;

    /// <summary>Проходов сглаживания поверхности воды. Врезка русла даёт бугры
    /// размером ~2 ячейки сетки, и одного прохода мало; 6 проходов дают радиус
    /// влияния около 6 ячеек, что перекрывает шаг между регионами.</summary>
    private const int WaterSmoothPasses = 6;

    /// <summary>На сколько мировых единиц зеркалу позволено превысить исходный
    /// уровень после сглаживания. Ноль возвращает рябь, слишком много — вода лезет
    /// на берег. Толщина воды у кромки для сравнения около 0.9.</summary>
    /// V71: понижен с 0.20 до 0.10. Допуск задавался при узком русле, где он был
    /// заведомо незаметен. На широком зеркале те же 0.20 дают видимый выход воды
    /// на берег по всей ширине.
    /// <summary>Доля глубины русла, до которой оно заполнено водой.
    /// Остаток — свободный борт, благодаря которому берег виден.</summary>
    private const float WaterFillRatio = 0.72f;

    /// <summary>Допуск подъёма воды над расчётным зеркалом.
    /// V72: обнулён. Замер показал, что 48% вершин воды упирались ровно в допуск,
    /// то есть он не сглаживал редкие выбросы, а поднимал зеркало.</summary>
    private const float WaterBankAllowance = 0f;
    private const float RidgeBaseFreq = 3.8f;
    private const int RidgeOctaves = 4;

    /// <summary>Частота слоёв породы по высоте. Больше значение — тоньше слои.</summary>
    private const float StrataFrequency = 46f;

    /// <summary>Сила слоистости по яркости и по оттенку.</summary>
    private const float StrataStrength = 0.10f;
    private const float StrataHue = 0.035f;

    /// <summary>
    /// Минимальная глубина, при которой рисуется поверхность воды.
    ///
    /// Значение подобрано РАСЧЁТОМ, а не на глаз. Прежнее 0.004 составляло всего 2.7%
    /// от глубины в центре русла, поэтому вода объявлялась почти до самого края радиуса
    /// врезки (13 единиц карты), где она поднята над дном лишь на 0.17 мировых единицы.
    /// При этом складки рельефа там ещё работали на 80% силы, то есть ±0.92 — БОЛЬШЕ,
    /// чем подъём воды. Рельеф торчал сквозь поверхность и разрывал её на «осколки»,
    /// а кромка получала рваную форму.
    ///
    /// При 0.016 вода у кромки поднята на 0.67 единицы, а складки к этому моменту уже
    /// погашены полностью (см. WetFadeDepth). Река при этом остаётся шириной ~4.5 ячейки
    /// сетки (2.8 мировых единицы) — уже, чем было, но по-прежнему читается.
    /// </summary>
    private const float WaterMinDepth = 0.016f;

    /// <summary>
    /// Глубина врезки, при которой складки рельефа гасятся ПОЛНОСТЬЮ. Должна быть
    /// МЕНЬШЕ WaterMinDepth: к моменту, когда появляется вода, дно уже должно быть
    /// гладким, иначе неровности пробьют поверхность у самой кромки.
    /// </summary>
    private const float WetFadeDepth = 0.008f;

    /// <summary>Глубина врезки, начиная с которой вода считается «глубокой» (нормированная
    /// глубина для шейдера упирается в 1). Ориентир — центр русла крупной реки.</summary>
    private const float WaterDeepDepth = 0.12f;

    /// <summary>
    /// Уровень воды в каждой ячейке сетки рельефа (нормированная высота) либо NaN, если
    /// воды нет. Нужен и для построения поверхности воды, и для будущих запросов
    /// «эта точка под водой?» — рыбы должны плавать НИЖЕ поверхности, а не в воздухе.
    /// </summary>
    private float[]? _waterLevel;
    private MeshInstance3D _water = null!;
    private float _maxSampleDist = 48f;

    private MeshInstance3D _terrain = null!;
    private MeshInstance3D _rivers = null!;
    private MeshInstance3D _stemMarkers = null!;
    private MeshInstance3D _walkMarkers = null!;
    private Node3D _vegRoot = null!;
    private SeasonType _season = SeasonType.Summer;
    private LevelData? _data;
    private float _mapSize = 1000f;

    // Cached height grid for FPS camera (world Y)
    private float[]? _heightY;
    private bool[]? _heightValid;
    private float _hStep;
    private int _hRes;
    private float _hCx;
    private float _hCz;

    private const string WaterShaderPath = "res://assets/shaders/water.gdshader";
    private const string TerrainShaderPath = "res://assets/shaders/terrain.gdshader";

    /// <summary>
    /// Загрузить шейдер, вернув null и внятное сообщение, если файла нет.
    ///
    /// Ошибка «шейдер не найден» и ошибка «конвейер не собрался» выглядят в логе
    /// совершенно по-разному, хотя вторая часто вызвана первой: ShaderMaterial с
    /// пустым Shader уходит в рендерер и падает там, не упоминая имени файла.
    /// </summary>
    private static Shader? LoadShaderOrNull(string path)
    {
        if (!ResourceLoader.Exists(path))
        {
            GD.PushWarning($"Шейдер не найден: {path}. Используется запасной материал.");
            return null;
        }
        var sh = GD.Load<Shader>(path);
        if (sh == null)
            GD.PushWarning($"Шейдер не загрузился: {path}. Используется запасной материал.");
        return sh;
    }

    /// <summary>
    /// Проверка наличия всех шейдеров при старте. Одна строка в логе на каждый —
    /// вместо разбора, какой из них не собрался, по внутренним ошибкам рендерера.
    /// </summary>
    public static void LogShaderInventory()
    {
        string[] paths =
        {
            TerrainShaderPath,
            WaterShaderPath,
            FoliageShaderPath,
            "res://assets/shaders/impostor.gdshader",
            "res://assets/shaders/sketch_id.gdshader",
            "res://assets/shaders/sketch_depth.gdshader",
            "res://assets/shaders/sketch_normal.gdshader",
        };
        // ---- УСПЕХ ПЕЧАТАЕТСЯ ОДНОЙ СТРОКОЙ ----
        //
        // Прежде всякий шейдер печатал «ок» — семь строк, в которых нечего
        // читать. Полезна лишь НЕУДАЧА.
        int okCount = 0;
        foreach (var p in paths)
        {
            if (ResourceLoader.Exists(p) && GD.Load<Shader>(p) != null) okCount++;
            else GD.PrintErr($"[shaders] {p} — ОТСУТСТВУЕТ");
        }
        if (okCount == paths.Length)
            SessionLog.Print($"[shaders] все {okCount} на месте");
        else
            SessionLog.Print($"[shaders] на месте {okCount} из {paths.Length}");
    }
    private const string FoliageShaderPath = "res://assets/shaders/foliage.gdshader";
    private const string FoliageAtlasPath = "res://assets/textures/foliage/foliage_atlas.png";
    private static Texture2D? _foliageAtlasTex;
    private static Shader? _foliageShader;

    /// <summary>
    /// Материал для растений: непрозрачный ствол/ветки (солид-ячейка атласа) +
    /// alpha-cutout карточки листвы (лист/хвоя) в одном draw call. AlphaScissor вместо
    /// AlphaBlend — на MultiMesh сортировки по глубине нет, cutout не требует сортировки
    /// и заметно дешевле на мобильном GPU.
    ///
    /// V86: перевод со StandardMaterial3D на собственный шейдер. Причина одна —
    /// обводка карточек листвы: крона из десятков одинаково окрашенных
    /// четырёхугольников читается как сплошное пятно, отдельные листья в нём не
    /// различить. Встроенный материал такого не умеет, а contour по силуэту стоит
    /// четырёх дополнительных выборок текстуры и ни одного лишнего вызова отрисовки.
    ///
    /// Всё остальное перенесено один в один: цвет вершины как альбедо, порог
    /// отсечения 0.5, шероховатость, отключённое отсечение граней и Rim
    /// («The Godot Shaders Bible», гл. 2.8) — светлая кромка отделяет карточки,
    /// стоящие под углом к взгляду, друг от друга.
    /// </summary>
    private static ShaderMaterial CreateFoliageMaterial(float roughness)
    {
        _foliageAtlasTex ??= GD.Load<Texture2D>(FoliageAtlasPath);
        _foliageShader ??= LoadShaderOrNull(FoliageShaderPath);
        var m = new ShaderMaterial { Shader = _foliageShader };
        m.SetShaderParameter("albedo_tex", _foliageAtlasTex);
        m.SetShaderParameter("roughness_v", roughness);
        m.SetShaderParameter("rim_v", 0.45f);
        m.SetShaderParameter("rim_tint_v", 0.35f);
        m.SetShaderParameter("outline_color", FoliageOutlineColor);
        m.SetShaderParameter("outline_texels", FoliageOutlineTexels);
        m.SetShaderParameter("outline_strength", 0.85f);
        return m;
    }

    /// <summary>Цвет обводки карточек листвы. Чёрный читается спокойнее красного;
    /// поменять можно здесь, шейдер принимает любой.</summary>
    private static readonly Color FoliageOutlineColor = new(0f, 0f, 0f, 1f);

    /// <summary>Ширина обводки в текселях атласа (атлас 256×256, ячейка 128×128).
    /// Ноль полностью выключает обводку.</summary>
    private const float FoliageOutlineTexels = 1.2f;

    public override void _Ready()
    {
        // V90: рельеф красится градиентами по высоте и уклону (см. terrain.gdshader и
        // TerrainGradient). Цвет вершины сохранён и несёт то, что градиентом не
        // выражается: воду, тропу, эрозию — вес накладки лежит в его АЛЬФЕ.
        // ЗАГРУЗКА ПРОВЕРЯЕТСЯ. Материал с пустым шейдером не даёт понятной ошибки:
        // движок пытается собрать для него конвейер и падает где-то в недрах
        // рендерера (render_pipeline_create), а причина — отсутствующий файл — в
        // сообщении не упоминается. Проверка стоит одну строку, а разбирательство
        // без неё — целый прогон.
        Material terrainMaterial;
        var terrainShader = LoadShaderOrNull(TerrainShaderPath);
        if (terrainShader != null)
        {
            _terrainMat = new ShaderMaterial { Shader = terrainShader };
            _terrainMat.SetShaderParameter("height_min", 0f);
            _terrainMat.SetShaderParameter("height_max", HeightScale);
            _terrainMat.SetShaderParameter("roughness_v", 0.55f);
            // V126: шейдерный ковёр; меши травы только вблизи
            _terrainMat.SetShaderParameter("grass_detail", 0.55f);
            // grass_scale не задаём: он подбирается в шейдере вместе с дальностью
            // гашения, и задавать его отсюда значило бы перебить подбор.
            terrainMaterial = _terrainMat;
        }
        else
        {
            // Запасной путь — прежняя окраска цветом вершины. Она полноценна: цвет
            // вершины по-прежнему считается целиком, градиент лишь заменяет его
            // основную часть. Игра остаётся играбельной, просто без резких границ.
            terrainMaterial = new StandardMaterial3D
            {
                VertexColorUseAsAlbedo = true,
                Roughness = 0.55f,
                Metallic = 0.0f,
                CullMode = BaseMaterial3D.CullModeEnum.Disabled
            };
        }
        _terrain = new MeshInstance3D
        {
            Name = "TerrainMesh",
            MaterialOverride = terrainMaterial
        };
        AddChild(_terrain);

        // ---- V169: ДАЛЬНИЙ ФОН ----
        //
        // За краем чанка была чернота — она видна на каждом снимке уровня. Фон
        // строится методом дерева водоразделов на масштабе, для которого метод и
        // предназначен: сто километров, вершины через пять, складчатая карта
        // поднятия. Подробный чанк долины остаётся прежним: на его масштабе тот же
        // метод даёт сыпь бугров вместо долины, это проверено.
        //
        // Флагом — чтобы можно было выключить одной строкой и сравнить.
        if (FarBackgroundEnabled)
        {
            _farBackground = new FarBackground { Name = "FarBackgroundRoot" };
            AddChild(_farBackground);
        }

        var riverMat = new StandardMaterial3D
        {
            VertexColorUseAsAlbedo = true,
            Roughness = 0.08f,
            Metallic = 0.35f,
            Transparency = BaseMaterial3D.TransparencyEnum.Alpha,
            CullMode = BaseMaterial3D.CullModeEnum.Disabled,
            AlbedoColor = new Color(1f, 1f, 1f, 0.85f)
        };
        // Поверхность воды — ОТДЕЛЬНЫЙ меш, а не подкраска рельефа. Это принципиально
        // для дальнейших планов: рыбы должны плавать МЕЖДУ дном и поверхностью, а для
        // этого нужна сама поверхность и запрос её уровня (SampleWaterY ниже).
        // Шейдер воды (рябь, пена у кромки, Френель). Если файл не найден — не падаем,
        // а откатываемся на простой материал: сцена должна собираться и без ассета.
        Material waterMat;
        var waterShader = ResourceLoader.Exists(WaterShaderPath)
            ? GD.Load<Shader>(WaterShaderPath)
            : null;
        if (waterShader != null)
        {
            waterMat = new ShaderMaterial { Shader = waterShader };
        }
        else
        {
            GD.PushWarning($"Шейдер воды не найден: {WaterShaderPath}. Используется запасной материал.");
            waterMat = new StandardMaterial3D
            {
                VertexColorUseAsAlbedo = true,
                Roughness = 0.06f,
                Metallic = 0.25f,
                Transparency = BaseMaterial3D.TransparencyEnum.Alpha,
                CullMode = BaseMaterial3D.CullModeEnum.Disabled,
                AlbedoColor = new Color(1f, 1f, 1f, 1f)
            };
        }
        // ---- ПУСТЫЕ УЗЛЫ ОСТАВЛЕНЫ, НО СКРЫТЫ ----
        //
        // _water здесь никогда не наполнялся: лента строилась в FarBackground, и
        // опыт с клавишей W это вскрыл — журнал писал «меша воды нет».
        // _rivers наполнялся BuildRiverMesh, который не вызывается ниоткуда.
        //
        // Узлы не удаляем: на них завязаны переключатели и отчёты. Но по
        // умолчанию скрыты, чтобы не путать при разборе.
        _water = new MeshInstance3D { Name = "WaterSurface", MaterialOverride = waterMat,
                                      Visible = false };
        AddChild(_water);

        _rivers = new MeshInstance3D
        {
            Name = "RiverMesh",
            MaterialOverride = riverMat,
            Visible = false
        };
        AddChild(_rivers);

        // Маркеры судоходного ствола: жёлтые треугольники, остриём по течению (+Y map / +Z world).
        var stemMat = new StandardMaterial3D
        {
            VertexColorUseAsAlbedo = true,
            AlbedoColor = new Color(1f, 0.85f, 0.1f, 0.95f),
            EmissionEnabled = true,
            Emission = new Color(1f, 0.75f, 0.05f),
            EmissionEnergyMultiplier = 1.4f,
            Roughness = 0.4f,
            CullMode = BaseMaterial3D.CullModeEnum.Disabled,
            ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded
        };
        _stemMarkers = new MeshInstance3D
        {
            // Маркеры ствола и пеших коридоров — отладочные. По умолчанию скрыты:
            // уровень показывается сам по себе, без наложенных подсказок.
            Visible = false,
            Name = "MainStemMarkers",
            MaterialOverride = stemMat
        };
        AddChild(_stemMarkers);

        // V47 A: пешие коридоры — бирюзовые маркеры (контраст к оранжевому stem).
        var walkMat = new StandardMaterial3D
        {
            VertexColorUseAsAlbedo = true,
            AlbedoColor = new Color(0.15f, 0.95f, 0.85f, 0.95f),
            EmissionEnabled = true,
            Emission = new Color(0.1f, 0.9f, 0.8f),
            EmissionEnergyMultiplier = 1.3f,
            Roughness = 0.4f,
            CullMode = BaseMaterial3D.CullModeEnum.Disabled,
            ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded
        };
        _walkMarkers = new MeshInstance3D
        {
            Visible = false,
            Name = "WalkPathMarkers",
            MaterialOverride = walkMat
        };
        AddChild(_walkMarkers);

        _vegRoot = new Node3D { Name = "VegetationRoot" };
        AddChild(_vegRoot);
    }

    /// <summary>
    /// Диагностика состояния сцены одной строкой — что реально построено и видно.
    /// Нужна, чтобы отличать "режим не переключился" от "режим переключился, но
    /// рельеф не построился/невиден": по картинке эти случаи выглядят одинаково.
    /// </summary>
    public string DescribeSceneState()
    {
        string terr = _terrain == null
            ? "terrain=NULL(node not created)"
            : $"terrain: mesh={(_terrain.Mesh == null ? "null" : "ok")} visible={_terrain.Visible}";
        string riv = _rivers == null
            ? "rivers=NULL"
            : $"rivers: mesh={(_rivers.Mesh == null ? "null" : "ok")} visible={_rivers.Visible}";
        string wat = _water == null
            ? "water=NULL"
            : $"water: mesh={(_water.Mesh == null ? "null" : "ok")} visible={_water.Visible}";
        string veg = _vegRoot == null
            ? "vegRoot=NULL"
            : $"vegRoot: children={_vegRoot.GetChildCount()} visible={_vegRoot.Visible}";
        string gal = _galleryRoot == null
            ? "galleryRoot=none"
            : $"galleryRoot: children={_galleryRoot.GetChildCount()}";
        int regions = _data?.Regions.Count ?? -1;
        return $"galleryActive={_galleryActive} regions={regions} | {terr} | {riv} | {wat} | {veg} | {gal}";
    }

    public void SetData(LevelData data, float mapSize = 1000f, int gridRes = 240)
    {
        if (_terrain == null)
        {
            // Раньше здесь был молчаливый `return` — если узел рельефа почему-то не создан,
            // уровень просто не появлялся, без единого сообщения. Теперь это видно в консоли.
            GD.PushError("LevelView3D.SetData: _terrain == null (узел рельефа не создан, _Ready не отработал?) — уровень не будет построен.");
            return;
        }
        _data = data;
        _mapSize = mapSize;
        // Шум микрорельефа детерминирован по сиду уровня: одна и та же карта всегда
        // получает одну и ту же поверхность.
        _detailNoise = new SimplexNoise(data.Seed);
        // ---- СИД МИРА ДЛЯ ДАЛЬНЕГО ФОНА ----
        //
        // Отдельное поле, а НЕ _currentSeed. Тот принадлежит витрине растений и в
        // режиме уровня не присваивается никем — оставался нулём, и фон всё время
        // строился на сиде 0. Проверено точно: восстановленный дренаж на нуле
        // совпал с выгрузкой игры на 100% по всем кольцам, а число ячеек воды
        // сошлось в точности (1425); на сидах 42 и 0xC01A7 совпадений ноль.
        //
        // Промах прошёл потому, что поля с одним именем есть и здесь, и в
        // GameBootstrap, где лежит настоящий сид мира. Имя _worldSeed выбрано
        // так, чтобы спутать их было нельзя.
        // Берётся WorldSeed, а НЕ Seed. Seed — это сид ОТДЕЛЬНОГО ЧАНКА, выведенный
        // из мирового: у мира 42 чанк 0 получает -1193011390. В V211 фон взялся
        // именно за него, и это проверено по выгрузке — копия сошлась бит в бит
        // на сиде -1193011390.
        //
        // Так делать нельзя: горизонт принадлежит МИРУ, а не куску реки. Иначе,
        // когда сплав дойдёт до следующего чанка, горы вокруг перетасуются. Сейчас
        // это не проявляется только потому, что фон строится один раз за запуск
        // (флаг _farBackgroundBuilt), но полагаться на это нельзя.
        _worldSeed = data.WorldSeed ?? data.Seed;
        _gridRes = Math.Clamp(gridRes, 64, 320);
        // Wider search → fewer interior holes in the height grid
        _maxSampleDist = _mapSize / (_gridRes * 0.35f);
        if (_maxSampleDist < 36f) _maxSampleDist = 36f;
        if (_maxSampleDist > 95f) _maxSampleDist = 95f;
        _season = data.SeasonState.Current;
        UpdateTerrainGradients();
        RebuildMeshes();
    }


    /// <summary>
    /// World-space terrain height (Y) at camera XZ. Returns 0 if outside land.
    /// Used by FPS camera to follow relief.
    /// </summary>
    public float SampleWorldY(float worldX, float worldZ)
        => TrySampleWorldY(worldX, worldZ, out float y) ? y : 0f;

    /// <summary>
    /// То же, но с явным признаком «данных нет». Нужен там, где ноль от отсутствия
    /// данных надо отличать от честной высоты около нуля: дно долины у воды лежит
    /// низко, и по значению эти два случая неразличимы.
    /// </summary>
    public bool TrySampleWorldY(float worldX, float worldZ, out float height)
    {
        height = 0f;

        // ---- СНАЧАЛА НАШ РЕЛЬЕФ ----
        //
        // Сетка _heightY принадлежит СТАРОМУ мешу, которого больше нет: она
        // пуста, и метод возвращал ложь на каждый вызов. Растительность падала в
        // запасную ветку и отбраковывалась там по высоте — все 11498 штук, а в
        // журнале было «узлов MultiMesh: 0».
        //
        // Наш фон высоту знает всегда.
        if (_farBackground != null)
        {
            // Прямо у фона, а НЕ через SampleWorldY: та сама зовёт этот метод, и
            // вышла бы бесконечная петля.
            height = _farBackground.HeightAtWorld(worldX, worldZ);
            return true;
        }

        if (_heightY == null || _heightValid == null || _hRes < 2)
            return false;

        // world → map coords
        float wx = worldX / WorldScale + _hCx;
        float wz = worldZ / WorldScale + _hCz;

        float gx = wx / _hStep;
        float gz = wz / _hStep;
        int ix = (int)gx;
        int iz = (int)gz;
        if (ix < 0 || iz < 0 || ix >= _hRes - 1 || iz >= _hRes - 1)
            return false;

        float fx = gx - ix;
        float fz = gz - iz;
        int i00 = iz * _hRes + ix;
        int i10 = i00 + 1;
        int i01 = i00 + _hRes;
        int i11 = i01 + 1;

        float e00 = _heightValid[i00] ? _heightY[i00] : float.NaN;
        float e10 = _heightValid[i10] ? _heightY[i10] : float.NaN;
        float e01 = _heightValid[i01] ? _heightY[i01] : float.NaN;
        float e11 = _heightValid[i11] ? _heightY[i11] : float.NaN;

        // ВЫБОРКА ИДЁТ ПО ТОМУ ЖЕ ТРЕУГОЛЬНИКУ, ЧТО И РИСУЕТСЯ.
        //
        // Раньше здесь была билинейная интерполяция по четырём углам. Меш рельефа —
        // не билинейная поверхность: квад режется на два треугольника по диагонали
        // i1–i2 (см. сборку индексов: i0,i2,i1 и i1,i2,i3). Билинейная поверхность
        // отличается от плоскостей этих треугольников на «скрутку» квада
        // (e00 − e10 − e01 + e11), и на седловидных ячейках она проходит НИЖЕ меша.
        // Растение, посаженное по такой выборке, оказывается частично под землёй —
        // ровно то, что видно на скриншоте. Барицентрическая интерполяция по нужному
        // треугольнику даёт точку строго на поверхности.
        //
        // Диагональ идёт из угла (1,0) в угол (0,1), то есть fx + fz = 1.
        if (!float.IsNaN(e00) && !float.IsNaN(e10) && !float.IsNaN(e01) && !float.IsNaN(e11))
        {
            height = fx + fz <= 1f
                ? e00 + fx * (e10 - e00) + fz * (e01 - e00)
                : e11 + (1f - fx) * (e01 - e11) + (1f - fz) * (e10 - e11);
            return true;
        }

        // Запасной путь для ячеек с недостающими углами (край карты, разрывы сетки):
        // билинейно по тем углам, что есть.
        float wsum = 0f, y = 0f;
        if (!float.IsNaN(e00)) { float w = (1 - fx) * (1 - fz); y += e00 * w; wsum += w; }
        if (!float.IsNaN(e10)) { float w = fx * (1 - fz); y += e10 * w; wsum += w; }
        if (!float.IsNaN(e01)) { float w = (1 - fx) * fz; y += e01 * w; wsum += w; }
        if (!float.IsNaN(e11)) { float w = fx * fz; y += e11 * w; wsum += w; }
        if (wsum <= 1e-6f) return false;
        height = y / wsum;
        return true;
    }

    /// <summary>
    /// V127: нормаль рельефа из той же сетки, что SampleWorldY — для прижима куртин к склону.
    /// </summary>
    public bool TrySampleWorldNormal(float worldX, float worldZ, out Vector3 normal)
    {
        normal = Vector3.Up;
        const float eps = 0.35f;
        if (!TrySampleWorldY(worldX, worldZ, out float y0)) return false;
        bool hx = TrySampleWorldY(worldX + eps, worldZ, out float yx);
        bool hz = TrySampleWorldY(worldX, worldZ + eps, out float yz);
        if (!hx || !hz) return false;
        var dx = new Vector3(eps, yx - y0, 0f);
        var dz = new Vector3(0f, yz - y0, eps);
        normal = dz.Cross(dx);
        if (normal.LengthSquared() < 1e-10f) { normal = Vector3.Up; return true; }
        normal = normal.Normalized();
        if (normal.Y < 0f) normal = -normal;
        return true;
    }

    /// <summary>
    /// ГДЕ ПОСТАВИТЬ ИГРОКА.
    ///
    /// ---- ЧТО БЫЛО НЕ ТАК ----
    ///
    /// Прежняя редакция искала низкую область у СТАРОГО генератора чанка, чья
    /// карта 1000 единиц против наших 5760. Игрок в итоге оказывался в начале
    /// координат, а там — вершина: замер дал высоту 2946 м, долю 0.78, вокруг
    /// 58% снега и 39% скалы.
    ///
    /// Отсюда шло сразу несколько бед: растительности вокруг нет (её пояс ниже),
    /// долина со сплава узкая, воды в кадре мало.
    ///
    /// ---- КАК ТЕПЕРЬ ----
    ///
    /// Ищем по НАШЕМУ дренажу место, где сходятся три условия:
    ///   • крупная река — по ней и сплавляются;
    ///   • пояс леса — там есть растительность, то есть вертикали в кадре;
    ///   • умеренная высота — не вершина.
    ///
    /// Замер по полю: таких мест 157, и лежат они в 24-27 км от центра на
    /// высотах 1843-2526 м. То есть выбор есть, надо только его сделать.
    /// </summary>
    public Vector3 FindValleyWorldPos()
    {
        var pos = FarBackground.FindStartPosition();
        if (pos == null) return Vector3.Zero;
        float wx = pos.Value.X, wz = pos.Value.Y;
        return new Vector3(wx, SampleWorldY(wx, wz), wz);
    }

    /// <summary>
    /// Строит НАШ рельеф и растительность.
    ///
    /// Вынесено из RebuildMeshes: там ниже стоит выход «областей меньше трёх»,
    /// писанный под старый генератор, и после перехода на пустые области
    /// построение выходило до фона — рельеф не строился вовсе.
    /// </summary>
    private void BuildFarBackgroundAndVegetation()
    {
        if (_farBackground != null && !_farBackgroundBuilt)
        {
            _farBackgroundBuilt = true;
            // Довода о дне долины больше нет: фон привязывается к СВОЕМУ дну.
            _farBackground.Build(_worldSeed, WorldScale);
            _farBackgroundLift = _farBackground.Lift;
        }
        BuildVegetation();
    }

    private void RebuildMeshes()
    {
        if (_data == null) return;

        // ---- НАШ РЕЛЬЕФ СТРОИТСЯ ДО ПРОВЕРКИ ОБЛАСТЕЙ ----
        //
        // Ниже стоит выход «областей меньше трёх» — он писан под СТАРЫЙ
        // генератор, у которого области и были рельефом. Мы теперь передаём их
        // пустыми, и построение выходило сразу: рельеф не строился вовсе,
        // 31 мс вместо 57 секунд, точка старта (0,0), земля 0 м, кадры пустые.
        //
        // Седьмой случай подряд, когда остаток старого генератора молча рушит
        // работу. Наш фон и растительность от его областей не зависят, поэтому
        // строятся здесь.
        BuildFarBackgroundAndVegetation();

        var regions = _data.Regions;
        int n = regions.Count;
        if (n < 3)
        {
            // Старый меш не строится: областей нет и не будет.
            _terrain.Mesh = null;
            _rivers.Mesh = null;
            if (_water != null) { _water.Mesh = null; _waterLevel = null; }
            return;
        }

        float cx = _mapSize * 0.5f;
        float cz = _mapSize * 0.5f;

        // --- spatial hash ---
        const int buckets = 48;
        float cell = _mapSize / buckets;
        var bucketsArr = new List<int>[buckets * buckets];
        for (int i = 0; i < bucketsArr.Length; i++)
            bucketsArr[i] = new List<int>(6);

        // river segments (neighbor pairs) + lake points for continuous carve / tint
        var riverSegs = new List<(float ax, float az, float bx, float bz, float flux)>();

        // Отрезки пеших маршрутов — по ним рисуется протоптанная полоса.
        // Собираются так же, как речные: ребро графа, у которого оба конца на тропе.
        var walkSegs = new List<(float ax, float az, float bx, float bz)>();

        var lakePts = new List<(float x, float z)>();
        for (int i = 0; i < n; i++)
        {
            int bx = ClampI((int)(regions[i].Position.X / cell), 0, buckets - 1);
            int bz = ClampI((int)(regions[i].Position.Y / cell), 0, buckets - 1);
            bucketsArr[bz * buckets + bx].Add(i);
            if (regions[i].Biome == BiomeType.Lake || regions[i].Terrain == TerrainType.Lake)
                lakePts.Add((regions[i].Position.X, regions[i].Position.Y));
            if (regions[i].IsWalkPath)
            {
                foreach (int j in regions[i].Neighbors)
                {
                    if (j <= i || !regions[j].IsWalkPath) continue;
                    walkSegs.Add((
                        regions[i].Position.X, regions[i].Position.Y,
                        regions[j].Position.X, regions[j].Position.Y));
                }
            }

            if (!regions[i].IsRiver) continue;
            // Carve only lowland segments — high-ridge flux paths stay dry visually
            if (regions[i].Elevation > 0.42f) continue;
            foreach (int j in regions[i].Neighbors)
            {
                if (j <= i || !regions[j].IsRiver) continue;
                if (regions[j].Elevation > 0.42f) continue;
                float flux = Math.Max(regions[i].Flux, regions[j].Flux);
                riverSegs.Add((
                    regions[i].Position.X, regions[i].Position.Y,
                    regions[j].Position.X, regions[j].Position.Y,
                    flux));
            }
        }

        int res = _gridRes;
        int vertCount = res * res;
        var verts = new Vector3[vertCount];
        var colors = new Color[vertCount];
        var normals = new Vector3[vertCount];
        var elevs = new float[vertCount];
        // Глубина врезки русла/чаши в каждой ячейке (нормированная высота, 0 — суши).
        var carveDepth = new float[vertCount];
        var waterY = new float[vertCount];
        Array.Fill(waterY, float.NaN);
        // ВТОРОЙ массив уровня воды — БЕЗ NaN, «виртуальный» уровень в каждом узле,
        // включая сухие. Нужен только для геометрии кромки, см. BuildWaterSurface.
        var waterSurfAll = new float[vertCount];
        // NaN у негодных узлов: там Node() честно падает обратно на высоту рельефа,
        // как было раньше. Без этого нулевая инициализация утянула бы кромку к y=0.
        Array.Fill(waterSurfAll, float.NaN);
        var distToLand = new float[vertCount]; // nearest sample distance
        // Плоское зеркало озера: уровень и «озёрность» узла.
        var lakeLevel = new float[vertCount];
        var lakeFrac = new float[vertCount];
        Array.Fill(lakeLevel, -1f);
        var valid = new bool[vertCount];

        float step = _mapSize / (res - 1);
        float maxDist2 = _maxSampleDist * _maxSampleDist;

        // ИНТЕРПОЛЯЦИЯ ВЫСОТ: k ближайших регионов с ГЛАДКИМ ядром Вендланда.
        //
        // Было: 3 ближайших с весом 1/d^2. У такой схемы производная разрывна там, где
        // меняется сам НАБОР трёх ближайших, из-за чего по рельефу шли изломы — те самые
        // «острые углы» в долинах. Замер излома между нормалями соседних граней
        // heightmap (192x192, seed 42): средний 9.50°, p95 27.16°. Лечили это box-
        // размытием, но только при высоте <= 0.55, чтобы не сгладить вершины, — поэтому
        // склоны долин выше этого порога оставались гранёными.
        //
        // Стало: ядро Вендланда (1-t)^4 * (4t+1), C2-гладкое, с компактным носителем по
        // k-му соседу. Излом падает до 3.84° / 10.66° БЕЗ размытия, то есть без порога
        // по высоте. Вершины при этом почти не страдают: максимум высоты 0.8234 против
        // 0.8586 у исходных данных (потеря 4%), тогда как box-размытие в 3 прохода даёт
        // 0.8146 при том же эффекте.
        const int NearK = 8;
        const float WendlandSupport = 1.6f;   // носитель = расстояние до k-го соседа * это
        int[] nearIdx = new int[NearK];
        float[] nearD2 = new float[NearK];

        // ---- pass 1: sample IDW elev + color, record dist ----
        for (int gz = 0; gz < res; gz++)
        {
            for (int gx = 0; gx < res; gx++)
            {
                float wx = gx * step;
                float wz = gz * step;
                int idx = gz * res + gx;

                int bx = ClampI((int)(wx / cell), 0, buckets - 1);
                int bz = ClampI((int)(wz / cell), 0, buckets - 1);

                for (int k = 0; k < NearK; k++) { nearIdx[k] = -1; nearD2[k] = float.MaxValue; }

                for (int dz = -1; dz <= 1; dz++)
                for (int dx = -1; dx <= 1; dx++)
                {
                    int nx = bx + dx, nz = bz + dz;
                    if ((uint)nx >= buckets || (uint)nz >= buckets) continue;
                    var bucket = bucketsArr[nz * buckets + nx];
                    for (int bi = 0; bi < bucket.Count; bi++)
                    {
                        int ri = bucket[bi];
                        float ddx = regions[ri].Position.X - wx;
                        float ddz = regions[ri].Position.Y - wz;
                        float d2 = ddx * ddx + ddz * ddz;
                        // Вставка в упорядоченный список k ближайших.
                        if (d2 < nearD2[NearK - 1])
                        {
                            int pos = NearK - 1;
                            while (pos > 0 && nearD2[pos - 1] > d2)
                            {
                                nearD2[pos] = nearD2[pos - 1];
                                nearIdx[pos] = nearIdx[pos - 1];
                                pos--;
                            }
                            nearD2[pos] = d2;
                            nearIdx[pos] = ri;
                        }
                    }
                }

                distToLand[idx] = nearIdx[0] < 0 ? float.MaxValue : MathF.Sqrt(nearD2[0]);

                if (nearIdx[0] < 0 || nearD2[0] > maxDist2)
                {
                    valid[idx] = false;
                    elevs[idx] = 0f;
                    colors[idx] = Colors.Transparent;
                    continue;
                }

                // Сколько соседей реально нашлось (у края карты может быть меньше k).
                int found = 0;
                while (found < NearK && nearIdx[found] >= 0) found++;

                // Носитель ядра — расстояние до САМОГО ДАЛЬНЕГО из найденных соседей,
                // умноженное на запас. Так вес последнего соседа плавно уходит в ноль,
                // и при смене набора соседей никакого скачка не возникает — именно это
                // и убирает изломы, в отличие от 1/d^2, где вклад обрывается резко.
                float support = MathF.Sqrt(nearD2[found - 1]) * WendlandSupport;
                if (support < 1e-4f) support = 1e-4f;

                float elev = 0f, wSum = 0f, cr = 0, cg = 0, cb = 0;
                // Вес накладки: накапливается максимумом по всем особым влияниям —
                // русло, озеро, тропа. См. terrain.gdshader: ноль означает «красить
                // градиентом», единица — «красить запечённым цветом».
                float overlay = 0f;
                // Крутизна усредняется тем же весом — нужна для амплитуды микрорельефа
                // (на скале поверхность грубая, на лугу почти гладкая).
                float slopeAcc = 0f;
                // Глубина воды в этой точке: > 0 под руслом реки или в чаше озера.
                // Заполняется ниже при врезании русла/чаши, используется и для
                // микрорельефа, и для построения поверхности воды.
                float waterDepthHere = 0f;
                // Уровень зеркала озера, усреднённый ТОЛЬКО по клеткам-озёрам: если
                // подмешать сюда сушу, у берега зеркало поедет вниз и снова пойдёт
                // многогранниками. wLake — суммарный вес именно озёрных соседей.
                float lakeLvlAcc = 0f, wLake = 0f;
                for (int k = 0; k < found; k++)
                {
                    // Ядро Вендланда C2: w(t) = (1-t)^4 * (4t+1), t = d / support.
                    float t = MathF.Sqrt(nearD2[k]) / support;
                    if (t >= 1f) continue;
                    float om = 1f - t;
                    float om2 = om * om;
                    float w = om2 * om2 * (4f * t + 1f);
                    if (w < 1e-12f) w = 1e-12f;

                    var r = regions[nearIdx[k]];
                    elev += r.Elevation * w;
                    slopeAcc += r.Slope * w;
                    var col = SeasonColorMapper.GetColor(r.Biome, r.Elevation, r.Moisture, r.Slope, _season);
                    // lakes keep blue
                    if (r.Biome == BiomeType.Lake)
                        col = SeasonColorMapper.GetColor(BiomeType.Lake, r.Elevation, _season);
                    cr += col.R * w; cg += col.G * w; cb += col.B * w;
                    wSum += w;
                    if (r.WaterLevel >= 0f) { lakeLvlAcc += r.WaterLevel * w; wLake += w; }
                }
                if (wSum <= 0f)
                {
                    // Страховка: если все веса выродились, берём ближайший регион.
                    var r0 = regions[nearIdx[0]];
                    elev = r0.Elevation; slopeAcc = r0.Slope; wSum = 1f;
                    var c0 = SeasonColorMapper.GetColor(r0.Biome, r0.Elevation, r0.Moisture, r0.Slope, _season);
                    cr = c0.R; cg = c0.G; cb = c0.B;
                }
                elev /= wSum;
                cr /= wSum; cg /= wSum; cb /= wSum;
                float slopeAt = slopeAcc / wSum;
                // Доля «озёрности» узла и плоский уровень зеркала для него.
                lakeFrac[idx] = wLake / wSum;
                lakeLevel[idx] = wLake > 0f ? lakeLvlAcc / wLake : -1f;

                // ---- continuous river carve (distance to nearest segment) ----
                if (riverSegs.Count > 0)
                {
                    float bestRd = float.MaxValue;
                    float bestFlux = 0f;
                    for (int si = 0; si < riverSegs.Count; si++)
                    {
                        var s = riverSegs[si];
                        float d = DistPointToSegment(wx, wz, s.ax, s.az, s.bx, s.bz);
                        if (d < bestRd)
                        {
                            bestRd = d;
                            bestFlux = s.flux;
                        }
                    }
                    if (bestRd < RiverCarveRadius)
                    {
                        float t = 1f - bestRd / RiverCarveRadius;
                        t = t * t; // sharper channel center
                        float depth = RiverCarveDepth * (0.7f + 0.5f * Math.Clamp(bestFlux / 25f, 0f, 1.5f));

                        // ВРЕЗКА НЕ ГЛУБЖЕ ДОЛИ ЛОКАЛЬНОЙ ОТМЕТКИ.
                        //
                        // V71 поднял RiverCarveDepth до 0.26, но отметка дна долины
                        // всего 0.10-0.20 — врезка упиралась в нижний предел 0.01 при
                        // любой отметке, и вместо русла получался каньон глубиной
                        // 3-7 мировых единиц с отвесными стенами. Замер по логу это
                        // подтвердил: крутизна кромки воды p95 = 72.4°.
                        //
                        // Ограничиваем врезку долей от того, что есть под ногами:
                        // глубокое русло возможно только там, где долина сама высоко.
                        depth = MathF.Min(depth, MathF.Max(elev - 0.02f, 0f) * RiverCarveMaxFraction);

                        elev -= depth * t;
                        waterDepthHere = Math.Max(waterDepthHere, depth * t);
                        float blend = Math.Clamp(t * 0.85f, 0f, 0.80f);
                        overlay = MathF.Max(overlay, blend);
                        var water = SeasonColorMapper.GetRiverColor(bestFlux, _season);
                        // push toward saturated water blue
                        water = new Color(water.R * 0.55f, water.G * 0.70f, Math.Min(water.B * 1.25f, 1f), 1f);
                        cr = cr * (1f - blend) + water.R * blend;
                        cg = cg * (1f - blend) + water.G * blend;
                        cb = cb * (1f - blend) + water.B * blend;
                    }
                }

                // ---- lake basin depression + strong blue tint ----
                if (lakePts.Count > 0)
                {
                    float bestLd = float.MaxValue;
                    for (int li = 0; li < lakePts.Count; li++)
                    {
                        float ldx = lakePts[li].x - wx;
                        float ldz = lakePts[li].z - wz;
                        float ld2 = ldx * ldx + ldz * ldz;
                        if (ld2 < bestLd) bestLd = ld2;
                    }
                    float ld = MathF.Sqrt(bestLd);
                    if (ld < LakeCarveRadius)
                    {
                        float t = 1f - ld / LakeCarveRadius;
                        t = t * t;
                        elev -= LakeCarveDepth * t;
                        waterDepthHere = Math.Max(waterDepthHere, LakeCarveDepth * t);
                        float blend = Math.Clamp(t * 0.95f, 0f, 0.95f);
                        overlay = MathF.Max(overlay, blend);
                        var lakeCol = SeasonColorMapper.GetColor(BiomeType.Lake, elev, _season);
                        cr = cr * (1f - blend) + lakeCol.R * blend;
                        cg = cg * (1f - blend) + lakeCol.G * blend;
                        cb = cb * (1f - blend) + lakeCol.B * blend;
                    }
                }

                // ---- микрорельеф и разбиение цвета ----
                // Причина «поверхности, выдутой из цветного стекла»: и высота, и цвет
                // интерполируются методом IDW по трём ближайшим регионам из ~6900 точек.
                // Расстояние между точками ~12 единиц карты, поэтому деталей мельче этого
                // масштаба НЕ СУЩЕСТВУЕТ — между опорными точками получается гладкий
                // пузырь. Здесь добавляется высокочастотная составляющая, которой в
                // исходных данных нет и быть не может.
                //
                // Важно: микрорельеф НЕ уходит в _heightY (см. ниже), то есть на игровую
                // логику — ходьбу животных, размещение растений, запрос высоты — он не
                // влияет. Это чисто визуальная надбавка к мешу.
                // Имена detailNx/detailNz, а не nx/nz: последние уже заняты во внешних
                // областях видимости этого метода (обход бакетов и сглаживание нормалей).
                float detailNx = wx * 0.055f;
                float detailNz = wz * 0.055f;
                float detail = _detailNoise.Fbm(detailNx, detailNz, DetailAmps);

                // Шероховатость по уклону — используется ниже для дозировки слоистости
                // цвета (и, через «скалистость», для гребней при вычислении y).
                float rough = Math.Clamp((slopeAt - 2.0f) / 8.0f, 0f, 1f);

                // «Скалистость» точки: растёт с уклоном и с высотой. По ней дозируются и
                // грубость рельефа, и слоистость цвета — на лугу ни того, ни другого быть
                // не должно.
                float rocky = Math.Clamp(
                    rough * 0.65f + Math.Clamp((elev - 0.45f) / 0.35f, 0f, 1f) * 0.55f, 0f, 1f);

                // ВЫСОТУ ЗДЕСЬ НЕ ТРОГАЕМ. Первая версия добавляла микрорельеф и гребни
                // прямо тут, но ниже по коду высоты проходят РАЗМЫТИЕ (elevBlur), и вся
                // высокочастотная добавка частично сглаживалась обратно — отсюда жалоба,
                // что склоны всё ещё гладкие. В коде это уже было учтено для складок
                // рельефа: они применяются ПОСЛЕ сглаживания. Гребни перенесены туда же,
                // см. блок «эрозионные гребни» при вычислении y.
                // Здесь остаётся только цвет: он размытию не подвергается.

                // ---- ЦВЕТ: слоистость породы + разбиение однотонных заливок ----
                // Порода неоднородна, и по мере разрушения обнажаются слои разного цвета.
                // Слои идут примерно по горизонтали, поэтому берём высоту с добавкой шума
                // (без неё полосы получаются идеально ровными и выглядят нарисованными)
                // и режем её периодической функцией.
                float strataPhase = elev * StrataFrequency
                                    + _detailNoise.Noise2D(wx * 0.02f, wz * 0.02f) * 2.2f;
                float strata = MathF.Sin(strataPhase);
                strata = MathF.Sign(strata) * MathF.Pow(MathF.Abs(strata), 0.65f);

                float tint = 1f
                    + detail * 0.18f // V111: сильнее пятна дёрна
                    + _detailNoise.Noise2D(wx * 0.21f, wz * 0.21f) * 0.09f
                    + strata * StrataStrength * rocky;
                cr = Math.Clamp(cr * tint, 0f, 1f);
                cg = Math.Clamp(cg * tint, 0f, 1f);
                cb = Math.Clamp(cb * tint, 0f, 1f);

                // Слои различаются не только яркостью, но и оттенком: одни рыжее
                // (железистые), другие холоднее. Только на породе.
                float hueShift = strata * StrataHue * rocky;
                cr = Math.Clamp(cr + hueShift, 0f, 1f);
                cb = Math.Clamp(cb - hueShift * 0.8f, 0f, 1f);

                // ---- V71: ПРОТОПТАННАЯ ТРОПА ----
                //
                // Маршруты существовали только в данных: регионы помечались IsWalkPath,
                // но на поверхности их было не видно, и игрок не понимал, куда идти.
                // Рисуем тропу прямо в цвете поверхности: утоптанная земля по центру
                // и красная кромка по обоим краям — так тропа читается и сверху,
                // и с уровня глаз.
                if (walkSegs.Count > 0)
                {
                    float bestWd = float.MaxValue;
                    for (int si = 0; si < walkSegs.Count; si++)
                    {
                        var ws = walkSegs[si];
                        float d = DistPointToSegment(wx, wz, ws.ax, ws.az, ws.bx, ws.bz);
                        if (d < bestWd) bestWd = d;
                    }
                    if (bestWd < TrailEdgeRadius)
                    {
                        if (bestWd < TrailCoreRadius)
                        {
                            // Ядро тропы: утоптанный грунт. Чем ближе к центру,
                            // тем сильнее вытоптано.
                            // V112: почти полностью суглинок в ядре — иначе трава в vertex
                            // color перебивает тропу (на снимках brown%=0).
                            float t = 1f - bestWd / TrailCoreRadius;
                            float b = Math.Clamp(0.55f + t * 0.45f, 0.55f, 1f);
                            overlay = MathF.Max(overlay, b);
                            cr = cr * (1f - b) + TrailR * b;
                            cg = cg * (1f - b) + TrailG * b;
                            cb = cb * (1f - b) + TrailB * b;
                        }
                        else
                        {
                            // Кромка: красная полоса по обоим краям тропы.
                            float u = (bestWd - TrailCoreRadius)
                                    / MathF.Max(TrailEdgeRadius - TrailCoreRadius, 1e-4f);
                            // Пик в середине кромки, спад к обоим её краям —
                            // иначе полоса обрывается резко и выглядит наклейкой.
                            float b = MathF.Sin(u * MathF.PI) * TrailEdgeStrength;
                            overlay = MathF.Max(overlay, b);
                            // V111: кромка — примятая трава/суглинок, не красная полоса
                            cr = cr * (1f - b) + 0.50f * b;
                            cg = cg * (1f - b) + 0.40f * b;
                            cb = cb * (1f - b) + 0.24f * b;
                        }
                    }
                }

                elevs[idx] = Math.Max(elev, 0.01f);
                // АЛЬФА — ВЕС НАКЛАДКИ, а не прозрачность (материал рельефа непрозрачен).
                // Ноль — обычная поверхность, её красит градиент; единица — особое
                // место (вода, тропа), которое красится запечённым цветом как раньше.
                colors[idx] = new Color(cr, cg, cb, Math.Clamp(overlay, 0f, 1f));
                valid[idx] = true;

                // Сохраняем ГЛУБИНУ ВРЕЗКИ, а не готовый уровень.
                // Первая версия писала сюда elevs[idx] + waterDepthHere, то есть уровень
                // от НЕСГЛАЖЕННОЙ высоты. Но ниже рельеф проходит размытие (elevBlur),
                // которое приподнимает дно врезанного русла, — и вода, посчитанная до
                // размытия, оказывалась выше берегов и разливалась по долине. Теперь
                // уровень считается позже, от той же сглаженной высоты, что и рельеф:
                // вода стоит ровно на carveDepth выше дна, где бы дно ни оказалось.
                carveDepth[idx] = waterDepthHere;
            }
        }

        // ---- pass 1b: dilate valid once to close 1-cell holes ----
        var validDilated = new bool[vertCount];
        Array.Copy(valid, validDilated, vertCount);
        for (int gz = 1; gz < res - 1; gz++)
        {
            for (int gx = 1; gx < res - 1; gx++)
            {
                int idx = gz * res + gx;
                if (valid[idx]) continue;
                // If ≥3 of 4-neighbors are valid, fill this cell from neighbors
                int nValid = 0;
                float eSum = 0f;
                float cR = 0f, cG = 0f, cB = 0f;
                int[] offs = { -1, 1, -res, res };
                for (int oi = 0; oi < 4; oi++)
                {
                    int ni = idx + offs[oi];
                    if (!valid[ni]) continue;
                    nValid++;
                    eSum += elevs[ni];
                    cR += colors[ni].R; cG += colors[ni].G; cB += colors[ni].B;
                }
                if (nValid >= 3)
                {
                    validDilated[idx] = true;
                    elevs[idx] = eSum / nValid;
                    colors[idx] = new Color(cR / nValid, cG / nValid, cB / nValid, 1f);
                    distToLand[idx] = 0f; // treat as solid interior
                }
            }
        }
        Array.Copy(validDilated, valid, vertCount);

        // ---- pass 2: soft coastal falloff + mild elevation blur ----
        // ---- ЭРОЗИЯ ----
        // Гидравлическая эрозия частицами (метод «снежков», Job Talle 2020) плюс
        // термическая (осыпание круче угла естественного откоса). Именно эрозия даёт
        // узнаваемые формы горного рельефа: V-образные долины, сеть водосборов, гребни
        // между ними и конусы осыпи под скалами. Без неё поверхность остаётся «шумом»,
        // каким бы хорошим он ни был.
        //
        // Модуль Godot-независим и проверяется в харнессе. Замеры выявили две вещи,
        // без которых он не работает вовсе (см. лог, раздел 22):
        //   * масштаб высоты к шагу сетки — иначе частицы считают рельеф плоским;
        //   * ограничители размыва — иначе вместо долин получаются одиночные ямы.
        // ErosionEnabled — константа, поэтому компилятор заранее знает, какая ветка
        // живая, и ругается на вторую (CS0162). Прагма гасит предупреждение, не меняя
        // поведения: флаг оставлен именно как переключатель на время отладки.
#pragma warning disable CS0162
        if (ErosionEnabled)
        {
            HydraulicErosion.Apply(elevs, res, valid, _data?.Seed ?? 42,
                new HydraulicErosion.Settings
                {
                    Droplets = ErosionDroplets,
                    ErosionRate = ErosionRate,
                    DepositionRate = 0.15f,
                    MaxErosionPerStep = 0.006f,
                    Speed = ErosionSpeed,
                    Friction = ErosionFriction,
                    MaxIterations = ErosionSteps,
                });
            // Термическая: конусы осыпи под крутыми стенами.
            HydraulicErosion.ApplyThermal(elevs, res, valid, ThermalIterations, ThermalTalus);
        }
#pragma warning restore CS0162

        var elevBlur = new float[vertCount];
        // Размытая глубина врезки. Нужна для УРОВНЯ ВОДЫ, и вот почему.
        // Размытие — линейный box 3x3, а elevs уже содержит врезанное русло, поэтому
        //   elevBlur = blur(неврезанное) - blur(врезки).
        // Уровень воды должен стоять на отметке НЕВРЕЗАННОЙ поверхности, то есть
        //   вода = elevBlur + blur(врезки),
        // а не elevBlur + врезка. Первая версия прибавляла НЕРАЗМЫТУЮ врезку, и на
        // осевой линии русла (где врезка максимальна, а её размытая версия заметно
        // меньше) возникал излишек — вода вспучивалась горбом вдоль русла. Замер
        // синтетического профиля: разброс уровня поперёк русла был 2.82 мировых
        // единицы, с размытой врезкой стал 0.00. Это и были «пирамиды».
        var carveBlur = new float[vertCount];
        for (int gz = 0; gz < res; gz++)
        {
            for (int gx = 0; gx < res; gx++)
            {
                int idx = gz * res + gx;
                if (!valid[idx])
                {
                    elevBlur[idx] = 0f;
                    carveBlur[idx] = 0f;
                    continue;
                }

                // soft edge: reduce height near land boundary
                // V40: пол soft-edge поднят (0.05→0.22), чтобы силуэт rim-гор
                // оставался читаемым, а не превращался в плоскую кромку.
                float d = distToLand[idx];
                float edgeFactor = 1f;
                float edgeStart = _maxSampleDist - SoftEdgeWidth;
                if (d > edgeStart)
                {
                    float t = (d - edgeStart) / SoftEdgeWidth;
                    edgeFactor = 1f - t * t; // quadratic falloff
                    if (edgeFactor < 0.22f) edgeFactor = 0.22f;
                }

                // Размытие только на низких и средних высотах; вершины (elev > 0.55)
                // сохраняют исходную высоту, чтобы острые пики из AlpineTerrain пережили
                // построение меша.
                //
                // ПРИМЕЧАНИЕ: раньше этот порог был ЕДИНСТВЕННОЙ защитой от изломов, и
                // из-за него склоны долин выше 0.55 оставались гранёными (излом 9.50°
                // против 3.66° на размытом дне). Теперь изломы убирает сама интерполяция
                // (ядро Вендланда, см. выше), поэтому размытие здесь работает только как
                // дополнительное смягчение дна, а не как основное лекарство.
                float raw = elevs[idx];
                if (raw > 0.55f)
                {
                    elevBlur[idx] = raw * edgeFactor;
                }
                else
                {
                    float sum = 0f;
                    int cnt = 0;
                    for (int dz = -1; dz <= 1; dz++)
                    for (int dx = -1; dx <= 1; dx++)
                    {
                        int nx = gx + dx, nz = gz + dz;
                        if ((uint)nx >= res || (uint)nz >= res) continue;
                        int ni = nz * res + nx;
                        if (!valid[ni]) continue;
                        sum += elevs[ni];
                        cnt++;
                    }
                    float blurred = cnt > 0 ? sum / cnt : raw;
                    elevBlur[idx] = blurred * edgeFactor;
                }

                // Врезка размывается ТЕМ ЖЕ ядром и с тем же edgeFactor — иначе
                // равенство elevBlur + blur(врезки) = blur(неврезанного) нарушится.
                {
                    float csum = 0f;
                    int ccnt = 0;
                    for (int dz = -1; dz <= 1; dz++)
                    for (int dx = -1; dx <= 1; dx++)
                    {
                        int nx2 = gx + dx, nz2 = gz + dz;
                        if ((uint)nx2 >= res || (uint)nz2 >= res) continue;
                        int ni2 = nz2 * res + nx2;
                        if (!valid[ni2]) continue;
                        csum += carveDepth[ni2];
                        ccnt++;
                    }
                    carveBlur[idx] = (ccnt > 0 ? csum / ccnt : carveDepth[idx]) * edgeFactor;
                }
            }
        }

        // Копия высот ДО складок 2b. Поверхность воды строится от неё: иначе складки
        // рельефа попадали бы и в воду, и она шла бы волнами вместе с дном.
        var elevBase = (float[])elevBlur.Clone();

        // ---- pass 2b: medium folds in elev domain (not blurred further) ----
        int detailSeed = _data != null ? _data.Seed : 42;
        var detailNoise = new SimplexNoise(detailSeed ^ 0x5F3759DF);
        float invMap = 1f / Math.Max(_mapSize, 1f);
        {
            for (int i = 0; i < vertCount; i++)
            {
                if (!valid[i]) continue;
                float e = elevBlur[i];
                float band = 1f - MathF.Abs(e - 0.36f) / 0.50f;
                if (band < 0f) band = 0f;
                band *= band;

                int gz = i / res;
                int gx = i - gz * res;
                float wx = gx * step;
                float wz = gz * step;
                float n0 = detailNoise.Noise2D(wx * invMap * 9f, wz * invMap * 9f);
                float n1 = detailNoise.Noise2D(wx * invMap * 22f + 3f, wz * invMap * 22f + 3f);
                // В русле и чаше складки гасятся — см. wetMask ниже при вычислении y.
                float wet2 = 1f - Math.Clamp(carveBlur[i] / WetFadeDepth, 0f, 1f);
                elevBlur[i] = Math.Clamp(e + (n0 * 0.6f + n1 * 0.4f) * 0.12f * band * wet2, 0.01f, 1f);
            }
        }

        // ---- build vertices (+ high-freq world-space displacement AFTER pow) ----
        float skirtEdgeStart = _maxSampleDist - SoftEdgeWidth;
        for (int gz = 0; gz < res; gz++)
        {
            for (int gx = 0; gx < res; gx++)
            {
                int idx = gz * res + gx;
                float wx = gx * step;
                float wz = gz * step;
                float x = (wx - cx) * WorldScale;
                float z = (wz - cz) * WorldScale;
                float e = elevBlur[idx];
                float y = MathF.Pow(Math.Max(e, 0.01f), 1.15f) * HeightScale;

                // High-freq folds in metres — applied after all smoothing so player sees them
                if (valid[idx] && e > 0.05f)
                {
                    // ГЕЙТ СКЛАДОК — ПО НАСТОЯЩЕМУ УКЛОНУ, а не по высоте.
                    //
                    // Было: slopeBand = 1 - |e - 0.40| / 0.55, то есть множитель назывался
                    // «slope», но считался от ВЫСОТЫ и достигал максимума при e = 0.40 —
                    // ровно на отметке дна долин. На плоском лугу складки работали в
                    // полную силу, и при амплитуде 3.5 на длине волны 36 единиц карты
                    // (это всего ~4 мировых единицы) поверхность вставала почти дыбом.
                    // Замер крутизны рёбер на дне долин (seed 42, 192x192):
                    //   только рельеф                 ср  9.9°, p95 23.1°
                    //   + гребни                      ср 10.0°, p95 23.2°  (гасятся верно)
                    //   + складки (было)              ср 32.4°, p95 61.4°  <-- зубцы
                    //   + складки по уклону (стало)   ср 10.3°, p95 26.2°
                    // На склонах складки при этом сохраняются: p95 78.0° против 76.9° без
                    // них, то есть расчленение рельефа никуда не делось.
                    //
                    // Физически так и правильнее: складки — это сползание грунта, они
                    // образуются на склонах, а не на ровном дне долины.
                    // Уклон считаем ЗДЕСЬ ЖЕ, центральной разностью по уже сглаженным
                    // высотам, и сразу в мировых единицах — это ровно та величина, по
                    // которой подбирались пороги 0.35..1.0.
                    int gxm = gx > 0 ? gx - 1 : gx;
                    int gxp = gx < res - 1 ? gx + 1 : gx;
                    int gzm = gz > 0 ? gz - 1 : gz;
                    int gzp = gz < res - 1 ? gz + 1 : gz;
                    float yxm = MathF.Pow(Math.Max(elevBlur[gz * res + gxm], 0.01f), 1.15f) * HeightScale;
                    float yxp = MathF.Pow(Math.Max(elevBlur[gz * res + gxp], 0.01f), 1.15f) * HeightScale;
                    float yzm = MathF.Pow(Math.Max(elevBlur[gzm * res + gx], 0.01f), 1.15f) * HeightScale;
                    float yzp = MathF.Pow(Math.Max(elevBlur[gzp * res + gx], 0.01f), 1.15f) * HeightScale;
                    float hStepWorld = Math.Max((gxp - gxm) * step * WorldScale, 1e-4f);
                    float vStepWorld = Math.Max((gzp - gzm) * step * WorldScale, 1e-4f);
                    float gX = (yxp - yxm) / hStepWorld;
                    float gZ = (yzp - yzm) / vStepWorld;
                    float localSlope = MathF.Sqrt(gX * gX + gZ * gZ);

                    float slopeBand = Math.Clamp((localSlope - 0.35f) / 0.65f, 0f, 1f);
                    // wavelengths ~1–5 m in world space
                    // wavelengths ~2–8 m (several triangles) so folds survive normal averaging
                    float h0 = detailNoise.Noise2D(wx * invMap * 28f, wz * invMap * 28f);
                    float h1 = detailNoise.Noise2D(wx * invMap * 55f + 7f, wz * invMap * 55f + 7f);
                    float h2 = detailNoise.Noise2D(wx * invMap * 95f + 19f, wz * invMap * 95f + 19f);
                    float hi = h0 * 0.45f + h1 * 0.35f + h2 * 0.20f;
                    // up to ~3.5 m of surface relief on mid-slopes
                    // Складки ГАСЯТСЯ в русле и чаше озера. Иначе у кромки воды они
                    // (амплитуда до ~1.15) превышают подъём поверхности над дном (у самой
                    // кромки всего ~0.17), и берег «прогрызает» воду рваными пятнами.
                    // Замер этих величин — в логе, раздел 19.7.
                    float wetMask = 1f - Math.Clamp(carveBlur[idx] / WetFadeDepth, 0f, 1f);
                    y += hi * FoldAmpMetres * slopeBand * wetMask;
                }

                // ---- ЭРОЗИОННЫЕ ГРЕБНИ (после сглаживания, иначе размоются) ----
                // Параметры подобраны ЗАМЕРОМ, а не на глаз (см. лог, раздел 19.7).
                // Мерилась крутизна каждого ребра сетки: dY между соседними вершинами
                // против горизонтального шага 0.627 мировых единиц.
                //   было (bf=34, 4 октавы, амплитуда 7): p95 = 77°, max = 83° -> ИГЛЫ;
                //   существующие складки рельефа (эталон, выглядели нормально): p95 = 66°;
                //   стало (bf=20, 3 октавы, амплитуда 1.4): p95 = 34°.
                // Отдельно проверен АЛИАСИНГ: длина волны каждой октавы должна быть не
                // меньше ~3 ячеек сетки, иначе соседние вершины получают некоррелированный
                // шум и рельеф превращается в частокол. При bf=34 и 4 октавах последняя
                // октава давала 0.85 отсчёта на период — вдвое хуже предела Найквиста.
                // При bf=20 и 3 октавах: 12.8, 6.2 и 3.0 ячейки — все в пределах.
                if (valid[idx] && e > 0.30f)
                {
                    float rf = invMap * RidgeBaseFreq;
                    float rsum = 0f, ramp = 1f, rnorm = 0f;
                    for (int oct = 0; oct < RidgeOctaves; oct++)
                    {
                        float nr = detailNoise.Noise2D(wx * rf + 31f, wz * rf + 31f);
                        float rr = 1f - MathF.Abs(nr);
                        rr *= rr;
                        rsum += rr * ramp;
                        rnorm += ramp;
                        ramp *= 0.5f;
                        rf *= 2.07f;   // не ровно 2 — иначе октавы дают видимую решётку
                    }
                    rsum = rsum / rnorm - 0.5f;

                    // Гашение у вершины. Тот же приём, что у складок выше: они гаснут
                    // через slopeBand, и именно поэтому пики РАНЬШЕ выглядели гладкими.
                    // Максимум расчленения приходится на склоны, а вершина — эрозионно
                    // устойчивая шапка.
                    // Гашение у вершины ОСЛАБЛЕНО 0.92 -> 0.55.
                    // Оно вводилось против игл на пиках, но иглы были следствием
                    // АЛИАСИНГА (октавы короче двух ячеек сетки), а он устранён
                    // переходом на 3 октавы с базовой частотой 20. При D=0.92 на пике
                    // оставалось 8% амплитуды — вершины выходили гладкими, «парафиновыми».
                    // При 0.55 остаётся 45%, что даёт на пике угол ребра 34° — заведомо
                    // меньше эталонных 66°, то есть иглы не вернутся.
                    float belt = Math.Clamp((e - 0.30f) / 0.25f, 0f, 1f)
                               * (1f - Math.Clamp((e - 0.68f) / 0.22f, 0f, 1f) * 0.55f);
                    // В руслах и чашах гребни гасятся: при амплитуде 9 единиц они иначе
                    // разорвут поверхность воды, у которой подъём над дном меньше метра.
                    belt *= 1f - Math.Clamp(carveBlur[idx] / WetFadeDepth, 0f, 1f);
                    y += rsum * RidgeAmpMetres * belt;
                }

                float dEdge = distToLand[idx];
                if (dEdge > skirtEdgeStart)
                {
                    float t = Math.Clamp((dEdge - skirtEdgeStart) / SoftEdgeWidth, 0f, 1f);
                    y = y + (-12f - y) * (t * t);
                    var c = colors[idx];
                    float dark = 1f - 0.85f * t;
                    colors[idx] = new Color(c.R * dark, c.G * dark, c.B * dark, c.A);
                }

                verts[idx] = new Vector3(x, y, z);

                // Мировая высота поверхности воды — ОТ ТОЙ ЖЕ сглаженной высоты, что и
                // рельеф, плюс глубина врезки. Считается той же формулой pow(e,1.15)*H,
                // что и дно, поэтому поверхность не может оказаться ни ниже дна, ни
                // выше берега.
                // Уровень воды считаем ДЛЯ ВСЕХ узлов, даже сухих: на сухом берегу это
                // «уровень, который был бы здесь», и он лежит чуть выше рельефа. Именно
                // он нужен для интерполяции кромки. А waterY с NaN оставляем как есть —
                // на нём держится SampleWaterY (есть тут вода или нет).
                // ЗЕРКАЛО НИЖЕ БЕРЕГА.
                //
                // Раньше здесь стояло elevBase + carveBlur, то есть НЕВРЕЗАННАЯ
                // поверхность: русло заполнялось до краёв по построению. Любая складка
                // рельефа, добавленная после (микрорельеф, эрозионные гребни), сразу
                // оказывалась ниже зеркала — отсюда «вода над землёй». Замер по логу:
                // 2278 вершин воды из 4721, то есть 48%, стояли выше берега, причём
                // ровно на величину допуска — значит допуск работал не как редкая
                // поблажка, а как штатный режим.
                //
                // Теперь вода заполняет русло на WaterFillRatio его глубины, и над ней
                // остаётся свободный борт.
                float surfAll = MathF.Pow(
                    Math.Max(elevBase[idx] + carveBlur[idx] * WaterFillRatio, 0.01f),
                    1.15f) * HeightScale;

                // ОЗЕРО — ПЛОСКОЕ. Формула выше выводит зеркало из рельефа дна плюс
                // глубина врезки, и для реки это верно (она течёт под уклон), а для
                // озера — нет: поверхность повторяла неровности дна и разваливалась на
                // многогранники. Уровень зеркала мы уже знаем точно — это отметка
                // порога стока, посчитанная priority-flood (Hydrology.Filled) и
                // донесённая сюда через RegionData.WaterLevel. В пределах озера она
                // постоянна, поэтому поверхность выходит ровной.
                //
                // Переход от озера к реке плавный по lakeFrac, иначе на стыке будет
                // ступенька. Берём максимум с рельефным уровнем: зеркало не должно
                // оказаться НИЖЕ уже посчитанной поверхности у впадающего ручья.
                if (lakeFrac[idx] > 0.5f && lakeLevel[idx] >= 0f)
                {
                    float flat = MathF.Pow(Math.Max(lakeLevel[idx], 0.01f), 1.15f) * HeightScale;
                    float t = Math.Clamp((lakeFrac[idx] - 0.5f) / 0.3f, 0f, 1f);
                    surfAll = surfAll + (flat - surfAll) * t;
                }
                waterSurfAll[idx] = surfAll;
            }
        }

        // ---- СГЛАЖИВАНИЕ ПОВЕРХНОСТИ ВОДЫ ----
        //
        // Плоское зеркало из Hydrology.Filled закрывает только ОЗЁРА, а их в замере
        // оказалось 811 узлов из 4369 — остальное реки, и там поверхность по-прежнему
        // выводится как «дно + врезка». Врезка русла строится конусами вокруг отрезков
        // между регионами, и на стыках отрезков (особенно на изломах русла) в carveBlur
        // остаются бугры размером с шаг между регионами — это 2.3 ячейки сетки, поэтому
        // размытие 3x3, применяемое к самой врезке, их не берёт. Поверхность воды эти
        // бугры наследовала: замер дал p95 крутизны рёбер ВОДЫ 47.8°, max 74.7°, что для
        // поверхности воды бессмысленно много.
        //
        // Вода физически гладкая, поэтому сглаживаем саму поверхность, а не врезку.
        // Важно усреднять ТОЛЬКО по мокрым соседям: если подмешать берег, зеркало
        // потянется вверх к склону и у кромки снова полезут зубцы (ровно та же ошибка,
        // что была в Node(), см. ниже).
        // Копия уровня ДО сглаживания: нужна и как потолок (см. ограничения ниже),
        // и в диагностике — по ней считается, не залезла ли вода на берег.
        var surfRaw = (float[])waterSurfAll.Clone();
        {
            var wet = new bool[vertCount];
            for (int i = 0; i < vertCount; i++)
                wet[i] = valid[i] && carveBlur[i] > WaterMinDepth * 0.5f;

            var tmp = new float[vertCount];
            for (int pass = 0; pass < WaterSmoothPasses; pass++)
            {
                Array.Copy(waterSurfAll, tmp, vertCount);
                for (int gz = 0; gz < res; gz++)
                for (int gx = 0; gx < res; gx++)
                {
                    int i = gz * res + gx;
                    if (!wet[i]) continue;
                    float sum = tmp[i];
                    int cnt = 1;
                    for (int dz = -1; dz <= 1; dz++)
                    for (int dx = -1; dx <= 1; dx++)
                    {
                        if (dx == 0 && dz == 0) continue;
                        int nx = gx + dx, nz = gz + dz;
                        if ((uint)nx >= res || (uint)nz >= res) continue;
                        int ni = nz * res + nx;
                        if (!wet[ni]) continue;
                        sum += tmp[ni];
                        cnt++;
                    }
                    waterSurfAll[i] = sum / cnt;
                }
            }

            // Ограничения после сглаживания.
            //
            // СВЕРХУ: сглаживание усредняет вдоль русла, а русло идёт под уклон —
            // поэтому ниже по течению уровень подтягивается вверх соседями сверху и
            // вода вылезает на берег. В сечении поперёк русла это давало не прямую, а
            // параболу. Исходный уровень (дно + врезка) по построению равен неврезанной
            // поверхности, то есть высоте берега у самой кромки, — выше него воде
            // подниматься нельзя. Сглаживание при этом сохраняется: оно срезает бугры
            // вниз, а ограничение мешает только подъёму.
            //
            // СНИЗУ: зеркало не должно опуститься ниже дна, иначе вода уйдёт под рельеф.
            // ПОТОЛОК БЕРЁТСЯ ОТ СЛЕГКА СГЛАЖЕННОГО исходного уровня, а не от сырого.
            // Замер показал, зачем: с сырым потолком min(сглаженное, сырое) возвращает
            // исходные значения везде, где сглаживание подняло впадину, — то есть
            // впадины исходной ряби лезут обратно. Цифры до/после введения сырого
            // потолка: p95 крутизны рёбер воды 13.2° -> 36.6°, разброс зеркала озёр
            // 0.027 -> 0.170. Два прохода сглаживания снимают с потолка эту рябь,
            // оставляя его назначение — не пускать воду на берег — в силе.
            var ceiling = (float[])surfRaw.Clone();
            for (int pass = 0; pass < 2; pass++)
            {
                Array.Copy(ceiling, tmp, vertCount);
                for (int gz = 0; gz < res; gz++)
                for (int gx = 0; gx < res; gx++)
                {
                    int i = gz * res + gx;
                    if (!wet[i]) continue;
                    float sum = tmp[i];
                    int cnt = 1;
                    for (int dz = -1; dz <= 1; dz++)
                    for (int dx = -1; dx <= 1; dx++)
                    {
                        if (dx == 0 && dz == 0) continue;
                        int nx = gx + dx, nz = gz + dz;
                        if ((uint)nx >= res || (uint)nz >= res) continue;
                        int ni = nz * res + nx;
                        if (!wet[ni]) continue;
                        sum += tmp[ni];
                        cnt++;
                    }
                    ceiling[i] = sum / cnt;
                }
            }

            for (int i = 0; i < vertCount; i++)
            {
                if (!wet[i]) continue;
                // Потолок — сглаженный, но НЕ ВЫШЕ исходного уровня с малым допуском.
                // Замер показал цену чисто сглаженного потолка: гладкость выросла
                // (p95 крутизны воды 36.6° -> 17.2°), но вода полезла на берег в 2136
                // узлах из 4369 против нуля до этого. Допуск ограничивает выход берега
                // величиной заведомо незаметной на глаз, сохраняя выигрыш в гладкости.
                float cap = MathF.Min(ceiling[i], surfRaw[i] + WaterBankAllowance);
                if (waterSurfAll[i] > cap) waterSurfAll[i] = cap;
                float bed = verts[i].Y;
                if (waterSurfAll[i] < bed + 0.02f) waterSurfAll[i] = bed + 0.02f;
            }

            // waterY (версия с NaN) пересобирается ПОСЛЕ сглаживания, иначе SampleWaterY
            // возвращал бы старые, несглаженные отметки.
            for (int i = 0; i < vertCount; i++)
                waterY[i] = carveBlur[i] > WaterMinDepth ? waterSurfAll[i] : float.NaN;
        }

        // ---- ДИАГНОСТИКА ПОСТРОЕННОЙ ПОВЕРХНОСТИ ----
        // Считается ИМЕННО ЗДЕСЬ, а не в MapgenLevelGenerator: там доступен только граф
        // регионов, а всё, что портит поверхность (складки, гребни, врезка русел),
        // добавляется на этом этапе и в региональные метрики не попадает вовсе.
        try
        {
            var yWorld = new float[vertCount];
            for (int i = 0; i < vertCount; i++) yWorld[i] = verts[i].Y;
            var meshDiag = ColoringBook.Infrastructure.Generation.Diagnostics.MeshDiagnostics.Build(
                yWorld, elevBlur, valid, res, step * WorldScale, waterY, lakeFrac,
                carveBlur, WaterMinDepth, surfRaw);
            string mp = ColoringBook.Infrastructure.Generation.Diagnostics.GenerationLog.WriteMesh(
                meshDiag, _data?.Seed ?? 0);
            SessionLog.Print($"[mesh] лог поверхности записан: {mp}");
            SessionLog.Print($"[mesh] дно долин: p95 крутизны рёбер {meshDiag.FloorEdgeAngleP95:0.0}°, "
                     + $"игл на дне {meshDiag.SpikeCountOnFloor}");
            SessionLog.Print($"[mesh] вода: узлов {meshDiag.WaterVertices} (в озёрах {meshDiag.LakeVertices}), "
                     + $"разброс зеркала ср {meshDiag.LakeSurfaceSpreadMean:0.###} / max {meshDiag.LakeSurfaceSpreadMax:0.###}, "
                     + $"воды ниже дна {meshDiag.WaterBelowBedCount}");
            SessionLog.Print($"[mesh] кромка: толщина ср {meshDiag.ShoreThicknessMean:0.###} / "
                     + $"max {meshDiag.ShoreThicknessMax:0.###}, воды на берегу {meshDiag.WaterAboveBankCount}");
        }
        catch (Exception ex)
        {
            SessionLog.Print($"[mesh] диагностика поверхности не записана: {ex.Message}");
        }

        // ---- indices: solid mesh, ≥3 valid corners ----
        // rendered[i] — вершина реально попала в меш. Отличается от valid[i]: угол с
        // недостающими данными ниже ЧИНИТСЯ через AverageValid и после этого рисуется,
        // но в valid остаётся false. Кеш высот раньше строился по valid, поэтому
        // SampleWorldY пропускал именно те углы, которые видны на экране, и возвращал
        // высоту заметно ниже поверхности — растения у краёв и разрывов уходили под землю.
        var rendered = new bool[vertCount];
        var indices = new List<int>((res - 1) * (res - 1) * 6);
        for (int gz = 0; gz < res - 1; gz++)
        {
            for (int gx = 0; gx < res - 1; gx++)
            {
                int i0 = gz * res + gx;
                int i1 = i0 + 1;
                int i2 = i0 + res;
                int i3 = i2 + 1;
                int vCount = (valid[i0] ? 1 : 0) + (valid[i1] ? 1 : 0)
                           + (valid[i2] ? 1 : 0) + (valid[i3] ? 1 : 0);
                if (vCount < 3) continue;

                if (!valid[i0]) verts[i0] = AverageValid(verts, elevBlur, valid, i1, i2, i3, HeightScale);
                if (!valid[i1]) verts[i1] = AverageValid(verts, elevBlur, valid, i0, i2, i3, HeightScale);
                if (!valid[i2]) verts[i2] = AverageValid(verts, elevBlur, valid, i0, i1, i3, HeightScale);
                if (!valid[i3]) verts[i3] = AverageValid(verts, elevBlur, valid, i0, i1, i2, HeightScale);

                indices.Add(i0); indices.Add(i2); indices.Add(i1);
                indices.Add(i1); indices.Add(i2); indices.Add(i3);
                rendered[i0] = true; rendered[i1] = true;
                rendered[i2] = true; rendered[i3] = true;
            }
        }

        if (indices.Count == 0)
        {
            _terrain.Mesh = null;
            _rivers.Mesh = null;
            if (_water != null) { _water.Mesh = null; _waterLevel = null; }
            ClearVegetation();
            return;
        }

        // normals
        Array.Clear(normals, 0, normals.Length);
        for (int t = 0; t < indices.Count; t += 3)
        {
            int ia = indices[t], ib = indices[t + 1], ic = indices[t + 2];
            var fn = (verts[ib] - verts[ia]).Cross(verts[ic] - verts[ia]);
            if (fn.LengthSquared() < 1e-12f) continue;
            fn = fn.Normalized();
            normals[ia] += fn;
            normals[ib] += fn;
            normals[ic] += fn;
        }
        for (int i = 0; i < vertCount; i++)
            normals[i] = normals[i].LengthSquared() > 1e-10f
                ? normals[i].Normalized()
                : Vector3.Up;

        // ---- UV и ТАНГЕНТЫ ----
        // Нужны для шейдеров: без UV нельзя выбрать текстуру обычным способом, без
        // тангентов не работают карты нормалей (не из чего построить TBN-матрицу).
        // Раньше меш содержал только Vertex/Normal/Color/Index.
        //
        // UV — плоская проекция по мировым X/Z с тайлингом. Для рельефа это стандартный
        // приём: развёртки у процедурной сетки нет и быть не может, а плоская проекция
        // корректна везде, кроме отвесных стен (там текстура растягивается — это лечится
        // трипланарным наложением в шейдере, для чего UV тоже не помеха).
        //
        // ТАНГЕНТЫ считаются АНАЛИТИЧЕСКИ, а не через SurfaceTool.GenerateTangents():
        // при плоской проекции направление роста U совпадает с мировым +X, поэтому
        // тангент — это ось X, спроецированная на плоскость вершины (то есть с вычтенной
        // компонентой вдоль нормали). Это точно, дёшево и не требует переписывать сборку
        // меша на SurfaceTool.
        var uvs = new Vector2[vertCount];
        var tangents = new float[vertCount * 4];
        for (int i = 0; i < vertCount; i++)
        {
            var v = verts[i];
            uvs[i] = new Vector2(v.X / TerrainUvTile, v.Z / TerrainUvTile);

            // Имена nrm/tanV, а не n/t: короткие имена уже заняты в объемлющих
            // областях видимости этого метода (n = число регионов и т.п.).
            var nrm = normals[i];
            // Ось X минус её проекция на нормаль = касательная, лежащая в плоскости.
            var tanV = new Vector3(1f, 0f, 0f) - nrm * nrm.X;
            if (tanV.LengthSquared() < 1e-8f) tanV = new Vector3(0f, 0f, 1f) - nrm * nrm.Z;
            tanV = tanV.LengthSquared() > 1e-10f ? tanV.Normalized() : new Vector3(1f, 0f, 0f);

            tangents[i * 4 + 0] = tanV.X;
            tangents[i * 4 + 1] = tanV.Y;
            tangents[i * 4 + 2] = tanV.Z;
            // w — знак бинормали. UV.y растёт вдоль +Z, поэтому бинормаль = cross(nrm, tanV)
            // должна смотреть в +Z; если нет, знак переворачивается.
            tangents[i * 4 + 3] = nrm.Cross(tanV).Z >= 0f ? 1f : -1f;
        }

        var arrays = new Godot.Collections.Array();
        arrays.Resize((int)Mesh.ArrayType.Max);
        arrays[(int)Mesh.ArrayType.Vertex] = verts;
        arrays[(int)Mesh.ArrayType.Normal] = normals;
        arrays[(int)Mesh.ArrayType.Tangent] = tangents;
        arrays[(int)Mesh.ArrayType.TexUV] = uvs;
        arrays[(int)Mesh.ArrayType.Color] = colors;
        arrays[(int)Mesh.ArrayType.Index] = indices.ToArray();

        var mesh = new ArrayMesh();
        mesh.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, arrays);
        _terrain.Mesh = mesh;

        if (NewTerrainPreview)
        {
            // Старый рельеф, вода и реки убираются из кадра. Сами данные при этом
            // остаются: регионы, маршруты и биомы считаются как прежде, поэтому
            // выход из режима не требует пересборки уровня.
            _terrain.Mesh = null;
            _rivers.Mesh = null;
            if (_water != null) _water.Mesh = null;
        }

        // Фон строится ПОСЛЕ рельефа: ему нужна высота дна долины, чтобы стык не
        // дал уступа.
        //
        // waterY — массив ПО ВЕРШИНАМ, а не одно число: у каждой вершины своя отметка
        // зеркала, а где воды нет, там NaN. Фону нужна одна величина, поэтому берётся
        // среднее по вершинам с водой. Если воды в чанке нет вовсе, берётся наименьшая
        // высота рельефа — то есть то же дно долины, только сухое.
        // Фон и растительность строятся в BuildFarBackgroundAndVegetation, до
        // проверки областей: они от старого генератора не зависят.

        _waterLevel = waterY;
        // ЦЕНТР ПЕРЕДАЁТСЯ ЯВНО. Раньше метод брал _hCx/_hCz из полей, но они
        // присваиваются НИЖЕ по коду (кеш высот), поэтому при первой сборке уровня были
        // нулевыми — и вся поверхность воды уезжала на полкарты вбок, повисая обрывками
        // за границей рельефа. Явные аргументы убирают зависимость от порядка вызовов.
        // Вода строится ПОСЛЕ обнуления мешей выше, поэтому в режиме проверки она
        // возвращалась в кадр: на снимке остались голубые ленты русла поверх нового
        // рельефа. Пропускаем построение целиком.
        if (!NewTerrainPreview)
            BuildWaterSurface(carveBlur, waterSurfAll, verts, valid, res);

        // Cache final world-Y grid for FPS camera
        _heightY = new float[vertCount];
        _heightValid = new bool[vertCount];
        for (int i = 0; i < vertCount; i++)
        {
            _heightY[i] = verts[i].Y;
            _heightValid[i] = rendered[i];
        }
        _hStep = step;
        _hRes = res;
        _hCx = cx;
        _hCz = cz;

        // No separate river mesh: water is carve + blue tint on terrain only
        _rivers.Mesh = null;

        // V70: отладочные маркеры убраны.
        //
        // Оранжевые стрелки русла и бирюзовые ромбы троп были нужны, пока русло и
        // маршруты нельзя было увидеть иначе. Теперь русло видно по воде, а тропы
        // получили собственное представление в рельефе (протоптанная полоса с
        // краями) — маркеры только загораживали кадр и висели в воздухе.
        //
        // Сами методы оставлены: включаются флагом на время отладки генерации.
        // DebugRiverMarkers/DebugWalkMarkers — константы false, поэтому компилятор
        // знает, что вызовы недостижимы (CS0162). Флаги оставлены как переключатели
        // на время отладки, поэтому гасим предупреждение прагмой, а не убираем код.
#pragma warning disable CS0162
        // ---- ПОСТРОИТЕЛИ ОТЛАДОЧНЫХ МАРКЕРОВ УБРАНЫ ----
        //
        // Маркеры русла и троп брали данные у СТАРОГО генератора чанка (его
        // области), были по умолчанию выключены и в игре не показывались.
        // Убраны вместе с зависимостью.
#pragma warning restore CS0162
        // BuildVegetation здесь убран: он вызывается в BuildFarBackgroundAndVegetation,
        // до проверки областей. Иначе растительность строилась бы дважды.
    }

    /// <summary>
    /// Отладочные маркеры судоходного ствола: контрастные треугольники над руслом,
    /// остриё указывает вниз по течению (map +Y → world +Z). Расставляются с шагом
    /// по координате Y, чтобы был читаем путь лодки.
    /// </summary>
    /// <summary>Отладочные маркеры русла (оранжевые стрелки). По умолчанию выключены.</summary>
    private const bool DebugRiverMarkers = false;

    /// <summary>Отладочные маркеры троп (бирюзовые ромбы). По умолчанию выключены.</summary>
    private const bool DebugWalkMarkers = false;

    private void BuildRiverMesh(
        IReadOnlyList<RegionData> regions,
        float cx, float cz,
        float[] elevBlur, float step, int res, bool[] valid)
    {
        var rVerts = new List<Vector3>();
        var rCols = new List<Color>();
        var rIdx = new List<int>();

        // Water sits on channel floor: sample min height across width, then slight sink
        const float maxRiverElev = 0.42f;
        const int subDiv = 6;
        const float waterSink = 0.35f; // small extra sink below channel floor

        for (int i = 0; i < regions.Count; i++)
        {
            if (!regions[i].IsRiver) continue;
            if (regions[i].Elevation > maxRiverElev) continue;

            var col = SeasonColorMapper.GetRiverColor(regions[i].Flux, _season);
            col = new Color(col.R * 0.70f, col.G * 0.82f, Math.Min(col.B * 1.20f, 1f), 0.90f);

            // Ширина: на равнине чуть шире, у скал — уже (горная река).
            // Озёр нет — только лента реки.
            float flux0 = regions[i].IsMainStem ? Math.Max(regions[i].Flux, 6f) : regions[i].Flux;
            float base0 = regions[i].IsMainStem
                ? 0.42f + 0.28f * Math.Clamp(flux0 / 28f, 0.2f, 1.2f)
                : 0.50f + 0.55f * Math.Clamp(flux0 / 28f, 0.25f, 1.5f);
            float halfW0 = base0 * SlopeWidthFactor(regions[i].Slope);

            foreach (int j in regions[i].Neighbors)
            {
                if (j <= i || !regions[j].IsRiver) continue;
                if (regions[j].Elevation > maxRiverElev) continue;
                // Оба конца на отвесе — сегмент пропускаем (вода на камне).
                if (regions[i].Slope > 11.0f && regions[j].Slope > 11.0f) continue;

                float flux1 = regions[j].IsMainStem ? Math.Max(regions[j].Flux, 6f) : regions[j].Flux;
                float base1 = regions[j].IsMainStem
                    ? 0.42f + 0.28f * Math.Clamp(flux1 / 28f, 0.2f, 1.2f)
                    : 0.50f + 0.55f * Math.Clamp(flux1 / 28f, 0.25f, 1.5f);
                float halfW1 = base1 * SlopeWidthFactor(regions[j].Slope);

                float mx0 = regions[i].Position.X;
                float mz0 = regions[i].Position.Y;
                float mx1 = regions[j].Position.X;
                float mz1 = regions[j].Position.Y;

                for (int s = 0; s < subDiv; s++)
                {
                    float t0 = s / (float)subDiv;
                    float t1 = (s + 1) / (float)subDiv;
                    float sx0 = mx0 + (mx1 - mx0) * t0;
                    float sz0 = mz0 + (mz1 - mz0) * t0;
                    float sx1 = mx0 + (mx1 - mx0) * t1;
                    float sz1 = mz0 + (mz1 - mz0) * t1;

                    float ax = (sx0 - cx) * WorldScale;
                    float az = (sz0 - cz) * WorldScale;
                    float bx = (sx1 - cx) * WorldScale;
                    float bz = (sz1 - cz) * WorldScale;

                    var dir2d = new Vector3(bx - ax, 0f, bz - az);
                    if (dir2d.LengthSquared() < 1e-8f) continue;
                    dir2d = dir2d.Normalized();
                    var side = dir2d.Cross(Vector3.Up);
                    if (side.LengthSquared() < 1e-8f) side = Vector3.Right;
                    else side = side.Normalized();

                    float w0 = halfW0 + (halfW1 - halfW0) * t0;
                    float w1 = halfW0 + (halfW1 - halfW0) * t1;

                    // channel floor = min height across cross-section (center + left + right)
                    float ay = ChannelFloorY(sx0, sz0, side, w0 * 0.6f, elevBlur, step, res, valid, cx, cz) - waterSink;
                    float by = ChannelFloorY(sx1, sz1, side, w1 * 0.6f, elevBlur, step, res, valid, cx, cz) - waterSink;

                    // flat water surface: use same Y for left/right of each cross-section
                    var aL = new Vector3(ax, ay, az) - side * w0;
                    var aR = new Vector3(ax, ay, az) + side * w0;
                    var bR = new Vector3(bx, by, bz) + side * w1;
                    var bL = new Vector3(bx, by, bz) - side * w1;

                    int baseIdx = rVerts.Count;
                    rVerts.Add(aL); rVerts.Add(aR);
                    rVerts.Add(bR); rVerts.Add(bL);
                    rCols.Add(col); rCols.Add(col); rCols.Add(col); rCols.Add(col);
                    rIdx.Add(baseIdx); rIdx.Add(baseIdx + 1); rIdx.Add(baseIdx + 2);
                    rIdx.Add(baseIdx); rIdx.Add(baseIdx + 2); rIdx.Add(baseIdx + 3);
                }
            }
        }

        if (rVerts.Count == 0)
        {
            _rivers.Mesh = null;
            return;
        }

        var arrays = new Godot.Collections.Array();
        arrays.Resize((int)Mesh.ArrayType.Max);
        arrays[(int)Mesh.ArrayType.Vertex] = rVerts.ToArray();
        arrays[(int)Mesh.ArrayType.Color] = rCols.ToArray();
        arrays[(int)Mesh.ArrayType.Index] = rIdx.ToArray();

        var mesh = new ArrayMesh();
        mesh.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, arrays);
        _rivers.Mesh = mesh;
    }


    /// <summary>
    /// Множитель ширины реки по уклону: равнина ≈1.35, склон ≈1.0, скала ≈0.45.
    /// </summary>
    private static float SlopeWidthFactor(float slope)
    {
        // slope ~0..4 flat/meadow, 4..8 gentle, 8..11 scree, >11 cliff
        if (slope <= 3.5f) return 1.35f;
        if (slope >= 11.0f) return 0.45f;
        // smooth lerp 3.5 → 11 : 1.35 → 0.45
        float t = (slope - 3.5f) / (11.0f - 3.5f);
        return 1.35f + (0.45f - 1.35f) * t;
    }

    /// <summary>
    /// Lowest terrain height across a short cross-section — approximates river channel floor.
    /// </summary>
    private float ChannelFloorY(
        float wx, float wz, Vector3 side, float halfProbe,
        float[] elevBlur, float step, int res, bool[] valid, float cx, float cz)
    {
        float mapHalf = halfProbe / WorldScale;
        float sx = side.X * mapHalf;
        float sz = side.Z * mapHalf;

        float y0 = SampleElevAt(wx, wz, elevBlur, step, res, valid, cx, cz);
        float yL = SampleElevAt(wx - sx, wz - sz, elevBlur, step, res, valid, cx, cz);
        float yR = SampleElevAt(wx + sx, wz + sz, elevBlur, step, res, valid, cx, cz);
        float y = y0;
        if (yL < y) y = yL;
        if (yR < y) y = yR;
        return y;
    }

        private float SampleElevAt(float wx, float wz, float[] elevBlur, float step, int res,
                               bool[] valid, float cx, float cz)
    {
        float gx = wx / step;
        float gz = wz / step;
        int ix = ClampI((int)gx, 0, res - 2);
        int iz = ClampI((int)gz, 0, res - 2);
        float fx = gx - ix;
        float fz = gz - iz;

        int i00 = iz * res + ix;
        int i10 = i00 + 1;
        int i01 = i00 + res;
        int i11 = i01 + 1;

        float e00 = valid[i00] ? elevBlur[i00] : 0f;
        float e10 = valid[i10] ? elevBlur[i10] : 0f;
        float e01 = valid[i01] ? elevBlur[i01] : 0f;
        float e11 = valid[i11] ? elevBlur[i11] : 0f;

        float e0 = e00 * (1 - fx) + e10 * fx;
        float e1 = e01 * (1 - fx) + e11 * fx;
        float e = e0 * (1 - fz) + e1 * fz;
        // same curve as terrain vertices → water sits on actual surface
        return MathF.Pow(Math.Max(e, 0.01f), 1.15f) * HeightScale;
    }

    private static Vector3 AverageValid(Vector3[] verts, float[] elevBlur, bool[] valid,
                                        int a, int b, int c, float hScale)
    {
        float x = 0, y = 0, z = 0;
        int n = 0;
        if (valid[a]) { x += verts[a].X; y += verts[a].Y; z += verts[a].Z; n++; }
        if (valid[b]) { x += verts[b].X; y += verts[b].Y; z += verts[b].Z; n++; }
        if (valid[c]) { x += verts[c].X; y += verts[c].Y; z += verts[c].Z; n++; }
        if (n == 0) return verts[a];
        return new Vector3(x / n, y / n, z / n);
    }

    /// <summary>Distance from point (px,pz) to segment (ax,az)-(bx,bz).</summary>
    private static float DistPointToSegment(float px, float pz, float ax, float az, float bx, float bz)
    {
        float dx = bx - ax;
        float dz = bz - az;
        float len2 = dx * dx + dz * dz;
        if (len2 < 1e-8f)
        {
            float ex = px - ax, ez = pz - az;
            return MathF.Sqrt(ex * ex + ez * ez);
        }
        float t = ((px - ax) * dx + (pz - az) * dz) / len2;
        if (t < 0f) t = 0f;
        else if (t > 1f) t = 1f;
        float qx = ax + t * dx - px;
        float qz = az + t * dz - pz;
        return MathF.Sqrt(qx * qx + qz * qz);
    }

    private static int ClampI(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);


    /// <summary>
    /// True if world XZ is on water (lake / river / ocean) — player cannot walk there.
    /// </summary>
    /// <summary>
    /// Есть ли вода в мировой точке.
    ///
    /// Было: поиск ближайшей области у СТАРОГО генератора, чья карта 1000 единиц
    /// против наших 5760 — то есть ответ давался по чужим координатам.
    ///
    /// Стало: спрашиваем наш дренаж. Вода там, где река накрывает ячейку —
    /// тот же признак, по которому вода попадает в покров.
    /// </summary>
    public bool IsWaterAt(float worldX, float worldZ)
        => FarBackground.IsWaterAt(worldX, worldZ);
    private Node3D? _galleryRoot;
    private bool _galleryActive;
    // ПРАВКА: раньше _genHistory копил ВСЕ когда-либо сгенерированные seed'ы и разрешал
    // листать назад (Down) — это лишний груз на видеокарту без пользы (старое поколение
    // всё равно не нужно держать, если вперёд идти можно только заново генерируя). Теперь
    // только текущее поколение: Up — сразу новый seed, старое поколение отбрасывается,
    // возврата назад нет.
    private int _currentSeed;
    /// <summary>Сид мира — им строится дальний фон. НЕ путать с _currentSeed:
    /// тот принадлежит витрине растений и в режиме уровня не задаётся вовсе.</summary>
    private int _worldSeed;
    private int _currentGen = -1; // -1 = ещё ни одного поколения не сгенерировано

    public bool IsGalleryActive => _galleryActive;

    /// <summary>
    /// ГРУППА ВИТРИНЫ для серии замеров.
    ///
    /// Полный перебор по одному растению дал бы 22 вида × 6 дистанций × несколько
    /// возрастов — сотни снимков и десятки мегабайт архива. Группировка сокращает это
    /// на порядок и при этом не смешивает несравнимое: у деревьев есть возраст и
    /// качество, у мелочи их нет, а хвойные и лиственные строятся разными движками.
    /// </summary>
    public enum GalleryGroup { Conifer = 0, Deciduous = 1, Small = 2 }

    private static bool InGroup(VegetationKind k, GalleryGroup g) => g switch
    {
        GalleryGroup.Conifer => k is VegetationKind.Fir or VegetationKind.Pine,
        GalleryGroup.Deciduous => k == VegetationKind.Deciduous,
        _ => k is VegetationKind.Bush or VegetationKind.Flower or VegetationKind.Reed
                or VegetationKind.GrassTuft or VegetationKind.Moss or VegetationKind.Stone,
    };

    /// <summary>
    /// Показать только одну группу и задать возраст. Раскладка пересчитывается: пять
    /// деревьев в кадре крупнее, чем двадцать два, а зум орбитальной камеры идёт
    /// строго в центр — значит крайние объекты тем мельче, чем шире ряд.
    /// </summary>
    public void GalleryShowGroup(GalleryGroup group, int ageLevel, int quality = -1,
        PlantGenerator.FoliageDetail? detail = null)
    {
        // ---- V155: ВИТРИНА УМЕЕТ ПОКАЗЫВАТЬ ИГРОВОЙ МЕШ ----
        //
        // EnterPlantGallery ставит Detailed, потому что витрина заведена разглядывать
        // геометрию вплотную. Но на уровень едет Compact, и это ДРУГОЙ меш: у хвойных
        // там лапы-карточки вместо отдельных игл. Пока витрина знала только подробный
        // режим, она отвечала на вопрос о дереве, которого в игре нет.
        //
        // Обнаружилось это так: правка числа лап компактного режима изменила замер
        // импосторов (83-87% заполненности стало 80-84%), а шаблоны витрины остались
        // ПОБАЙТНО прежними — все двенадцать значений совпали до единицы. Константа в
        // витрине просто не участвовала.
        if (detail.HasValue) PlantGenerator.Detail = detail.Value;
        _galleryCrowdingLevel = 0;   // обычные шаги показывают дерево открытого роста
        if (quality >= 0) PlantGenerator.QualityLevel = Math.Clamp(quality, 0, 12);
        _hiddenEntries.Clear();
        for (int i = 0; i < GalleryEntries.Length; i++)
            if (!InGroup(GalleryEntries[i].Kind, group))
                _hiddenEntries.Add(i);
        PlantGenerator.AgeLevel = Math.Clamp(ageLevel, 0, 8);
        ApplyGenerationSeed();
        ShowGalleryRow();
    }

    /// <summary>Вернуть витрину к показу всех видов — после серии замеров.</summary>
    public void GalleryShowAll()
    {
        _hiddenEntries.Clear();
        ShowGalleryRow();
    }

    /// <summary>
    /// План серии замеров: какие группы и в каких возрастах снимать. У деревьев берутся
    /// края и середина игрового диапазона — по ним видно, растёт ли дерево и как
    /// меняется силуэт. У мелочи возраст ни на что не влияет, поэтому одна съёмка.
    /// </summary>
    public static List<(GalleryGroup group, int age, int quality,
        PlantGenerator.FoliageDetail detail, string label)> GallerySweepPlan()
    {
        // ---- V138: ТОЛЬКО ИГРОВОЙ ДИАПАЗОН ----
        //
        // Возрасты 0–4 на уровень не попадают: игровой пул строится в GameAgeMin..Max,
        // а это 5–8 (проверено по константам). Молодые деревья всех пород к тому же
        // похожи друг на друга — по этой причине ранние возрасты в своё время и
        // убрали из пула. Снимать их значит тратить кадры на то, чего игрок не увидит.
        //
        // Качества тоже только те, что имеют смысл: ноль как нижняя граница
        // читаемости и игровое значение. Промежуточные ничего не добавляют — вклад
        // качества ограничен сверху qEff, и выше игрового визуала почти нет.
        // ДВА МЕША, И ЭТО ГЛАВНОЕ В ПЛАНЕ.
        //
        // Подробный — разглядывать геометрию: ветвление, форму иглы, посадку листа.
        // Компактный — то, что стоит на уровне, и только по нему можно судить, как
        // порода будет читаться в раскраске. Метка меша входит в название шага и
        // потому попадает и в имя файла, и в строку отчёта: раньше ничто в логе не
        // говорило, какой меш вы видите.
        var plan = new List<(GalleryGroup, int, int, PlantGenerator.FoliageDetail, string)>();
        int[] qualities = { 0, PlantGenerator.GameQEffTarget };
        foreach (var g in new[] { GalleryGroup.Conifer, GalleryGroup.Deciduous })
        {
            string gname = g == GalleryGroup.Conifer ? "хвойные" : "лиственные";
            for (int age = PlantGenerator.GameAgeMin; age <= PlantGenerator.GameAgeMax; age++)
                foreach (int q in qualities)
                    plan.Add((g, age, q, PlantGenerator.FoliageDetail.Detailed,
                        $"{gname} возраст {age} качество {q} подробный"));
            // Компактный — только на игровом качестве: качество 0 это проверка нижней
            // границы читаемости, на уровень оно не попадает.
            for (int age = PlantGenerator.GameAgeMin; age <= PlantGenerator.GameAgeMax; age++)
                plan.Add((g, age, PlantGenerator.GameQEffTarget, PlantGenerator.FoliageDetail.Compact,
                    $"{gname} возраст {age} ИГРОВОЙ МЕШ"));
        }
        plan.Add((GalleryGroup.Small, PlantGenerator.GameAgeMin,
                  PlantGenerator.GameQEffTarget, PlantGenerator.FoliageDetail.Compact,
                  "мелкие растения ИГРОВОЙ МЕШ"));
        return plan;
    }

    /// <summary>
    /// ШАГИ ПО СТУПЕНЯМ ЗАТЕНЁННОСТИ — по одному типу за шаг.
    ///
    /// Отдельный список, потому что вопрос другой: обычные шаги сравнивают ПОРОДЫ
    /// между собой, эти — один тип с самим собой на открытом месте, в среднем лесу и
    /// в чаще. Иначе разницу силуэтов пришлось бы ловить на уровне пешком, а это
    /// долго и ненадёжно: нужное дерево ещё надо найти.
    /// </summary>
    public static List<(VegetationKind kind, int level, int age, string label)> GalleryCrowdingPlan()
    {
        var plan = new List<(VegetationKind, int, int, string)>();
        var names = new (VegetationKind kind, string name)[]
        {
            (VegetationKind.Fir, "ель"),
            (VegetationKind.Pine, "сосна"),
            (VegetationKind.Deciduous, "лиственные"),
        };
        string[] levelNames = { "открытый рост", "средний лес", "чаща" };
        foreach (var (kind, name) in names)
            for (int lvl = 0; lvl < PlantCatalog.CrowdingLevels; lvl++)
                plan.Add((kind, lvl, PlantGenerator.GameAgeMax,
                    $"{name} {levelNames[Math.Min(lvl, levelNames.Length - 1)]} ИГРОВОЙ МЕШ"));
        return plan;
    }


    /// <summary>
    /// Включить режим только-растения: скрыть рельеф, показать все виды в ряд.
    /// </summary>
    public void EnterPlantGallery()
    {
        // Витрина — инструмент отладки, бюджет уровня на неё не распространяется:
        // здесь дерево одно и его разглядывают вплотную, поэтому подробная хвоя.
        PlantGenerator.Detail = PlantGenerator.FoliageDetail.Detailed;
        PlantCatalog.RegenerateAll(_currentSeed);
        _soReportPrinted = false;   // каталог пересобран — отчёт о росте нужен заново

        // ---- V134: ВОЗРАСТ ТОЖЕ ИГРОВОЙ ----
        //
        // Здесь стоял ноль, и витрина показывала ВСХОДЫ: по логу age=0 при игровом
        // диапазоне 4–8. Отсюда и тощие деревца на снимке витрины — это не дефект
        // геометрии, а младенцы. Качество уже приведено к игровому (GameQEffTarget),
        // возраст оставался нулевым.
        //
        // Смотреть надо ровно то, что попадёт на уровень; ход развития с всхода
        // по-прежнему доступен вручную (Alt+↓).
        PlantGenerator.AgeLevel = (PlantGenerator.GameAgeMin + PlantGenerator.GameAgeMax) / 2;
        ApplyGenerationSeed();

        _galleryActive = true;
        if (_terrain != null) _terrain.Visible = false;
        if (_rivers != null) _rivers.Visible = false;
        if (_water != null) _water.Visible = false;
        if (_vegRoot != null) _vegRoot.Visible = false;
        // V55b: маркеры main-stem / walk-path не должны попадать на витрину.
        if (_stemMarkers != null) _stemMarkers.Visible = false;
        if (_walkMarkers != null) _walkMarkers.Visible = false;

        if (_currentGen < 0)
        {
            _currentSeed = 0xC01A7;
            _currentGen = 0;
            // ВИТРИНА ОТКРЫВАЕТСЯ НА ИГРОВОМ КАЧЕСТВЕ, А НЕ НА НУЛЕВОМ.
            //
            // Здесь стоял ноль, и витрина показывала самый бедный из возможных
            // вариантов дерева. По ней принимались решения о том, как выглядят
            // породы, — а уровень при этом строится на GameQEffTarget. Судить о
            // силуэте по картинке, которой на уровне не бывает, бессмысленно;
            // крутить качество вниз по-прежнему можно вручную (Ctrl+↓).
            PlantGenerator.QualityLevel = PlantGenerator.GameQEffTarget;
            PlantCatalog.RegenerateAll(_currentSeed);
        _soReportPrinted = false;   // каталог пересобран — отчёт о росте нужен заново
        }
        ShowGalleryRow();
    }

    public void ExitPlantGallery()
    {
        // ВОЗВРАТ НА УРОВЕНЬ — ЧЕРЕЗ ИГРОВОЙ ПУЛ, А НЕ ЧЕРЕЗ RegenerateAll.
        //
        // Здесь стоял RegenerateAll(_currentSeed), и он применял ко всем вариантам
        // ТЕКУЩИЕ возраст и качество витрины. Возраст витрина ставит нулевым при
        // открытии и обратно не возвращает, качество — то, на котором её оставили.
        // В итоге достаточно было один раз заглянуть в витрину, чтобы весь лес на
        // уровне стал всходами одного возраста и качества ноль — и оставался таким
        // до перезапуска. Именно поэтому правки геометрии деревьев не проявлялись
        // на уровне: их перекрывала подмена всего каталога.
        //
        // Компактный режим по-прежнему обязателен: из подробных мешей лес не влезет
        // в бюджет кадра.
        PlantGenerator.Detail = PlantGenerator.FoliageDetail.Compact;
        PlantCatalog.EnsureGamePool();
        _soReportPrinted = false;   // каталог пересобран — отчёт о росте нужен заново

        _galleryActive = false;
        ClearGallery();
        if (_terrain != null) _terrain.Visible = true;
        if (_rivers != null) _rivers.Visible = true;
        if (_water != null) _water.Visible = true;
        if (_vegRoot != null) _vegRoot.Visible = true;
        // Восстановить маркеры только если они были запрошены (не в режиме лодки).
        if (_stemMarkers != null)
            _stemMarkers.Visible = _stemMarkersWanted && _stemMarkers.Mesh != null;
        if (_walkMarkers != null)
            _walkMarkers.Visible = _stemMarkersWanted && _walkMarkers.Mesh != null;
    }

    /// <summary>
    /// Показывать ли отладочные маркеры русла и троп.
    ///
    /// Сами ПОСТРОИТЕЛИ маркеров убраны вместе с зависимостью от старого
    /// генератора: они брали его области. Узлы и управление видимостью
    /// оставлены — ими пользуется загрузчик, и мешей у них теперь просто нет.
    /// </summary>
    private bool _stemMarkersWanted;

    /// <summary>Показать или скрыть маркеры. Меши пусты, так что видимость ни на
    /// что не влияет; метод оставлен, чтобы не править загрузчик.</summary>
    public void SetStemMarkersVisible(bool show)
    {
        _stemMarkersWanted = show;
        if (_stemMarkers != null) _stemMarkers.Visible = show && _stemMarkers.Mesh != null;
        if (_walkMarkers != null) _walkMarkers.Visible = show && _walkMarkers.Mesh != null;
    }


    /// <summary>Перерисовать текущее поколение тем же seed/quality — например, после
    /// переключения PlantGenerator.SkeletonDebugMode, чтобы сравнить одно и то же дерево
    /// с листвой и без.</summary>
    public void GalleryRefresh()
    {
        if (_currentGen >= 0) ApplyGenerationSeed();
        ShowGalleryRow();
    }

    /// <summary>Пересобрать каталог растений под текущие сид и качество.
    /// НЕ вызывает GalleryRefresh — иначе получается взаимная рекурсия.</summary>
    private void ApplyGenerationSeed()
    {
        PlantCatalog.RegenerateAll(_currentSeed);
        _soReportPrinted = false;   // каталог пересобран — отчёт о росте нужен заново
    }

    /// <summary>Новый сид растений при ТОМ ЖЕ качестве (Shift+Up).</summary>
    public void GalleryNewSeed()
    {
        if (_currentGen < 0) _currentSeed = 0xC01A7;
        _currentGen++;
        _currentSeed = unchecked(_currentSeed * 1103515245 + 12345);
        if (_currentSeed == 0) _currentSeed = 1;
        // V134: новый сид сохраняет ИГРОВОЙ возраст. Прежний сброс в ноль возвращал
        // витрину к всходам после каждого Shift+↑, и снимки обхода уходили не про то.
        PlantGenerator.AgeLevel = Math.Clamp(PlantGenerator.AgeLevel,
            PlantGenerator.GameAgeMin, PlantGenerator.GameAgeMax);
        ApplyGenerationSeed();
        ShowGalleryRow();
    }

    /// <summary>Изменить качество при ТОМ ЖЕ сиде (Ctrl+Up / Ctrl+Down).
    ///
    /// Раньше качество было намертво связано с номером поколения, из-за чего одно
    /// нажатие меняло сразу два фактора и сравнивать результаты было нельзя.</summary>
    public void GalleryChangeQuality(int delta)
    {
        PlantGenerator.QualityLevel = Math.Clamp(PlantGenerator.QualityLevel + delta, 0, 12);
        ApplyGenerationSeed();
        ShowGalleryRow();
    }

    /// <summary>Изменить ВОЗРАСТ при том же сиде и качестве (Alt+Up / Alt+Down).
    ///
    /// Возраст — отдельный фактор, а не разновидность качества: по статье Палубицки
    /// он переключает форму кроны с excurrent (молодое дерево с выраженной осью) на
    /// decurrent (старое, раскидистое), тогда как качество меняет только детализацию.
    /// Раньше отдельного управления возрастом не было вовсе, и сравнить эти два
    /// фактора было нельзя.</summary>
    public void GalleryChangeAge(int delta)
    {
        PlantGenerator.AgeLevel = Math.Clamp(PlantGenerator.AgeLevel + delta, 0, 8);
        ApplyGenerationSeed();
        ShowGalleryRow();
    }

    /// <summary>
    /// ОПЫТ: скрыть или показать всю воду.
    ///
    /// Нужен, чтобы отличить ленту воды от рельефа. Скрывает и меш воды, и
    /// старый узел рек — оба, чтобы не гадать, какой из них рисует.
    /// </summary>
    public void ToggleWaterVisible()
    {
        bool show = !(_water?.Visible ?? true);
        if (_water != null) _water.Visible = show;
        if (_rivers != null) _rivers.Visible = show;
        // Главное: вода ФОНА — она в другом узле, и лента лежит именно там.
        _farBackground?.SetWaterVisible(show);
        SessionLog.Print($"[опыт] вода {(show ? "показана" : "СКРЫТА")}");
        LogWaterBounds();
    }

    /// <summary>Границы меша воды в мировых единицах — если он выходит за
    /// территорию, это видно числом, а не на глаз.</summary>
    private void LogWaterBounds()
    {
        if (_water?.Mesh == null) { SessionLog.Print("[опыт] меша воды нет"); return; }
        var aabb = _water.Mesh.GetAabb();
        SessionLog.Print($"[опыт] меш воды: x {aabb.Position.X:F0}..{aabb.End.X:F0}, "
            + $"z {aabb.Position.Z:F0}..{aabb.End.Z:F0}, "
            + $"y {aabb.Position.Y:F0}..{aabb.End.Y:F0}, "
            + $"поверхностей {_water.Mesh.GetSurfaceCount()}");
        if (_terrain?.Mesh != null)
        {
            var t = _terrain.Mesh.GetAabb();
            SessionLog.Print($"[опыт] меш рельефа: x {t.Position.X:F0}..{t.End.X:F0}, "
                + $"z {t.Position.Z:F0}..{t.End.Z:F0}");
        }
        if (_farBackground != null)
            SessionLog.Print($"[опыт] узлов фона: {_farBackground.GetChildCount()}");
    }

    /// <summary>ОПЫТ: скрыть рельеф фона. Если линии останутся и без воды, и без
    /// рельефа — значит их рисует что-то третье.</summary>
    public void ToggleTerrainVisible()
    {
        _terrainHidden = !_terrainHidden;
        _farBackground?.SetTerrainVisible(!_terrainHidden);
        if (_terrain != null) _terrain.Visible = !_terrainHidden;
    }

    private bool _terrainHidden;

    /// <summary>Строка для надписи на экране.</summary>
    public string WaterVisibilityStatus()
        => $"вода: {((_water?.Visible ?? true) ? "показана" : "СКРЫТА")} — нажмите W ещё раз";

    public string GalleryStatus()
    {
        string skel = PlantGenerator.SkeletonDebugMode ? "  |  S=skeleton:ON" : "  |  S=skeleton:off";
        int visible = GalleryEntries.Length - _hiddenEntries.Count;
        string shown = visible == GalleryEntries.Length
            ? $"all {GalleryEntries.Length}"
            : (visible == 0
                ? "none"
                : string.Join(", ", Enumerable.Range(0, GalleryEntries.Length)
                    .Where(i => !_hiddenEntries.Contains(i)).Select(EntryLabel)));
        return $"PLANTS  AGE:{PlantGenerator.AgeLevel}/8  QUALITY:{PlantGenerator.QualityLevel}/12  gen:{_currentGen + 1}  seed:{_currentSeed}  |  Alt+↑↓ age  Ctrl+↑↓ quality  Shift+↑ seed  |  1-9 species  P exit{skel}  |  {shown}";
    }


    private void ClearGallery()
    {
        if (_galleryRoot == null) return;
        while (_galleryRoot.GetChildCount() > 0)
        {
            var c = _galleryRoot.GetChild(0);
            _galleryRoot.RemoveChild(c);
            c.QueueFree();
        }
    }

    /// <summary>
    /// Высота точки, на которую должна смотреть камера в галерее (GameBootstrap._target.Y).
    /// Считается динамически по факту раскладки: середина между низом нижнего ряда
    /// (Y≈0) и верхом кроны верхнего ряда. Раньше была константа 11.2 под старую
    /// сетку 3×3 — при 2 рядах и тем более при 1 ряде (после скрытия части растений)
    /// камера смотрела слишком высоко, сверху оставалось много пустого места.
    /// </summary>
    public static float GalleryFocusHeight => _lastFocusY;

    /// <summary>
    /// Живое управление видимостью видов в витрине — какие VegetationKind сейчас СКРЫТЫ
    /// (пустое множество = показаны все 6). Переключается в реальном времени клавишами
    /// 1-6 (см. GameBootstrap._UnhandledInput, порядок соответствует VegetationKind:
    /// 1=Pine 2=Fir 3=Deciduous 4=Bush 5=Flower 6=Reed) — заменяет прежний статический
    /// GalleryPreviewKinds (был захардкожен на 3 вида "для скорости тестирования",
    /// требовал правки кода и пересборки на каждое переключение). Теперь можно скрыть
    /// именно тяжёлые виды (Deciduous/Bush) и смотреть только на то, что нужно, не
    /// перегружая видеокарту пересчётом/рендером остальных.
    /// </summary>

    /// <summary>
    /// ЗАПИСЬ ВИТРИНЫ: тип растения + конкретная порода внутри него.
    ///
    /// Раньше витрина показывала ТИПЫ (Pine/Fir/Deciduous/Bush/Flower/Reed) — по одному
    /// экземпляру на тип. Теперь пород стало по три на каждое дерево, и сравнивать их
    /// нужно рядом, поэтому единицей показа стала пара «тип + порода»: девять деревьев
    /// в ряд. Мелкие растения (куст, цветок, камыш, трава, мох) из витрины убраны —
    /// сейчас работа идёт по деревьям, и они только занимали место в кадре.
    /// </summary>
    private readonly struct GalleryEntry
    {
        public readonly VegetationKind Kind;
        public readonly int Species;
        public GalleryEntry(VegetationKind kind, int species) { Kind = kind; Species = species; }
    }

    /// <summary>Все породы всех деревьев: 3 ели + 3 сосны + 3 лиственных = 9.
    /// Индекс варианта в каталоге совпадает с индексом породы (PlantCatalog
    /// раскладывает породы по вариантам как v % Count).</summary>
    private static readonly GalleryEntry[] GalleryEntries = BuildGalleryEntries();

    private static GalleryEntry[] BuildGalleryEntries()
    {
        // ---- V134: В ВИТРИНЕ ВСЕ ВИДЫ, А НЕ ТОЛЬКО ДЕРЕВЬЯ ----
        //
        // Раньше показывались три древесных типа, и половина того, что стоит на уровне,
        // не проверялась вовсе: кусты, цветы, камыш, дернина, мох, камни. Между тем по
        // замеру кадра трава и кусты дают 70% его стоимости — то есть отлаживались
        // как раз не те растения.
        //
        // Второй ряд с мелочью раскладывается ниже (ShowGalleryRow): у них другой
        // масштаб, и мешать их с деревьями в одну линию бессмысленно — либо деревья
        // упрутся в горизонт, либо мох станет неразличим.
        var trees = new[] { VegetationKind.Fir, VegetationKind.Pine, VegetationKind.Deciduous };
        var small = new[] { VegetationKind.Bush, VegetationKind.Flower, VegetationKind.Reed,
                            VegetationKind.GrassTuft, VegetationKind.Moss, VegetationKind.Stone };
        var list = new List<GalleryEntry>();
        foreach (var k in trees)
            for (int sp = 0; sp < PlantSpecies.Count(k); sp++)
                list.Add(new GalleryEntry(k, sp));
        foreach (var k in small)
            for (int sp = 0; sp < PlantSpecies.Count(k); sp++)
                list.Add(new GalleryEntry(k, sp));
        return list.ToArray();
    }

    /// <summary>Скрытые записи витрины (индексы в GalleryEntries).</summary>
    private static readonly HashSet<int> _hiddenEntries = new();

    /// <summary>Ступень затенённости, которую показывает витрина: 0 — открытый рост,
    /// 1 — среднее, 2 — чаща. Меняется по шагам серии.</summary>
    private int _galleryCrowdingLevel;

    /// <summary>Показать только один тип растений на заданной ступени затенённости.
    /// Нужно, чтобы сравнивать силуэты ОДНОЙ породы: ради этого иначе пришлось бы
    /// ходить по уровню и искать нужное дерево.</summary>
    public void GalleryShowKindAtCrowding(VegetationKind kind, int crowdingLevel, int ageLevel)
    {
        PlantGenerator.Detail = PlantGenerator.FoliageDetail.Compact;
        PlantGenerator.AgeLevel = Math.Clamp(ageLevel, 0, 8);
        PlantGenerator.QualityLevel = PlantGenerator.GameQEffTarget;
        _galleryCrowdingLevel = Math.Clamp(crowdingLevel, 0, PlantCatalog.CrowdingLevels - 1);
        _hiddenEntries.Clear();
        for (int i = 0; i < GalleryEntries.Length; i++)
            if (GalleryEntries[i].Kind != kind) _hiddenEntries.Add(i);
        ApplyGenerationSeed();
        ShowGalleryRow();
    }

    /// <summary>Переключить видимость вида, вернуть true если теперь ВИДЕН.</summary>
    /// <summary>Показать/скрыть одну запись витрины по её номеру (клавиши 1-9).
    /// Возвращает новое состояние видимости и подпись записи.</summary>
    public (bool visible, string label) ToggleEntryVisibility(int index)
    {
        if (index < 0 || index >= GalleryEntries.Length) return (true, "—");
        bool nowVisible;
        if (_hiddenEntries.Contains(index)) { _hiddenEntries.Remove(index); nowVisible = true; }
        else { _hiddenEntries.Add(index); nowVisible = false; }
        ShowGalleryRow();
        return (nowVisible, EntryLabel(index));
    }

    private static string EntryLabel(int i)
    {
        var e = GalleryEntries[i];
        return PlantSpecies.Get(e.Kind, e.Species).Name;
    }

    /// <summary>Сколько записей в витрине — нужно GameBootstrap для раскладки клавиш.</summary>
    public static int GalleryEntryCount => GalleryEntries.Length;

    /// <summary>Полуширина и высота сетки последней раскладки (для дистанции камеры).</summary>
    private static float _lastGridHalfWidth = 12.0f;
    private static float _lastGridHeight = 16.0f;
    /// <summary>Y-центр bbox растений последней раскладки (для _target.Y камеры).</summary>
    private static float _lastFocusY = 5.5f;

    /// <summary>
    /// Дистанция камеры для витрины. Берётся max по горизонтали и вертикали bbox,
    /// чтобы оба ряда (или один) целиком попадали в кадр с небольшим запасом ~12%.
    /// Раньше +8 к дистанции давало лишний «воздух» сверху/по бокам.
    /// tan(FOV/2)≈0.75 при FOV≈75° (горизонт.); вертикаль чуть уже → 0.55.
    /// </summary>
    public static float GalleryCameraDistance
    {
        get
        {
            float byWidth = _lastGridHalfWidth / 0.72f;
            float byHeight = (_lastGridHeight * 0.5f) / 0.52f;
            // Небольшой запас, чтобы подписи и края крон не обрезались.
            return Math.Max(8f, Math.Max(byWidth, byHeight) * 1.12f);
        }
    }


    /// <summary>
    /// Все виды растений на дуге-полукруге вокруг точки, вокруг которой орбитит камера
    /// (см. GameBootstrap._target / _distance), без подложки — растения на пустом фоне
    /// (см. GameBootstrap.BackgroundColor для контрастного фона).
    /// Порядок: Pine, Fir, Deciduous, Bush, Flower, Reed.
    ///
    /// Раньше растения стояли в один линейный ряд вдоль X. Проблема: при облёте камерой
    /// (LMB orbit) расстояние камера→растение для разных растений в ряду сильно менялось
    /// в зависимости от угла обзора, поэтому под каждое приходилось заново подбирать зум —
    /// неудобно при съёмке скриншотов. На дуге радиуса ArcRadius вокруг общей точки обзора
    /// это расстояние остаётся в узком диапазоне [camDistance − ArcRadius, camDistance + ArcRadius]
    /// независимо от угла облёта (не идеально константа — точно так было бы, только если бы
    /// сама камера тоже стояла в центре дуги, — но разброс уже гораздо меньше, чем в линейном
    /// ряду, и одного зума хватает на все растения без сильной перестройки кадра.
    ///
    /// Дуга ВОГНУТАЯ в сторону камеры (открыта к ней, как амфитеатр/сцена): крайние
    /// растения ближе к камере, растение в центре дуги — дальше всего вглубь сцены.
    /// </summary>
    private void ShowGalleryRow()
    {
        if (_galleryRoot == null)
        {
            _galleryRoot = new Node3D { Name = "PlantGallery" };
            AddChild(_galleryRoot);
        }
        ClearGallery();

        var shownIdx = Enumerable.Range(0, GalleryEntries.Length)
            .Where(i => !_hiddenEntries.Contains(i)).ToArray();

        // ДВА РЯДА. Мелкие растения ставятся ОТДЕЛЬНОЙ линией ближе к камере: у них
        // масштаб на порядок меньше, и в одном ряду с деревьями либо деревья уходят
        // за горизонт, либо мох становится точкой. Ряд смещён по Z, поэтому обе линии
        // видны с одной камеры, и при этом мелочь не заслоняет стволы.
        // Признак мелкого растения когда-то использовался здесь для разделения на два
        // ряда; сейчас разделение делает ShowGalleryRow ниже по индексам записей, и
        // функция осталась висеть без вызова. Удалена: неиспользуемая локальная
        // функция — ошибка компиляции в этой сборке (CS8321).
        var kinds = shownIdx.Select(i => GalleryEntries[i].Kind).ToArray();
        int n = kinds.Length;
        if (n == 0) return; // всё скрыто — пустая витрина, ничего рисовать не нужно

        // Полуширина кроны В ВИТРИНЕ (после нормировки к targetH). Значения посчитаны
        // из ЗАМЕРЕННЫХ crownRatio при age 8, а не на глаз:
        //   Pine: max crownRatio 0.934 (кедр) x targetH 5.5 = 5.14 -> полуширина 2.57
        //   Fir:  max 0.777 (тсуга) x 6.5 = 5.05 -> 2.53
        //   Deciduous: до правки дуб давал 1.789 x 5.0 = 8.95 -> 4.47; после сужения
        //              кроны ожидается около 1.2 x 5.0 = 6.0 -> 3.0, берём 3.4 с запасом.
        // Прежние 1.9 / 1.3 / 2.4 были занижены вдвое, отсюда и перехлёст крон.
        float CanopyHalfWidth(VegetationKind k) => k switch
        {
            VegetationKind.Pine => 2.7f,
            VegetationKind.Fir => 2.6f,
            VegetationKind.Deciduous => 3.4f,
            VegetationKind.Bush => 0.9f,
            VegetationKind.Flower => 0.35f,
            VegetationKind.Reed => 0.5f,
            _ => 1.0f
        };

        // v11: ДВА РЯДА по 4 (для 8 деревьев витрины).
        //
        // Раньше cols = ceil(sqrt(n)) давало 3×3 сетку — три ряда, нижние деревья
        // мелкие на экране, верхние далековаты. Пользователь попросил 2 ряда × 4,
        // чтобы каждое дерево было крупнее и лучше читалось.
        //
        // Все деревья в плоскости Z = 0 (ничто никого не загораживает).
        // Ряды без шахматного сдвига — ровная сетка, подписи выровнены.
        const float ClearanceMargin = 2.8f;

        var rowX = new float[n];
        var rowY = new float[n];

        float maxHalfWidth = 0f;
        foreach (var k in kinds) maxHalfWidth = Math.Max(maxHalfWidth, CanopyHalfWidth(k));

        // ---- V135: ТРИ-ЧЕТЫРЕ РЯДА В ШАХМАТНОМ ПОРЯДКЕ ----
        //
        // Двух рядов мало: орбитальная камера приближается строго к центру, поэтому
        // при широкой раскладке крайние растения остаются россыпью пикселей. Чем
        // компактнее сетка, тем крупнее каждый объект при том же охвате.
        //
        // Ряды сдвинуты на полшага: нижнее растение больше не заслоняет верхнее по
        // той же колонке, а плотность по горизонтали при этом почти вдвое выше, чем
        // у ровной сетки.
        int rows = n <= 4 ? 1 : n <= 9 ? 2 : n <= 16 ? 3 : 4;
        int cols = (int)MathF.Ceiling(n / (float)rows);

        // Шаг по X: соседи в одном ряду стоят рядом — обе полуширины + просвет.
        // Шаг по Y: высота самого высокого + небольшой зазор, чтобы кроны не сливались.
        const float TallestInGallery = 6.5f;
        float stepX = maxHalfWidth * 2f + ClearanceMargin;
        // При шахматном сдвиге ряды можно ставить теснее: соседи сверху и снизу не
        // стоят строго друг над другом, поэтому кроны не сливаются даже при перехлёсте.
        float stepY = TallestInGallery * (rows >= 3 ? 0.80f : 1f) + 1.6f;

        for (int k = 0; k < n; k++)
        {
            int row = k / cols;
            int col = k % cols;
            // Шахматный сдвиг: нечётные ряды смещены на половину шага.
            rowX[k] = col * stepX + (row % 2 == 1 ? stepX * 0.5f : 0f);
            // Нулевой ряд — снизу (ближе к камере по смыслу «передний»).
            rowY[k] = (rows - 1 - row) * stepY;
        }

        float totalWidth = (cols - 1) * stepX;
        for (int k = 0; k < n; k++) rowX[k] -= totalWidth * 0.5f;

        // Bbox раскладки: низ = основание нижнего ряда (подписи чуть ниже, −0.55),
        // верх = основание верхнего ряда + высота самого высокого дерева.
        // Фокус камеры — геометрический центр bbox, чтобы сверху и снизу был
        // одинаковый запас, а не «воздух» только сверху.
        float yMin = -0.6f; // чуть ниже подписей
        float yMax = (rows - 1) * stepY + TallestInGallery;
        _lastGridHalfWidth = totalWidth * 0.5f + maxHalfWidth;
        _lastGridHeight = yMax - yMin;
        _lastFocusY = (yMin + yMax) * 0.5f;

        // Общий множитель: самое высокое дерево витрины приводится к TallestInGallery,
        // все остальные масштабируются тем же числом.
        float tallestLocal = 0.1f;
        for (int i = 0; i < n; i++)
        {
            var kk = kinds[i];
            int spIdx = GalleryEntries[shownIdx[i]].Species;
            tallestLocal = Math.Max(tallestLocal,
                PlantCatalog.Instance.Get(kk, PlantCatalog.VariantOf(spIdx, _galleryCrowdingLevel)).LocalHeight);
        }
        float galleryScale = TallestInGallery / tallestLocal;

        for (int i = 0; i < n; i++)
        {
            var kind = kinds[i];
            // ВАРИАНТ = ВИД + СТУПЕНЬ ЗАТЕНЁННОСТИ.
            //
            // Раньше здесь стояло «вариант каталога = индекс породы»: каталог
            // раскладывал породы как v % Count. После V156 вариант несёт ещё и
            // затенённость (см. PlantCatalog.VariantsPerKind), поэтому номер
            // собирается явно. Ступень задаётся витриной и меняется по шагам серии —
            // иначе разные силуэты одной породы посмотреть было бы негде: на уровне
            // их пришлось бы искать пешком.
            int speciesIdx = GalleryEntries[shownIdx[i]].Species;
            var plantData = PlantCatalog.Instance.Get(
                kind, PlantCatalog.VariantOf(speciesIdx, _galleryCrowdingLevel));
            var proto = ToArrayMesh(plantData);
            float localH = Math.Max(plantData.LocalHeight, 0.1f);

            // ОБЩИЙ МАСШТАБ ДЛЯ ВСЕХ, а не подгонка каждого к своей целевой высоте.
            //
            // Раньше каждое дерево нормировалось к targetH СВОЕГО ТИПА (Pine 5.5,
            // Fir 6.5, Deciduous 5.0), и разница высот между породами стиралась
            // начисто: пихта в 42 м и тсуга в 25 м отображались одинаковыми. Именно
            // поэтому на скриншотах все ели были одного роста. Теперь множитель один
            // на всю витрину, поэтому относительные высоты видны как есть.
            float s2 = galleryScale;

            var mi = new MeshInstance3D
            {
                Name = $"Plant_{kind}",
                Mesh = proto,
                MaterialOverride = CreateFoliageMaterial(0.7f)
            };
            mi.Scale = new Vector3(s2, s2, s2);
            // Все растения в одной плоскости Z: разнос по глубине заменён шахматной
            // сеткой, иначе при зуме дальний ряд оказывался вне резкости охвата.
            const float rowZ = 0f;
            mi.Position = new Vector3(rowX[i], rowY[i], rowZ);
            _galleryRoot.AddChild(mi);

            // ПОДПИСЬ с названием породы под деревом. Label3D всегда развёрнут к
            // камере (Billboard), поэтому читается с любого ракурса, а «вертикальность»
            // обеспечивается тем, что текст стоит НАД землёй столбиком под растением,
            // а не лежит на ней.
            var label = new Label3D
            {
                // Имя начинается с GalleryLabel_, чтобы проход идентификаторов мог
                // исключить подписи: иначе они попадают в шаблон прямоугольниками и
                // мешают считать области растений (см. SketchCapture.IdColorFor).
                Name = $"GalleryLabel_{i}",
                // Номер = исходный индекс GalleryEntries (клавиши 1-9), не позиция в отфильтрованном ряду.
                Text = $"{shownIdx[i] + 1}. {EntryLabel(shownIdx[i])}",
                FontSize = 96,
                PixelSize = 0.006f,
                Billboard = BaseMaterial3D.BillboardModeEnum.Enabled,
                NoDepthTest = false,
                Modulate = new Color(0.92f, 0.95f, 0.85f),
                OutlineSize = 16,
                OutlineModulate = new Color(0f, 0f, 0f, 0.85f),
                // Подпись сдвинута к камере по Z, чтобы не тонула в кроне соседа
                // по колонке (соседи теперь стоят друг за другом именно по Z).
                // Подпись — прямо под своим деревом, на его же уровне.
                Position = new Vector3(rowX[i], rowY[i] - 0.55f, rowZ + 0.6f),
            };
            _galleryRoot.AddChild(label);
        }

        // Постцентрирование больше не нужно: каждый ряд центрируется при построении.
    }

    /// <summary>
    /// Поверхность воды отдельным мешем, границей по МЕТОДУ MARCHING SQUARES.
    ///
    /// Первая версия включала ячейку в воду целиком либо не включала вовсе, и кромка
    /// шла строго по рёбрам сетки — отсюда «квадратная» вода со ступеньками: русло реки
    /// занимает всего 2-3 ячейки шириной, и ступени были в треть его ширины.
    ///
    /// Здесь граница проходит там, где глубина пересекает порог: для каждой ячейки
    /// обходятся её четыре угла по кругу, внутренние углы попадают в многоугольник,
    /// а на рёбрах, где глубина меняет знак относительно порога, вставляется точка
    /// ЛИНЕЙНОЙ ИНТЕРПОЛЯЦИИ. Кромка получается наклонной и следует руслу, а не сетке.
    ///
    /// Зачем отдельный меш, а не подкраска рельефа (как было раньше): под водой должны
    /// плавать рыбы, а значит нужен объём — дно снизу, поверхность сверху.
    /// </summary>
    private void BuildWaterSurface(
        float[] carveBlur, float[] waterSurfAll, Vector3[] verts, bool[] valid, int res)
    {
        if (_water == null) return;

        var wv = new List<Vector3>();
        var wc = new List<Color>();
        var wi = new List<int>();
        // UV.x — нормированная глубина для шейдера воды (см. assets/shaders/water.gdshader).
        // Цвет вершины отвечает за базовый тон, а глубина нужна шейдеру отдельно: по ней
        // считаются прозрачность, пена у берега и затухание ряби на мелководье.
        var wuv = new List<Vector2>();

        // Значение поля в узле: глубина минус порог. Больше нуля — вода.
        float Field(int gx, int gz)
        {
            int i = gz * res + gx;
            if (!valid[i]) return -1f;
            return carveBlur[i] - WaterMinDepth;
        }
        // Позиция узла: X и Z берём у РЕЛЬЕФА (гарантированно та же сетка), Y — водный.
        //
        // БЫЛО: для СУХОГО узла подставлялась высота РЕЛЬЕФА. Кромка воды строится
        // интерполяцией вдоль ребра между мокрым и сухим узлом, и такая подстановка
        // тянула её вверх к берегу — вода задиралась над своим уровнем острыми
        // треугольниками (видно как «пирамиды» и «зубцы» по руслу). Причём чем круче
        // берег, тем выше зубец, потому что тем больше разница высот.
        //
        // СТАЛО: у сухого узла берётся ВИРТУАЛЬНЫЙ уровень воды (какой был бы здесь),
        // который лежит чуть выше рельефа. Интерполяция идёт между двумя уровнями
        // ВОДЫ, а не между водой и берегом, поэтому поверхность остаётся ровной.
        Vector3 Node(int gx, int gz)
        {
            int i = gz * res + gx;
            var t = verts[i];
            float y = waterSurfAll[i];
            if (float.IsNaN(y)) y = t.Y;
            return new Vector3(t.X, y, t.Z);
        }
        // Нормированная глубина 0..1 для шейдера. WaterDeepDepth — отметка, начиная с
        // которой вода считается «глубокой»; выше неё значение упирается в 1.
        float Depth01(float depth) =>
            Math.Clamp((depth - WaterMinDepth) / Math.Max(WaterDeepDepth - WaterMinDepth, 1e-4f), 0f, 1f);

        // Цвет по глубине: у берега светлее и прозрачнее, на глубине темнее и плотнее.
        Color ColOf(float depth)
        {
            float t = Math.Clamp(depth / 0.05f, 0f, 1f);
            var shallow = new Color(0.55f, 0.74f, 0.80f, 0.45f);
            var deep = new Color(0.12f, 0.32f, 0.52f, 0.88f);
            return shallow.Lerp(deep, t);
        }

        var poly = new List<Vector3>(8);
        var polyC = new List<Color>(8);
        var polyD = new List<float>(8);
        // Буферы углов ячейки создаются ОДИН раз до цикла. Раньше здесь был stackalloc
        // внутри двойного цикла — анализатор справедливо ругался (CA2014): память в стеке
        // не освобождается до выхода из метода, поэтому stackalloc в цикле на 65 тысяч
        // итераций — это переполнение стека.
        var cxs = new int[4];
        var czs = new int[4];

        for (int gz = 0; gz < res - 1; gz++)
        for (int gx = 0; gx < res - 1; gx++)
        {
            // Углы по кругу: (0,0) -> (1,0) -> (1,1) -> (0,1)
            cxs[0] = gx; cxs[1] = gx + 1; cxs[2] = gx + 1; cxs[3] = gx;
            czs[0] = gz; czs[1] = gz;     czs[2] = gz + 1; czs[3] = gz + 1;

            poly.Clear();
            polyC.Clear();
            polyD.Clear();
            for (int k = 0; k < 4; k++)
            {
                int k2 = (k + 1) & 3;
                float f1 = Field(cxs[k], czs[k]);
                float f2 = Field(cxs[k2], czs[k2]);

                if (f1 > 0f)
                {
                    float dHere = carveBlur[czs[k] * res + cxs[k]];
                    poly.Add(Node(cxs[k], czs[k]));
                    polyC.Add(ColOf(dHere));
                    polyD.Add(Depth01(dHere));
                }
                // Ребро пересекает границу — вставляем точку пересечения.
                if ((f1 > 0f) != (f2 > 0f))
                {
                    float t = f1 / (f1 - f2);          // доля вдоль ребра до нуля поля
                    t = Math.Clamp(t, 0f, 1f);

                    // КРОМКА САДИТСЯ НА ДНО, а не висит на уровне воды.
                    //
                    // Контур проходит там, где глубина равна WaterMinDepth, а не нулю.
                    // Если поставить кромочную вершину на уровень ВОДЫ, лист воды
                    // обрывается, будучи ещё ~1 мировую единицу толщиной, — и между
                    // водой и берегом виден воздушный зазор, вода выглядит вставленным
                    // в русло инородным телом.
                    //
                    // Поэтому кромочная вершина берётся по ДНУ (verts), причём
                    // интерполяцией ДНА между обоими узлами — тогда вода плавно сходит
                    // на нет у берега. Важно не повторить прежнюю ошибку: нельзя
                    // смешивать уровень воды у мокрого узла с рельефом у сухого, именно
                    // это давало зубцы. Здесь обе стороны — одна и та же величина, дно.
                    var b1 = verts[czs[k] * res + cxs[k]];
                    var b2 = verts[czs[k2] * res + cxs[k2]];
                    poly.Add(b1.Lerp(b2, t));
                    // На самой кромке глубина равна порогу — берём мелководный цвет
                    // и нулевую нормированную глубину (там будет пена).
                    polyC.Add(ColOf(WaterMinDepth));
                    polyD.Add(0f);
                }
            }

            if (poly.Count < 3) continue;
            int baseIdx = wv.Count;
            for (int k = 0; k < poly.Count; k++)
            {
                wv.Add(poly[k]);
                wc.Add(polyC[k]);
                wuv.Add(new Vector2(polyD[k], 0f));
            }
            for (int k = 1; k < poly.Count - 1; k++)
            {
                wi.Add(baseIdx);
                wi.Add(baseIdx + k);
                wi.Add(baseIdx + k + 1);
            }
        }

        if (wi.Count == 0) { _water.Mesh = null; return; }

        var normals = new Vector3[wv.Count];
        Array.Fill(normals, Vector3.Up);

        // Тангенты воды тривиальны: поверхность горизонтальна, нормаль всегда вверх,
        // поэтому касательная — это +X, а бинормаль — +Z. Шейдер строит по ним
        // возмущение нормали от волн, без них рябь считать не в чем.
        var wTangents = new float[wv.Count * 4];
        for (int i = 0; i < wv.Count; i++)
        {
            wTangents[i * 4 + 0] = 1f;
            wTangents[i * 4 + 1] = 0f;
            wTangents[i * 4 + 2] = 0f;
            wTangents[i * 4 + 3] = 1f;
        }

        var arrays = new Godot.Collections.Array();
        arrays.Resize((int)Mesh.ArrayType.Max);
        arrays[(int)Mesh.ArrayType.Vertex] = wv.ToArray();
        arrays[(int)Mesh.ArrayType.Normal] = normals;
        arrays[(int)Mesh.ArrayType.Tangent] = wTangents;
        arrays[(int)Mesh.ArrayType.TexUV] = wuv.ToArray();
        arrays[(int)Mesh.ArrayType.Color] = wc.ToArray();
        arrays[(int)Mesh.ArrayType.Index] = wi.ToArray();

        var m = new ArrayMesh();
        m.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, arrays);
        _water.Mesh = m;
    }

    /// <summary>
    /// Мировая высота ПОВЕРХНОСТИ ВОДЫ в точке, либо null, если воды здесь нет.
    /// Задел под рыб: допустимая глубина для рыбы — между SampleWorldY (дно) и этим
    /// значением. Для наземных животных достаточно SampleWorldY, но проверять
    /// SampleWaterY тоже стоит, чтобы они не заходили в озеро.
    /// </summary>
    public float? SampleWaterY(float worldX, float worldZ)
    {
        if (_waterLevel == null || _hRes < 2) return null;
        float wx = worldX / WorldScale + _hCx;
        float wz = worldZ / WorldScale + _hCz;
        float gx = wx / _hStep;
        float gz = wz / _hStep;
        int ix = (int)gx;
        int iz = (int)gz;
        if (ix < 0 || iz < 0 || ix >= _hRes - 1 || iz >= _hRes - 1)
        {
            // Край сетки: ближайшая ячейка.
            ix = Math.Clamp(ix, 0, _hRes - 1);
            iz = Math.Clamp(iz, 0, _hRes - 1);
            float edge = _waterLevel[iz * _hRes + ix];
            return float.IsNaN(edge) ? null : edge;
        }

        float fx = gx - ix;
        float fz = gz - iz;
        int i00 = iz * _hRes + ix;
        int i10 = i00 + 1;
        int i01 = i00 + _hRes;
        int i11 = i01 + 1;

        // Билинейная выборка среди мокрых узлов; если все NaN — поиск в 3×3.
        float wsum = 0f, y = 0f;
        void Acc(int i, float w)
        {
            float v = _waterLevel[i];
            if (float.IsNaN(v)) return;
            y += v * w;
            wsum += w;
        }
        Acc(i00, (1 - fx) * (1 - fz));
        Acc(i10, fx * (1 - fz));
        Acc(i01, (1 - fx) * fz);
        Acc(i11, fx * fz);
        if (wsum > 1e-6f) return y / wsum;

        // Fallback: любая вода поблизости (лодка на осевой, сетка может промахнуться).
        for (int dz = -2; dz <= 2; dz++)
        for (int dx = -2; dx <= 2; dx++)
        {
            int nx = ix + dx, nz = iz + dz;
            if ((uint)nx >= (uint)_hRes || (uint)nz >= (uint)_hRes) continue;
            float v = _waterLevel[nz * _hRes + nx];
            if (!float.IsNaN(v)) return v;
        }
        return null;
    }


    private void ClearVegetation()
    {
        // Кеш мешей сбрасывается вместе с растительностью: после смены сида
        // каталог пересобирается, и старые меши стали бы чужими.
        _protoMeshCache.Clear();

        _vegChunks.Clear();
        if (_vegRoot == null) return;
        while (_vegRoot.GetChildCount() > 0)
        {
            var child = _vegRoot.GetChild(0);
            _vegRoot.RemoveChild(child);
            child.QueueFree();
        }
    }


    /// <summary>
    /// ОТЛАДОЧНЫЙ РЕЖИМ: вместо настоящих мешей растений рисуются контрастные примитивы
    /// (по фигуре и цвету на каждый вид). Настоящая листва на общем плане сливается в
    /// зелёную массу — по скриншоту невозможно понять, где какой вид и как он
    /// распределён по карте. Примитивы это показывают сразу. Переключается клавишей V.
    /// Форма и цвет подобраны так, чтобы различаться и по силуэту, и по тону, — на случай
    /// перекрытия и на случай чёрно-белого просмотра.
    /// </summary>
    public static bool DebugPrimitiveVegetation;

    /// <summary>
    /// Сторона сетки чанков растительности. Значение подобрано ЗАМЕРОМ (High, seed 42):
    /// чанкование дробит один большой MultiMesh на много мелких, и здесь есть размен —
    /// мельче чанк, точнее отсечение и LOD, но больше узлов и вызовов отрисовки.
    ///   8x8 + все варианты -> 1851 узел, медиана всего 5 экземпляров в группе;
    ///   6x6 + все варианты -> 1153 узла, медиана 8;
    ///   4x4 + схлопнутые варианты покрытий -> 400 узлов (против 45 до чанкования).
    /// Взят последний: дробление уже не съедает выгоду, а 400 вызовов приемлемы.
    /// </summary>
    private const int VegChunkGrid = 4;

    // ---- V83: кэш атласов импосторов ----

    private sealed class BakedImpostor
    {
        public required Mesh Card;
        public required Material Material;
    }

    /// <summary>Атлас на породу (вид + вариант). Выпекается один раз и делится
    /// между всеми чанками этой породы.</summary>
    private readonly Dictionary<(VegetationKind kind, int variant), BakedImpostor> _impostorAtlases = new();

    private readonly HashSet<(VegetationKind kind, int variant)> _impostorPending = new();

    /// <summary>Готовые меши растений по паре «вид и вариант». Сбрасывается при
    /// пересборке уровня вместе с растительностью.</summary>
    private readonly Dictionary<(int kind, int variant), Mesh> _protoMeshCache = new();

    /// <summary>Сколько атласов карточек выпечено. Печатается в строке [PERF].</summary>
    public int BakedImpostorCount => _impostorAtlases.Count;

    private ImpostorAtlasBaker? _impostorBaker;
    private ShaderMaterial? _impostorTemplate;

    /// <summary>
    /// Запустить выпекание атласа для породы. Асинхронно: рендер восьми ракурсов
    /// занимает восемь кадров, и делать это синхронно означало бы фриз при первой
    /// загрузке уровня. До готовности чанк рисуется прежней геометрией.
    /// </summary>
    private async void RequestImpostorAtlas(
        (VegetationKind kind, int variant) key, Mesh proto, Material mat, Mesh? lodMesh = null)
    {
        if (!_impostorPending.Add(key)) return;
        try
        {
            _impostorBaker ??= new ImpostorAtlasBaker { Name = "ImpostorBaker" };
            if (_impostorBaker.GetParent() == null) AddChild(_impostorBaker);

            var atlas = await _impostorBaker.BakeAsync(proto, mat);
            if (atlas == null)
            {
                // Раньше здесь стоял молчаливый return: атлас не получался, а в логе не
                // было ни строки, и счётчик atlas в HUD просто не рос. Отличить это от
                // «выпекание ещё идёт» было невозможно.
                GD.PrintErr($"[impostor] ОШИБКА выпекания {key.kind}/{key.variant}: " +
                            "снимок не получен (пустой меш или кадр не прочитался)");
                return;
            }
            if (atlas.OpaqueFraction < 0.02f)
            {
                // Атлас формально есть, но по нему нечего рисовать: шейдер отбрасывает
                // фрагмент при альфе ниже 0.5, поэтому такая карточка будет невидима, а
                // дальний план — пуст. Отказываемся и оставляем запасную геометрию.
                GD.PrintErr($"[impostor] ОШИБКА выпекания {key.kind}/{key.variant}: " +
                            $"снимок пустой, непрозрачных точек {atlas.OpaqueFraction * 100f:F2}%");
                return;
            }

            _impostorTemplate ??= new ShaderMaterial
            {
                Shader = GD.Load<Shader>("res://assets/shaders/impostor.gdshader")
            };
            var m = (ShaderMaterial)_impostorTemplate.Duplicate();
            m.SetShaderParameter("atlas", atlas.Texture);
            m.SetShaderParameter("angle_count", atlas.Angles);

            // ЗАПОЛНЕННОСТЬ И СЫПЬ — впереди прочего: это мера пригодности кроны, а
            // остальное здесь техника выпекания. Прежние «непрозрачных точек 5%»
            // ничего не значили — там делилось на площадь квадратного кадра.
            //
            // ---- V154: ПОРОГИ СОГЛАСОВАНЫ С ШАБЛОНОМ ----
            //
            // Первые пороги (заполненность выше 35%, сыпь ниже 12%) я назначил по
            // рассуждению, до того как увидел хоть один шаблон. Витрина показала, что
            // они ведут не туда: хвойные с заполненностью 83-87% и сыпью 11-13%
            // проходили без замечаний, а на раскраске давали ОДНО пятно на дерево;
            // лиственные с сыпью 18-21% помечались дефектом, а давали внутри кроны
            // читаемую структуру из перекрывающихся клубов.
            //
            // Значит сыпь в этом диапазоне — не дефект, а внутренние линии рисунка,
            // и порог поднят до 20%. Заполненность получила ВЕРХНЮЮ границу: выше 78%
            // крона становится монолитом. Полоса 45-78% — та, в которой лежат
            // лиственные, читающиеся лучше всех.
            // Порог сыпи тоже видовой — обоснование в SpeckleLimit.
            // ПОРОГИ ПО ТИПАМ, А НЕ ОДИН НА ВСЕХ.
            //
            // Общий порог 45% метил «редкими» все пять вариантов камыша (36-41%), хотя
            // у стеблевого растения сплошного силуэта не бывает и быть не должно: это
            // пучок стеблей, а не крона. Дерево при тех же 40% — действительно редкое.
            // Мера одна, а норма у неё разная, и делать вид, что это не так, значит
            // приучать себя не замечать пометки.
            (float lo, float hi) = key.kind switch
            {
                VegetationKind.Reed => (0.25f, 0.60f),      // пучок стеблей
                VegetationKind.GrassTuft => (0.30f, 0.70f), // дернина
                VegetationKind.Moss => (0.30f, 0.95f),      // подушка, монолит уместен
                VegetationKind.Stone => (0.60f, 1.00f),     // камень сплошной по природе
                VegetationKind.Flower => (0.20f, 0.60f),
                _ => (0.45f, 0.78f)                          // деревья и кусты
            };
            bool tooSparse = atlas.CrownFill < lo;
            bool tooSolid = atlas.CrownFill > hi;
            SessionLog.Print($"[impostor] {key.kind}/{key.variant}: " +
                     $"ЗАПОЛНЕННОСТЬ СИЛУЭТА {atlas.CrownFill * 100f:F0}%, " +
                     $"мелких дырок {atlas.SmallHoleFraction * 100f:F1}%" +
                     (tooSparse ? "  <-- РЕДКО" : "") +
                     (tooSolid ? "  <-- МОНОЛИТ" : "") +
                     (atlas.SmallHoleFraction > SpeckleLimit(key.kind) ? "  <-- СЫПЬ" : "") +
                     $" | ракурсов {atlas.Angles}, отношение сторон {atlas.AspectHeightOverWidth:F2}, " +
                     $"сторона кадра {atlas.FrameLocalSize:F2} лок.ед., центр {atlas.FrameLocalCentreY:F2}, " +
                     $"непрозрачных точек кадра {atlas.OpaqueFraction * 100f:F1}%");

                // ---- V166: ЗАМЕР ПРОРЕЖЕННОГО МЕША ----
                //
                // Метрика кроны считалась по атласу импостора, а он выпекается из ПОЛНОГО
                // меша. Значит все девять итераций мы мерили меш, который на уровне
                // встречается в двух случаях из тысячи: по телеметрии обхода полным мешем
                // отрисовано 0.0% лиственных, 0.2% сосен, 0.2% кустов. Игрок видит
                // импосторы (97.6%) и ПРОРЕЖЕННЫЙ меш (2.4%), а качество последнего не
                // измерялось ни разу — он не проходит через выпечку.
                //
                // Прореженный меш — обычный меш, поэтому меряется тем же прибором:
                // выпекается такой же атлас, из него берутся заполненность и сыпь.
                // Текстура выбрасывается, нужны только числа. Восемь лишних кадров на
                // вариант при загрузке — приемлемая цена за то, чтобы увидеть, что
                // происходит с деревьями ближнего плана.
                if (lodMesh != null && lodMesh.GetSurfaceCount() > 0)
                {
                    var lodAtlas = await _impostorBaker.BakeAsync(lodMesh, mat);
                    if (lodAtlas != null)
                    {
                        float dFill = lodAtlas.CrownFill - atlas.CrownFill;
                        float dHole = lodAtlas.SmallHoleFraction - atlas.SmallHoleFraction;
                        SessionLog.Print($"[lod1] {key.kind}/{key.variant}: " +
                                 $"ЗАПОЛНЕННОСТЬ {lodAtlas.CrownFill * 100f:F0}% " +
                                 $"({dFill * 100f:+0;-0;0} к полному), " +
                                 $"мелких дырок {lodAtlas.SmallHoleFraction * 100f:F1}% " +
                                 $"({dHole * 100f:+0.0;-0.0;0} к полному)" +
                                 (dFill < -0.15f ? "  <-- КРОНА РАСПАЛАСЬ" : "") +
                                 (dHole > 0.10f ? "  <-- СЫПЬ ОТ ПРОРЕЖИВАНИЯ" : ""));
                    }
                }


            _impostorAtlases[key] = new BakedImpostor
            {
                Card = ImpostorAtlasBaker.BuildCardMesh(
                    atlas.FrameLocalSize, atlas.FrameLocalCentreY, atlas.Angles),
                Material = m,
            };

            // Раздаём готовый атлас уже созданным чанкам этой породы.
            foreach (var ch in _vegChunks)
            {
                if (ch.Kind != key.kind || ch.Variant != key.variant) continue;
                ch.Lod2 = _impostorAtlases[key].Card;
                ch.Lod2Material = _impostorAtlases[key].Material;
                // Узел импостора получает готовый атлас немедленно; пересборки корзин
                // для этого не требуется — состав корзин от материала не зависит.
                ch.MmImp.Mesh = ch.Lod2;
                ch.NodeImp.MaterialOverride = ch.Lod2Material;
            }
        }
        catch (Exception ex)
        {
            GD.PrintErr($"[impostor] ОШИБКА выпекания {key.kind}/{key.variant}: {ex.Message}");
        }
        finally
        {
            _impostorPending.Remove(key);
            // ---- V162: ОТЧЁТ О САМООРГАНИЗАЦИИ — КОГДА ОНА ТОЧНО ЗАКОНЧИЛАСЬ ----
            //
            // Лиственные строятся отложенно, при первом обращении к варианту, поэтому
            // на момент «каталог готов» счётчики роста ещё нули — так и вышло в V161,
            // где строка показала нули, а обрыв роста был у семи деревьев из девяти.
            // Выпечка импосторов обращается ко всем вариантам, поэтому опустевшая
            // очередь — надёжная точка, к которой все деревья уже построены.
            if (_impostorPending.Count == 0 && !_soReportPrinted)
            {
                _soReportPrinted = true;
                long grown = PlantGenerator.SoStats.NodesBeforeShed;
                long left = PlantGenerator.SoStats.NodesAfterShed;
                SessionLog.Print($"[рост] самоорганизация: выращено {grown}, осталось {left}, " +
                         $"сброшено затенённых {grown - left}, " +
                         $"прорежено {PlantGenerator.SoStats.NodesPruned}" +
                         (PlantGenerator.SoStats.NodeCapHit > 0
                            ? $"  <-- РОСТ ОБОРВАН у {PlantGenerator.SoStats.NodeCapHit} деревьев"
                            : ""));
            }
        }
    }

    /// <summary>Отчёт о росте печатается один раз за сборку каталога.</summary>
    private bool _soReportPrinted;

    // V38: с лодки Full ЗАПРЕЩЁН — только Lod1/Hide.
    // Анализ видео: full-счётчик прыгал 15↔27 при дрейфе; AABB ближайшей точки
    // чанка у берега постоянно пересекала FullEnter/Exit → смена меша (×5–9 карточек)
    // выглядела как «мигание» крон. Full остаётся только для будущей пешей прогулки.
    // V82: полосы сужены под новый бюджет. Расчёт при дереве 736 треугольников,
    // Lod1 ~150 и импосторе 4:
    //   полосы 12/26 -> 550k треугольников (цель 250k)
    //   полосы  6/20 -> 231k  ✓
    /// <summary>Опорная высота окна в точках. Все пороги LOD, размеры ячеек атласа и
    /// толщина обводки подбирались именно для неё; на других разрешениях они
    /// пересчитываются, а не переподбираются.</summary>
    public const float ReferenceScreenHeight = 1080f;

    /// <summary>Опорное вертикальное поле зрения в градусах (значение Godot по умолчанию).</summary>
    public const float ReferenceFovDeg = 75f;

    private static float Sq(float x) => x * x;

    /// <summary>
    /// Во сколько раз раздвинуть пороги LOD относительно опорной конфигурации.
    ///
    /// Видимый размер объекта в точках экрана равен
    ///     размер / дистанция · H / (2·tan(fov/2)).
    /// Чтобы переключение происходило при одном и том же видимом размере, дистанция
    /// должна быть пропорциональна H / (2·tan(fov/2)) — это и есть множитель.
    /// На экране выше опорного пороги отодвигаются, на узком поле зрения (зум) тоже:
    /// при зуме дерево крупнее, и подменять его импостором рано.
    /// </summary>
    private float LodDistanceScale()
    {
        var vp = GetViewport();
        float h = vp != null ? vp.GetVisibleRect().Size.Y : ReferenceScreenHeight;
        if (h < 1f) h = ReferenceScreenHeight;
        float fov = GetViewport()?.GetCamera3D()?.Fov ?? ReferenceFovDeg;
        float tanRef = MathF.Tan(ReferenceFovDeg * MathF.PI / 360f);
        float tanCur = MathF.Tan(Math.Clamp(fov, 5f, 170f) * MathF.PI / 360f);
        return (h / ReferenceScreenHeight) * (tanRef / tanCur);
    }

    // ---- V100: ПОЛОСЫ СЖАТЫ ПОД НАСТОЯЩУЮ ПЛОТНОСТЬ ЛЕСА ----
    //
    // Прежние 5/9 и 30 подбирались, когда деревьев на чанк было около полутора тысяч.
    // При лесной плотности их двадцать тысяч, и видимое число в полосе растёт как
    // КВАДРАТ её радиуса. Расчёт при 1.0 дерева на квадратную мировую единицу:
    //   полный меш в круге радиусом 9  — 254 кв.ед., 254 дерева по 3000 тр. = 762k
    //   полный меш в круге радиусом 4  —  50 кв.ед.,  50 деревьев        = 150k
    // Поэтому ближняя полоса сжата до четырёх единиц (сорок метров — дальше дерево
    // и так не разглядеть в подробностях), а средняя до шестнадцати.
    private const float VegLodFullEnter = 1.3f; // V128: гистерезис под новый VegLodFullExit = 6
    // ---- V128: ПОЛОСЫ ВОЗВРАЩЕНЫ К БЮДЖЕТУ ----
    //
    // 12 и 32 задавались ради дальнего подробного плана, но видимое число экземпляров
    // растёт как КВАДРАТ радиуса полосы: 12 против 4.5 — это площадь в семь раз
    // больше, 32 против 16 — в четыре. Вместе с потяжелевшим мешем прогноз кадра
    // давал 19 миллионов треугольников при ориентире 400 тысяч; отсюда и 7 fps.
    // Возврат к 6/20 при вчетверо более дешёвом дереве укладывается в бюджет и
    // сохраняет подробный план на шестидесяти метрах.
    // ---- V130: ПОДРОБНЫЙ МЕШ ТОЛЬКО ВПЛОТНУЮ ----
    //
    // Реалистичное дерево стоит 25 640 треугольников — это цена карточек НАТУРАЛЬНОГО
    // размера: пучок в полметра вместо двухметрового лопуха. Дешевле сделать нельзя,
    // не вернувшись к лопухам. Зато такой меш нужен только там, где его разглядывают.
    //
    // Двадцать метров: на этом расстоянии дерево занимает почти весь экран по высоте.
    // Дальше работает прореженный уровень, а он ограничен сверху по числу карточек
    // (LeafQuadCap/WoodQuadCap), то есть стоит около 360 треугольников независимо от
    // того, насколько тяжёл исходный меш. Именно поэтому подорожание полного меша
    // почти не бьёт по средней полосе.
    private const float VegLodFullExit  = 2.0f;
    // V67: дальность скрытия уменьшена вслед за удвоением плотности.
    //
    // Видимое число экземпляров растёт как КВАДРАТ дальности. Плотность выросла
    // с 0.343 до 0.720 экз. на мировую кв. единицу, поэтому при прежней дальности 90
    // в кадре оказалось бы 18 300 экземпляров вместо 8 700 — рост вдвое. Дальность 75
    // даёт 12 700, то есть рост в 1.46 раза вместо двукратного.
    //
    // Это ПОЛУМЕРА. Правильное решение — третий уровень LOD (см. комментарий к
    // VegChunk): на средней дистанции дерево должно вырождаться в две скрещённые
    // карточки. Godot не применяет встроенный mesh LOD к MultiMesh, поэтому
    // подменять меш нужно вручную — механизм для этого в VegChunk уже есть.
    /// <summary>Дистанция перехода на импостор (4 треугольника вместо 1330).</summary>
    // V84: отодвинуто с 20 до 45. Замер видимого размера: на 20 единицах дерево
    // занимает 66-103 точки экрана — плоская карточка там читается как «зелёный щит»,
    // что и было видно на скриншоте. На 45 единицах остаётся 30-45 точек, подмена
    // незаметна.
    // V84: 30 — компромисс. На 45 подмена совсем незаметна, но полоса среднего
    // уровня тогда вмещает 4144 экземпляра и стоит 1 079k треугольников при
    // бюджете 250k. На 30 в полосе 1813 экземпляров и 286k — проходит, а дерево
    // на этой дистанции занимает 44-70 точек экрана.
    // V100: 30 -> 16. На шестнадцати единицах (160 м) дерево занимает около 90 точек
    // экрана при опорном разрешении — подмена карточкой заметна меньше, чем провал
    // кадра от полутора тысяч подробных мешей в полосе.
    private const float VegLodImpostorEnter = 8f;   // V130
    private const float VegLodImpostorExit  = 6.5f; // V128: гистерезис под VegLodImpostorEnter = 20

    // V84: СКРЫТИЕ ПО ДИСТАНЦИИ ОТКЛЮЧЕНО.
    //
    // Деревья появлялись перед камерой из пустоты — по скриншотам это видно прямо:
    // при повороте камеры чанки входили в полосу видимости и возникали разом.
    // Дерево, попавшее в кадр, должно быть видно всегда.
    //
    // Это стало возможно именно после импостора: все 16 886 экземпляров на дальнем
    // уровне стоят 34k треугольников, то есть скрывать их незачем. Отсечение по
    // видимости убирает то, что вне кадра, и этого достаточно.
    /// <summary>Дистанция скрытия ПОКРЫТИЙ (трава, мох, камни), мировые единицы.
    /// Куртина высотой полметра дальше этого расстояния мельче точки экрана при
    /// опорном разрешении; порог масштабируется вместе с остальными.</summary>
    // V103: 14 -> 6. Замер экранного размера расставил всё по местам: куртина
    // высотой полметра при опорном разрешении даёт около восьми точек экрана на
    // пяти мировых единицах и две на двадцати. То есть дальше шести единиц её
    // показывать бессмысленно при любой плотности — а платить за неё приходилось
    // на всех четырнадцати. Освободившийся бюджет уходит в плотность ближнего
    // круга: там, где трава видна, её теперь ковёр, а не отдельные пучки.
    // V128: 18 -> 9. Куртина подорожала с 200 до 1300 треугольников, и круг
    // радиусом 18 при её плотности давал 3.4 миллиона только на траву. Ковёр даёт
    // шейдер; мешам остаётся ближний круг, где видна их геометрия.
    // V129: 6 -> 5. Трава даёт 29.3% стоимости кадра; площадь круга падает как
    // квадрат радиуса, то есть это минус треть при почти незаметной разнице у ног.
    // ---- V144: ПОКРЫТИЯ ПОКАЗЫВАЮТСЯ ТОЛЬКО ТАМ, ГДЕ РАЗЛИЧИМЫ ----
    //
    // Замер экранного размера: куртина высотой 45 см занимает 7 точек экрана с пяти
    // метров и 2 с двадцати. Ниже десяти точек растение неразличимо. При этом круг
    // радиусом 5 единиц вмещал 198 куртин и стоил 102 766 треугольников — половину
    // всей растительности кадра при том, что видно её почти не было.
    //
    // Три единицы (30 метров) — это круг втрое меньшей площади: около 25 тысяч
    // треугольников вместо ста. Сплошной ковёр дальше рисует шейдер рельефа
    // (grass_detail), для чего он и заводился.
    // ---- V146: ДИСТАНЦИИ ПО ЯРУСАМ, КАК В РАБОТАЮЩИХ ПРОЕКТАХ ----
    //
    // Из разбора процедурного озеленения на UE 5.7 (137 500 экземпляров на 500×500 м):
    // полог живёт до 300 м, подлесок до 150, наземное покрытие до 50. У нас наземка
    // отсекалась на двадцати метрах — вчетверо ближе, отсюда и «край ковра» под ногами.
    //
    // Пятьдесят метров = 5 мировых единиц. Цена растёт как квадрат радиуса, поэтому
    // одновременно куртина удешевляется крестовыми карточками (см. GenerateGrassTuft):
    // 90 отдельных лезвий -> 30 крестов, то есть та же густота втрое дешевле.
    private const float VegLodCoverHide = 5f;
    private const float VegLodFlowerHide = 16f; // V119

    /// <summary>На сколько должна сместиться камера, чтобы группу разобрали заново.
    /// Ширина переходной полосы между полным мешем и прорежённым — около полутора
    /// единиц; смещение меньше этого ничего не меняет ни для одного экземпляра.</summary>
    private const float VegSortStep = 1.2f;

    /// <summary>Сколько групп разбирается за кадр. При двухстах группах и пороге
    /// смещения выше за кадр обычно набирается две-три; ограничение нужно на случай
    /// прыжка камеры, когда пересборки требуют все сразу.</summary>
    private const int VegSortPerFrame = 12;

    private const float VegLodHideEnter = 100000f;
    private const float VegLodHideExit  = 99000f;
    /// <summary>Минимальное время в одном LOD-состоянии (мс), прежде чем можно сменить.</summary>
    private const ulong VegLodMinDwellMs = 700;

    /// <summary>
    /// Один чанк растительности: узел с MultiMesh плюс два варианта меша под LOD.
    /// Переключение LOD — замена ссылки mm.Mesh (трансформы не трогаем).
    /// </summary>
    /// <summary>
    /// Группа растений одной породы и варианта в одной клетке карты.
    ///
    /// V100: УРОВЕНЬ ДЕТАЛИЗАЦИИ ТЕПЕРЬ У КАЖДОГО ЭКЗЕМПЛЯРА, А НЕ У ГРУППЫ.
    ///
    /// Прежде группа целиком переключалась между полным мешем, прорежённым и
    /// импостором по расстоянию до её габаритов. Клетка при сетке 4×4 имеет сторону
    /// около 37 мировых единиц, а полный меш положен ближе девяти — то есть стоило
    /// камере войти в клетку, и весь её лес, включая деревья на другом краю в
    /// тридцати единицах, рисовался полным мешем. Это и был потолок, упиравший
    /// плотность леса: увеличить число деревьев было нельзя, потому что ближняя
    /// клетка сразу выходила за бюджет кадра.
    ///
    /// Теперь на группу приходится ТРИ узла MultiMesh с одним и тем же набором
    /// экземпляров, но разными мешами. Каждый экземпляр по своему расстоянию попадает
    /// ровно в один из них; буферы переписываются целиком через MultiMesh.Buffer —
    /// это одна операция на узел, а не вызов на экземпляр.
    ///
    /// Узел с пустой корзиной выключается, поэтому вызовов отрисовки в среднем
    /// прибавляется немного: клетка целиком далека — работает один узел импостора,
    /// целиком близка — один узел полного меша, и лишь на границе полос их два-три.
    /// </summary>
    private sealed class VegChunk
    {
        public required MultiMeshInstance3D NodeFull;
        public required MultiMeshInstance3D NodeLod1;
        public required MultiMeshInstance3D NodeImp;
        public required MultiMesh MmFull;
        public required MultiMesh MmLod1;
        public required MultiMesh MmImp;

        /// <summary>Исходный буфер MultiMesh: преобразование и цвет каждого
        /// экземпляра подряд. Строится один раз движком (через SetInstanceTransform на
        /// временном MultiMesh), поэтому раскладка гарантированно совпадает с той,
        /// которую движок ожидает обратно.</summary>
        public required float[] SrcBuffer;
        public required int Stride;
        public required Vector3[] Pos;

        public required Mesh Full;
        public required Mesh Lod1;
        /// <summary>Импостор: карточка из атласа либо, пока атлас не готов,
        /// скрещённые карточки геометрии.</summary>
        public required Mesh Lod2;

        public Material? Lod2Material;
        public Material? NearMaterial;

        public VegetationKind Kind;
        public int Variant;
        public Vector3 BoundsMin;
        public Vector3 BoundsMax;

        /// <summary>Положение камеры на момент последнего разбора по корзинам.
        /// Пока камера не сдвинулась заметно, разбирать заново нечего.</summary>
        public Vector3 LastSortCam = new(float.MaxValue, float.MaxValue, float.MaxValue);

        /// <summary>Сколько экземпляров сейчас в каждой корзине — для HUD.</summary>
        public int NFull, NLod1, NImp;

        /// <summary>Треугольников в мешах каждой корзины. Нужны телеметрии кадра:
        /// без них нельзя сказать, во что обходится вид, а не сколько его штук.</summary>
        public int FullTris, Lod1Tris, ImpTris;

        /// <summary>Габаритная высота и радиус кроны экземпляра единичного масштаба —
        /// по ним считается ЭКРАННЫЙ размер, то есть то, видно растение или нет.</summary>
        public float ProtoHeight, ProtoRadius;

        /// <summary>Масштаб каждого экземпляра: в SrcBuffer он зашит в матрицу,
        /// доставать его оттуда ради телеметрии дороже, чем хранить рядом.</summary>
        public required float[] Scales;
    }

    private readonly List<VegChunk> _vegChunks = new();

    // V109: Flower как покрытие — full в ближней полосе, без impostor
    // (V108: impostor давал readable≈1 при 126 visible).
    // V119: GrassTuft снова cover. Impostor-«кресты» на склоне читались как
    // поле крестов, а не ковёр. Ковёр вдали даёт цвет рельефа; детали — только
    // вблизи игрока (full), дальше скрытие.
    private static bool IsCoverKind(VegetationKind k) =>
        k is VegetationKind.GrassTuft or VegetationKind.Moss or VegetationKind.Stone
            or VegetationKind.Flower;

    /// <summary>V110: у цветов своя дальность скрытия — иначе куртины
    /// пропадают раньше, чем трава, хотя они крупнее.</summary>
    private static float CoverHideDistance(VegetationKind k) =>
        k == VegetationKind.Flower ? VegLodFlowerHide : VegLodCoverHide;

    /// <summary>
    /// Переключение LOD чанков по расстоянию до камеры. Вызывается каждый кадр, но
    /// реальную работу делает только при СМЕНЕ уровня у конкретного чанка.
    /// </summary>
    /// <summary>
    /// Пересобрать корзины СРАЗУ И ЦЕЛИКОМ вокруг заданной точки.
    ///
    /// Нужно снимкам обхода уровня. Первые снимки показали ровно тот дефект, ради
    /// которого инструмент и заводился, только в самом инструменте: закадровая камера
    /// ставится в новую точку, а разбор экземпляров по корзинам остаётся посчитанным
    /// вокруг НАСТОЯЩЕЙ камеры игрока. Покрытия за шесть единиц от неё скрыты, и на
    /// каждом снимке земля выходила голой независимо от того, сколько травы там растёт.
    ///
    /// Обычный путь для этого не годится: он и порог смещения проверяет, и бюджет в
    /// двенадцать групп на кадр держит — после телепортации правильная картина
    /// сложилась бы через двадцать кадров, а снимок делается через два.
    /// </summary>
    public void ForceVegetationResort(Vector3 cameraPos)
    {
        for (int i = 0; i < _vegChunks.Count; i++)
            _vegChunks[i].LastSortCam = new Vector3(float.MaxValue, float.MaxValue, float.MaxValue);
        UpdateVegetationLod(cameraPos, boatMode: false, unlimited: true);
    }

    public void UpdateVegetationLod(Vector3 cameraPos, bool boatMode = false, bool unlimited = false)
    {
        if (_galleryActive || _vegChunks.Count == 0) return;

        // ПОРОГИ ПРИВЯЗАНЫ К РАЗРЕШЕНИЮ, А НЕ К МИРУ.
        //
        // Уровень детализации имеет смысл переключать тогда, когда объект занимает
        // определённое число ТОЧЕК ЭКРАНА, а не когда до него определённое число метров.
        // Порог, подобранный в окне 1080 точек по высоте, на экране вдвое выше
        // переключится вдвое раньше по видимому размеру — и дальний план поплывёт.
        // Здесь считается множитель относительно опорной конфигурации; сами константы
        // ниже подобраны именно для неё.
        float k = LodDistanceScale();
        float fullExit2  = Sq(VegLodFullExit  * k);
        float coverHide2 = Sq(VegLodCoverHide * k);
        float impostorEnter2 = Sq(VegLodImpostorEnter * k);
        // В режиме лодки полный меш не нужен: берег проплывает мимо, и кроны
        // постоянно входили бы и выходили из ближней полосы.
        if (boatMode) fullExit2 = 0f;

        // Порог пересборки. Разбор по корзинам стоит копирования буфера, поэтому он
        // делается не каждый кадр, а когда камера сместилась заметно относительно
        // ширины переходной полосы. При шаге пешей прогулки в 0.8 единицы это примерно
        // раз в три шага.
        float resort2 = Sq(VegSortStep * k);

        // Бюджет пересборок на кадр. Без него первый же кадр после телепортации
        // камеры перебрал бы все двести групп разом и дал бы заметный провал.
        int budget = unlimited ? int.MaxValue : VegSortPerFrame;

        for (int i = 0; i < _vegChunks.Count; i++)
        {
            var ch = _vegChunks[i];

            // Расстояние до БЛИЖНЕЙ точки габаритов группы.
            var near = new Vector3(
                Math.Clamp(cameraPos.X, ch.BoundsMin.X, ch.BoundsMax.X),
                Math.Clamp(cameraPos.Y, ch.BoundsMin.Y, ch.BoundsMax.Y),
                Math.Clamp(cameraPos.Z, ch.BoundsMin.Z, ch.BoundsMax.Z));
            float dNear2 = near.DistanceSquaredTo(cameraPos);

            // Группа целиком за дальней полосой: разбирать нечего, всё в импосторе
            // (или скрыто, если это покрытие). Проверка дешёвая и снимает с бюджета
            // подавляющее большинство групп.
            bool cover = IsCoverKind(ch.Kind);
            if (cover && dNear2 > Sq(CoverHideDistance(ch.Kind) * k))
            {
                if (ch.NFull + ch.NLod1 + ch.NImp != 0) SetBuckets(ch, 0, 0, 0);
                continue;
            }
            float farAll2 = Sq(MathF.Sqrt(impostorEnter2) + ChunkSpan(ch));
            if (!cover && dNear2 > farAll2 && ch.NImp == ch.Pos.Length && ch.NFull == 0)
                continue;

            if (ch.LastSortCam.DistanceSquaredTo(cameraPos) < resort2) continue;
            if (budget-- <= 0) break;

            SortChunk(ch, cameraPos, fullExit2, impostorEnter2, coverHide2, cover);
        }
    }

    /// <summary>Полудиагональ габаритов группы — на сколько её дальний край может
    /// отстоять от ближнего.</summary>
    /// <summary>
    /// Копия MultiMesh с тем же числом экземпляров и форматом, но другим мешем.
    /// Буфер не копируется: его перепишет первый же разбор по корзинам.
    /// </summary>
    private static MultiMesh CloneMultiMesh(MultiMesh src, Mesh mesh)
    {
        var mm = new MultiMesh
        {
            TransformFormat = src.TransformFormat,
            UseColors = src.UseColors,
            Mesh = mesh,
        };
        mm.InstanceCount = src.InstanceCount;
        mm.VisibleInstanceCount = 0;
        return mm;
    }

    private static float ChunkSpan(VegChunk ch) => (ch.BoundsMax - ch.BoundsMin).Length();

    /// <summary>
    /// Разложить экземпляры группы по трём корзинам и переписать буферы.
    ///
    /// Гистерезиса здесь нет намеренно: он вводился против дребезга при переключении
    /// ГРУППЫ целиком, когда одно решение меняло вид всего леса разом. Отдельный
    /// экземпляр на границе полосы переключается незаметно, а пересборка и без того
    /// ограничена смещением камеры (VegSortStep), которое работает тем же
    /// антидребезгом, только дешевле.
    /// </summary>
    private void SortChunk(VegChunk ch, Vector3 cam,
        float fullExit2, float impostorEnter2, float coverHide2, bool cover)
    {
        int n = ch.Pos.Length;
        int stride = ch.Stride;
        EnsureSortBuffers(n * stride);

        int nf = 0, nl = 0, ni = 0;
        for (int i = 0; i < n; i++)
        {
            float d2 = ch.Pos[i].DistanceSquaredTo(cam);
            int bucket;
            if (cover) bucket = d2 > Sq(CoverHideDistance(ch.Kind) * LodDistanceScale()) ? 3 : 0;
            else if (d2 > impostorEnter2) bucket = 2;
            else if (d2 > fullExit2) bucket = 1;
            else bucket = 0;

            if (bucket == 3) continue;
            int dst = bucket == 0 ? nf++ : bucket == 1 ? nl++ : ni++;
            var target = bucket == 0 ? _sortFull : bucket == 1 ? _sortLod1 : _sortImp;
            Array.Copy(ch.SrcBuffer, i * stride, target, dst * stride, stride);
        }

        WriteBucket(ch.MmFull, _sortFull, nf, stride);
        WriteBucket(ch.MmLod1, _sortLod1, nl, stride);
        WriteBucket(ch.MmImp, _sortImp, ni, stride);
        SetBuckets(ch, nf, nl, ni);
        ch.LastSortCam = cam;
    }

    private float[] _sortFull = Array.Empty<float>();
    private float[] _sortLod1 = Array.Empty<float>();
    private float[] _sortImp = Array.Empty<float>();

    private void EnsureSortBuffers(int need)
    {
        if (_sortFull.Length >= need) return;
        _sortFull = new float[need];
        _sortLod1 = new float[need];
        _sortImp = new float[need];
    }

    /// <summary>
    /// Записать корзину в MultiMesh. InstanceCount задан один раз при сборке по полному
    /// числу экземпляров; меняется только VisibleInstanceCount — это дешевле, чем
    /// пересоздавать буфер, и не вызывает перевыделения памяти на стороне движка.
    /// </summary>
    private static void WriteBucket(MultiMesh mm, float[] src, int count, int stride)
    {
        if (count == 0) { mm.VisibleInstanceCount = 0; return; }
        var buf = mm.Buffer;
        Array.Copy(src, 0, buf, 0, count * stride);
        mm.Buffer = buf;
        mm.VisibleInstanceCount = count;
    }

    private static void SetBuckets(VegChunk ch, int nf, int nl, int ni)
    {
        ch.NFull = nf; ch.NLod1 = nl; ch.NImp = ni;
        // Пустой узел выключается: невидимый MultiMesh не попадает в отрисовку вовсе,
        // и именно это удерживает число вызовов на прежнем уровне.
        if (ch.NodeFull.Visible != nf > 0) ch.NodeFull.Visible = nf > 0;
        if (ch.NodeLod1.Visible != nl > 0) ch.NodeLod1.Visible = nl > 0;
        if (ch.NodeImp.Visible != ni > 0) ch.NodeImp.Visible = ni > 0;
        if (nf == 0) ch.MmFull.VisibleInstanceCount = 0;
        if (nl == 0) ch.MmLod1.VisibleInstanceCount = 0;
        if (ni == 0) ch.MmImp.VisibleInstanceCount = 0;
    }

    /// <summary>
    /// Сводка LOD растительности для HUD/логов нагрузки.
    /// full / lod1 / hidden — число MultiMesh-чанков в каждом состоянии;
    /// instances* — сумма InstanceCount по видимым (full+lod1) и скрытым чанкам.
    /// </summary>

    /// <summary>
    /// Включить или выключить отладочную заливку импосторов сплошным цветом.
    /// Разделяет две неразличимые по пустому экрану причины: «карточка не доходит»
    /// и «карточка есть, но полностью отбрасывается по альфе».
    /// </summary>
    public bool ToggleImpostorDebug()
    {
        _impostorDebugSolid = !_impostorDebugSolid;
        foreach (var kv in _impostorAtlases)
            if (kv.Value.Material is ShaderMaterial sm)
                sm.SetShaderParameter("debug_solid", _impostorDebugSolid);
        return _impostorDebugSolid;
    }

    private bool _impostorDebugSolid;

    /// <summary>
    /// ТЕЛЕМЕТРИЯ КАДРА.
    ///
    /// ЗАЧЕМ. В HUD до сих пор было число экземпляров по корзинам LOD, и оно ничего не
    /// говорит о том, ВИДНО ли их. Показательный случай: в радиусе скрытия покрытий
    /// оказалось 383 куртины травы, 329 подушек мха и 44 каменные группы — а на кадре
    /// земля была пуста. Спорить об этом можно бесконечно, измерить — нет.
    ///
    /// Здесь по каждому виду и корзине считается:
    ///   • сколько экземпляров попало В ПИРАМИДУ ВИДИМОСТИ (а не в радиус);
    ///   • гистограмма их экранного размера в точках: крупнее 50, 10–50, 2–10, мельче 2;
    ///   • сколько треугольников вид дал в кадре.
    ///
    /// Экранный размер считается по габаритам прототипа и масштабу экземпляра тем же
    /// соотношением, что и пороги LOD: размер / дистанция · H / (2·tan(fov/2)).
    /// Мельче двух точек — растение неразличимо, сколько бы его ни было.
    ///
    /// Отсечение по пирамиде — грубое, по описанной сфере экземпляра: цель не точный
    /// счёт, а порядок величины и ответ на вопрос «есть ли оно на экране вообще».
    /// </summary>
    public string BuildFrameTelemetryJson(Vector3 camPos, Vector3 camFwd,
                                          float fov, Vector2 vpSize, string label)
    {
        float pxPerRad = vpSize.Y / (2f * MathF.Tan(Mathf.DegToRad(fov) * 0.5f));
        // Полуугол конуса, описывающего пирамиду: по диагонали кадра, с запасом.
        float aspect = vpSize.X / MathF.Max(vpSize.Y, 1f);
        float halfDiag = MathF.Atan(MathF.Tan(Mathf.DegToRad(fov) * 0.5f) * MathF.Sqrt(1f + aspect * aspect));
        float cosCone = MathF.Cos(MathF.Min(halfDiag + 0.12f, 1.55f));

        // [вид][корзина] -> счётчики
        int kinds = Enum.GetValues(typeof(VegetationKind)).Length;
        var seen = new int[kinds, 3];
        var tris = new long[kinds, 3];
        var hist = new int[kinds, 4];      // >50, 10..50, 2..10, <2 точек
        // V109: корзины по дистанции
        var nearBand = new int[kinds, 3]; // 0:<8  1:8-16  2:>16
        float sumPxFlower = 0f; int nPxFlower = 0;
        float sumScaleFlower = 0f;


        for (int c = 0; c < _vegChunks.Count; c++)
        {
            var ch = _vegChunks[c];
            int ki = (int)ch.Kind;
            // Корзину экземпляра восстанавливаем по той же дистанции, что и разбор:
            // хранить её отдельно значило бы держать второй источник правды.
            float k = LodDistanceScale();
            float fullExit2 = Sq(VegLodFullExit * k);
            float impEnter2 = Sq(VegLodImpostorEnter * k);
            float coverHide2 = Sq(VegLodCoverHide * k);
            bool cover = IsCoverKind(ch.Kind);

            for (int i = 0; i < ch.Pos.Length; i++)
            {
                var p = ch.Pos[i];
                var d = p - camPos;
                float dist2 = d.LengthSquared();
                float dist = MathF.Sqrt(dist2);

                int bucket;
                if (cover) { if (dist2 > Sq(CoverHideDistance(ch.Kind) * k)) continue; bucket = 0; }
                else if (dist2 <= fullExit2) bucket = 0;
                else if (dist2 <= impEnter2) bucket = 1;
                else bucket = 2;

                // Грубое отсечение по конусу вокруг направления взгляда.
                float s = ch.Scales[i];
                float radius = MathF.Max(ch.ProtoRadius, ch.ProtoHeight * 0.5f) * s;
                if (dist > 0.001f)
                {
                    float cosA = d.Dot(camFwd) / dist;
                    // Запас на радиус экземпляра: близкое крупное растение видно даже
                    // когда его центр чуть за краем кадра.
                    float slack = radius / MathF.Max(dist, 0.01f);
                    if (cosA < cosCone - slack) continue;
                }

                seen[ki, bucket]++;
                tris[ki, bucket] += bucket == 0 ? ch.FullTris : bucket == 1 ? ch.Lod1Tris : ch.ImpTris;

                float px = (ch.ProtoHeight * s) / MathF.Max(dist, 0.01f) * pxPerRad;
                int hb = px > 50f ? 0 : px > 10f ? 1 : px > 2f ? 2 : 3;
                hist[ki, hb]++;

                int db = dist < 8f ? 0 : dist < 16f ? 1 : 2;
                nearBand[ki, db]++;
                if (ch.Kind == VegetationKind.Flower)
                {
                    sumPxFlower += px;
                    nPxFlower++;
                    sumScaleFlower += s;
                }
            }
        }

        // ---- ЧТО РЕАЛЬНО ВКЛЮЧЕНО НА ОТРИСОВКУ ----
        //
        // Всё выше считает, что ДОЛЖНО попасть в кадр: обход по экземплярам с
        // пирамидой видимости и полосами LOD. Ничто при этом не сверяется с тем, что
        // фактически включено в MultiMesh — а это разные вещи, и однажды они разошлись
        // полностью: телеметрия давала 494 куртины в кадре при пустой земле на снимке,
        // потому что корзины покрытий были погашены вокруг настоящей камеры игрока.
        // Три часа разбора вместо строки в отчёте.
        //
        // Поэтому рядом с «должно» пишется «включено»: суммы NFull/NLod1/NImp по
        // группам вида. Расхождение между ними — дефект инструмента, а не уровня, и
        // теперь оно видно сразу (правило в read_level_sweep.py).
        var drawn = new int[kinds, 3];
        for (int c = 0; c < _vegChunks.Count; c++)
        {
            var ch = _vegChunks[c];
            int ki = (int)ch.Kind;
            drawn[ki, 0] += ch.NFull;
            drawn[ki, 1] += ch.NLod1;
            drawn[ki, 2] += ch.NImp;
        }

        var sb = new System.Text.StringBuilder();
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        sb.Append('{');
        sb.Append("\"label\":\"").Append(label).Append("\",");
        sb.Append("\"camera\":{\"x\":").Append(camPos.X.ToString("F2", ci))
          .Append(",\"y\":").Append(camPos.Y.ToString("F2", ci))
          .Append(",\"z\":").Append(camPos.Z.ToString("F2", ci))
          .Append(",\"fwd\":[").Append(camFwd.X.ToString("F3", ci)).Append(',')
          .Append(camFwd.Y.ToString("F3", ci)).Append(',')
          .Append(camFwd.Z.ToString("F3", ci)).Append("]},");
        sb.Append("\"ground_y\":")
          .Append((TrySampleWorldY(camPos.X, camPos.Z, out float gy) ? gy : 0f).ToString("F2", ci)).Append(',');
        sb.Append("\"kinds\":{");
        bool first = true;
        long grand = 0;
        foreach (VegetationKind vk in Enum.GetValues(typeof(VegetationKind)))
        {
            int ki = (int)vk;
            int total = seen[ki, 0] + seen[ki, 1] + seen[ki, 2];
            long tt = tris[ki, 0] + tris[ki, 1] + tris[ki, 2];
            grand += tt;
            if (!first) sb.Append(',');
            first = false;
            sb.Append('"').Append(vk).Append("\":{")
              .Append("\"visible\":").Append(total)
              .Append(",\"by_lod\":{\"full\":").Append(seen[ki, 0])
              .Append(",\"lod1\":").Append(seen[ki, 1])
              .Append(",\"impostor\":").Append(seen[ki, 2]).Append('}')
              .Append(",\"tris\":").Append(tt)
              .Append(",\"screen_px\":{\"gt50\":").Append(hist[ki, 0])
              .Append(",\"10_50\":").Append(hist[ki, 1])
              .Append(",\"2_10\":").Append(hist[ki, 2])
              .Append(",\"lt2\":").Append(hist[ki, 3]).Append('}')
              .Append(",\"dist\":{\"lt8\":").Append(nearBand[ki, 0])
              .Append(",\"8_16\":").Append(nearBand[ki, 1])
              .Append(",\"gt16\":").Append(nearBand[ki, 2]).Append('}')
              // «drawn» — не расчёт, а состояние узлов на момент замера.
              .Append(",\"drawn\":{\"full\":").Append(drawn[ki, 0])
              .Append(",\"lod1\":").Append(drawn[ki, 1])
              .Append(",\"imp\":").Append(drawn[ki, 2]).Append('}')
              .Append('}');
        }
        sb.Append("},\"vegetation_tris\":").Append(grand);
        sb.Append(",\"flower_summary\":{")
          .Append("\"n\":").Append(nPxFlower)
          .Append(",\"avg_px\":").Append((nPxFlower > 0 ? sumPxFlower / nPxFlower : 0f).ToString("F1", ci))
          .Append(",\"avg_scale\":").Append((nPxFlower > 0 ? sumScaleFlower / nPxFlower : 0f).ToString("F2", ci))
          .Append(",\"proto_h\":");
        float flowerProto = 0f;
        for (int ci2 = 0; ci2 < _vegChunks.Count; ci2++)
            if (_vegChunks[ci2].Kind == VegetationKind.Flower)
            { flowerProto = _vegChunks[ci2].ProtoHeight; break; }
        sb.Append(flowerProto.ToString("F2", ci)).Append('}');

        // V127: прижим травы — gap = instanceY - terrainY (>0 парит)
        float gapSum = 0f, gapMin = float.MaxValue, gapMax = float.MinValue;
        int gapN = 0, gapFloat = 0, gapSink = 0, grassNear = 0;
        const float floatEps = 0.05f;
        const float sinkEps = -0.08f;
        for (int gi = 0; gi < _vegChunks.Count; gi++)
        {
            var ch = _vegChunks[gi];
            if (ch.Kind != VegetationKind.GrassTuft) continue;
            for (int i = 0; i < ch.Pos.Length; i++)
            {
                var gp = ch.Pos[i];
                float d = gp.DistanceTo(camPos);
                if (d > VegLodCoverHide * LodDistanceScale()) continue;
                grassNear++;
                if (!TrySampleWorldY(gp.X, gp.Z, out float terrainY)) continue;
                float gap = gp.Y - terrainY;
                gapSum += gap;
                if (gap < gapMin) gapMin = gap;
                if (gap > gapMax) gapMax = gap;
                gapN++;
                if (gap > floatEps) gapFloat++;
                if (gap < sinkEps) gapSink++;
            }
        }
        float grassDetail = 0f, grassScaleSh = 0f;
        if (_terrainMat != null)
        {
            try
            {
                grassDetail = _terrainMat.GetShaderParameter("grass_detail").AsSingle();
                grassScaleSh = _terrainMat.GetShaderParameter("grass_scale").AsSingle();
            }
            catch { /* uniform отсутствует в старом шейдере */ }
        }
        sb.Append(",\"grass_snap\":{")
          .Append("\"near\":").Append(grassNear)
          .Append(",\"sampled\":").Append(gapN)
          .Append(",\"gap_avg\":").Append(gapN > 0 ? (gapSum / gapN).ToString("F4", ci) : "0")
          .Append(",\"gap_min\":").Append(gapN > 0 ? gapMin.ToString("F4", ci) : "0")
          .Append(",\"gap_max\":").Append(gapN > 0 ? gapMax.ToString("F4", ci) : "0")
          .Append(",\"float_n\":").Append(gapFloat)
          .Append(",\"sink_n\":").Append(gapSink)
          .Append(",\"cover_hide\":").Append(VegLodCoverHide.ToString("F1", ci))
          .Append(",\"shader_detail\":").Append(grassDetail.ToString("F2", ci))
          .Append(",\"shader_scale\":").Append(grassScaleSh.ToString("F1", ci))
          .Append('}');

        sb.Append('}');
        return sb.ToString();
    }

    /// <summary>
    /// ОБХОД УРОВНЯ: телеметрия из десятков характерных точек за одно нажатие.
    ///
    /// ЗАЧЕМ ИМЕННО ТАК. Камеру двигать не требуется: замер аналитический — дистанции,
    /// корзины LOD и экранные размеры считаются из положения наблюдателя, а не из того,
    /// что успел перебрать разбор буферов. Поэтому обход мгновенный, повторяемый и не
    /// зависит от того, сколько чанков движок успел пересобрать к этому кадру.
    ///
    /// ТОЧКИ ИЩУТСЯ ПО СМЫСЛУ, А НЕ ПО КООРДИНАТАМ. Уровень процедурный, и жёсткие
    /// координаты на другом сиде укажут в пустоту. Каждая точка — регион, отобранный
    /// предикатом: глубина леса, опушка, луг вдали от леса, берег, осыпь, кустарник,
    /// тропа. Из каждой снимается четыре азимута, чтобы удачный или неудачный
    /// разворот не решал за всю точку.
    ///
    /// Наблюдатель ставится на высоте глаз пешего игрока — именно с неё и надо судить
    /// об уровне.
    /// </summary>
    /// <summary>
    /// ОБХОД ВИТРИНЫ РАСТЕНИЙ ПО ДИСТАНЦИЯМ.
    ///
    /// ЗАЧЕМ. Обход уровня показывает геймплей, но отлаживать по нему геометрию
    /// отдельного растения тяжело: в кадре тысячи экземпляров разных видов на разном
    /// удалении, и понять, какой именно уровень детализации выглядит плохо, нельзя.
    /// Витрина ставит все виды в один ряд — остаётся отснять её с нескольких дистанций,
    /// и тогда на одном наборе кадров видны ВСЕ растения во ВСЕХ уровнях сразу.
    ///
    /// Дистанции привязаны к границам полос LOD, а не к круглым числам: нужно поймать
    /// каждую полосу и переход между ними — именно на переходах и вылезают дефекты
    /// вроде прореженного меша, который вдруг стал набором плоских досок.
    /// </summary>
    public List<(Vector3 pos, Vector3 fwd, string label)> BuildGallerySweepPoses()
    {
        var result = new List<(Vector3, Vector3, string)>();
        if (!_galleryActive || _galleryRoot == null || _galleryRoot.GetChildCount() == 0)
            return result;

        // ---- V137: РАКУРСЫ ИГРОКА, А НЕ ФРОНТАЛЬНЫЙ РЯД ----
        //
        // Прошлая версия ставила камеру по центру ряда и отходила назад. На ближней
        // дистанции кадр оказался ПУСТЫМ: между растениями в шахматной сетке промежуток,
        // и объектив смотрел ровно в него.
        //
        // Правильнее снимать не ряд, а КАЖДОЕ растение с той позиции, с которой его
        // увидит игрок:
        //   дерево выше человека — взгляд прямо (ствол и низ кроны) и вверх (полог);
        //   куст ниже человека — взгляд сверху вниз, снизу его не бывает видно;
        //   мелочь под ногами — взгляд круто вниз.
        // Плюс общий план группы для сравнения растений между собой.
        float eye = PlayerEyeMetresStatic / MetresPerUnit;

        // Собираем растения витрины: положение и габариты.
        var items = new List<(Vector3 pos, float h, float r, VegetationKind kind, string name)>();
        foreach (Node c in _galleryRoot.GetChildren())
        {
            if (c is not MeshInstance3D mi || !mi.Name.ToString().StartsWith("Plant_")) continue;
            var aabb = mi.GetAabb();
            float hh = aabb.End.Y * mi.Scale.Y;
            float rr = MathF.Max(aabb.Size.X, aabb.Size.Z) * 0.5f * mi.Scale.X;
            items.Add((mi.Position, hh, rr, VegetationKind.Deciduous, mi.Name.ToString()));
        }
        if (items.Count == 0) return result;

        float minX = items.Min(t => t.pos.X - t.r), maxX = items.Max(t => t.pos.X + t.r);
        float maxTop = items.Max(t => t.pos.Y + t.h);
        float cxMid = (minX + maxX) * 0.5f;

        // Тип группы определяем по самому высокому растению: дерево, куст или мелочь.
        float tallest = items.Max(t => t.h);
        bool isTree = tallest > 1.5f;
        bool isSmall = tallest < 0.5f;

        // ---- ракурсы по одному растению ----
        // Берём три представителя: первый, средний и последний в ряду — так видно и
        // крайние породы, и середину, а кадров остаётся немного.
        // ОДНО РАСТЕНИЕ НА ШАГ. Полный перебор возрастов и качеств даёт 41 шаг; при трёх
        // растениях и трёх ракурсах это 404 снимка, то есть архив под 140 МБ. Берём
        // среднее растение группы: породы всё равно сравниваются на общем плане, а
        // ракурсы игрока нужны, чтобы увидеть КАЧЕСТВО геометрии, а не различия пород.
        var picks = new[] { items.Count / 2 };
        foreach (int idx in picks)
        {
            var it = items[idx];
            string nm = it.name.Replace("Plant_", "");

            if (isTree)
            {
                // ВПЛОТНУЮ, НАСКОЛЬКО ПУСКАЕТ ПРЕГРАДА. Радиус преграды у ствола —
                // TreeBlockerCrownFraction от радиуса кроны, но не меньше минимума;
                // ближе игрок физически подойти не может.
                float block = MathF.Max(it.r * TreeBlockerCrownFraction,
                                        TreeBlockerMinMetres / MetresPerUnit);
                float near = block * 1.15f;
                var basePos = new Vector3(it.pos.X, it.pos.Y + eye, it.pos.Z + near);

                // ---- V139: ВПЛОТНУЮ ИМЕЕТ СМЫСЛ ТОЛЬКО ВЗГЛЯД ВВЕРХ ----
                //
                // Кадр «вплотную, взгляд прямо» пришёл стволом во весь экран: преграда
                // пускает к дереву на четверть метра, и на этой дистанции прямо перед
                // глазами ничего, кроме коры, быть не может. Информации ноль.
                //
                // Осмысленны два ракурса, и оба — те, что бывают у игрока:
                //   стоя под деревом смотреть ВВЕРХ (полог, низ кроны, просветы);
                //   отойти на пару высот и смотреть прямо (силуэт целиком).
                // ---- V143: «ВЗГЛЯД ВВЕРХ» СНИМАЕТСЯ НЕ ОТ САМОГО СТВОЛА ----
                //
                // Прежний кадр ставил камеру в 0.4 локальных единицы от ствола. Геометрия:
                // при высоте дерева 10 угол до макушки оттуда 88°, а поле зрения 70° —
                // крона физически не помещается, в кадр попадает только ствол, уходящий
                // в точку схода. Именно поэтому снимок не изменился, хотя ветвей стало
                // в полтора раза больше (карточек 11 396 -> 16 576).
                //
                // Отходим на треть высоты и наклоняем взгляд умереннее: тогда в кадре
                // и ствол, и нижние ярусы кроны — то, что игрок видит, подойдя к дереву.
                float upDist = MathF.Max(it.h * 0.33f, near);
                result.Add((new Vector3(it.pos.X, it.pos.Y + eye, it.pos.Z + upDist),
                            new Vector3(0f, 0.62f, -0.78f).Normalized(),
                            $"{nm} снизу взгляд вверх"));
                // Силуэт целиком: дистанция из угла обзора, а не из множителя высоты.
                float step = it.h * 0.80f + it.r;
                result.Add((new Vector3(it.pos.X, it.pos.Y + eye, it.pos.Z + step),
                            new Vector3(0f, 0.34f, -1f).Normalized(),
                            $"{nm} силуэт с высоты глаз"));
            }
            else
            {
                // КУСТ И МЕЛОЧЬ — ТОЛЬКО СВЕРХУ. Игрок выше них, снизу он их не увидит
                // никогда; фронтальный кадр давал бы ракурс, которого в игре не бывает.
                float dist = MathF.Max(it.r * 2.2f, isSmall ? 0.35f : 1.2f);
                var pos = new Vector3(it.pos.X, it.pos.Y + eye, it.pos.Z + dist);
                float down = isSmall ? -0.75f : -0.45f;
                result.Add((pos, new Vector3(0f, down, -1f).Normalized(),
                            $"{nm} взгляд игрока сверху"));
            }
        }

        // ---- общий план группы ----
        //
        // V139: охват считается по ОБЕИМ сторонам, а не только по ширине. Прежний
        // расчёт брал горизонталь, и при двух рядах верхний ряд уходил за кадр —
        // на снимке оставались подпись и одно дерево в углу. Берётся максимум из
        // требуемых дистанций, плюс камера наводится в середину габарита по высоте.
        float aspect = 16f / 9f;
        float halfV = Mathf.DegToRad(70f) * 0.5f;
        float halfH = MathF.Atan(MathF.Tan(halfV) * aspect);
        float minBottom = items.Min(t => t.pos.Y);
        float fitH = (maxX - minX) * 0.5f / MathF.Max(MathF.Tan(halfH), 0.01f);
        float fitV = (maxTop - minBottom) * 0.5f / MathF.Max(MathF.Tan(halfV), 0.01f);
        float fit = MathF.Max(fitH, fitV) * 1.20f;
        float midY = (minBottom + maxTop) * 0.5f;
        result.Add((new Vector3(cxMid, midY, fit), new Vector3(0f, 0f, -1f), "весь ряд"));
        return result;
    }


    /// <summary>
    /// Позы обхода: точка, направление и подпись. Один источник и для телеметрии, и
    /// для снимков — иначе числа и картинки описывали бы разные места.
    /// </summary>
    /// <summary>
    /// ПОЗЫ ОБХОДА ДЛЯ ПРОВЕРКИ РЕЛЬЕФА.
    ///
    /// Обычные позы строятся по маршрутам старого генератора — по руслу и тропе,
    /// которых в этом режиме нет. Здесь камера идёт по прямой через всю область на
    /// высоте глаз над рельефом и смотрит вперёд, вбок и назад: три взгляда на
    /// точку, как в обходе уровня.
    ///
    /// Высота берётся из той же функции, что строит рельеф, поэтому камера не
    /// проваливается и не висит.
    /// </summary>
    /// <summary>
    /// ПОЗЫ ДЛЯ СВЕРКИ С ЧИСЛАМИ СТЕНДА.
    ///
    /// ---- ЗАЧЕМ ИМЕННО ТАК ----
    ///
    /// Стенд меряет кадры по восьми направлениям с высоты глаз из ТОЧКИ СТАРТА и
    /// даёт числа: долю неба, слои глубины, число пятен раскраски. Сверять их не
    /// с чем, если снимки делаются в других местах и под другими углами.
    ///
    /// Поэтому позы ровно те же:
    ///   • точка старта, высота глаз, восемь направлений через 45°;
    ///   • та же точка с высоты шара — четыре направления;
    ///   • обзорная камера — один кадр для общего вида.
    ///
    /// Прежняя редакция шла по косой линии через ближнее кольцо и брала высоту у
    /// СТАРОЙ шумовой функции LayeredHeight — то есть снимала не там, где стоит
    /// игрок, и не на той высоте.
    /// </summary>
    /// <summary>
    /// ПОЗЫ ОБХОДА: весь уровень и виды с земли.
    ///
    /// ---- ЧТО ИЗМЕНИЛОСЬ ----
    ///
    /// Прежде снимались только виды из точки старта, и пользователь справедливо
    /// заметил, что видит лишь ЧАСТЬ уровня. Территория 57.6 км, а обзорная
    /// камера с удаления 2.2 км показывает от силы пятую часть.
    ///
    /// Добавлены общие виды сверху. Высота считается из угла обзора: чтобы в
    /// кадр вошли 57.6 км при обзоре 75°, нужно около 37 км над рельефом —
    /// вершины у нас 3.5 км, так что камера заведомо снаружи.
    /// </summary>
    private List<(Vector3 pos, Vector3 fwd, string label)> BuildTerrainPreviewPoses()
    {
        // ---- ВЫСОТА ЗЕМЛИ ДЛЯ КАМЕРЫ ----
        //
        // SampleWorldY при неудаче возвращает НОЛЬ, и камера уходит под рельеф:
        // снимки получались снизу, из-под уровня. Пользователь это заметил.
        //
        // Здесь высота берётся прямо у фона — он к этому времени построен, и
        // отказа быть не может.
        static float GroundY(float wx, float wz)
            => FarBackground.SampleHeightStatic(wx, wz) + FarBackground.LiftStatic;

        var result = new List<(Vector3, Vector3, string)>();
        float ext = FarBackground.OuterExtentWorldStatic;

        // ---- 1. ВЕСЬ УРОВЕНЬ СВЕРХУ ----
        //
        // Отвесно вниз и три косых: отвесный показывает устройство территории,
        // косые — рельеф, потому что при взгляде строго вниз горы не читаются.
        {
            // Высота из угла обзора: чтобы сторона ext вошла в кадр при обзоре
            // 75°, нужна высота ext / 2 / tg(37.5°) = ext * 0.652. Берём с
            // запасом 0.70, иначе края срезаются перспективой.
            // ---- ВЫСОТА ОБЗОРА ----
            //
            // Было 0.70 охвата. При уровне 115 км это давало разумный кадр, но
            // при 231 км камера уходила на 160 километров, и уровень занимал
            // ПОЛОВИНУ КАДРА: журнал показал «ПУСТОТЫ 50%».
            //
            // Верная высота выводится из угла обзора: чтобы уровень занял
            // кадр целиком, нужно ext / (2 · tg(половина угла)).
            //
            // При обычных семидесяти пяти градусах это около 0.65 охвата, но
            // угол берётся из самой камеры, а не назначается.
            float fovDeg = GetViewport()?.GetCamera3D()?.Fov ?? 75f;
            float top = ext * 0.5f / Mathf.Tan(Mathf.DegToRad(fovDeg * 0.5f));
            result.Add((new Vector3(0, top, 0), new Vector3(0, -1, 0.001f).Normalized(),
                "весь уровень сверху"));

            for (int a = 0; a < 3; a++)
            {
                float yaw = a * Mathf.Pi * 2f / 3f;
                float pitch = Mathf.DegToRad(38f);
                float dist = ext * 0.55f;
                var cam = new Vector3(
                    -Mathf.Sin(yaw) * dist * Mathf.Cos(pitch),
                    dist * Mathf.Sin(pitch),
                    -Mathf.Cos(yaw) * dist * Mathf.Cos(pitch));
                result.Add((cam, (Vector3.Zero - cam).Normalized(), $"весь уровень косо {a * 120}°"));
            }
        }

        // ---- 2. ЧЕТВЕРТИ ТЕРРИТОРИИ ----
        //
        // Общий вид скрадывает подробности: с 36 км ячейка в 30 м занимает
        // меньше точки экрана. Четыре вида вдвое ближе показывают, что на самом
        // деле в каждой части.
        for (int q = 0; q < 4; q++)
        {
            float qx = (q % 2 == 0 ? -1 : 1) * ext * 0.22f;
            float qz = (q < 2 ? -1 : 1) * ext * 0.22f;
            float dist = ext * 0.28f;
            float pitch = Mathf.DegToRad(35f);
            var cam = new Vector3(qx, GroundY(qx, qz) + dist * Mathf.Sin(pitch), qz - dist * Mathf.Cos(pitch));
            result.Add((cam, (new Vector3(qx, GroundY(qx, qz), qz) - cam).Normalized(),
                $"четверть {q + 1}"));
        }

        // ---- 3 и 4 УБРАНЫ ----
        //
        // Здесь стояли два цикла: восемь видов с высоты глаз из точки старта и
        // два с высоты шара. Оба считали направление и НИ ОДНОГО СНИМКА НЕ
        // ДОБАВЛЯЛИ — result.Add в них не было. Мёртвыми они были давно, а
        // FarBackground.FindStartPosition() при этом звался по-настоящему.
        //
        // Точка старта — свойство игрока, а не рельефа. В режиме оценки её
        // искать незачем.

        SessionLog.Print($"[обход] {result.Count} поз: весь уровень, четверти");
        // ---- ВИДЫ СВЕРХУ ПО ЧЕТВЕРТЯМ И ИХ ЧЕТВЕРТЯМ ----
        //
        // Прежде уровень покрывался общим видом и косыми по четвертям. Этого не
        // хватало: на общем виде подробности не видны, на косом закрыты
        // склонами.
        //
        // Здесь двадцать видов СВЕРХУ: четыре по четвертям и шестнадцать по их
        // четвертям. Координаты каждого печатаются в журнал, чтобы числа
        // сопоставлялись с местом.
        {
            float halfW = FarBackground.OuterExtentWorldStatic * 0.5f;
            // Строго вниз. Малая примесь по X нужна, чтобы движок мог задать
            // поворот кадра: при чистом (0,-1,0) он не определён. По Z примеси
            // нет — иначе уровень в кадре разворачивается ромбом.
            var down = new Vector3(0.0001f, -1f, 0f).Normalized();

            // ---- РАСЧЁТ ВЫСОТЫ ПО РАЗМЕРУ СНИМАЕМОГО ----
            //
            // Прежде я брал высоту по ПОЛОВИНЕ СТОРОНЫ УРОВНЯ для всех видов —
            // и четверть попадала в кадр вчетверо мельче нужного, клином
            // посреди неба.
            //
            // Верно: высота считается от стороны ТОГО, ЧТО СНИМАЕТСЯ. Чтобы
            // квадрат стороной `side` вошёл в кадр при обзоре 75°:
            //
            //     высота = side / 2 / tg(37.5°)
            //
            // Множитель 1.1 — малый запас, чтобы края не срезались.
            float ViewHeight(float sideWorld)
                => sideWorld * 0.5f / Mathf.Tan(Mathf.DegToRad(37.5f)) * 1.1f;

            float full = FarBackground.OuterExtentWorldStatic;

            // ---- ЧЕТВЕРТИ СВЕРХУ УБРАНЫ ----
            //
            // Четыре вида сверху по четвертям перекрыты девятью клетками: те
            // подробнее и покрывают ту же площадь. Держать оба набора — значит
            // снимать одно место дважды.
            //
            // Клетки: уровень делится на ДЕВЯТЬ частей, три на три.
            const int Grid = 3;
            for (int j2 = 0; j2 < Grid; j2++)
            for (int i2 = 0; i2 < Grid; i2++)
            {
                float cx = (-0.5f + (i2 + 0.5f) / Grid) * full;
                float cz = (-0.5f + (j2 + 0.5f) / Grid) * full;
                float g = FarBackground.SampleHeightStatic(cx, cz) + FarBackground.LiftStatic;
                result.Add((new Vector3(cx, g + ViewHeight(full / Grid), cz), down,
                            $"клетка {i2},{j2} из {Grid}x{Grid}"));
            }
        }

        // ---- СНИМКИ ОЗЁР: НЕ БОЛЕЕ ПЯТИ, САМЫЕ КРУПНЫЕ ----
        //
        // Прежде снимок делался на КАЖДОЕ озеро. Их бывало вдесятеро больше
        // обещанных полутора десятков, и обход раздувался вдвое против всего
        // остального вместе взятого.
        //
        // Мелкие озёра об устройстве уровня ничего не говорят: крупные видны и
        // на клетках, а по мелким судить о заполнении чаши всё равно нельзя.
        //
        // ВАЖНО: камера поднимается ВЫШЕ УРЕЗА ВОДЫ. Прежде она ставилась на
        // два метра над землёй и оказывалась ПОД ВОДОЙ: озеро глубиной 55 м
        // рядом с берегом даёт урез выше камеры, и снимок выходил из толщи.
        int lakeShots = 0;
        foreach (var lake in FarBackground.EnumerateLakes()
                                          .OrderByDescending(l => l.AreaKm2))
        {
            if (lakeShots++ >= 5) break;
            float g = FarBackground.SampleHeightStatic(lake.X, lake.Z)
                    + FarBackground.LiftStatic;
            // высота: вся чаша в кадре, но не ниже уреза воды
            float up = MathF.Max(lake.RadiusWorld / Mathf.Tan(Mathf.DegToRad(37.5f)),
                                 lake.SurfaceY - g + 50f / FarBackground.MetresPerUnit);
            result.Add((new Vector3(lake.X, g + up, lake.Z),
                        new Vector3(0.001f, -1f, 0.001f).Normalized(),
                        $"озеро {lake.AreaKm2:F1} км²"));
        }

        return result;
    }

    public List<(Vector3 pos, Vector3 fwd, string label)> BuildSweepPoses()
    {
        if (NewTerrainPreview) return BuildTerrainPreviewPoses();

        // V112: обход с точек игрока — река и пешая тропа.
        // Биомная «ромашка» давала кадры в склон и green%=100 на «тропе».
        var result = new List<(Vector3, Vector3, string)>();
        if (_data == null) return result;
        var regions = _data.Regions;
        float eye = PlayerEyeMetresStatic / MetresPerUnit;
        float halfWorld = _mapSize * 0.5f * WorldScale;
        float margin = halfWorld * 0.30f;

        bool TryCam(int i, out Vector3 cam, out float groundY)
        {
            cam = default; groundY = 0f;
            var r = regions[i];
            if (r.IsRiver) return false;
            if (r.Slope > 3.5f) return false;
            float wx = (r.Position.X - _mapSize * 0.5f) * WorldScale;
            float wz = (r.Position.Y - _mapSize * 0.5f) * WorldScale;
            if (MathF.Abs(wx) > halfWorld - margin || MathF.Abs(wz) > halfWorld - margin)
                return false;
            if (!TrySampleWorldY(wx, wz, out groundY)) return false;
            var wl = SampleWaterY(wx, wz);
            if (wl.HasValue && groundY < wl.Value + 0.08f) return false;
            if (IsEnclosed(wx, wz, groundY + eye)) return false;
            cam = new Vector3(wx, groundY + eye, wz);
            return true;
        }

        // Касательная по соседям того же класса (тропа / берег).
        Vector3 TangentAt(int i, Func<int, bool> same)
        {
            var r = regions[i];
            float wx = (r.Position.X - _mapSize * 0.5f) * WorldScale;
            float wz = (r.Position.Y - _mapSize * 0.5f) * WorldScale;
            float sx = 0f, sz = 0f; int n = 0;
            foreach (int j in r.Neighbors)
            {
                if (!same(j)) continue;
                float jx = (regions[j].Position.X - _mapSize * 0.5f) * WorldScale;
                float jz = (regions[j].Position.Y - _mapSize * 0.5f) * WorldScale;
                sx += jx - wx; sz += jz - wz; n++;
            }
            if (n == 0) return new Vector3(0f, 0f, 1f);
            var t = new Vector3(sx, 0f, sz);
            return t.LengthSquared() < 1e-6f ? new Vector3(0f, 0f, 1f) : t.Normalized();
        }

        float Openness(Vector3 cam, float ang)
        {
            float dx = MathF.Sin(ang), dz = MathF.Cos(ang);
            int blocked = 0;
            foreach (float dd in OpennessProbes)
            {
                if (!TrySampleWorldY(cam.X + dx * dd, cam.Z + dz * dd, out float h))
                    continue;
                if (h > cam.Y + 0.5f) blocked++;
            }
            return -blocked;
        }

        void AddAlong(Vector3 cam, Vector3 tangent, string tag, int idx)
        {
            // вдоль пути вперёд / назад
            var dirs = new[] { tangent, -tangent };
            for (int d = 0; d < dirs.Length; d++)
            {
                var flat = new Vector3(dirs[d].X, 0f, dirs[d].Z);
                if (flat.LengthSquared() < 1e-6f) flat = new Vector3(0f, 0f, 1f);
                flat = flat.Normalized();
                float ang = MathF.Atan2(flat.X, flat.Z);
                // если вдоль пути упираемся в стену — слегка повернём к более открытому
                float bestAng = ang; float best = Openness(cam, ang);
                for (int k = -2; k <= 2; k++)
                {
                    if (k == 0) continue;
                    float a = ang + k * 0.18f;
                    float o = Openness(cam, a);
                    if (o > best) { best = o; bestAng = a; }
                }
                var fwd = new Vector3(MathF.Sin(bestAng), -0.10f, MathF.Cos(bestAng)).Normalized();
                int deg = (int)MathF.Round(Mathf.RadToDeg(bestAng));
                deg = ((deg % 360) + 360) % 360;
                string way = d == 0 ? "вперёд" : "назад";
                result.Add((cam, fwd, $"{tag} {idx}, {way} {deg}°"));
            }
            // под ноги — проверка грунта/колеи
            var down = new Vector3(tangent.X, 0f, tangent.Z);
            if (down.LengthSquared() < 1e-6f) down = new Vector3(0f, 0f, 1f);
            down = down.Normalized();
            var lookDown = new Vector3(down.X * 0.35f, -0.55f, down.Z * 0.35f).Normalized();
            result.Add((cam, lookDown, $"{tag} {idx}, под ноги"));
            // боковой открытый вид
            float side0 = MathF.Atan2(tangent.X, tangent.Z) + MathF.PI * 0.5f;
            float sideBest = side0; float sideOpen = Openness(cam, side0);
            float side1 = side0 + MathF.PI;
            if (Openness(cam, side1) > sideOpen) { sideBest = side1; }
            var sideFwd = new Vector3(MathF.Sin(sideBest), -0.12f, MathF.Cos(sideBest)).Normalized();
            int sideDeg = (int)MathF.Round(Mathf.RadToDeg(sideBest));
            sideDeg = ((sideDeg % 360) + 360) % 360;
            result.Add((cam, sideFwd, $"{tag} {idx}, бок {sideDeg}°"));
        }

        List<int> PickSpread(Func<int, bool> pred, int want, float minSep)
        {
            var cand = new List<(int i, Vector3 cam)>();
            for (int i = 0; i < regions.Count; i++)
            {
                if (!pred(i)) continue;
                if (!TryCam(i, out var cam, out _)) continue;
                cand.Add((i, cam));
            }
            var chosen = new List<int>();
            if (cand.Count == 0) return chosen;
            // чуть предпочитаем центр карты
            cand.Sort((a, b) =>
            {
                float da = a.cam.X * a.cam.X + a.cam.Z * a.cam.Z;
                float db = b.cam.X * b.cam.X + b.cam.Z * b.cam.Z;
                return da.CompareTo(db);
            });
            float sep = minSep;
            for (int pass = 0; pass < 3 && chosen.Count < want; pass++)
            {
                foreach (var (i, cam) in cand)
                {
                    if (chosen.Count >= want) break;
                    bool ok = true;
                    foreach (int j in chosen)
                    {
                        if (!TryCam(j, out var c2, out _)) continue;
                        if ((cam - c2).LengthSquared() < sep * sep) { ok = false; break; }
                    }
                    if (ok) chosen.Add(i);
                }
                sep *= 0.55f;
            }
            return chosen;
        }

        // V120: только два игровых режима — пешая тропа и сплав по реке.
        // Высота камеры = как у игрока (1.70 м / 1.35 м в лодке).

        // ---- 1) ПЕШАЯ ПРОГУЛКА (IsWalkPath, глаза 1.70 м) ----
        var trailPts = PickSpread(i => regions[i].IsWalkPath, 10, halfWorld * 0.14f);
        for (int t = 0; t < trailPts.Count; t++)
        {
            int i = trailPts[t];
            if (!TryCam(i, out var cam, out _)) continue;
            var tan = TangentAt(i, j => regions[j].IsWalkPath);
            AddAlong(cam, tan, "прогулка", t + 1);
        }

        // ---- 2) СПЛАВ (на воде, глаза лодки 1.35 м) ----
        float boatEye = 1.35f / MetresPerUnit;
        bool TryCamBoat(int i, out Vector3 cam)
        {
            cam = default;
            var r = regions[i];
            if (!r.IsRiver) return false;
            float wx = (r.Position.X - _mapSize * 0.5f) * WorldScale;
            float wz = (r.Position.Y - _mapSize * 0.5f) * WorldScale;
            // V121: сплав ближе к краю карты, чем пеший margin
            float boatMargin = halfWorld * 0.12f;
            if (MathF.Abs(wx) > halfWorld - boatMargin || MathF.Abs(wz) > halfWorld - boatMargin)
                return false;
            if (!TrySampleWorldY(wx, wz, out float bedY)) return false;
            var wl = SampleWaterY(wx, wz);
            float surface = wl ?? bedY;
            cam = new Vector3(wx, surface + boatEye, wz);
            return true;
        }

        var riverPts = PickSpread(i => regions[i].IsRiver, 10, halfWorld * 0.12f);
        for (int t = 0; t < riverPts.Count; t++)
        {
            int i = riverPts[t];
            if (!TryCamBoat(i, out var cam)) continue;
            var tan = TangentAt(i, j => regions[j].IsRiver);
            // сплав: вперёд/назад по течению, взгляд на берег (бок), без «под ноги» в воду
            var dirs = new[] { tan, -tan };
            for (int d = 0; d < dirs.Length; d++)
            {
                var flat = new Vector3(dirs[d].X, 0f, dirs[d].Z);
                if (flat.LengthSquared() < 1e-6f) flat = new Vector3(0f, 0f, 1f);
                flat = flat.Normalized();
                float ang = MathF.Atan2(flat.X, flat.Z);
                var fwd = new Vector3(MathF.Sin(ang), -0.06f, MathF.Cos(ang)).Normalized();
                int deg = (int)MathF.Round(Mathf.RadToDeg(ang));
                deg = ((deg % 360) + 360) % 360;
                string way = d == 0 ? "вперёд" : "назад";
                result.Add((cam, fwd, $"сплав {t + 1}, {way} {deg}°"));
            }
            float side0 = MathF.Atan2(tan.X, tan.Z) + MathF.PI * 0.5f;
            float sideBest = side0;
            if (Openness(cam, side0 + MathF.PI) > Openness(cam, side0))
                sideBest = side0 + MathF.PI;
            var sideFwd = new Vector3(MathF.Sin(sideBest), -0.08f, MathF.Cos(sideBest)).Normalized();
            int sideDeg = (int)MathF.Round(Mathf.RadToDeg(sideBest));
            sideDeg = ((sideDeg % 360) + 360) % 360;
            result.Add((cam, sideFwd, $"сплав {t + 1}, берег {sideDeg}°"));
        }

        return result;
    }

    /// <summary>Телеметрия по позам обхода витрины.</summary>
    public string BuildGallerySweepJson(float fov, Vector2 vpSize)
        => BuildSweepJson(BuildGallerySweepPoses(), fov, vpSize);

    /// <summary>Телеметрия по всем позам обхода одним файлом.</summary>
    public string BuildLevelSweepJson(float fov, Vector2 vpSize)
        => BuildSweepJson(BuildSweepPoses(), fov, vpSize);

    private string BuildSweepJson(List<(Vector3 pos, Vector3 fwd, string label)> poses,
                                  float fov, Vector2 vpSize)
    {
        if (poses.Count == 0) return "{\"error\":\"уровень не построен\"}";
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        var sb = new System.Text.StringBuilder();
        sb.Append("{\"stamp\":\"").Append(BuildStamp).Append("\",");
        sb.Append("\"time\":\"").Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")).Append("\",");
        sb.Append("\"viewport\":{\"w\":").Append((int)vpSize.X).Append(",\"h\":").Append((int)vpSize.Y)
          .Append(",\"fov\":").Append(fov.ToString("F1", ci)).Append("},");
        sb.Append("\"bands\":{\"full_exit\":").Append(VegLodFullExit.ToString("F1", ci))
          .Append(",\"impostor_enter\":").Append(VegLodImpostorEnter.ToString("F1", ci))
          .Append(",\"cover_hide\":").Append(VegLodCoverHide.ToString("F1", ci))
          .Append(",\"flower_hide\":").Append(VegLodFlowerHide.ToString("F1", ci))
          .Append(",\"scale\":").Append(LodDistanceScale().ToString("F2", ci)).Append("},");
        sb.Append("\"plants\":").Append(BuildPlantPoolJson()).Append(',');
        sb.Append("\"views\":[");
        for (int i = 0; i < poses.Count; i++)
        {
            if (i > 0) sb.Append(',');
            // КОРЗИНЫ ПЕРЕСОБИРАЮТСЯ ПОД КАЖДУЮ ПОЗУ — так же, как перед снимком.
            //
            // Без этого «drawn» описывал бы одно и то же состояние (вокруг настоящей
            // камеры) для всех сорока видов, то есть был бы бесполезен именно там, где
            // нужен. Заявленный принцип обхода — числа и картинки описывают одно и то
            // же место; расстановка по корзинам входит в это «одно и то же».
            //
            // Вызывающая сторона обязана вернуть корзины к настоящей камере после
            // построения телеметрии (GameBootstrap делает это сразу за записью файла).
            ForceVegetationResort(poses[i].pos);
            sb.Append(BuildFrameTelemetryJson(poses[i].pos, poses[i].fwd, fov, vpSize, poses[i].label));
        }
        sb.Append("],\"views_count\":").Append(poses.Count).Append('}');
        return sb.ToString();
    }

    /// <summary>
    /// ЧЕМ ЗАСАЖЕН УРОВЕНЬ НА МОМЕНТ ЗАМЕРА.
    ///
    /// Обход до сих пор отвечал только на вопрос «что попало в кадр». Чем это «что»
    /// является — каким возрастом, каким качеством, каким видом собран каждый
    /// вариант — в логе уровня не было ни разу, хотя ровно это дважды и оказывалось
    /// причиной: витрина показывала всходы (V134), а после захода в неё всходами
    /// становился и лес (см. PlantCatalog.IsGamePool). Диагностировать это
    /// приходилось по скриншотам, хотя достаточно одной строки в файле.
    ///
    /// Здесь два источника сведены вместе:
    ///   • каталог — возраст, качество, вид, размеры прототипа;
    ///   • расстановка — сколько экземпляров этого варианта реально стоит на уровне
    ///     и какого они РОСТА В МИРЕ (прототип домножен на масштаб экземпляра).
    /// Второе важно не меньше первого: прототип может быть верным, а на уровне
    /// стоять втрое мельче — таблицу «в игре / натура» из handover иначе не
    /// перепроверить, её приходилось собирать руками.
    /// </summary>
    private string BuildPlantPoolJson()
    {
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        var sb = new System.Text.StringBuilder();
        sb.Append('{');
        sb.Append("\"game_pool\":").Append(PlantCatalog.IsGamePool ? "true" : "false");
        sb.Append(",\"age_range\":[").Append(PlantGenerator.GameAgeMin).Append(',')
          .Append(PlantGenerator.GameAgeMax).Append(']');
        sb.Append(",\"q_target\":").Append(PlantGenerator.GameQEffTarget);
        sb.Append(",\"foliage_detail\":\"").Append(PlantGenerator.Detail.ToString()).Append('"');
        sb.Append(",\"baked_impostors\":").Append(_impostorAtlases.Count);
        sb.Append(",\"kinds\":{");

        if (!PlantCatalog.IsInitialized)
        {
            sb.Append("},\"error\":\"каталог не собран\"}");
            return sb.ToString();
        }

        bool firstKind = true;
        foreach (VegetationKind vk in Enum.GetValues(typeof(VegetationKind)))
        {
            int variants = PlantCatalog.Instance.VariantCount(vk);
            if (variants == 0) continue;
            if (!firstKind) sb.Append(',');
            firstKind = false;
            sb.Append('"').Append(vk).Append("\":[");
            for (int v = 0; v < variants; v++)
            {
                if (v > 0) sb.Append(',');
                var build = PlantCatalog.Instance.GetBuild(vk, v);
                var genome = PlantCatalog.Instance.GetGenome(vk, v);
                string species = PlantSpecies.Get(vk, genome.Species).Name;

                // Расстановка: сколько таких стоит и какого они роста в мире.
                int inst = 0;
                float hMin = float.MaxValue, hMax = 0f, hSum = 0f;
                long tris = 0;
                for (int c = 0; c < _vegChunks.Count; c++)
                {
                    var ch = _vegChunks[c];
                    if (ch.Kind != vk || ch.Variant != v) continue;
                    tris = ch.FullTris;
                    for (int i = 0; i < ch.Scales.Length; i++)
                    {
                        float wh = ch.ProtoHeight * ch.Scales[i];
                        if (wh < hMin) hMin = wh;
                        if (wh > hMax) hMax = wh;
                        hSum += wh;
                        inst++;
                    }
                }
                float hAvg = inst > 0 ? hSum / inst : 0f;
                if (inst == 0) hMin = 0f;

                sb.Append("{\"v\":").Append(v)
                  .Append(",\"species\":\"").Append(species).Append('"')
                  .Append(",\"age\":").Append(build.Age)
                  .Append(",\"quality\":").Append(build.Quality)
                  .Append(",\"mesh_ready\":").Append(build.MeshReady ? "true" : "false")
                  .Append(",\"height_mul\":").Append(genome.HeightMul.ToString("F2", ci))
                  .Append(",\"instances\":").Append(inst)
                  .Append(",\"tris\":").Append(tris)
                  // Рост в МЕТРАХ — в тех же единицах, что справочные значения,
                  // чтобы сверка с натурой не требовала пересчёта в уме.
                  .Append(",\"h_m\":{\"min\":").Append((hMin * MetresPerUnit).ToString("F2", ci))
                  .Append(",\"avg\":").Append((hAvg * MetresPerUnit).ToString("F2", ci))
                  .Append(",\"max\":").Append((hMax * MetresPerUnit).ToString("F2", ci))
                  .Append("}}");
            }
            sb.Append(']');
        }
        sb.Append("}}");
        return sb.ToString();
    }

    /// <summary>
    /// ПОРОГ СЫПИ ПО ТИПУ РАСТЕНИЯ.
    ///
    /// Общий порог 20% помечал ель и сосну (20-21%) и пропускал лиственные (13-19%),
    /// то есть резал распределение ровно посередине. Проверил по шаблону, прежде чем
    /// трогать число: у хвойных при 20.1-20.9% сыпи чёрных клякс на шаблоне 0.00-0.06%
    /// кадра, крапин ноль, крона читается формой. Значит на шаблон эта сыпь не
    /// выходит, и порог просто стоит не там.
    ///
    /// Причина различия геометрическая: хвойная лапа — вытянутый клин, и просветы
    /// между наложенными лапами получаются узкими полосами; лиственный пучок круглый,
    /// и просветы между пучками круглее и крупнее. Одна и та же доля площади означает
    /// у них разное.
    ///
    /// ОГОВОРКА. Поднимать норму сразу после того, как замер лёг чуть выше неё, —
    /// приём опасный, и я к нему уже прибегал (сыпь с 12% до 20% в V154). Поэтому
    /// здесь порог не подгоняется к числу, а ставится по шаблону: 26% — это заметный
    /// запас над нынешними 21%, но всё ещё ниже 29%, при которых лиственные в V154
    /// давали видимые кляксы.
    /// </summary>
    private static float SpeckleLimit(VegetationKind kind) => kind switch
    {
        VegetationKind.Fir or VegetationKind.Pine => 0.26f,   // вытянутые лапы
        VegetationKind.Reed => 0.18f,                          // стебли, просветов быть не должно
        _ => 0.20f
    };

    /// <summary>Удаления, на которых щупается рельеф при оценке открытости
    /// направления. Статическое поле, а не stackalloc в цикле: последний копил бы
    /// кадр стека на каждой итерации (CA2014).</summary>
    private static readonly float[] OpennessProbes = { 3f, 8f, 15f, 25f };

    /// <summary>
    /// Заперта ли точка рельефом. Проверяются четыре стороны на двух удалениях:
    /// если ВЕЗДЕ земля выше глаз, наблюдатель в яме или в толще склона.
    /// Порог по числу закрытых направлений, а не по всем сразу: в узком ущелье три
    /// стороны из четырёх выше глаз — это нормальное место, а не яма.
    /// </summary>
    private bool IsEnclosed(float wx, float wz, float eyeY)
    {
        int blocked = 0;
        Span<float> offs = stackalloc float[] { 1.5f, 4.0f };
        for (int dir = 0; dir < 4; dir++)
        {
            float dx = dir == 0 ? 1f : dir == 1 ? -1f : 0f;
            float dz = dir == 2 ? 1f : dir == 3 ? -1f : 0f;
            bool wall = true;
            foreach (float o in offs)
            {
                if (!TrySampleWorldY(wx + dx * o, wz + dz * o, out float h)) { wall = false; break; }
                if (h < eyeY + 0.4f) { wall = false; break; }
            }
            if (wall) blocked++;
        }
        return blocked >= 4;
    }

    /// <summary>Высота глаз в метрах — та же, что в GameBootstrap. Держится здесь,
    /// чтобы обход уровня не зависел от загрузчика.</summary>
    public const float PlayerEyeMetresStatic = 1.70f;

    /// <summary>Штамп сборки — чтобы по файлу телеметрии было видно, к какой версии
    /// он относится. Дублировать строку из GameBootstrap не нужно: она приходит сюда.</summary>
    public static string BuildStamp = "неизвестно";


    public void GetVegetationLodStats(
        out int chunks, out int full, out int lod1, out int hidden,
        out int instVisible, out int instHidden, out int imp)
    {
        chunks = _vegChunks.Count;
        full = lod1 = hidden = imp = 0;
        instVisible = instHidden = 0;
        // После перехода на LOD по экземпляру группа больше не имеет одного уровня:
        // в ней одновременно бывают и полный меш, и импостор. Поэтому счётчики f/l1/imp
        // теперь считают ЭКЗЕМПЛЯРЫ по корзинам, а не группы — так по HUD видно
        // фактическую раскладку, а не число узлов.
        for (int i = 0; i < _vegChunks.Count; i++)
        {
            var ch = _vegChunks[i];
            int n = ch.Pos.Length;
            full += ch.NFull;
            lod1 += ch.NLod1;
            imp += ch.NImp;
            int shown = ch.NFull + ch.NLod1 + ch.NImp;
            hidden += n - shown;
            instVisible += shown;
            instHidden += n - shown;
        }
    }


    /// <summary>
    /// Упрощённый меш растения для дальних чанков — ПРОРЕЖИВАНИЕ настоящих карточек.
    ///
    /// История двух неудачных попыток (обе провалились на экране, не в цифрах):
    ///  1. Один крест из двух больших карточек, 4 треугольника. Читался как зелёная
    ///     «плита» во весь габарит кроны — у дерева издалека рыхлый силуэт, а не заливка.
    ///  2. Кластеризация по регулярной сетке 3x4x3, ~120 треугольников. Карточки
    ///     выстроились в ряды и столбцы ОДИНАКОВОГО размера и ОДИНАКОВОЙ ориентации,
    ///     из-за чего дальние деревья выглядели как тёмно-зелёные полосатые коробки.
    ///
    /// Общая ошибка обеих: я строил НОВУЮ геометрию вместо того, чтобы взять настоящую.
    /// И целился в 120 треугольников, хотя бюджет это не требовал: деревьев на уровне
    /// всего 581, при 1500 треугольниках на дальнее дерево они стоят 871 тыс. против
    /// 23.7 млн у полных мешей — выигрыш в 27 раз и без потери формы.
    ///
    /// Здесь берутся РЕАЛЬНЫЕ карточки исходного меша, но каждая N-я, и слегка
    /// увеличиваются вокруг своего центра, чтобы крона не поредела. Ориентация, положение,
    /// цвет и UV остаются авторскими — поэтому нет ни решётки, ни полос, ни плит:
    /// это то же самое дерево, просто прорежённое.
    ///
    /// Локальная высота СОВПАДАЕТ с полным мешем — иначе экземпляры меняли бы размер в
    /// момент переключения LOD, потому что масштаб уже посчитан от LocalHeight.
    /// </summary>
    /// <summary>
    /// ИМПОСТОР — самый дальний уровень детализации: две скрещённые карточки.
    ///
    /// ЗАЧЕМ. Замер стоимости показал потолок прежней схемы: дальний уровень (Lod1) —
    /// это прорежённые карточки, 1330 треугольников на дерево (Fir 40504 -> 1326).
    /// Для сомкнутого полога нужно около 20 000 деревьев на чанк, что дало бы
    /// 26 млн треугольников. Импостор стоит 4 треугольника, то есть в 330 раз меньше,
    /// и именно он снимает ограничение на плотность.
    ///
    /// Строится по габаритам растения: высота и ширина кроны берутся из самого меша,
    /// цвет — среднее по вершинам листвы, чтобы пятно на расстоянии совпадало по тону
    /// с полной моделью и переход не бросался в глаза.
    /// </summary>
    private static ArrayMesh BuildImpostorMesh(PlantMeshData data)
    {
        int vc = data.Positions.Count / 3;
        if (vc == 0) return ToArrayMesh(data);

        float minX = float.MaxValue, maxX = float.MinValue;
        float minY = float.MaxValue, maxY = float.MinValue;
        float minZ = float.MaxValue, maxZ = float.MinValue;
        double cr = 0, cg = 0, cb = 0; int cn = 0;

        for (int v = 0; v < vc; v++)
        {
            float px = data.Positions[v * 3];
            float py = data.Positions[v * 3 + 1];
            float pz = data.Positions[v * 3 + 2];
            if (px < minX) minX = px; if (px > maxX) maxX = px;
            if (py < minY) minY = py; if (py > maxY) maxY = py;
            if (pz < minZ) minZ = pz; if (pz > maxZ) maxZ = pz;

            // Листва отличается от древесины UV-ячейкой атласа.
            bool leaf = data.UVs.Count >= (v + 1) * 2
                && FoliageAtlas.IsFoliageUv(data.UVs[v * 2], data.UVs[v * 2 + 1]);
            if (!leaf) continue;
            cr += data.Colors[v * 4];
            cg += data.Colors[v * 4 + 1];
            cb += data.Colors[v * 4 + 2];
            cn++;
        }
        if (cn == 0) return BuildLodMesh(data);

        var col = new Color((float)(cr / cn), (float)(cg / cn), (float)(cb / cn), 1f);
        float h = MathF.Max(maxY - minY, 1e-3f);
        float wHalf = MathF.Max(MathF.Max(maxX - minX, maxZ - minZ) * 0.5f, h * 0.18f);
        float cx = (minX + maxX) * 0.5f, cz = (minZ + maxZ) * 0.5f;

        // Крона занимает верхнюю часть; низ карточки опускаем к подножию, чтобы
        // импостор не «висел» над землёй.
        float y0 = minY, y1 = minY + h;

        var verts = new List<Vector3>(8);
        var cols = new List<Color>(8);
        var uvs = new List<Vector2>(8);
        var idx = new List<int>(12);

        void Quad(float ax, float az, float bx, float bz)
        {
            int b0 = verts.Count;
            verts.Add(new Vector3(cx + ax, y0, cz + az));
            verts.Add(new Vector3(cx + bx, y0, cz + bz));
            verts.Add(new Vector3(cx + bx, y1, cz + bz));
            verts.Add(new Vector3(cx + ax, y1, cz + az));
            for (int k = 0; k < 4; k++) cols.Add(col);
            // UV берём из ячейки листа: материал листвы режет по альфе, и сплошная
            // ячейка дала бы прямоугольник вместо силуэта кроны.
            var uv = FoliageAtlas.LeafA;
            uvs.Add(new Vector2(uv.uMin, uv.vMax));
            uvs.Add(new Vector2(uv.uMax, uv.vMax));
            uvs.Add(new Vector2(uv.uMax, uv.vMin));
            uvs.Add(new Vector2(uv.uMin, uv.vMin));
            idx.Add(b0); idx.Add(b0 + 1); idx.Add(b0 + 2);
            idx.Add(b0); idx.Add(b0 + 2); idx.Add(b0 + 3);
        }

        Quad(-wHalf, 0f, wHalf, 0f);
        Quad(0f, -wHalf, 0f, wHalf);

        // Нормали и импостору: без них дальний уровень терял бы освещение и rim,
        // и переход с Lod1 на импостор был бы виден скачком яркости.
        var inorm = new Vector3[verts.Count];
        for (int t = 0; t + 2 < idx.Count; t += 3)
        {
            var n = (verts[idx[t + 1]] - verts[idx[t]])
                .Cross(verts[idx[t + 2]] - verts[idx[t]]);
            if (n.LengthSquared() < 1e-12f) continue;
            n = n.Normalized();
            inorm[idx[t]] += n; inorm[idx[t + 1]] += n; inorm[idx[t + 2]] += n;
        }
        for (int i = 0; i < inorm.Length; i++)
            inorm[i] = inorm[i].LengthSquared() > 1e-9f ? inorm[i].Normalized() : Vector3.Up;

        var arrays = new Godot.Collections.Array();
        arrays.Resize((int)Mesh.ArrayType.Max);
        arrays[(int)Mesh.ArrayType.Vertex] = verts.ToArray();
        arrays[(int)Mesh.ArrayType.Normal] = inorm;
        arrays[(int)Mesh.ArrayType.Color] = cols.ToArray();
        arrays[(int)Mesh.ArrayType.TexUV] = uvs.ToArray();
        arrays[(int)Mesh.ArrayType.Index] = idx.ToArray();
        var m = new ArrayMesh();
        m.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, arrays);
        return m;
    }

    private static ArrayMesh BuildLodMesh(PlantMeshData data)
    {
        // Меши растений собираются через AddQuad(a,b,c,d) -> индексы (a,b,c),(a,c,d),
        // поэтому индексный список идёт четвёрками вершин по 6 индексов = одна карточка.
        int idxCount = data.Indices.Count;
        int quadCount = idxCount / 6;
        if (quadCount == 0) return ToArrayMesh(data);

        // Сколько карточек листвы и древесины всего.
        //
        // Признак берётся по UV-ячейке атласа — тем же правилом, что в PlantMetrics и
        // BuildImpostorMesh. Раньше здесь стояло правило по цвету (g >= r). Замер по
        // всем видам: на деревьях оба правила совпадают полностью, но у цветка оно
        // ошибается на 92% карточек, у камыша на 85% — листва и стебель уходили в
        // противоположные корзины, и прореживание применяло к ним чужие шаги и чужую
        // компенсацию площади.
        bool hasUvAll = data.UVs.Count >= (data.Positions.Count / 3) * 2;
        int leafQuads = 0, woodQuads = 0;
        var isLeaf = new bool[quadCount];
        for (int q = 0; q < quadCount; q++)
        {
            int v = data.Indices[q * 6];
            isLeaf[q] = hasUvAll
                && FoliageAtlas.IsFoliageUv(data.UVs[v * 2], data.UVs[v * 2 + 1]);
            if (isLeaf[q]) leafQuads++; else woodQuads++;
        }

        // ПРОРЕЖИВАНИЕ И КОМПЕНСАЦИЯ ДОЛЖНЫ БЫТЬ СОГЛАСОВАНЫ.
        //
        // Если оставить каждую N-ю карточку, площадь листвы падает в N раз, поэтому
        // оставшиеся надо увеличить в sqrt(N) раз — тогда крона сохранит плотность.
        // В прошлой версии шаг брался из целевого числа карточек (для лиственного это
        // ~18), а увеличение было ограничено потолком 2.2 — компенсация выходила
        // НЕПОЛНОЙ: (2.2/sqrt(18))^2 = 27% исходного покрытия. На экране это и выглядело
        // как «фрагментированное», просвечивающее дерево.
        //
        // Теперь наоборот: потолок увеличения задан первым (карточка крупнее ~3x уже
        // читается как заплатка), а шаг ОГРАНИЧЕН так, чтобы компенсация была ТОЧНОЙ.
        // Максимум: шаг 9 -> увеличение ровно sqrt(9) = 3. Никакой потери плотности.
        // ---- V131: ПОТОЛОК ШАГА СВОДИЛ НА НЕТ ПОТОЛОК ЧИСЛА КАРТОЧЕК ----
        //
        // Замер по обходу V130: прореженный лиственный весил 1 800 треугольников, а
        // не 360, как я считал. Причина здесь: targetLeaf ограничен 120 карточками,
        // но фактический шаг зажат сверху девяткой. У дерева с восемью тысячами
        // карточек шаг 9 оставляет 889 — потолок числа карточек не работает вовсе.
        //
        // Ограничение шага вводилось из-за компенсации площади: при шаге 9 карточка
        // растёт втрое. Теперь компенсация ограничена отдельно (LodScaleCap ниже),
        // поэтому шаг можно поднять — карточек станет столько, сколько и задумано.
        const int MaxLeafStep = 26;
        const int MaxWoodStep = 10;
        // V84: потолки понижены. Расчёт бюджета: в полосе среднего уровня
        // (5-30 единиц) оказывается около 1800 экземпляров; при 245 треугольниках
        // это 440k при бюджете растительности 250k. Потолок 120 карточек листвы
        // и 60 древесины даёт около 120 треугольников на экземпляр — 218k, проходит.
        const int LeafQuadCap = 120;
        const int WoodQuadCap = 60;
        int targetLeaf = Math.Max(1, Math.Min(LeafQuadCap, leafQuads / 5));
        int targetWood = Math.Max(1, Math.Min(WoodQuadCap, woodQuads / 5));
        int leafStep = Math.Clamp(leafQuads / targetLeaf, 1, MaxLeafStep);
        int woodStep = Math.Clamp(woodQuads / targetWood, 1, MaxWoodStep);

        // КОМПЕНСАЦИЯ ПЛОЩАДИ С ПОТОЛКОМ.
        //
        // Полная компенсация (корень из шага) при шаге 26 растянула бы карточку в пять
        // раз — вернулись бы двухметровые лопухи, от которых мы только что ушли.
        // Потолок 2.2 держит карточку в пределах правдоподобия; недобор покрытия на
        // среднем уровне допустим — он работает с двадцати метров и дальше, где крона
        // и без того сливается в массу.
        const float LodScaleCap = 2.2f;
        float leafScale = MathF.Min(MathF.Sqrt(leafStep), LodScaleCap);
        float woodScale = MathF.Min(MathF.Sqrt(woodStep), LodScaleCap);

        var st = new SurfaceTool();
        st.Begin(Mesh.PrimitiveType.Triangles);
        bool hasUv = data.UVs.Count >= (data.Positions.Count / 3) * 2;

        int leafSeen = 0, woodSeen = 0;
        for (int q = 0; q < quadCount; q++)
        {
            bool leaf = isLeaf[q];
            int seen = leaf ? leafSeen++ : woodSeen++;
            int step = leaf ? leafStep : woodStep;
            if (seen % step != 0) continue;
            float scale = leaf ? leafScale : woodScale;

            // Четыре различные вершины карточки: индексы 0,1,2 и 5 в шестёрке.
            int i0 = data.Indices[q * 6];
            int i1 = data.Indices[q * 6 + 1];
            int i2 = data.Indices[q * 6 + 2];
            int i3 = data.Indices[q * 6 + 5];
            var quad = new[] { i0, i1, i2, i3 };

            // Центр карточки — вокруг него и увеличиваем.
            float cxq = 0f, cyq = 0f, czq = 0f;
            foreach (int vi in quad)
            {
                cxq += data.Positions[vi * 3];
                cyq += data.Positions[vi * 3 + 1];
                czq += data.Positions[vi * 3 + 2];
            }
            cxq *= 0.25f; cyq *= 0.25f; czq *= 0.25f;
            var centre = new Vector3(cxq, cyq, czq);

            Vector3 Scaled(int vi)
            {
                var pos = new Vector3(
                    data.Positions[vi * 3], data.Positions[vi * 3 + 1], data.Positions[vi * 3 + 2]);
                return centre + (pos - centre) * scale;
            }

            void Emit(int vi)
            {
                st.SetColor(new Color(
                    data.Colors[vi * 4], data.Colors[vi * 4 + 1],
                    data.Colors[vi * 4 + 2], data.Colors[vi * 4 + 3]));
                st.SetNormal(Vector3.Up);
                // UV обязательны: материал листвы — alpha-scissor по атласу, без них
                // координаты (0,0) попадают в прозрачную ячейку и меш исчезает целиком.
                st.SetUV(hasUv
                    ? new Vector2(data.UVs[vi * 2], data.UVs[vi * 2 + 1])
                    : new Vector2(FoliageAtlas.SolidU, FoliageAtlas.SolidV));
                st.AddVertex(Scaled(vi));
            }

            Emit(i0); Emit(i1); Emit(i2);
            Emit(i0); Emit(i2); Emit(i3);
        }

        return st.Commit();
    }

    private static (Color color, string shape) DebugVegStyle(VegetationKind kind) => kind switch
    {
        //                       цвет                              фигура
        VegetationKind.Pine      => (new Color(1.00f, 0.15f, 0.15f), "cone"),     // красный конус
        VegetationKind.Fir       => (new Color(1.00f, 0.55f, 0.00f), "cone"),     // оранжевый конус
        VegetationKind.Deciduous => (new Color(0.20f, 0.55f, 1.00f), "sphere"),   // синий шар
        VegetationKind.Bush      => (new Color(0.85f, 0.20f, 1.00f), "sphere"),   // фиолетовый шар
        VegetationKind.Flower    => (new Color(1.00f, 1.00f, 0.10f), "box"),      // жёлтый куб
        VegetationKind.Reed      => (new Color(0.10f, 1.00f, 0.85f), "box"),      // бирюзовый куб
        VegetationKind.GrassTuft => (new Color(0.55f, 1.00f, 0.30f), "cone"),     // салатовый конус
        VegetationKind.Moss      => (new Color(0.00f, 0.45f, 0.25f), "sphere"),   // тёмно-зелёный шар
        VegetationKind.Stone     => (new Color(0.85f, 0.85f, 0.90f), "box"),      // светло-серый куб
        _ => (Colors.White, "box")
    };

    private static Mesh CreateDebugPrimitive(VegetationKind kind)
    {
        var (_, shape) = DebugVegStyle(kind);
        switch (shape)
        {
            case "cone":
                // Конус = цилиндр с нулевым верхним радиусом.
                return new CylinderMesh { TopRadius = 0f, BottomRadius = 0.42f, Height = 1f, RadialSegments = 6, Rings = 1 };
            case "sphere":
                return new SphereMesh { Radius = 0.45f, Height = 0.9f, RadialSegments = 8, Rings = 4 };
            default:
                return new BoxMesh { Size = new Vector3(0.6f, 0.8f, 0.6f) };
        }
    }

    /// <summary>
    /// ВРЕМЕННО ОТКЛЮЧЕНО (запрос пользователя 31.07): на уровне оставлены только горы,
    /// долины и реки, чтобы оценивать форму рельефа без отвлечения на растительность.
    /// Вернуть — поставить true.
    /// </summary>
    // Включено обратно: вернулись к работе над растениями. Отключалось на время
    // отладки рельефа, чтобы не мешало и не тратило время генерации.
    private const bool VegetationEnabled = true;

    /// <summary>Строить ли растительность. ВЫКЛЮЧЕНО по просьбе пользователя:
    /// каждая сборка тратила на неё около минуты, а сейчас разбирается рельеф и
    /// вода. Включить обратно, когда дойдём до растительности по цепочке.</summary>
    /// ---- ВКЛЮЧЕНО ОБРАТНО ----
    ///
    /// Отключалась, чтобы не тратить минуту на сборку, пока разбирался рельеф.
    /// Рельеф разобран, растительность нужна в игре.
    /// ВЫКЛЮЧЕНА: проверяются горы, поля, долины, реки, озёра. Растительность
    /// заслоняет рельеф и тратит минуту на сборку.
    public const bool VegetationOn = false;

    private void BuildVegetation()
    {
        if (!VegetationOn)
        {
            ClearVegetation();
            SessionLog.Print("[растительность] ОТКЛЮЧЕНА (LevelView3D.VegetationOn = false)");
            return;
        }

        // В режиме проверки нового рельефа растительность не строится: она стоит по
        // регионам старого генератора и к новому рельефу не привязана — висела бы
        // в воздухе или тонула.
        // ---- РАСТИТЕЛЬНОСТЬ РАБОТАЕТ И В РЕЖИМЕ ПРОСМОТРА РЕЛЬЕФА ----
        //
        // Здесь стоял безусловный выход: режим заводился, чтобы старый меш и его
        // растительность не мешали смотреть новый рельеф.
        //
        // Теперь растительность своя (RingVegetationPlacer по нашим поясам), и
        // глушить её незачем — наоборот, она даёт недостающий четвёртый тон
        // кадра по Carlson. Из-за этой строки её и не было видно: в журнале не
        // появлялось даже сообщения о расстановке.

        // VegetationEnabled — константа (см. выше), отсюда CS0162 на ветке отключения.
#pragma warning disable CS0162
        if (!VegetationEnabled)
        {
            ClearVegetation();
            return;
        }
#pragma warning restore CS0162

        if (_data == null)
        {
            ClearVegetation();
            return;
        }

        // Именно EnsureGamePool, а не EnsureInitialized: второй возвращается сразу,
        // если каталог уже есть, — даже если это каталог витрины с одним возрастом.
        PlantCatalog.EnsureGamePool();
        _soReportPrinted = false;   // каталог пересобран — отчёт о росте нужен заново

        // ---- РАСТИТЕЛЬНОСТЬ СТАВИТСЯ ПО НАШЕМУ УРОВНЮ ----
        //
        // Было `_data.Vegetation` — растения СТАРОГО генератора чанка, чья карта
        // 1000 единиц против наших 5760. В журнале их было 26872, а в сцене ноль:
        // они лежали в другой системе координат.
        //
        // Зачем вообще: по Carlson у пейзажа четыре первичные плоскости, и
        // вертикали — самый тёмный тон. Замер кадра дал «вертикалей 0.0%», и
        // получить их рельефом НЕВОЗМОЖНО: крона шириной 5 м на сетке 30 м даёт
        // уклон в несколько градусов, а не вертикаль.
        var swVeg = System.Diagnostics.Stopwatch.StartNew();
        var start = FarBackground.FindStartPosition() ?? Godot.Vector2.Zero;
        long tStart = swVeg.ElapsedMilliseconds;
        var plants = RingVegetationPlacer.Place(
            SampleWorldY,
            (wx, wz) => FarBackground.BiomeAtWorld(wx, wz),
            // Центр — та же точка, что выбрана для старта. Поле _target
            // принадлежит GameBootstrap, а не виду: слои перепутаны быть не должны.
            //
            // У Vector2 составляющие X и Y, причём Y здесь — это МИРОВАЯ Z
            // (глубина). Написал по привычке start.Z и сломал сборку.
            start.X, start.Y,
            // ---- РАДИУС 1.8 КМ ----
            //
            // Угловой размер кроны шириной 5 м:
            //
            //     0.6 км  0.48°   3282 растения
            //     1.2 км  0.24°  12199
            //     1.8 км  0.16°  24101
            //     3.6 км  0.08°  78831   мельче точки экрана
            //
            // Дальше 1.8 км дерево не различить, а память и отрисовка платятся
            // полной ценой. В журнале телефона память видеокарты 102 МБ при НУЛЕ
            // растений — запас невелик.
            // Радиус 1.2 км: на 1.8 км выходило 1359 групп и 4077 узлов
            // MultiMesh, построение 160 секунд, памяти больше гигабайта.
            // На 1.2 км групп 691 — вдвое меньше.
            radiusWorld: 120f,
            // ---- V319: ШАГ 4 М ВМЕСТО 10 ----
            //
            // Шаг задаёт ВЕРХНИЙ предел плотности: реже сетки растений не
            // поставить, сколько долю полян ни уменьшай. При 10 м сомкнутость
            // полога упиралась в 15% при природных 60-90.
            //
            // Замер на стенде (лесной пояс, разрежение вчетверо к краю круга):
            //
            //     поляны  шаг м  растений  полог вблизи  полог вдали
            //       0.60     6     77 914       15.0%        17.0%
            //       0.35     4     86 248       58.8%        17.0%   ВЗЯТО
            //       0.20     4    114 133       76.5%        21.9%
            //       0.20     3    202 946       86.5%        33.7%
            //
            // Взято 0.35 и 4 м: нижний край природного полога при наименьшем
            // числе растений из тех, что до него дотягивают.
            stepWorld: 0.4f,
            seed: _worldSeed);
        long tPlace = swVeg.ElapsedMilliseconds;
        SessionLog.Print($"[растительность] поставлено {plants.Count} вокруг игрока "
            + $"(выбор точки {tStart} мс, расстановка {tPlace - tStart} мс)");
        if (plants.Count == 0)
        {
            ClearVegetation();
            return;
        }

        ClearVegetation();

        float cx = _mapSize * 0.5f;
        float cz = _mapSize * 0.5f;

        // РАЗБИЕНИЕ НА ЧАНКИ.
        // Раньше группировка шла только по (вид, вариант) — получалось ~28 узлов
        // MultiMeshInstance3D, и КАЖДЫЙ охватывал всю карту. Godot отсекает по пирамиде
        // видимости на уровне узла (VisualInstance3D), а не отдельного экземпляра внутри
        // MultiMesh, поэтому все 23 тысячи растений отправлялись на отрисовку каждый кадр
        // независимо от направления камеры — отсечение по видимости не работало вовсе.
        // Теперь ключ включает координаты чанка: у каждого узла компактный AABB, и
        // отсечение начинает работать само, без дополнительного кода. Тот же разрез
        // даёт единицу для LOD по расстоянию (см. UpdateVegetationLod).
        var groups = new Dictionary<(int cxi, int czi, VegetationKind kind, int variant), List<VegetationInstance>>();
        float chunkWorld = _mapSize / VegChunkGrid;

        // ---- V89: СКОЛЬКО ВАРИАНТОВ ДЕРЖАТЬ В КЛЕТКЕ ----
        //
        // Замер показал, откуда берутся вызовы отрисовки. Дело не в общем числе
        // растений, а в РЕДКИХ группах: у цветов приходилось 7 экземпляров на узел,
        // у кустов 4, у пихты 4, у камыша 2. Каждая такая группа — полноценный вызов
        // отрисовки ради нескольких растений, притом что разницу между пятью
        // вариантами при четырёх экземплярах в клетке увидеть невозможно.
        //
        // Поэтому число вариантов подбирается по плотности: сколько экземпляров вида
        // в клетке, столько вариантов она и заслуживает, из расчёта не меньше
        // MinInstancesPerNode на узел. Густой лиственный лес сохраняет все пять форм,
        // одинокая пихта на склоне сводится к одной. Замер по чанку seed 12345:
        // 423 узла против 210, то есть вдвое меньше при ориентире 150.
        const int MinInstancesPerNode = 24;
        var perCellKind = new Dictionary<(int, int, VegetationKind), int>();
        for (int i = 0; i < plants.Count; i++)
        {
            var p = plants[i];
            var ck = (Math.Clamp((int)(p.X / chunkWorld), 0, VegChunkGrid - 1),
                      Math.Clamp((int)(p.Z / chunkWorld), 0, VegChunkGrid - 1),
                      p.Kind);
            perCellKind[ck] = perCellKind.TryGetValue(ck, out var n) ? n + 1 : 1;
        }

        for (int i = 0; i < plants.Count; i++)
        {
            var p = plants[i];
            int cxi = Math.Clamp((int)(p.X / chunkWorld), 0, VegChunkGrid - 1);
            int czi = Math.Clamp((int)(p.Z / chunkWorld), 0, VegChunkGrid - 1);
            // У покрытий (трава/мох/камни) варианты меша по группам НЕ разделяются:
            // их разнообразие даёт поворот и масштаб экземпляра, а не форма, зато
            // разделение по 5 вариантам множило бы число узлов почти втрое впустую.
            int variantKey;
            if (IsCoverKind(p.Kind))
            {
                variantKey = 0;
            }
            else
            {
                int inCell = perCellKind[(cxi, czi, p.Kind)];
                int allowed = Math.Clamp(inCell / MinInstancesPerNode, 1, PlantCatalog.VariantsPerKind);
                variantKey = p.VariantIndex % allowed;
            }
            var key = (cxi, czi, p.Kind, variantKey);
            if (!groups.TryGetValue(key, out var list))
            {
                list = new List<VegetationInstance>();
                groups[key] = list;
            }
            list.Add(p);
        }

        var mat = CreateFoliageMaterial(0.72f);
        // В отладочном режиме — плоский самосветящийся материал, чтобы цвет вида читался
        // одинаково на солнце и в тени, без влияния освещения.
        // Тип объявлен явно: обычный материал растительности теперь ShaderMaterial,
        // а отладочный остаётся StandardMaterial3D, и вывод типа для тернарника
        // общего предка сам не находит.
        Material? debugMat = DebugPrimitiveVegetation
            ? new StandardMaterial3D
            {
                VertexColorUseAsAlbedo = true,
                ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded,
                CullMode = BaseMaterial3D.CullModeEnum.Disabled
            }
            : null;

        _vegChunks.Clear();
        _treeBlockers.Clear();
        foreach (var kv in groups)
        {
            var kind = kv.Key.kind;
            int variant = kv.Key.variant;
            var list = kv.Value;
            if (list.Count == 0) continue;

            var plantData = PlantCatalog.Instance.Get(kind, variant);
            float localH = Math.Max(plantData.LocalHeight, 0.1f);
            Mesh proto;
            if (DebugPrimitiveVegetation)
            {
                proto = CreateDebugPrimitive(kind);
                localH = 1f; // примитивы заданы единичной высоты
            }
            else
            {
                // ---- МЕШ СТРОИТСЯ ОДИН РАЗ НА ПАРУ «ВИД И ВАРИАНТ» ----
                //
                // Групп сотни (чанк × вид × вариант), а РАЗНЫХ мешей всего
                // дюжина: три варианта на вид. Прежде ToArrayMesh вызывался на
                // каждую группу заново — сотни раз вместо дюжины.
                var protoKey = ((int)kind, variant);
                if (!_protoMeshCache.TryGetValue(protoKey, out var cached))
                {
                    cached = ToArrayMesh(plantData);
                    _protoMeshCache[protoKey] = cached;
                }
                proto = cached;
            }

            var mm = new MultiMesh();
            mm.TransformFormat = MultiMesh.TransformFormatEnum.Transform3D;
            mm.UseColors = true;
            mm.Mesh = proto;
            mm.InstanceCount = 1; // placeholder, set after filter;

            // В отладочном режиме примитивы крупнее реальных растений: цель — увидеть
            // РАСПРЕДЕЛЕНИЕ по карте с обзорной камеры, а не масштаб отдельного куста.
            float targetH = DebugPrimitiveVegetation
                ? kind switch
                {
                    VegetationKind.Pine => 4.0f,
                    VegetationKind.Fir => 4.0f,
                    VegetationKind.Deciduous => 3.6f,
                    VegetationKind.Bush => 2.4f,
                    VegetationKind.Flower => 2.0f,
                    VegetationKind.Reed => 2.2f,
                    VegetationKind.GrassTuft => 1.2f,
                    VegetationKind.Moss => 1.0f,
                    VegetationKind.Stone => 1.4f,
                    _ => 2.5f
                }
                : kind switch
            {
                // V67: масштаб приведён к реке. Замер до правки: река 2.08 мировых
                // единиц шириной против кроны ели 3.48 — дерево было ШИРЕ реки, отсюда
                // ощущение гигантских деревьев. После удвоения реки (4.16) и
                // уменьшения деревьев отношение «река / крона» выросло с 0.6 до 2.9.
                // V68: ещё уменьшено. Чтобы деревья складывались в ЧАЩУ, крона должна
                // быть заметно меньше расстояния между стволами. При плотности 18 400
                // экз./чанк на площадь 25 600 мировых кв. единиц приходится 1.39 экз.
                // на кв. единицу, то есть шаг между растениями около 0.85. Крона 1.42
                // была ШИРЕ шага — деревья не смыкались, а взаимно проникали.
                // При кроне 0.87 (ель 1.1) шаг и крона сопоставимы: кроны смыкаются
                // краями, что и даёт сплошной полог.
                // V72: подняты в 1.45 раза. Размер и плотность решаются СОВМЕСТНО:
                // сомкнутость полога определяется отношением шага между деревьями к
                // ширине кроны. При 4238 деревьях шаг 2.46 мировых единиц; крона 0.87
                // давала отношение 2.8, крона 1.26 даёт 2.0 — вдвое ближе к смыканию,
                // и это бесплатно по треугольникам, в отличие от роста числа деревьев.
                // ---- V88: ВЫСОТЫ ЗАДАНЫ В МЕТРАХ, А НЕ ПОДБОРОМ ----
                //
                // Прежние значения подбирались под вид СВЕРХУ: крону сужали, пока полог
                // не начинал смыкаться на общем плане. При пешей прогулке это дало
                // сосну ростом 1.52 мировой единицы при высоте глаз игрока 1.65 — то
                // есть игрок буквально выше леса и смотрит на макушки. Отсюда и
                // «деревья похожи на кусты».
                //
                // Масштаб мира определён явно (MetresPerUnit): по ширине русла
                // 4.16 единицы при типичной альпийской реке 40 м и по стороне чанка
                // 147 единиц при долине примерно полтора километра выходит около
                // десяти метров на единицу. От этого и считаются высоты — из тех же
                // справочных значений, что уже стоят в комментариях PlantSpecies:
                // пихта 42 м, ель 35, кедр 35, сосна 30, дуб 28, тсуга 25, клён 25,
                // берёза 20. Видовой множитель добавляется ниже, поэтому здесь —
                // средняя по типу.
                VegetationKind.Pine => 28f / MetresPerUnit,
                VegetationKind.Fir => 31f / MetresPerUnit,
                VegetationKind.Deciduous => 25f / MetresPerUnit,
                // ---- V141: КУСТЫ И ЦВЕТЫ ПРИВЕДЕНЫ К НАТУРЕ ----
                //
                // Сводная сверка показала то, чего не видно на отдельном растении:
                // можжевельник выходил 2.1 м при натурных 0.3–0.8, альпийская роза
                // 2.7 при 0.5–1.2, луговые цветы около метра при 0.2–0.6. Отношение
                // ели к подушковидному кусту было 11.5 вместо натурных 25–50 — потому
                // подлесок и читался вторым ярусом деревьев, а не подлеском.
                //
                // Здесь СРЕДНЯЯ по типу; форма роста и HeightMul вида домножаются
                // дальше, поэтому средняя берётся ниже верхней границы самой рослой
                // формы (ольха зелёная 2–4 м).
                VegetationKind.Bush => 1.1f / MetresPerUnit,
                VegetationKind.Flower => 0.32f / MetresPerUnit,
                VegetationKind.Reed => 1.4f / MetresPerUnit, // V124: камыш не гигант
                // Покрытия — мелкие, у самой земли.
                // ПРАВКА 2 (по скриншотам): камень был 0.45 при дереве 3.6-4.4, но на
                // картинке валуны читались почти вровень с деревьями — вместе с верхней
                // границей масштаба 2.2 они доходили до ~1.0, то есть до трети дерева.
                // Уменьшен; трава наоборот поднята, иначе на общем плане её не видно.
                VegetationKind.GrassTuft => 0.45f / MetresPerUnit, // V124
                VegetationKind.Moss => 0.2f / MetresPerUnit,
                VegetationKind.Stone => 0.7f / MetresPerUnit,
                _ => 2.0f
            };

            // ВИДОВАЯ ВЫСОТА. targetH выше — средняя по типу; без этого множителя
            // сосна и кедр, дуб и берёза выходили одного роста, хотя в справочных
            // данных между ними полтора раза. Именно это читалось как «деревья
            // примерно одинаковые по высоте между собой».
            if (!DebugPrimitiveVegetation)
            {
                var genome = PlantCatalog.Instance.GetGenome(kind, variant);
                targetH *= PlantSpecies.Get(kind, genome.Species).HeightMul;
            }

            // V39: двухпроходная укладка — сначала отбрасываем экземпляры у soft-edge
            // и с невалидной высотой (иначе «висят в воздухе» на горизонте).
            var accepted = new List<(Vector3 pos, float yaw, float scale, float elev)>(list.Count);

            for (int i = 0; i < list.Count; i++)
            {
                var p = list[i];

                // ---- КООРДИНАТЫ УЖЕ МИРОВЫЕ ----
                //
                // Было `(p.X - cx) * WorldScale` — пересчёт из карты СТАРОГО
                // генератора (1000 единиц) в мировые. Наш RingVegetationPlacer
                // отдаёт сразу мировые, и этот пересчёт уносил растения за
                // пределы safeR: все 26269 отбраковывались, а в журнале было
                // «vegRoot: children=0» при 159 секундах, потраченных на них.
                float wx = p.X;
                float wz = p.Z;
                // ЗАПАСНАЯ ФОРМУЛА — ТОЛЬКО ПРИ ОТСУТСТВИИ ДАННЫХ СЕТКИ.
                //
                // Раньше условие было «wy < 0.4», то есть срабатывало и на совершенно
                // корректной низкой высоте — на дне долины у реки, где растений больше
                // всего. Там верная выборка подменялась приближением
                // pow(elev, 1.15)·HeightScale, которое поверхности меша не совпадает,
                // и растения садились ниже или выше земли. Теперь запасной путь берётся
                // ровно тогда, когда сетка высот в этой точке ничего не знает.
                if (!TrySampleWorldY(wx, wz, out float wy))
                {
                    // fallback по elevation только если точка реально на суше
                    if (p.Elevation < 0.03f) continue;
                    wy = MathF.Pow(Math.Max(p.Elevation, 0.01f), 1.15f) * HeightScale;
                }
                accepted.Add((new Vector3(wx, wy, wz), p.Yaw, p.Scale, p.Elevation));
            }
            if (accepted.Count == 0) continue;
            mm.InstanceCount = accepted.Count;
            bool alignSlope = IsCoverKind(kind) || kind == VegetationKind.GrassTuft;
            for (int i = 0; i < accepted.Count; i++)
            {
                var a = accepted[i];
                float s = (targetH * a.scale) / localH;
                Vector3 origin = a.pos;
                Basis basis;
                if (alignSlope && TrySampleWorldNormal(a.pos.X, a.pos.Z, out Vector3 n))
                {
                    var yawFwd = new Vector3(MathF.Sin(a.yaw), 0f, MathF.Cos(a.yaw));
                    var right = n.Cross(yawFwd);
                    if (right.LengthSquared() < 1e-8f)
                        right = n.Cross(Vector3.Right);
                    right = right.Normalized();
                    var fwd = right.Cross(n).Normalized();
                    basis = new Basis(right, n, fwd).Scaled(new Vector3(s, s, s));
                    origin -= n * (0.02f * s);
                }
                else
                {
                    basis = Basis.Identity
                        .Rotated(Vector3.Up, a.yaw)
                        .Scaled(new Vector3(s, s, s));
                }
                mm.SetInstanceTransform(i, new Transform3D(basis, origin));
                mm.SetInstanceColor(i, DebugPrimitiveVegetation
                    ? DebugVegStyle(kind).color
                    : VegetationColor(kind, _season));
            }

            // ---- ПРЕГРАДЫ У СТВОЛОВ ----
            //
            // Дерево — единственное, во что игрок может «войти» и оказаться внутри
            // кроны. Ставим цилиндр вокруг ствола. Радиус берётся НЕ по кроне целиком:
            // при сомкнутом пологе кроны перекрываются, и преграда в полный радиус
            // сделала бы лес непроходимым — по замеру шаг между деревьями сопоставим
            // с диаметром кроны. Берём долю, при которой преграда ощущается стволом
            // с подлеском, а не невидимой стеной в воздухе.
            if (IsTreeKind(kind))
            {
                float localCrownR = 0f;
                for (int vi = 0; vi < plantData.VertexCount; vi++)
                {
                    float px = plantData.Positions[vi * 3];
                    float pz = plantData.Positions[vi * 3 + 2];
                    float rr = MathF.Sqrt(px * px + pz * pz);
                    if (rr > localCrownR) localCrownR = rr;
                }
                for (int i = 0; i < accepted.Count; i++)
                {
                    var a = accepted[i];
                    float s2 = (targetH * a.scale) / localH;
                    float br = MathF.Max(localCrownR * s2 * TreeBlockerCrownFraction,
                                         TreeBlockerMinMetres / MetresPerUnit);
                    _treeBlockers.Add((a.pos.X, a.pos.Z, br));
                }
            }

            // ТРИ УЗЛА НА ГРУППУ: полный меш, прорежённый, импостор.
            //
            // Меш и материал у каждого свои и не меняются в рантайме — меняется только
            // состав экземпляров (см. SortChunk). Прежняя схема подменяла меш у
            // единственного узла, и потому уровень был общим для всей группы.
            var mmi = new MultiMeshInstance3D
            {
                Name = $"Veg_{kv.Key.cxi}_{kv.Key.czi}_{kind}_{variant}_full",
                Multimesh = mm,
                MaterialOverride = debugMat ?? mat
            };
            // ---- V83: ТЕНИ РАСТИТЕЛЬНОСТИ ----
            //
            // Дальние экземпляры тени НЕ отбрасывают: карта теней рисуется отдельным
            // проходом, и 16 тысяч крон в ней стоили бы дороже самой сцены. Тень от
            // деревьев видна только вблизи, где она и нужна — под кроной, на тропе.
            // Принимают тень все: это бесплатно, зато дальний лес перестаёт светиться
            // одинаково ярко на склоне, обращённом от солнца.
            mmi.CastShadow = GeometryInstance3D.ShadowCastingSetting.Off;

            _vegRoot.AddChild(mmi);

            // Регистрируем чанк для LOD. В отладочном режиме примитивов LOD не нужен —
            // там и так дешёвые фигуры, а подмена меша сломала бы читаемость форм.
            if (!DebugPrimitiveVegetation)
            {
                // Габариты чанка по позициям экземпляров. Высота растений добавляется
                // сверху, иначе объём получается плоским и камера над кроной считалась бы
                // дальше, чем она есть.
                float bnX = float.MaxValue, bnY = float.MaxValue, bnZ = float.MaxValue;
                float bxX = float.MinValue, bxY = float.MinValue, bxZ = float.MinValue;
                for (int i = 0; i < accepted.Count; i++)
                {
                    var t = mm.GetInstanceTransform(i).Origin;
                    if (t.X < bnX) bnX = t.X; if (t.X > bxX) bxX = t.X;
                    if (t.Y < bnY) bnY = t.Y; if (t.Y > bxY) bxY = t.Y;
                    if (t.Z < bnZ) bnZ = t.Z; if (t.Z > bxZ) bxZ = t.Z;
                }
                float plantH = targetH * 1.5f;
                // LOD подключается ТОЛЬКО там, где он реально выигрывает. Замер по
                // видам (q=0, треугольников полный -> LOD, прореживание карточек):
                //   Fir 40504->1326, Deciduous 40768->1330, Pine 28648->1336  (21-31x)
                //   Bush 3302->662 (5x)
                //   Flower/Reed/GrassTuft/Moss/Stone — уже дешёвые, порог не проходят
                // У пучка травы всего пара карточек: прореживать нечего, и любая
                // перестройка меша только добавила бы работы. Для таких видов дальний
                // уровень = тот же полный меш, и переключения просто не происходит.
                int fullTris = plantData.Indices.Count / 3;
                var lodMesh = BuildLodMesh(plantData);
                int lodTris = 0;
                if (lodMesh.GetSurfaceCount() > 0)
                    lodTris = (int)(lodMesh.SurfaceGetArrayLen(0) / 3);
                // V82: порог понижен с 1000 до 250. Компактное дерево — около 736
                // треугольников, и прежний порог отключил бы у него LOD целиком:
                // дальний уровень не строился бы, а импостор не применялся.
                // Проверка «lodTris*3 < fullTris» тоже ослаблена до *2: при уже
                // экономной геометрии втрое ужать не всегда получается, а вдвое —
                // достаточно, чтобы уровень окупился.
                bool lodWorthIt = fullTris > 250 && lodTris > 0 && lodTris * 2 < fullTris;

                // ---- V83: ИМПОСТОР ИЗ АТЛАСА ----
                //
                // Атлас выпекается ОДИН РАЗ на породу и переиспользуется всеми
                // чанками этой породы: рендер восьми ракурсов на каждый из 349
                // чанков занял бы минуты и был бы бессмысленным дублированием.
                Mesh impostorMesh = lodWorthIt ? BuildImpostorMesh(plantData) : proto;
                Material? impostorMat = null;
                if (lodWorthIt)
                {
                    var atlasKey = (kind, variant);
                    if (!_impostorAtlases.TryGetValue(atlasKey, out var baked))
                    {
                        // Выпекание асинхронно, поэтому на первом кадре атласа ещё нет:
                        // до его готовности чанк рисуется прежней крестовиной, и это
                        // корректно — переключение произойдёт само, когда атлас появится.
                        RequestImpostorAtlas(atlasKey, proto, mat, lodMesh);
                    }
                    else
                    {
                        impostorMesh = baked.Card;
                        impostorMat = baked.Material;
                    }
                }

                // Исходный буфер берём У ДВИЖКА: он только что заполнен через
                // SetInstanceTransform/SetInstanceColor, а значит раскладка полей
                // заведомо та, которую движок ожидает получить обратно. Собирать её
                // вручную значило бы дублировать внутреннее соглашение MultiMesh.
                float[] srcBuffer = mm.Buffer;
                int stride = srcBuffer.Length / Math.Max(accepted.Count, 1);
                var positions = new Vector3[accepted.Count];
                var scales = new float[accepted.Count];
                for (int i = 0; i < accepted.Count; i++)
                {
                    // V127: позиция = фактический origin инстанса (после прижима)
                    positions[i] = mm.GetInstanceTransform(i).Origin;
                    scales[i] = (targetH * accepted[i].scale) / localH;
                }

                // Габариты прототипа в ЛОКАЛЬНЫХ единицах меша: телеметрия кадра
                // считает по ним экранный размер, а значит отвечает на вопрос
                // «видно ли», а не «сколько штук».
                float protoH = 0f, protoR = 0f;
                for (int vi = 0; vi < plantData.VertexCount; vi++)
                {
                    float vpx = plantData.Positions[vi * 3];
                    float vpy = plantData.Positions[vi * 3 + 1];
                    float vpz = plantData.Positions[vi * 3 + 2];
                    if (vpy > protoH) protoH = vpy;
                    float rr = MathF.Sqrt(vpx * vpx + vpz * vpz);
                    if (rr > protoR) protoR = rr;
                }

                // Карточка импостора — два треугольника; крестовина-запасной вариант
                // считается по массиву. ArrayMesh, а не Mesh: SurfaceGetArrayLen
                // объявлен именно у него.
                int impTrisCount = 2;
                if (impostorMesh is ArrayMesh impArr && impArr.GetSurfaceCount() > 0)
                    impTrisCount = (int)(impArr.SurfaceGetArrayLen(0) / 3);

                var mmLod1 = CloneMultiMesh(mm, lodWorthIt ? lodMesh : proto);
                var mmImp = CloneMultiMesh(mm, impostorMesh);
                var nodeLod1 = new MultiMeshInstance3D
                {
                    Name = mmi.Name + "_lod1",
                    Multimesh = mmLod1,
                    MaterialOverride = debugMat ?? mat,
                    CastShadow = GeometryInstance3D.ShadowCastingSetting.On,
                    Visible = false,
                };
                var nodeImp = new MultiMeshInstance3D
                {
                    Name = mmi.Name + "_imp",
                    Multimesh = mmImp,
                    // Пока атлас не готов, импостор рисуется крестовиной обычным
                    // материалом — это корректно, переключение произойдёт само.
                    MaterialOverride = impostorMat ?? debugMat ?? mat,
                    CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
                    Visible = false,
                };
                _vegRoot.AddChild(nodeLod1);
                _vegRoot.AddChild(nodeImp);
                // Тень отбрасывает только ближняя корзина: карта теней рисуется
                // отдельным проходом, и кроны дальнего плана стоили бы в ней дороже
                // самой сцены.
                // ---- V146: ТЕНЬ ТОЛЬКО ОТ ТОГО, ЧТО ЕЁ СТОИТ ----
                //
                // Приём из практики инстансинга: тень для средних уровней берётся с
                // более грубого меша, а у дальних отключается вовсе. У нас ближняя
                // корзина отбрасывает тень, средняя и импосторы — нет.
                //
                // Покрытия исключены целиком: тень от полуметровой куртины на земле
                // неразличима, а карта теней рисуется отдельным проходом, и восемьсот
                // куртин в ближнем круге стоили бы в ней дороже деревьев.
                mmi.CastShadow = IsCoverKind(kind)
                    ? GeometryInstance3D.ShadowCastingSetting.Off
                    : GeometryInstance3D.ShadowCastingSetting.On;
                mmi.Visible = false;

                _vegChunks.Add(new VegChunk
                {
                    NodeFull = mmi,
                    NodeLod1 = nodeLod1,
                    NodeImp = nodeImp,
                    MmFull = mm,
                    MmLod1 = mmLod1,
                    MmImp = mmImp,
                    SrcBuffer = srcBuffer,
                    Stride = stride,
                    Pos = positions,
                    Scales = scales,
                    FullTris = fullTris,
                    Lod1Tris = lodWorthIt ? lodTris : fullTris,
                    ImpTris = impTrisCount,
                    ProtoHeight = protoH,
                    ProtoRadius = protoR,
                    Full = proto,
                    Lod2Material = impostorMat,
                    NearMaterial = debugMat ?? mat,
                    Kind = kind,
                    Variant = variant,
                    Lod1 = lodWorthIt ? lodMesh : proto,
                    Lod2 = impostorMesh,
                    BoundsMin = new Vector3(bnX, bnY, bnZ),
                    BoundsMax = new Vector3(bxX, bxY + plantH, bxZ),
                });
            }
        }

        RebuildBlockerGrid();
        SessionLog.Print($"[veg] раскладка по узлам за {swVeg.ElapsedMilliseconds - tPlace} мс");
        SessionLog.Print($"[veg] преград у деревьев: {_treeBlockers.Count}, " +
                 $"узлов MultiMesh: {_vegChunks.Count}");
    }

    private static ArrayMesh ToArrayMesh(PlantMeshData data)
    {
        int vc = data.VertexCount;
        var verts = new Vector3[vc];
        var cols = new Color[vc];
        var uvs = new Vector2[vc];
        bool hasUv = data.UVs.Count >= vc * 2;
        for (int i = 0; i < vc; i++)
        {
            int pi = i * 3;
            int ci = i * 4;
            verts[i] = new Vector3(data.Positions[pi], data.Positions[pi + 1], data.Positions[pi + 2]);
            cols[i] = new Color(
                data.Colors[ci], data.Colors[ci + 1], data.Colors[ci + 2], data.Colors[ci + 3]);
            uvs[i] = hasUv
                ? new Vector2(data.UVs[i * 2], data.UVs[i * 2 + 1])
                : new Vector2(FoliageAtlas.SolidU, FoliageAtlas.SolidV);
        }

        // ---- V77: НОРМАЛИ ПО ГРАНЯМ ----
        //
        // Раньше меши растений собирались БЕЗ нормалей вообще: только вершины, цвет,
        // UV и индексы. Материал листвы при этом освещаемый (StandardMaterial3D,
        // не unshaded), поэтому светотени между листьями не возникало — крона читалась
        // сплошной зелёной массой.
        //
        // Тот же изъян портил и наброски: служебный проход нормалей читал у
        // растительности пустоту, и вместо контуров кроны получались каракули.
        //
        // Нормаль берётся ПО ГРАНИ, а не усредняется по вершине: каждая листовая
        // карточка имеет собственные четыре вершины и ни с кем их не делит, поэтому
        // плоская нормаль даёт каждому листу свою ориентацию — именно это и разделяет
        // их визуально. Усреднение, наоборот, слило бы соседние карточки обратно.
        var normals = new Vector3[vc];
        var idx = data.Indices;
        for (int t = 0; t + 2 < idx.Count; t += 3)
        {
            int i0 = idx[t], i1 = idx[t + 1], i2 = idx[t + 2];
            if (i0 >= vc || i1 >= vc || i2 >= vc) continue;
            var n = (verts[i1] - verts[i0]).Cross(verts[i2] - verts[i0]);
            if (n.LengthSquared() < 1e-12f) continue;
            n = n.Normalized();
            normals[i0] += n; normals[i1] += n; normals[i2] += n;
        }
        for (int i = 0; i < vc; i++)
        {
            normals[i] = normals[i].LengthSquared() > 1e-9f
                ? normals[i].Normalized()
                : Vector3.Up;   // вырожденная грань — вверх, чтобы не было NaN
        }

        var arrays = new Godot.Collections.Array();
        arrays.Resize((int)Mesh.ArrayType.Max);
        arrays[(int)Mesh.ArrayType.Vertex] = verts;
        arrays[(int)Mesh.ArrayType.Normal] = normals;
        arrays[(int)Mesh.ArrayType.Color] = cols;
        arrays[(int)Mesh.ArrayType.TexUV] = uvs;
        arrays[(int)Mesh.ArrayType.Index] = data.Indices.ToArray();
        var mesh = new ArrayMesh();
        mesh.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, arrays);
        return mesh;
    }

    /// <summary>
    /// V111: для деревьев и кустов instance color ≈ белый.
    /// Раньше единый зелёный множитель красил и кору, и листву — стволы «тёмно-оливковые
    /// и бежевые вперемешку без связи с породой» (обход V106). Кора и хвоя уже запечены
    /// в vertex color меша (PlantGenerator + PlantSpecies). Сезонная окраска листвы —
    /// отдельный заход (нужен split mesh или атлас), не ценой коры.
    /// </summary>
    private static Color VegetationColor(VegetationKind kind, SeasonType season)
    {
        return kind switch
        {
            // Древесные: vertex color как есть
            VegetationKind.Pine => new Color(1f, 1f, 1f),
            VegetationKind.Fir => new Color(1f, 1f, 1f),
            VegetationKind.Deciduous => new Color(1f, 1f, 1f),
            VegetationKind.Bush => new Color(1f, 1f, 1f),
            VegetationKind.Flower => season switch
            {
                SeasonType.Spring => new Color(0.88f, 0.50f, 0.72f),
                SeasonType.Summer => new Color(0.92f, 0.78f, 0.22f),
                SeasonType.Autumn => new Color(0.72f, 0.48f, 0.14f),
                _ => new Color(0.55f, 0.55f, 0.52f)
            },
            VegetationKind.Reed => season == SeasonType.Winter
                ? new Color(0.50f, 0.48f, 0.35f)
                : new Color(0.38f, 0.52f, 0.26f),
            VegetationKind.GrassTuft => season switch
            {
                SeasonType.Autumn => new Color(0.62f, 0.55f, 0.26f),
                SeasonType.Winter => new Color(0.62f, 0.62f, 0.58f),
                SeasonType.Spring => new Color(0.48f, 0.76f, 0.30f),
                _ => new Color(0.40f, 0.64f, 0.26f)
            },
            // Мох почти не меняется по сезонам — он вечнозелёный и живёт в тени,
            // где и снега меньше. Зимой лишь слегка выцветает.
            VegetationKind.Moss => season == SeasonType.Winter
                ? new Color(0.28f, 0.38f, 0.28f)
                : new Color(0.24f, 0.48f, 0.22f),
            // Камень не зависит от сезона вообще.
            VegetationKind.Stone => new Color(0.52f, 0.51f, 0.49f),
            _ => new Color(0.30f, 0.48f, 0.24f)
        };
    }

}
