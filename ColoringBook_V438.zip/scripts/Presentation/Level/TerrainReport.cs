using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using ColoringBook.Infrastructure.Generation.Diagnostics;

using ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

namespace ColoringBook.Presentation.Level;

/// <summary>
/// ПОЛНЫЙ ОТЧЁТ О ГЕОМЕТРИИ РЕЛЬЕФА — файл в каталоге логов.
///
/// ---- ЗАЧЕМ ----
///
/// До сих пор я судил о рельефе по снимкам. Снимок показывает кусок под одним
/// ракурсом: за семь итераций я четырежды принял погасшее освещение за дыры, и
/// каждый раз лечил не то. Числа охватывают весь уровень сразу и не зависят от
/// того, куда повёрнута камера.
///
/// ---- ЧТО СЮДА ВХОДИТ И ПОЧЕМУ ИМЕННО ЭТО ----
///
/// Средних величин мало: рельеф со средним уклоном 25° может быть и грядой
/// хребтов, и равномерной рябью. Поэтому пишутся РАСПРЕДЕЛЕНИЯ:
///
///   гистограмма уклонов     — форма важнее среднего: два горба означают «дно и
///                             стены», один пологий — однородную сыпь;
///   гистограмма высот       — сколько площади на каком уровне; у настоящих гор
///                             она скошена вниз (дна много, вершин мало);
///   вогнутость              — доля ячеек, где поверхность вогнута; отличает
///                             ложбины от бугров и показывает, есть ли долины;
///   азимут склонов          — если шум даёт направленную решётку, здесь будет
///                             перекос, невидимый на глаз. ВАЖНО: у ближнего
///                             кольца эта величина шумит. Оно охватывает 3.6 км,
///                             куда попадает меньше одного периода крупной полосы
///                             и всего несколько хребтов, поэтому разброс по
///                             румбам держится около 10% и от правок почти не
///                             зависит. Систематический перекос виден на дальних
///                             кольцах, и там он около 2%. Судить по ближнему
///                             кольцу — гоняться за шумом, я это уже делал;
///   сток                    — максимум и доля площади с большим стоком: это
///                             будущие русла;
///   проходимость            — доля площади с уклоном ниже 25° и наибольший
///                             связный такой участок: есть ли где идти;
///   разрезы                 — высоты вдоль нескольких линий через область, чтобы
///                             можно было увидеть профиль, а не только сводку.
/// </summary>
public static class TerrainReport
{
    /// <summary>Границы столбцов гистограммы уклонов, градусы.</summary>
    private static readonly float[] SlopeBins = { 0, 5, 10, 15, 20, 25, 30, 35, 40, 50, 60, 75, 90 };

    /// <summary>
    /// Пороги уклона, для которых считается доля проходимой площади, градусы.
    ///
    ///    6° — шоссейный велосипед, устойчивый подъём;
    ///   12° — горный, устойчивый подъём;
    ///   20° — горный, короткий подъём внатяг;
    ///   30° — горный, спуск; пешеход поднимается.
    ///
    /// Замер по нынешнему рельефу, ближнее кольцо: 8 / 18 / 32 / 53 процента.
    /// Для шоссейного порога трассу пришлось бы вымучивать, для горного при 20°
    /// доступна треть площади — это уже свобода прокладки.
    /// </summary>
    private static readonly float[] PassableLimits = { 6, 12, 20, 30 };

    /// <summary>
    /// Записать отчёт по одному кольцу.
    /// </summary>
    /// <param name="h">Сетка высот в мировых единицах.</param>
    /// <param name="side">Сторона сетки в отсчётах.</param>
    /// <param name="cellWorld">Шаг сетки в мировых единицах.</param>
    /// <param name="flow">Накопленный сток той же сетки; может быть null.</param>
    /// <param name="liftWorld">Вертикальное смещение фона, чтобы он сел на дно
    /// долины. В отчёт высоты пишутся БЕЗ него: со смещением я однажды прочитал
    /// минимум 21 м и решил, что эрозия просадила рельеф на шестьсот метров, тогда
    /// как настоящий минимум был 681 м.</param>
    /// <param name="filled">залитая поверхность, если она уже посчитана.
    /// Высоты кольца заливаются на месте ещё при построении, и своя заливка
    /// здесь давала ТО ЖЕ поле за 16 секунд на сетке 1921. Замер на стенде:
    /// повторная заливка уже залитого поля стоит 96% от первой — она не
    /// дешевеет оттого, что впадин нет.</param>
    public static string Ring(int ring, float[] h, int side, float cellWorld,
        float metresPerUnit, float[]? flow, float liftWorld = 0f,
        float[]? filled = null)
    {
        var c = CultureInfo.InvariantCulture;
        var sb = new StringBuilder();
        sb.Append("{\"ring\":").Append(ring);
        sb.Append(",\"cellM\":").Append((cellWorld * metresPerUnit).ToString("F1", c));
        sb.Append(",\"sideCells\":").Append(side - 1);
        sb.Append(",\"extentM\":")
          .Append(((side - 1) * cellWorld * metresPerUnit).ToString("F0", c));

        float lo = float.MaxValue, hi = float.MinValue;
        foreach (float v in h) { if (v < lo) lo = v; if (v > hi) hi = v; }
        sb.Append(",\"minM\":").Append(((lo - liftWorld) * metresPerUnit).ToString("F0", c));
        sb.Append(",\"maxM\":").Append(((hi - liftWorld) * metresPerUnit).ToString("F0", c));
        sb.Append(",\"liftM\":").Append((liftWorld * metresPerUnit).ToString("F0", c));

        // ---- уклоны, вогнутость, азимут ----
        var slopeHist = new int[SlopeBins.Length - 1];
        var aspect = new int[8];
        // ---- ПОРОГИ ПРОХОДИМОСТИ ----
        //
        // Раньше считалась одна доля — площадь с уклоном ниже 25°, названная
        // «проходимо». Порог был взят под пешехода и ни к чему не привязан.
        //
        // Режим передвижения решено делать на ГОРНОМ велосипеде, а у него пороги
        // другие и их несколько: подъём до 12° устойчиво и до 20° короткими
        // участками, спуск до 30°. Поэтому считаются все сразу — иначе я вычисляю
        // их вручную из гистограммы, как пришлось делать в прошлый раз.
        var passable = new int[PassableLimits.Length];
        int concave = 0, convex = 0, cells = 0;
        double slopeSum = 0;
        var slopes = new List<float>((side - 2) * (side - 2));
        for (int j = 1; j < side - 1; j++)
        for (int i = 1; i < side - 1; i++)
        {
            int k = j * side + i;
            float gx = (h[k + 1] - h[k - 1]) / (2f * cellWorld);
            float gy = (h[k + side] - h[k - side]) / (2f * cellWorld);
            float deg = MathF.Atan(MathF.Sqrt(gx * gx + gy * gy)) * 180f / MathF.PI;
            slopes.Add(deg);
            slopeSum += deg;
            cells++;
            for (int t = 0; t < PassableLimits.Length; t++)
                if (deg < PassableLimits[t]) passable[t]++;

            for (int b = 0; b < slopeHist.Length; b++)
                if (deg >= SlopeBins[b] && deg < SlopeBins[b + 1]) { slopeHist[b]++; break; }

            // Вогнутость: сумма вторых производных. Отрицательная — ложбина.
            float lap = h[k + 1] + h[k - 1] + h[k + side] + h[k - side] - 4f * h[k];
            if (lap > 0) concave++; else if (lap < 0) convex++;

            if (deg > 3f)
            {
                float a = MathF.Atan2(gy, gx) * 180f / MathF.PI;
                if (a < 0) a += 360f;
                aspect[(int)(a / 45f) % 8]++;
            }
        }
        slopes.Sort();
        sb.Append(",\"slopeMean\":").Append((slopeSum / Math.Max(cells, 1)).ToString("F1", c));
        sb.Append(",\"slopeP50\":").Append(slopes[slopes.Count / 2].ToString("F1", c));
        sb.Append(",\"slopeP95\":").Append(slopes[(int)(slopes.Count * 0.95)].ToString("F1", c));
        sb.Append(",\"slopeHist\":[");
        for (int b = 0; b < slopeHist.Length; b++)
        {
            if (b > 0) sb.Append(',');
            sb.Append((slopeHist[b] * 100f / Math.Max(cells, 1)).ToString("F1", c));
        }
        sb.Append("],\"slopeBins\":[");
        for (int b = 0; b < SlopeBins.Length; b++)
        {
            if (b > 0) sb.Append(',');
            sb.Append(SlopeBins[b].ToString("F0", c));
        }
        sb.Append(']');
        sb.Append(",\"concavePct\":")
          .Append((concave * 100f / Math.Max(concave + convex, 1)).ToString("F1", c));
        sb.Append(",\"passableLimits\":[");
        for (int t = 0; t < PassableLimits.Length; t++)
        {
            if (t > 0) sb.Append(',');
            sb.Append(PassableLimits[t].ToString("F0", c));
        }
        sb.Append("],\"passablePct\":[");
        for (int t = 0; t < PassableLimits.Length; t++)
        {
            if (t > 0) sb.Append(',');
            sb.Append((passable[t] * 100f / Math.Max(cells, 1)).ToString("F1", c));
        }
        sb.Append(']');
        sb.Append(",\"aspect\":[");
        for (int a = 0; a < 8; a++)
        {
            if (a > 0) sb.Append(',');
            sb.Append((aspect[a] * 100f / Math.Max(cells, 1)).ToString("F1", c));
        }
        sb.Append(']');

        // ---- гистограмма высот ----
        const int HeightBins = 10;
        var hHist = new int[HeightBins];
        float span = MathF.Max(hi - lo, 1e-3f);
        foreach (float v in h)
            hHist[Math.Clamp((int)((v - lo) / span * HeightBins), 0, HeightBins - 1)]++;
        // гистограмма высот от собственного минимума, поэтому смещение ей безразлично
        sb.Append(",\"heightHist\":[");
        for (int b = 0; b < HeightBins; b++)
        {
            if (b > 0) sb.Append(',');
            sb.Append((hHist[b] * 100f / h.Length).ToString("F1", c));
        }
        sb.Append(']');

        // ---- сток ----
        if (flow != null)
        {
            // ---- СТОК: ПОРОГ ОТНОСИТЕЛЬНЫЙ, А НЕ АБСОЛЮТНЫЙ ----
            //
            // Первая версия считала долю ячеек со стоком выше 200 и выдала 0.05% в
            // ближнем кольце и 0.00% в дальнем — будто русел нет. На деле порог
            // просто не подходил: на грубых кольцах ячеек меньше, и накопленный
            // сток по ним ниже при том же рисунке дренажа.
            //
            // Правильнее смотреть на распределение: где лежит верхний процент
            // стока и какая доля площади его несёт.
            var sorted = new float[flow.Length];
            Array.Copy(flow, sorted, flow.Length);
            Array.Sort(sorted);
            float fmax = sorted[^1];
            float p99 = sorted[(int)(sorted.Length * 0.99f)];
            int aboveP99 = 0, above10 = 0;
            foreach (float f in flow)
            {
                if (f >= p99) aboveP99++;
                if (f >= 10f) above10++;
            }
            sb.Append(",\"flowMax\":").Append(fmax.ToString("F0", c));
            sb.Append(",\"flowP99\":").Append(p99.ToString("F0", c));
            sb.Append(",\"flowMaxPerCells\":")
              .Append((fmax / flow.Length).ToString("F4", c));
            sb.Append(",\"flowAbove10Pct\":")
              .Append((above10 * 100f / flow.Length).ToString("F1", c));
        }

        // ---- разрезы: высоты вдоль трёх линий ----
        //
        // Сводка не показывает профиль. Три линии — по середине, по трети и по
        // диагонали — дают понять, идут ли хребты грядами или рассыпаны.
        // ---- РАЗРЕЗ ЧЕРЕЗ КРАЙНИЕ ТОЧКИ ----
        //
        // Три произвольные линии вводят в заблуждение: у одного и того же кольца
        // разрез по середине дал перепад 160 м, по трети 406, по диагонали 534, а
        // по всему кольцу — 925. Я взял первую линию и объявил ближнюю зону
        // плоской; проверка показала, что беды нет, и предложенная правка только
        // испортила бы проходимость.
        //
        // Поэтому главный разрез теперь идёт через САМУЮ ВЫСОКУЮ и САМУЮ НИЗКУЮ
        // точки кольца — он показывает настоящий размах, а не случайный. Рядом
        // пишется перепад по каждому разрезу и по кольцу целиком, чтобы
        // расхождение бросалось в глаза само.
        int iLo = 0, iHi = 0;
        for (int k = 0; k < h.Length; k++)
        {
            if (h[k] <= h[iLo]) iLo = k;
            if (h[k] >= h[iHi]) iHi = k;
        }
        sb.Append(",\"reliefRingM\":").Append(((hi - lo) * metresPerUnit).ToString("F0", c));

        // ---- МЕРЫ ПРАВДОПОДОБИЯ ----
        //
        // Прежний отчёт отвечал на вопрос «пологий рельеф или горный», но не
        // отвечал ни на один из тех, что решались последние дни: расчленён ли
        // рельеф, правдоподобна ли речная сеть, проявляется ли форма светом, есть
        // ли ямы и решётка. Разбирать это по снимкам раз за разом уводило не туда.
        //
        // Значения света берутся те же, что в сцене: солнце 1.20, рассеянный 0.10,
        // альбедо отладочной окраски 0.70.
        if (filled == null)
        {
            filled = (float[])h.Clone();
            RidgedMountains.FillDepressions(filled, side);
        }
        float minFlowCells = 1.7e6f / (cellWorld * metresPerUnit * cellWorld * metresPerUnit);
        sb.Append(',').Append(TerrainMetrics.ToJson(h, side, cellWorld, metresPerUnit,
                                                    1.20f, 0.10f, 0.70f, minFlowCells, filled));
        sb.Append(",\"profiles\":{");
        AppendLine(sb, "extremes", h, side, iLo % side, iLo / side, iHi % side, iHi / side,
                   metresPerUnit, c, liftWorld);
        sb.Append(',');
        AppendLine(sb, "mid", h, side, 0, side / 2, side - 1, side / 2,
                   metresPerUnit, c, liftWorld);
        sb.Append(',');
        AppendLine(sb, "diag", h, side, 0, 0, side - 1, side - 1,
                   metresPerUnit, c, liftWorld);
        sb.Append('}');

        sb.Append('}');
        return sb.ToString();
    }

    /// <summary>
    /// Разрез по прямой между двумя узлами сетки. Рядом с высотами пишется перепад
    /// этого разреза — чтобы было видно, насколько он представителен.
    /// </summary>
    private static void AppendLine(StringBuilder sb, string name, float[] h, int side,
        int i0, int j0, int i1, int j1, float metresPerUnit, CultureInfo c, float lift)
    {
        const int Samples = 64;
        float lo = float.MaxValue, hi = float.MinValue;
        var vals = new float[Samples];
        for (int s = 0; s < Samples; s++)
        {
            float t = s / (float)(Samples - 1);
            int i = Math.Clamp((int)MathF.Round(i0 + (i1 - i0) * t), 0, side - 1);
            int j = Math.Clamp((int)MathF.Round(j0 + (j1 - j0) * t), 0, side - 1);
            float v = (h[j * side + i] - lift) * metresPerUnit;
            vals[s] = v;
            if (v < lo) lo = v;
            if (v > hi) hi = v;
        }
        sb.Append('"').Append(name).Append("\":{\"reliefM\":").Append((hi - lo).ToString("F0", c));
        sb.Append(",\"h\":[");
        for (int s = 0; s < Samples; s++)
        {
            if (s > 0) sb.Append(',');
            sb.Append(vals[s].ToString("F0", c));
        }
        sb.Append("]}");
    }

    /// <summary>
    /// ВЫГРУЗКА САМИХ СЕТОК ВЫСОТ — двоичный файл рядом с отчётом.
    ///
    /// Сводка отвечает на вопросы, которые я догадался задать. Сетка отвечает на
    /// любые: по ней можно посчитать что угодно и нарисовать рельеф, не спрашивая
    /// снимков. За эту неделю я четырежды промахнулся именно потому, что судил по
    /// одной величине или одному разрезу.
    ///
    /// Цена невелика: пять колец по 121x121 отсчёту это 0.3 МБ высот и столько же
    /// стока.
    ///
    /// Формат простой, чтобы читался чем угодно:
    ///     "CBTR", версия int32 (=4), число колец int32
    ///     на кольцо: номер int32, сторона int32, шаг float32, смещение float32,
    ///                сторона² высот float32, столько же стока float32,
    ///                сторона² байтов покрова,
    ///                затем сторона² по три байта ЦВЕТА (r, g, b)
    ///
    /// Покров добавлен во второй версии: без него нельзя разбирать, почему рельеф
    /// выглядит так, а не иначе — приходилось возвращаться к снимкам.
    ///
    /// ТРЕТЬЯ ВЕРСИЯ — из неё убран Marsh, и номера видов покрова сдвинулись:
    /// теперь Water, Grassland, Forest, Shrubland, Alpine, Scree, Rock, Snow.
    /// Версия поднята НАРОЧНО: старые выгрузки надо читать по своей нумерации,
    /// иначе лес будет прочитан как луг и разбор старых замеров окажется ложным.
    /// ЧЕТВЁРТАЯ ВЕРСИЯ — добавлен ЦВЕТ вершины. Покров и цвет перестали быть
    /// одним и тем же с введением геологии: камень и осыпь красятся по породе
    /// места, поэтому один и тот же вид покрова имеет разный цвет в разных частях
    /// территории. Без цвета в выгрузке палитру приходилось восстанавливать по
    /// таблице биомов, а она этого уже не описывает.
    ///
    /// Все величины в мировых единицах, порядок байтов как у машины.
    /// </summary>
    /// <summary>
    /// ---- СЛОЙ ВОДЫ ДОБАВЛЕН (V380) ----
    ///
    /// Прежде в файле лежали высота, сток, пояс и цвет. По ним НЕЛЬЗЯ отличить
    /// озеро от сухой чаши: обе выглядят низиной, а есть ли в ней вода —
    /// неизвестно.
    ///
    /// Именно эту беду пользователь видел на снимках и не мог показать иначе,
    /// как обводя красным.
    ///
    /// Слой `water` — глубина воды в метрах, ноль при её отсутствии. По нему
    /// строится любой разрез: озеро с узким берегом или лужа на дне широкой
    /// чаши различаются сразу.
    ///
    /// Цена: 4 байта на ячейку, 3.7 МБ на кольцо 961. Для двоичного файла это
    /// немного, а разбирать по нему можно как угодно.
    /// </summary>
    public static string WriteRaw(IReadOnlyList<(int ring, int side, float cellWorld,
        float lift, float[] height, float[] flow, byte[] biome, byte[] color,
        float[] water)> rings)
    {
        string dir = GenerationLog.LogDirectory;
        Directory.CreateDirectory(dir);
        string path = Path.Combine(dir,
            DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_terrain.bin");
        using var fs = new FileStream(path, FileMode.Create);
        using var bw = new BinaryWriter(fs);
        bw.Write(new[] { (byte)'C', (byte)'B', (byte)'T', (byte)'R' });
        // Пятая версия: добавлен слой воды.
        bw.Write(5);
        bw.Write(rings.Count);
        foreach (var r in rings)
        {
            bw.Write(r.ring);
            bw.Write(r.side);
            bw.Write(r.cellWorld);
            bw.Write(r.lift);
            foreach (float v in r.height) bw.Write(v);
            for (int k = 0; k < r.height.Length; k++)
                bw.Write(r.flow != null && k < r.flow.Length ? r.flow[k] : 0f);
            for (int k = 0; k < r.height.Length; k++)
                bw.Write(r.biome != null && k < r.biome.Length ? r.biome[k] : (byte)0);
            for (int k = 0; k < r.height.Length; k++)
            {
                int o = k * 3;
                // Локальная переменная вместо тройного оператора: через него
                // компилятор не видит проверку на пустоту и предупреждает.
                var col = r.color;
                if (col != null && o + 2 < col.Length)
                {
                    bw.Write(col[o]);
                    bw.Write(col[o + 1]);
                    bw.Write(col[o + 2]);
                }
                else
                {
                    bw.Write((byte)0);
                    bw.Write((byte)0);
                    bw.Write((byte)0);
                }
            }

            // Слой воды: глубина в метрах, ноль при отсутствии.
            for (int k = 0; k < r.height.Length; k++)
                bw.Write(r.water != null && k < r.water.Length ? r.water[k] : 0f);
        }
        return path;
    }

    /// <summary>Сложить отчёты колец в один файл и вернуть путь.</summary>
    public static string Write(IEnumerable<string> ringReports, string extra)
    {
        string dir = GenerationLog.LogDirectory;
        Directory.CreateDirectory(dir);
        string path = Path.Combine(dir,
            DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_terrain.json");
        var sb = new StringBuilder();
        sb.Append("{\"rings\":[");
        bool first = true;
        foreach (string r in ringReports)
        {
            if (!first) sb.Append(',');
            sb.Append(r);
            first = false;
        }
        sb.Append(']');
        if (!string.IsNullOrEmpty(extra)) sb.Append(',').Append(extra);
        sb.Append('}');
        File.WriteAllText(path, sb.ToString());
        return path;
    }
}
