using Godot;
using ColoringBook.Domain.Level;
using ColoringBook.Domain.Level.Season;

namespace ColoringBook.Presentation.Level;

/// <summary>
/// Одномерные градиентные полосы для окраски рельефа.
///
/// ЗАЧЕМ. Цвет поверхности лежал целиком в цвете вершин, а значит разрешение окраски
/// равнялось разрешению сетки высот 192×192: граница между биомами интерполировалась
/// между узлами и размазывалась на 11–13 точек экрана. Полоса вычисляется на фрагмент,
/// поэтому снеговая линия и выход породы получаются ровно там, где проходит отметка.
///
/// Полосы строятся ТЕМ ЖЕ SeasonColorMapper, что и прежняя окраска, — иначе цвета
/// разъехались бы с растительностью и водой, которые красятся по нему же. Меняется
/// не палитра, а способ её выборки.
///
/// Стоимость: две текстуры 256×1 RGBA на сезон, то есть 2 КБ. Смена сезона — подмена
/// этих текстур вместо перезаписи всего массива цветов и перестроения меша.
/// </summary>
public static class TerrainGradient
{
    public const int Steps = 256;

    /// <summary>
    /// Полоса «по высоте»: пологая поверхность от дна долины до вершины.
    ///
    /// Биом на каждом шаге выбирается по отметке — той же лестницей, что и в
    /// генераторе. Одномерная полоса по определению не различает биомы, лежащие на
    /// ОДНОЙ высоте (луг и лес), поэтому такое различие остаётся за подмешиванием
    /// цвета вершины в шейдере (biome_tint_weight).
    /// </summary>
    public static ImageTexture BuildHeightRamp(SeasonType season, float heightScale)
    {
        var img = Image.CreateEmpty(Steps, 1, false, Image.Format.Rgba8);
        for (int i = 0; i < Steps; i++)
        {
            float y = (float)i / (Steps - 1) * heightScale;
            float elev = ElevationForWorldY(y, heightScale);
            var c = SeasonColorMapper.GetColor(BiomeForElevation(elev), elev, 0.5f, 0f, season);
            img.SetPixel(i, 0, c);
        }
        return ImageTexture.CreateFromImage(img);
    }

    /// <summary>
    /// Полоса «скала»: чем красить крутизну на каждой высоте. Ниже границы леса это
    /// порода, выше — осыпь, у самой вершины — заснеженный камень.
    /// </summary>
    public static ImageTexture BuildRockRamp(SeasonType season, float heightScale)
    {
        var img = Image.CreateEmpty(Steps, 1, false, Image.Format.Rgba8);
        for (int i = 0; i < Steps; i++)
        {
            float y = (float)i / (Steps - 1) * heightScale;
            float elev = ElevationForWorldY(y, heightScale);
            var biome = elev > 0.80f ? BiomeType.Snow
                      : elev > 0.60f ? BiomeType.Scree
                      : BiomeType.Rock;
            // Уклон передаём максимальный: именно скальный вариант нам и нужен.
            var c = SeasonColorMapper.GetColor(biome, elev, 0.25f, 12f, season);
            img.SetPixel(i, 0, c);
        }
        return ImageTexture.CreateFromImage(img);
    }

    /// <summary>
    /// Обратное к построению меша: там y = pow(elev, 1.15) · HeightScale.
    /// Полоса индексируется мировой высотой, потому что в шейдере доступна именно она,
    /// а не отметка.
    /// </summary>
    private static float ElevationForWorldY(float worldY, float heightScale)
    {
        float norm = Mathf.Clamp(worldY / Mathf.Max(heightScale, 1e-3f), 0f, 1f);
        return Mathf.Pow(norm, 1f / 1.15f);
    }

    /// <summary>
    /// Биом по отметке для пологой поверхности. Пороги те же, что использует
    /// классификация регионов; здесь берётся «типичный» биом высоты, а конкретный
    /// биом региона добавляется подмешиванием цвета вершины.
    /// </summary>
    private static BiomeType BiomeForElevation(float elev) => elev switch
    {
        < 0.22f => BiomeType.Grassland,
        < 0.42f => BiomeType.Forest,
        < 0.58f => BiomeType.Shrubland,
        < 0.72f => BiomeType.Scree,
        < 0.86f => BiomeType.Rock,
        _ => BiomeType.Snow,
    };
}
