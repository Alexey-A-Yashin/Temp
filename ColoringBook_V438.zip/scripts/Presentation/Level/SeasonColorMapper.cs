using Godot;
using ColoringBook.Domain.Level;
using ColoringBook.Domain.Level.Season;

namespace ColoringBook.Presentation.Level;

/// <summary>
/// Сезонная модуляция цветов биомов.
/// Зима: снег на вершинах, скалы и хвойный лес остаются читаемыми.
/// Осень: жёлтый / оранжевый / коричневый разброс.
/// </summary>
public static class SeasonColorMapper
{
    public static Color GetColor(BiomeType biome, float elevation, SeasonType season)
        => GetColor(biome, elevation, 0.5f, 0f, season);

    /// <summary>
    /// Цвет поверхности с учётом ВЛАЖНОСТИ и УКЛОНА, а не только высоты.
    ///
    /// Зачем: раньше цвет зависел лишь от биома и высоты, поэтому Shrubland — самый
    /// большой биом (4533 региона, 33% карты) — закрашивался ОДНИМ плоским оливковым
    /// тоном, и треть уровня выглядела однородным хаки. То же касалось луга и леса.
    /// Теперь внутри биома есть разброс: сухое/влажное различаются по тону, а на
    /// крутизне сквозь дёрн проступает порода. Последнее заодно смягчает резкие
    /// границы между биомами: переход идёт по уклону, а не строго по порогу высоты.
    /// </summary>
    public static Color GetColor(BiomeType biome, float elevation, float moisture, float slope, SeasonType season)
    {
        var baseColor = GetBaseColor(biome, elevation, moisture);
        baseColor = ApplyRockShowThrough(baseColor, biome, slope);
        return ApplySeason(baseColor, biome, elevation, season);
    }

    /// <summary>
    /// На крутом склоне сквозь растительный покров проступает камень. Доля породы
    /// растёт с уклоном (пороги согласованы с AlpineTerrain: осыпь от 7.5, обрыв от 11).
    /// Для воды, снега и уже каменистых биомов не применяется — там смешивать не с чем.
    /// </summary>
    private static Color ApplyRockShowThrough(Color c, BiomeType biome, float slope)
    {
        if (biome is BiomeType.Lake or BiomeType.Ocean or BiomeType.Snow
            or BiomeType.Rock or BiomeType.Scree)
            return c;
        // 0 на пологом, ~0.55 к обрыву — полностью породу не показываем, иначе
        // пропадёт различие между «лугом на склоне» и настоящей скалой.
        float t = Mathf.Clamp((slope - 3.5f) / 9f, 0f, 1f) * 0.55f;
        return c.Lerp(new Color(0.56f, 0.54f, 0.50f), t);
    }

    public static Color GetRiverColor(float flux, SeasonType season)
    {
        float t = Mathf.Clamp(flux / 40f, 0.3f, 1f);
        var summer = new Color(0.25f, 0.65f, 0.95f).Lerp(new Color(0.15f, 0.40f, 0.85f), t);
        return season switch
        {
            SeasonType.Winter => new Color(0.50f, 0.68f, 0.85f).Lerp(new Color(0.35f, 0.52f, 0.75f), t),
            SeasonType.Autumn => summer.Lerp(new Color(0.28f, 0.50f, 0.70f), 0.20f),
            SeasonType.Spring => summer.Lerp(new Color(0.35f, 0.75f, 0.95f), 0.15f),
            _ => summer
        };
    }

    private static Color GetBaseColor(BiomeType biome, float elev, float m = 0.5f)
    {
        // Влажность НОРМИРУЕТСЯ по фактическому диапазону каждого биома, а не по
        // абсолютной шкале 0..1. Замер (High, seed 42) показал, что диапазоны разные и
        // узкие: у Grassland влажность идёт всего от 0.15 до 0.36, у Shrubland от 0.36
        // до 0.88, у Forest от 0.46 до 0.88. Если брать абсолютное значение, луг
        // получился бы сплошь соломенным (он весь в сухом конце шкалы), а весь разброс
        // тона пропал бы. Нормировка растягивает реальный диапазон на весь ход цвета.
        static float Norm(float v, float lo, float hi) => Mathf.Clamp((v - lo) / (hi - lo), 0f, 1f);
        float wetGrass = Norm(m, 0.12f, 0.40f);
        float wetShrub = Norm(m, 0.33f, 0.90f);
        float wetForest = Norm(m, 0.44f, 0.90f);
        float wet = Mathf.Clamp(m, 0f, 1f);
        return biome switch
        {
            BiomeType.Ocean => new Color(0.12f, 0.28f, 0.68f),
            BiomeType.Lake => new Color(0.20f, 0.48f, 0.80f),
            BiomeType.Beach => new Color(0.90f, 0.84f, 0.55f),
            // Луг: сухая солома против сочной травы.
            BiomeType.Grassland => new Color(0.62f, 0.68f, 0.34f)
                .Lerp(new Color(0.40f, 0.76f, 0.32f), wetGrass),
            // Лес: выше по склону темнее и синее (хвойный), ниже — светлее лиственный.
            BiomeType.Forest => new Color(0.22f, 0.48f, 0.20f)
                .Lerp(new Color(0.11f, 0.32f, 0.20f), Mathf.Clamp((elev - 0.20f) / 0.35f, 0f, 1f))
                .Lerp(new Color(0.16f, 0.46f, 0.24f), wetForest * 0.45f),
            // Кустарник/редколесье — самый большой биом, поэтому разброс тут важнее
            // всего: от сухого выгоревшего хаки до сочного зелёного по влажности,
            // плюс лёгкое высветление с высотой.
            BiomeType.Shrubland => new Color(0.62f, 0.60f, 0.34f)
                .Lerp(new Color(0.38f, 0.58f, 0.28f), wetShrub)
                .Lerp(new Color(0.70f, 0.70f, 0.55f), Mathf.Clamp((elev - 0.45f) / 0.4f, 0f, 1f) * 0.35f),
            BiomeType.Rock => new Color(0.50f, 0.48f, 0.45f).Lerp(new Color(0.65f, 0.63f, 0.60f), elev),
            // Осыпь светлее и теплее монолитной скалы — это раздробленный, обкатанный
            // материал, а не тёмная мокрая стена. Отличие по цвету нужно, чтобы уклон
            // читался на карте, а не сливался в один серый.
            BiomeType.Scree => new Color(0.60f, 0.57f, 0.52f).Lerp(new Color(0.72f, 0.70f, 0.66f), elev),
            BiomeType.Snow => new Color(0.92f, 0.94f, 0.97f),
            _ => Colors.Magenta
        };
    }

    private static Color ApplySeason(Color c, BiomeType biome, float elev, SeasonType season)
    {
        switch (season)
        {
            case SeasonType.Winter:
                // Снег только на высоких местах; скалы серые; лес тёмно-хвойный;
                // луга слегка припорошены, но остаются читаемыми.
                if (biome == BiomeType.Snow)
                    return new Color(0.93f, 0.95f, 0.98f);

                if (biome is BiomeType.Rock or BiomeType.Scree)
                {
                    // Нижние скалы — серые; выше ~0.7 — шапка снега
                    if (elev > 0.72f)
                        return new Color(0.88f, 0.90f, 0.94f);
                    if (elev > 0.55f)
                        return new Color(0.62f, 0.60f, 0.58f).Lerp(new Color(0.85f, 0.87f, 0.92f), (elev - 0.55f) / 0.20f);
                    return new Color(0.48f, 0.46f, 0.44f);
                }

                if (biome == BiomeType.Forest)
                {
                    // Хвойный тёмно-зелёный; только высоко — иней
                    if (elev > 0.50f)
                        return new Color(0.30f, 0.40f, 0.32f).Lerp(new Color(0.70f, 0.76f, 0.82f), 0.45f);
                    return new Color(0.12f, 0.28f, 0.18f);
                }

                if (biome is BiomeType.Grassland or BiomeType.Shrubland)
                {
                    // Припорошенный луг, но не белый
                    float snow = elev > 0.35f ? 0.35f : 0.18f;
                    return new Color(0.55f, 0.62f, 0.48f).Lerp(new Color(0.82f, 0.86f, 0.90f), snow);
                }

                if (biome == BiomeType.Lake)
                    return new Color(0.58f, 0.72f, 0.86f); // светлый лёд, но не белый

                if (biome == BiomeType.Beach)
                    return c.Lerp(new Color(0.80f, 0.82f, 0.85f), 0.35f);

                return c.Lerp(new Color(0.80f, 0.84f, 0.88f), 0.25f);

            case SeasonType.Spring:
                if (biome == BiomeType.Grassland)
                    return new Color(0.52f, 0.84f, 0.38f);
                if (biome == BiomeType.Forest)
                    return new Color(0.20f, 0.55f, 0.24f);
                if (biome == BiomeType.Shrubland)
                    return new Color(0.58f, 0.72f, 0.38f);
                if (biome == BiomeType.Lake)
                    return new Color(0.25f, 0.58f, 0.88f);
                if (biome is (BiomeType.Rock or BiomeType.Scree) && elev > 0.70f)
                    return new Color(0.85f, 0.88f, 0.92f); // остаточный снег на пиках
                return c;

            case SeasonType.Autumn:
                // Разброс: жёлтый луг, оранжевый лес, коричневый кустарник
                if (biome == BiomeType.Forest)
                {
                    // Низ — оранжевый, выше — коричнево-красный
                    return new Color(0.78f, 0.48f, 0.12f).Lerp(new Color(0.55f, 0.22f, 0.08f), elev * 1.2f);
                }
                if (biome == BiomeType.Grassland)
                {
                    // Жёлто-золотой с лёгким зеленоватым оттенком в низинах
                    return elev < 0.20f
                        ? new Color(0.72f, 0.68f, 0.28f)
                        : new Color(0.82f, 0.62f, 0.18f);
                }
                if (biome == BiomeType.Shrubland)
                    return new Color(0.62f, 0.42f, 0.18f).Lerp(new Color(0.48f, 0.32f, 0.12f), elev);
                if (biome == BiomeType.Lake)
                    return new Color(0.20f, 0.40f, 0.68f);
                if (biome == BiomeType.Rock)
                    return new Color(0.52f, 0.48f, 0.44f).Lerp(new Color(0.60f, 0.55f, 0.50f), elev);
                return c;

            case SeasonType.Summer:
            default:
                if (biome == BiomeType.Grassland)
                    return new Color(0.42f, 0.75f, 0.30f);
                if (biome == BiomeType.Forest)
                    return new Color(0.12f, 0.48f, 0.16f);
                if (biome == BiomeType.Lake)
                    return new Color(0.18f, 0.52f, 0.85f);
                return c;
        }
    }
}
