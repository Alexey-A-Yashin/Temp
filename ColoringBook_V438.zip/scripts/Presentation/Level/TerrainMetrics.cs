using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace ColoringBook.Presentation.Level;

/// <summary>
/// МЕРЫ ПРАВДОПОДОБИЯ РЕЛЬЕФА ДЛЯ ОТЧЁТА.
///
/// ---- ЗАЧЕМ ЗАВЕДЕНО ----
///
/// Разбор шёл по снимкам, и это раз за разом уводило не туда: снимок показывает
/// кусок под одним ракурсом, а числа — весь уровень. Проверка показала, что
/// прежний отчёт отвечал на вопрос «пологий рельеф или горный», но не отвечал ни
/// на один из тех, что решались последние дни:
///
///     расчленён ли рельеф            нечем мерить
///     правдоподобна ли речная сеть   нечем
///     проявляется ли рельеф светом   нечем
///     есть ли ямы и шипы             нечем
///     есть ли диагональная решётка   aspect по 8 секторам слишком груб
///
/// Здесь собраны меры, которыми это проверяется. Все взяты из литературы, а не
/// придуманы: своя мера «смен знака склона на километр» оказалась негодной —
/// считала любую рябь и росла, пока картинка портилась.
/// </summary>
public static class TerrainMetrics
{
    /// <summary>Виды форм по геоморфонам, в порядке от вершины к яме.</summary>
    public static readonly string[] GeomorphonNames =
        { "peak", "ridge", "shoulder", "spur", "slope", "hollow", "footslope", "valley", "pit" };

    /// <summary>
    /// Природное распределение форм для горного рельефа, доли процента.
    /// По нему считается отклонение — чем меньше, тем правдоподобнее.
    /// </summary>
    public static readonly double[] NaturalGeomorphons = { 2, 8, 10, 15, 38, 15, 8, 4, 0 };

    /// <summary>
    /// ГЕОМОРФОНЫ (Jasiewicz и Stepinski; основа меры восприятия PTRM).
    ///
    /// Каждая точка относится к одному из десяти видов по тому, сколько из восьми
    /// направлений идут вверх и сколько вниз. У настоящих гор распределение этих
    /// видов устойчиво, и именно оно, по перцептивным опытам, определяет ощущение
    /// правдоподобия.
    /// </summary>
    public static double[] Geomorphons(float[] h, int side, float cellWorld, int radius)
    {
        var res = new double[9];
        int total = 0;
        int[] dx = { 1, 1, 0, -1, -1, -1, 0, 1 }, dy = { 0, 1, 1, 1, 0, -1, -1, -1 };
        for (int j = radius; j < side - radius; j++)
        for (int i = radius; i < side - radius; i++)
        {
            int plus = 0, minus = 0;
            float h0 = h[j * side + i];
            for (int k = 0; k < 8; k++)
            {
                float upMax = -1e9f, dnMax = -1e9f;
                for (int r = 1; r <= radius; r++)
                {
                    int x = i + dx[k] * r, y = j + dy[k] * r;
                    if (x < 0 || y < 0 || x >= side || y >= side) break;
                    float dist = r * cellWorld * ((k % 2 == 0) ? 1f : 1.41421f);
                    float ang = (h[y * side + x] - h0) / dist;
                    if (ang > upMax) upMax = ang;
                    if (-ang > dnMax) dnMax = -ang;
                }
                const float flat = 0.03f;          // около 1.7°
                if (upMax > flat && upMax > dnMax) plus++;
                else if (dnMax > flat && dnMax > upMax) minus++;
            }
            res[Classify(plus, minus)]++;
            total++;
        }
        for (int k = 0; k < res.Length; k++) res[k] = res[k] * 100.0 / Math.Max(total, 1);
        return res;
    }

    private static int Classify(int plus, int minus)
    {
        int d = minus - plus;
        if (plus == 0 && minus >= 7) return 0;
        if (d >= 5) return 1;
        if (d >= 3) return 2;
        if (d >= 1) return 3;
        if (d == 0) return 4;
        if (d >= -2) return 5;
        if (d >= -4) return 6;
        if (minus == 0 && plus >= 7) return 8;
        return 7;
    }

    /// <summary>Отклонение распределения форм от природного. Меньше — лучше.</summary>
    public static double GeomorphonDeviation(double[] g)
    {
        double d = 0;
        for (int i = 0; i < 9 && i < g.Length; i++) d += Math.Abs(g[i] - NaturalGeomorphons[i]);
        return d;
    }

    /// <summary>
    /// ЗАКОН ХОРТОНА (1945). Русла нумеруются по порядку Стралера: два русла
    /// первого порядка при слиянии дают второй. Отношение числа русел соседних
    /// порядков у настоящих рек 3–5.
    ///
    /// Случайная рябь этому не подчиняется — на ней порядок вырождается в единицу.
    /// Это и отличает упорядоченное расчленение от шума.
    /// </summary>
    public static (double ratio, int maxOrder) HortonRatio(float[] surfaceFilled, int side,
                                                           float minFlowCells)
    {
        var order = new int[side * side];
        var recv = new int[side * side];
        var flow = new float[side * side];
        for (int k = 0; k < side * side; k++) { order[k] = k; flow[k] = 1f; recv[k] = -1; }
        Array.Sort(order, (a, b) => surfaceFilled[b].CompareTo(surfaceFilled[a]));
        foreach (int c in order)
        {
            int i = c % side, j = c / side, best = -1; float drop = 0;
            for (int dj = -1; dj <= 1; dj++)
            for (int di = -1; di <= 1; di++)
            {
                if (di == 0 && dj == 0) continue;
                int x = i + di, y = j + dj;
                if (x < 0 || y < 0 || x >= side || y >= side) continue;
                float d = surfaceFilled[c] - surfaceFilled[y * side + x];
                if (d > drop) { drop = d; best = y * side + x; }
            }
            recv[c] = best;
            if (best >= 0) flow[best] += flow[c];
        }

        var strahler = new int[side * side];
        var upstream = new List<int>[side * side];
        for (int c = 0; c < side * side; c++)
            if (flow[c] >= minFlowCells && recv[c] >= 0 && flow[recv[c]] >= minFlowCells)
                (upstream[recv[c]] ??= new List<int>()).Add(c);

        // Обход от истоков к устью: order отсортирован по убыванию высоты.
        for (int q = 0; q < order.Length; q++)
        {
            int c = order[q];
            if (flow[c] < minFlowCells) continue;
            var ups = upstream[c];
            if (ups == null || ups.Count == 0) { strahler[c] = 1; continue; }
            int mx = 0, cnt = 0;
            foreach (int u in ups)
            {
                if (strahler[u] > mx) { mx = strahler[u]; cnt = 1; }
                else if (strahler[u] == mx) cnt++;
            }
            strahler[c] = cnt >= 2 ? mx + 1 : mx;
        }

        int maxOrd = 0;
        for (int c = 0; c < side * side; c++) maxOrd = Math.Max(maxOrd, strahler[c]);
        var counts = new int[maxOrd + 2];
        for (int c = 0; c < side * side; c++)
        {
            int s = strahler[c];
            if (s == 0) continue;
            bool isStart = upstream[c] == null || upstream[c].Count == 0;
            if (!isStart)
            {
                int mx = 0, cnt = 0;
                foreach (int u in upstream[c])
                {
                    if (strahler[u] > mx) { mx = strahler[u]; cnt = 1; }
                    else if (strahler[u] == mx) cnt++;
                }
                isStart = cnt >= 2;
            }
            if (isStart) counts[s]++;
        }
        double sum = 0; int n = 0;
        for (int s = 1; s < maxOrd; s++)
            if (counts[s] > 0 && counts[s + 1] > 0) { sum += (double)counts[s] / counts[s + 1]; n++; }
        return (n > 0 ? sum / n : 0, maxOrd);
    }

    /// <summary>
    /// РАЗМАХ СВЕТОТЕНИ: насколько форма ПРОЯВЛЯЕТСЯ светом.
    ///
    /// Без этой меры я дважды правил геометрию, тогда как форма была на месте, а
    /// свет её не показывал: замер по снимку дал размах 0.12 при 0.43 в стенде.
    ///
    /// Считается по тому же закону, что и в шейдере: яркость = альбедо × (солнце ×
    /// косинус угла + рассеянный).
    /// </summary>
    public static (double range, double median, double clipped) Shading(
        float[] h, int side, float cellWorld, float sun, float ambient, float albedo)
    {
        // свет с северо-запада и сверху, как у нас в сцене
        float lx = -0.40f, ly = 0.71f, lz = -0.58f;
        var vals = new List<double>();
        int clip = 0;
        for (int j = 1; j < side - 1; j++)
        for (int i = 1; i < side - 1; i++)
        {
            float gx = (h[j * side + i + 1] - h[j * side + i - 1]) / (2f * cellWorld);
            float gz = (h[(j + 1) * side + i] - h[(j - 1) * side + i]) / (2f * cellWorld);
            float nx = -gx, ny = 1f, nz = -gz;
            float len = MathF.Sqrt(nx * nx + ny * ny + nz * nz);
            float ndl = Math.Clamp((nx * lx + ny * ly + nz * lz) / len, 0f, 1f);
            double lum = albedo * (sun * ndl + ambient);
            if (lum > 0.98) clip++;
            vals.Add(lum);
        }
        vals.Sort();
        double p10 = vals[vals.Count / 10], p90 = vals[vals.Count * 9 / 10];
        return (p90 - p10, vals[vals.Count / 2], 100.0 * clip / vals.Count);
    }

    /// <summary>Ямы и шипы: узлы, отличающиеся от ВСЕХ соседей больше порога.
    /// Это не то же, что вогнутость: вогнутых мест много и они законны.</summary>
    public static (int pits, int spikes, double worstPitM, double worstSpikeM) PitsAndSpikes(
        float[] h, int side, float thresholdM, float metresPerUnit)
    {
        int pits = 0, spikes = 0;
        double wp = 0, ws = 0;
        for (int j = 1; j < side - 1; j++)
        for (int i = 1; i < side - 1; i++)
        {
            float c = h[j * side + i];
            float mn = float.MaxValue, mx = float.MinValue;
            for (int dj = -1; dj <= 1; dj++)
            for (int di = -1; di <= 1; di++)
            {
                if (di == 0 && dj == 0) continue;
                float v = h[(j + dj) * side + i + di];
                if (v < mn) mn = v; if (v > mx) mx = v;
            }
            double down = (mn - c) * metresPerUnit;
            double up = (c - mx) * metresPerUnit;
            if (down > thresholdM) { pits++; if (down > wp) wp = down; }
            if (up > thresholdM) { spikes++; if (up > ws) ws = up; }
        }
        return (pits, spikes, wp, ws);
    }

    /// <summary>Распределение направлений склона по 36 секторам: ловит решётку.
    /// Возвращает перекос (наибольший сектор к равномерному) и долю диагоналей.
    /// У равномерного распределения перекос 1.0, диагоналей 11.1%.</summary>
    public static (double bias, double diagonalPct) AspectBias(float[] h, int side, float cellWorld)
    {
        var hist = new double[36];
        double total = 0;
        for (int j = 1; j < side - 1; j++)
        for (int i = 1; i < side - 1; i++)
        {
            double gx = (h[j * side + i + 1] - h[j * side + i - 1]) / (2 * cellWorld);
            double gz = (h[(j + 1) * side + i] - h[(j - 1) * side + i]) / (2 * cellWorld);
            double m = Math.Sqrt(gx * gx + gz * gz);
            if (m < 0.02) continue;
            double a = (Math.Atan2(gz, gx) * 180 / Math.PI + 360) % 360;
            hist[(int)(a / 10) % 36] += m;
            total += m;
        }
        if (total <= 0) return (0, 0);
        double mx2 = 0;
        for (int k = 0; k < 36; k++) { hist[k] = hist[k] / total * 100; if (hist[k] > mx2) mx2 = hist[k]; }
        double diag = hist[4] + hist[13] + hist[22] + hist[31];
        return (mx2 / (100.0 / 36), diag);
    }

    /// <summary>Собирает все меры кольца в строку JSON.</summary>
    public static string ToJson(float[] h, int side, float cellWorld, float metresPerUnit,
                                float sun, float ambient, float albedo, float minFlowCells,
                                float[] surfaceFilled)
    {
        var ci = CultureInfo.InvariantCulture;
        var sb = new StringBuilder();
        var g = Geomorphons(h, side, cellWorld, 4);
        var (bias, diag) = AspectBias(h, side, cellWorld);
        var (range, medLum, clip) = Shading(h, side, cellWorld, sun, ambient, albedo);
        var (pits, spikes, wp, ws) = PitsAndSpikes(h, side, 10f, metresPerUnit);

        sb.Append("\"geomorphons\":{");
        for (int i = 0; i < 9; i++)
        {
            if (i > 0) sb.Append(',');
            sb.Append('"').Append(GeomorphonNames[i]).Append("\":")
              .Append(g[i].ToString("F1", ci));
        }
        sb.Append("},\"geomorphonDeviation\":")
          .Append(GeomorphonDeviation(g).ToString("F1", ci));
        sb.Append(",\"aspectBias\":").Append(bias.ToString("F2", ci));
        sb.Append(",\"diagonalPct\":").Append(diag.ToString("F1", ci));
        sb.Append(",\"shadingRange\":").Append(range.ToString("F3", ci));
        sb.Append(",\"shadingMedian\":").Append(medLum.ToString("F3", ci));
        sb.Append(",\"shadingClippedPct\":").Append(clip.ToString("F1", ci));
        sb.Append(",\"pits\":").Append(pits.ToString(ci));
        sb.Append(",\"spikes\":").Append(spikes.ToString(ci));
        sb.Append(",\"worstPitM\":").Append(wp.ToString("F0", ci));
        sb.Append(",\"worstSpikeM\":").Append(ws.ToString("F0", ci));
        if (surfaceFilled != null)
        {
            var (rb, ord) = HortonRatio(surfaceFilled, side, minFlowCells);
            sb.Append(",\"hortonRatio\":").Append(rb.ToString("F2", ci));
            sb.Append(",\"hortonMaxOrder\":").Append(ord.ToString(ci));
        }
        return sb.ToString();
    }
}
