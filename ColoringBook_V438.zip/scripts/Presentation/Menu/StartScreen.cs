using Godot;
using ColoringBook.Application;

namespace ColoringBook.Presentation.Menu;

/// <summary>
/// СТАРТОВЫЙ ЭКРАН.
///
/// Слой представления в чистом виде (книга, 9.1 и 9.3): не генерирует уровень, не
/// читает снимки, ничего не решает. Он только СООБЩАЕТ О НАМЕРЕНИИ — «хочу на уровень»,
/// «хочу в галерею» — а исполняет его маршрутизатор. Поэтому добавление третьей кнопки
/// или переход на сенсорный ввод не затрагивает ничего, кроме этого файла.
///
/// UI строится кодом, а не .tscn, — так же, как остальной интерфейс проекта, чтобы
/// не разносить описание по двум местам.
/// </summary>
public sealed partial class StartScreen : CanvasLayer
{
    private SceneRouter? _router;

    public void Bind(SceneRouter router)
    {
        _router = router;
        BuildUi();
    }

    private void BuildUi()
    {
        // ВАЖНО: одних якорей мало. В Godot 4 установка AnchorRight/AnchorBottom не
        // пересчитывает отступы, и контрол остаётся нулевого размера — интерфейс
        // строится, но не виден. Размер задаётся пресетом.
        var root = new Control { MouseFilter = Control.MouseFilterEnum.Ignore };
        AddChild(root);
        root.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);

        var bg = new ColorRect { Color = new Color(0.08f, 0.10f, 0.13f, 1f) };
        root.AddChild(bg);
        bg.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);

        var box = new VBoxContainer();
        box.AddThemeConstantOverride("separation", 18);
        root.AddChild(box);
        box.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.Center);
        box.GrowHorizontal = Control.GrowDirection.Both;
        box.GrowVertical = Control.GrowDirection.Both;

        var title = new Label
        {
            Text = "ColoringBook",
            HorizontalAlignment = HorizontalAlignment.Center,
        };
        title.AddThemeFontSizeOverride("font_size", 44);
        box.AddChild(title);

        var hint = new Label
        {
            Text = "Плывите по реке, находите пейзажи и делайте наброски",
            HorizontalAlignment = HorizontalAlignment.Center,
            Modulate = new Color(1, 1, 1, 0.65f),
        };
        hint.AddThemeFontSizeOverride("font_size", 16);
        box.AddChild(hint);

        box.AddChild(new Control { CustomMinimumSize = new Vector2(0, 24) });

        AddButton(box, "Открыть игровой уровень", () => _router?.GoLevel());

        AddButton(box, "Открыть галерею", () => _router?.GoGallery());
    }

    private static void AddButton(Container parent, string text, System.Action onPressed)
    {
        var b = new Button
        {
            Text = text,
            CustomMinimumSize = new Vector2(340, 56),
        };
        b.AddThemeFontSizeOverride("font_size", 20);
        b.Pressed += onPressed;
        parent.AddChild(b);
    }
}
