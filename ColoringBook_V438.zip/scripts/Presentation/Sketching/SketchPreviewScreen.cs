using System;
using Godot;

namespace ColoringBook.Presentation.Sketching;

/// <summary>
/// ПРЕДПРОСМОТР СНИМКА — экран сразу после нажатия «снять».
///
/// Показывает только что сделанный кадр и три действия:
///   • Удалить    — снимок не нужен, вернуться на уровень;
///   • Сохранить  — положить в галерею и вернуться на уровень;
///   • Редактировать — построить контуры и перейти к раскраске.
///
/// ПОЧЕМУ КОНТУРЫ СТРОЯТСЯ НЕ ЗДЕСЬ, А ПО КНОПКЕ. Построение требует двух
/// дополнительных проходов рендера и поиска границ по 590 тысячам точек. Снимок
/// игрок вполне может тут же удалить — считать для него контуры значило бы делать
/// работу впустую. Поэтому кадр снимается мгновенно, а контуры появляются только
/// когда игрок решил рисовать.
///
/// Экран НИЧЕГО не решает сам: он сообщает о выбранном действии наружу, а
/// сохранение, удаление и переход выполняет тот, кто его создал (книга, 9.3 —
/// удержание UI в роли слоя представления).
/// </summary>
public sealed partial class SketchPreviewScreen : CanvasLayer
{
    /// <summary>Игрок выбрал действие. Аргумент — что именно.</summary>
    public event Action<PreviewAction>? ActionChosen;

    public enum PreviewAction
    {
        Discard = 0,
        Save = 1,
        Edit = 2,
    }

    private TextureRect? _shot;
    private Label? _busy;
    private HBoxContainer? _buttons;

    public override void _Ready()
    {
        Layer = 12;   // выше остальных экранов: это модальное окно поверх кадра
        BuildUi();
        Visible = false;
    }

    private void BuildUi()
    {
        var bg = new ColorRect { Color = new Color(0.05f, 0.05f, 0.06f, 0.92f) };
        AddChild(bg);
        bg.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);

        _shot = new TextureRect
        {
            ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
            StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        AddChild(_shot);
        _shot.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);
        _shot.OffsetLeft = 40; _shot.OffsetTop = 40;
        _shot.OffsetRight = -40; _shot.OffsetBottom = -110;

        // Кнопки В ЛЕВОМ НИЖНЕМ УГЛУ, как и просили.
        _buttons = new HBoxContainer();
        _buttons.AddThemeConstantOverride("separation", 12);
        AddChild(_buttons);
        _buttons.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.BottomLeft);
        _buttons.OffsetLeft = 40; _buttons.OffsetTop = -84; _buttons.OffsetBottom = -28;

        AddButton(_buttons, "Удалить", PreviewAction.Discard);
        AddButton(_buttons, "Сохранить", PreviewAction.Save);
        AddButton(_buttons, "Редактировать", PreviewAction.Edit);

        _busy = new Label
        {
            Text = "Строю контуры…",
            Visible = false,
            Modulate = new Color(1, 1, 1, 0.85f),
        };
        AddChild(_busy);
        _busy.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.BottomRight);
        _busy.OffsetLeft = -260; _busy.OffsetTop = -70; _busy.OffsetRight = -40;
    }

    private void AddButton(Container parent, string text, PreviewAction action)
    {
        var b = new Button { Text = text, CustomMinimumSize = new Vector2(160, 48) };
        b.AddThemeFontSizeOverride("font_size", 17);
        b.Pressed += () => ActionChosen?.Invoke(action);
        parent.AddChild(b);
    }

    /// <summary>Показать только что снятый кадр.</summary>
    public void ShowShot(byte[] sourcePng)
    {
        var img = new Image();
        if (img.LoadPngFromBuffer(sourcePng) == Error.Ok && _shot != null)
            _shot.Texture = ImageTexture.CreateFromImage(img);
        SetBusy(false);
        Visible = true;
    }

    public void HideShot() => Visible = false;

    /// <summary>
    /// Блокировка кнопок. Сейчас не используется: контуры готовы к моменту показа
    /// предпросмотра. Оставлено на случай длительных операций (экспорт, отправка).
    ///
    /// Блокировка на время построения контуров: кнопки гаснут, появляется надпись.
    /// Без этого повторное нажатие «Редактировать» запустило бы второй захват,
    /// и два прохода подрались бы за материалы сцены.
    /// </summary>
    public void SetBusy(bool busy)
    {
        if (_busy != null) _busy.Visible = busy;
        if (_buttons == null) return;
        foreach (Node c in _buttons.GetChildren())
            if (c is Button b) b.Disabled = busy;
    }
}
