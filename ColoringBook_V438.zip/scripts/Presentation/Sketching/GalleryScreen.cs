using System.Collections.Generic;
using Godot;
using ColoringBook.Application;
using ColoringBook.Domain.Sketching;

namespace ColoringBook.Presentation.Sketching;

/// <summary>
/// ГАЛЕРЕЯ НАБРОСКОВ.
///
/// Показывает список сделанных снимков и открывает выбранный на раскраску.
/// Не знает ни о реке, ни о генерации: работает только через ISketchRepository,
/// поэтому её можно открыть сразу при запуске игры, минуя уровень.
///
/// Превью берётся из НАБРОСКА, а не из исходника: галерея — это папка работ, и
/// игрок должен видеть, что он уже закрасил, а не как выглядел кадр. Если работа
/// начата, показывается закрашенный слой.
/// </summary>
public sealed partial class GalleryScreen : CanvasLayer
{
    private SceneRouter? _router;
    private ISketchRepository? _repo;
    private VBoxContainer? _list;
    private Label? _empty;

    public void Bind(SceneRouter router, ISketchRepository repo)
    {
        _router = router;
        _repo = repo;
        BuildUi();
        router.ScreenChanged += screen =>
        {
            // Перечитываем при каждом входе: пока игрок был на уровне, снимков
            // могло прибавиться.
            if (screen == SceneRouter.Screen.Gallery) Refresh();
        };
    }

    private void BuildUi()
    {
        var bg = new ColorRect { Color = new Color(0.10f, 0.11f, 0.13f, 1f) };
        AddChild(bg);
        bg.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);

        var root = new VBoxContainer();
        AddChild(root);
        root.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);
        root.OffsetLeft = 24; root.OffsetTop = 20;
        root.OffsetRight = -24; root.OffsetBottom = -20;

        var header = new HBoxContainer();
        root.AddChild(header);

        var back = new Button { Text = "← Назад", CustomMinimumSize = new Vector2(120, 40) };
        back.Pressed += () => _router?.GoStart();
        header.AddChild(back);

        var title = new Label
        {
            Text = "  Галерея",
            VerticalAlignment = VerticalAlignment.Center,
        };
        title.AddThemeFontSizeOverride("font_size", 28);
        header.AddChild(title);

        root.AddChild(new HSeparator());

        _empty = new Label
        {
            Text = "Пока пусто. Сделайте снимок на уровне — он появится здесь.",
            Modulate = new Color(1, 1, 1, 0.6f),
        };
        root.AddChild(_empty);

        var scroll = new ScrollContainer
        {
            SizeFlagsVertical = Control.SizeFlags.ExpandFill,
            SizeFlagsHorizontal = Control.SizeFlags.ExpandFill,
        };
        root.AddChild(scroll);

        _list = new VBoxContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
        _list.AddThemeConstantOverride("separation", 12);
        scroll.AddChild(_list);
    }

    public void Refresh()
    {
        if (_list == null || _repo == null) return;

        foreach (Node c in _list.GetChildren()) c.QueueFree();

        IReadOnlyList<Sketch> items = _repo.List();
        if (_empty != null) _empty.Visible = items.Count == 0;

        foreach (var s in items) _list.AddChild(BuildRow(s));
    }

    private Control BuildRow(Sketch s)
    {
        var row = new HBoxContainer { CustomMinimumSize = new Vector2(0, 120) };
        row.AddThemeConstantOverride("separation", 14);

        // Превью: закрашенное, если работа начата, иначе — контуры.
        var layer = s.Progress == SketchProgress.NotStarted
            ? SketchLayer.Outline
            : SketchLayer.Painted;
        // Превью: работа, если начата; иначе контуры; иначе — исходник, потому что
        // у снимка, сохранённого без редактирования, контуров просто нет.
        var tex = LoadTexture(s.Id, layer)
               ?? LoadTexture(s.Id, SketchLayer.Outline)
               ?? LoadTexture(s.Id, SketchLayer.Source);

        var thumb = new TextureRect
        {
            Texture = tex,
            CustomMinimumSize = new Vector2(200, 112),
            ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
            StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered,
        };
        row.AddChild(thumb);

        var info = new VBoxContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
        row.AddChild(info);

        var name = new Label
        {
            Text = string.IsNullOrWhiteSpace(s.Title) ? s.Id.Value : s.Title,
        };
        name.AddThemeFontSizeOverride("font_size", 18);
        info.AddChild(name);

        info.AddChild(new Label
        {
            Text = $"{s.CreatedUtc.ToLocalTime():dd.MM.yyyy HH:mm}   {ProgressText(s)}",
            Modulate = new Color(1, 1, 1, 0.6f),
        });

        // Контуры строятся вместе со снимком, поэтому здесь они есть всегда.
        // Проверка оставлена как страховка на случай снимков от прежних версий.
        byte[]? outline = _repo?.ReadLayer(s.Id, SketchLayer.Outline);
        bool hasOutline = outline != null && outline.Length > 0;

        var open = new Button
        {
            Text = !hasOutline
                ? "Нет контуров"
                : (s.Progress == SketchProgress.NotStarted ? "Начать" : "Продолжить"),
            Disabled = !hasOutline,
            CustomMinimumSize = new Vector2(170, 44),
        };
        open.Pressed += () => _router?.RequestPainting(s.Id.Value);
        row.AddChild(open);

        return row;
    }

    private static string ProgressText(Sketch s) => s.Progress switch
    {
        SketchProgress.NotStarted => "не начато",
        SketchProgress.Finished => "готово",
        _ => $"закрашено {s.Completion * 100f:0}%",
    };

    private ImageTexture? LoadTexture(SketchId id, SketchLayer layer)
    {
        byte[]? png = _repo?.ReadLayer(id, layer);
        if (png == null || png.Length == 0) return null;
        var img = new Image();
        if (img.LoadPngFromBuffer(png) != Error.Ok) return null;
        return ImageTexture.CreateFromImage(img);
    }
}
