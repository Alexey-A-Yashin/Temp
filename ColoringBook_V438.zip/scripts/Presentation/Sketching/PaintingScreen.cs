using System;
using Godot;
using ColoringBook.Application;
using ColoringBook.Domain.Sketching;

namespace ColoringBook.Presentation.Sketching;

/// <summary>
/// СЦЕНА РАСКРАСКИ.
///
/// Три слоя изображения, наложенных друг на друга:
///   1. РАБОТА  — то, что игрок закрасил (нижний, по нему и рисуем);
///   2. КОНТУР  — линии заготовки, поверх работы, поэтому краска их не перекрывает;
///   3. ИСХОДНИК — цветной кадр, показывается по кнопке поверх всего.
///
/// Исходник нужен именно как СПРАВКА по цвету: игрок подсматривает, каким был
/// пейзаж, и возвращается к своей работе. Поэтому он не рядом, а поверх — так
/// сравнивать удобнее, чем переводя взгляд.
///
/// Незаконченная работа — норма, а не исключение: игрок может закрыть игру и
/// вернуться через месяц. Поэтому состояние пишется на диск при каждом уходе со
/// сцены, а не только по кнопке «сохранить».
/// </summary>
public sealed partial class PaintingScreen : CanvasLayer
{
    private SceneRouter? _router;
    private ISketchRepository? _repo;

    private Sketch? _sketch;
    private Image? _paint;            // изменяемый слой
    private ImageTexture? _paintTex;
    private TextureRect? _paintRect;
    private TextureRect? _outlineRect;
    private TextureRect? _sourceRect;

    private Color _brush = new(0.35f, 0.62f, 0.38f, 1f);
    private int _brushRadius = 12;
    private bool _drawing;
    private bool _dirty;

    /// <summary>Доля закрашенного, пересчитывается при сохранении.</summary>
    private float _completion;

    public void Bind(SceneRouter router, ISketchRepository repo)
    {
        _router = router;
        _repo = repo;
        BuildUi();
        router.ScreenChanged += screen =>
        {
            if (screen == SceneRouter.Screen.Painting) Open(router.ActiveSketchId);
            else SaveIfDirty();
        };
    }

    // ---- открытие ----

    private void Open(string id)
    {
        if (_repo == null) return;
        if (!_repo.TryLoad(new SketchId(id), out var s)) return;
        _sketch = s;

        var outline = LoadImage(s.Id, SketchLayer.Outline);
        if (outline == null)
        {
            // Сюда попасть не должны: контуры строятся до перехода (см.
            // GameBootstrap.OnPaintingRequested). Оставлено как страховка, чтобы при
            // сбое построения игрок вернулся в галерею, а не смотрел в пустой экран.
            GD.PrintErr($"[sketch] контуры отсутствуют, хотя должны быть: {s.Id}");
            _router?.GoGallery();
            return;
        }

        var painted = LoadImage(s.Id, SketchLayer.Painted);
        if (painted != null && painted.GetSize() == outline.GetSize())
        {
            _paint = painted;
        }
        else
        {
            // Новая работа — белый лист того же размера, что и контур.
            _paint = Image.CreateEmpty(
                outline.GetWidth(), outline.GetHeight(), false, Image.Format.Rgba8);
            _paint.Fill(new Color(1, 1, 1, 1));
        }

        _paintTex = ImageTexture.CreateFromImage(_paint);
        if (_paintRect != null) _paintRect.Texture = _paintTex;
        if (_outlineRect != null) _outlineRect.Texture = ImageTexture.CreateFromImage(outline);

        var src = LoadImage(s.Id, SketchLayer.Source);
        if (_sourceRect != null)
        {
            _sourceRect.Texture = src != null ? ImageTexture.CreateFromImage(src) : null;
            _sourceRect.Visible = false;
        }
        _dirty = false;
    }

    private Image? LoadImage(SketchId id, SketchLayer layer)
    {
        byte[]? png = _repo?.ReadLayer(id, layer);
        if (png == null || png.Length == 0) return null;
        var img = new Image();
        return img.LoadPngFromBuffer(png) == Error.Ok ? img : null;
    }

    // ---- интерфейс ----

    private void BuildUi()
    {
        var bg = new ColorRect { Color = new Color(0.12f, 0.12f, 0.14f, 1f) };
        AddChild(bg);
        bg.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);

        // ЛИСТ ЗАНИМАЕТ ВСЁ ОКНО ниже панели.
        //
        // Раньше стоял CustomMinimumSize 1024x576 с выравниванием по центру, и по
        // видео замер показал, что лист занимает лишь 45% ширины и 42% высоты окна —
        // меньше половины экрана, хотя рисовать нужно именно на нём. Теперь область
        // растягивается на весь кадр, а вписыванием с сохранением пропорций
        // занимается сам TextureRect.
        var canvas = new Control();
        AddChild(canvas);
        canvas.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);
        canvas.OffsetTop = 64;      // под панелью инструментов
        canvas.OffsetLeft = 12; canvas.OffsetRight = -12; canvas.OffsetBottom = -12;

        _paintRect = MakeLayer(canvas);
        _outlineRect = MakeLayer(canvas);
        // Контур поверх краски, но с умножением: линии остаются видимыми,
        // а белый фон заготовки не затирает закрашенное.
        _outlineRect.Modulate = new Color(1, 1, 1, 1);
        _outlineRect.Material = new CanvasItemMaterial
        {
            BlendMode = CanvasItemMaterial.BlendModeEnum.Mul,
        };

        _sourceRect = MakeLayer(canvas);
        _sourceRect.Visible = false;

        BuildToolbar();
    }

    private static TextureRect MakeLayer(Control parent)
    {
        var r = new TextureRect
        {
            ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
            StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered,
            MouseFilter = Control.MouseFilterEnum.Ignore,
        };
        parent.AddChild(r);
        r.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);
        return r;
    }

    private void BuildToolbar()
    {
        var bar = new HBoxContainer();
        bar.AddThemeConstantOverride("separation", 10);
        AddChild(bar);
        bar.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.TopWide);
        bar.OffsetLeft = 16; bar.OffsetTop = 12; bar.OffsetRight = -16;

        var back = new Button { Text = "← В галерею", CustomMinimumSize = new Vector2(140, 40) };
        back.Pressed += () => { SaveIfDirty(); _router?.GoGallery(); };
        bar.AddChild(back);

        foreach (var (name, col) in Palette)
        {
            var b = new Button { CustomMinimumSize = new Vector2(40, 40), TooltipText = name };
            var sb = new StyleBoxFlat { BgColor = col };
            b.AddThemeStyleboxOverride("normal", sb);
            var captured = col;
            b.Pressed += () => _brush = captured;
            bar.AddChild(b);
        }

        var srcBtn = new Button { Text = "Исходник", ToggleMode = true, CustomMinimumSize = new Vector2(120, 40) };
        srcBtn.Toggled += on => { if (_sourceRect != null) _sourceRect.Visible = on; };
        bar.AddChild(srcBtn);

        var save = new Button { Text = "Сохранить", CustomMinimumSize = new Vector2(130, 40) };
        save.Pressed += SaveIfDirty;
        bar.AddChild(save);
    }

    private static readonly (string, Color)[] Palette =
    {
        ("небо",   new Color(0.62f, 0.78f, 0.92f)),
        ("вода",   new Color(0.35f, 0.62f, 0.80f)),
        ("трава",  new Color(0.45f, 0.68f, 0.38f)),
        ("хвоя",   new Color(0.20f, 0.42f, 0.28f)),
        ("камень", new Color(0.70f, 0.70f, 0.72f)),
        ("земля",  new Color(0.52f, 0.42f, 0.30f)),
    };

    // ---- рисование ----

    // _GuiInput здесь не переопределяется: он объявлен у Control, а эта сцена —
    // CanvasLayer, у которого такого метода нет (CS0115). Ввод ловим через
    // _UnhandledInput: до него событие доходит уже после кнопок панели, поэтому
    // нажатие на кнопку палитры не оставляет мазка под ней.
    public override void _UnhandledInput(InputEvent @event)
    {
        if (_paint == null || _paintRect == null) return;

        if (@event is InputEventMouseButton mb && mb.ButtonIndex == MouseButton.Left)
        {
            _drawing = mb.Pressed;
            if (mb.Pressed) PaintAt(mb.Position);
        }
        else if (@event is InputEventMouseMotion mm && _drawing)
        {
            PaintAt(mm.Position);
        }
    }

    private void PaintAt(Vector2 screenPos)
    {
        if (_paint == null || _paintRect == null || _paintTex == null) return;

        // Экранные координаты -> координаты изображения. Прямоугольник растянут
        // с сохранением пропорций, поэтому учитываем поля.
        Rect2 rect = _paintRect.GetGlobalRect();
        Vector2 texSize = _paint.GetSize();
        float scale = Mathf.Min(rect.Size.X / texSize.X, rect.Size.Y / texSize.Y);
        Vector2 shown = texSize * scale;
        Vector2 origin = rect.Position + (rect.Size - shown) * 0.5f;
        Vector2 local = (screenPos - origin) / scale;

        int cx = (int)local.X, cy = (int)local.Y;
        int w = _paint.GetWidth(), h = _paint.GetHeight();
        int r = _brushRadius;

        for (int y = cy - r; y <= cy + r; y++)
        {
            if (y < 0 || y >= h) continue;
            for (int x = cx - r; x <= cx + r; x++)
            {
                if (x < 0 || x >= w) continue;
                int dx = x - cx, dy = y - cy;
                if (dx * dx + dy * dy > r * r) continue;
                _paint.SetPixel(x, y, _brush);
            }
        }

        _paintTex.Update(_paint);
        _dirty = true;
    }

    // ---- сохранение ----

    private void SaveIfDirty()
    {
        if (!_dirty || _sketch == null || _paint == null || _repo == null) return;

        _completion = MeasureCompletion(_paint);
        _sketch.MarkPainted(_completion);
        _repo.SavePainting(_sketch, _paint.SavePngToBuffer());
        _dirty = false;
    }

    /// <summary>
    /// Доля закрашенного — по числу точек, отличающихся от белого. Считается при
    /// сохранении, а не на каждый мазок: проход по миллиону точек в кадре
    /// съел бы отзывчивость кисти.
    /// </summary>
    private static float MeasureCompletion(Image img)
    {
        int w = img.GetWidth(), h = img.GetHeight();
        int painted = 0, total = 0;
        // Каждая четвёртая точка: для процента этого достаточно, а работы вчетверо меньше.
        for (int y = 0; y < h; y += 2)
        for (int x = 0; x < w; x += 2)
        {
            total++;
            var c = img.GetPixel(x, y);
            if (c.R < 0.97f || c.G < 0.97f || c.B < 0.97f) painted++;
        }
        return total > 0 ? (float)painted / total : 0f;
    }
}
