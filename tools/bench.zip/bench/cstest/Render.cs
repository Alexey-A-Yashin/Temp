using System;
using System.IO;

namespace TerrainCheck;

/// <summary>
/// Затенённый рельеф в BMP без единой зависимости.
///
/// Нужен, чтобы смотреть на результат самому, а не отправлять сборку и ждать
/// снимка. BMP выбран потому, что пишется двадцатью строками: PNG потребовал бы
/// zlib, а System.Drawing на Linux тянет libgdiplus.
/// </summary>
public static class Render
{
    public static void Shaded(float[] h, int side, float cellM, string path,
        float lightX = 0.42f, float lightY = 0.50f, float lightZ = 0.76f)
    {
        float lo = float.MaxValue, hi = float.MinValue;
        foreach (float v in h) { if (v < lo) lo = v; if (v > hi) hi = v; }
        float ln = MathF.Sqrt(lightX * lightX + lightY * lightY + lightZ * lightZ);
        lightX /= ln; lightY /= ln; lightZ /= ln;

        var px = new byte[side * side * 3];
        for (int j = 0; j < side; j++)
        for (int i = 0; i < side; i++)
        {
            int i0 = Math.Max(i - 1, 0), i1 = Math.Min(i + 1, side - 1);
            int j0 = Math.Max(j - 1, 0), j1 = Math.Min(j + 1, side - 1);
            float gx = (h[j * side + i1] - h[j * side + i0]) / ((i1 - i0) * cellM);
            float gy = (h[j1 * side + i] - h[j0 * side + i]) / ((j1 - j0) * cellM);
            float nl = MathF.Sqrt(gx * gx + gy * gy + 1f);
            float sh = Math.Clamp((-gx * lightX - gy * lightY + lightZ) / nl, 0f, 1f);
            float t = Math.Clamp((h[j * side + i] - lo) / MathF.Max(hi - lo, 1e-6f), 0f, 1f);
            float slope = MathF.Atan(MathF.Sqrt(gx * gx + gy * gy)) * 180f / MathF.PI;

            // трава внизу, камень на крутизне, снег наверху — как в игре
            float r = 0.33f + 0.16f * t, g = 0.46f - 0.04f * t, b = 0.29f + 0.10f * t;
            float rock = Math.Clamp((slope - 30f) / 16f, 0f, 1f);
            r = r * (1 - rock) + 0.50f * rock;
            g = g * (1 - rock) + 0.49f * rock;
            b = b * (1 - rock) + 0.47f * rock;
            float snow = Math.Clamp((t - 0.68f) / 0.18f, 0f, 1f)
                       * Math.Clamp(1f - (slope - 40f) / 25f, 0f, 1f);
            r = r * (1 - snow) + 0.95f * snow;
            g = g * (1 - snow) + 0.96f * snow;
            b = b * (1 - snow) + 0.98f * snow;
            float k = 0.28f + 0.85f * sh;

            int o = ((side - 1 - j) * side + i) * 3;   // BMP снизу вверх
            px[o + 2] = (byte)Math.Clamp(r * k * 255f, 0, 255);
            px[o + 1] = (byte)Math.Clamp(g * k * 255f, 0, 255);
            px[o + 0] = (byte)Math.Clamp(b * k * 255f, 0, 255);
        }
        WriteBmp(path, px, side, side);
    }

    private static void WriteBmp(string path, byte[] bgr, int w, int hgt)
    {
        int rowPad = (4 - (w * 3) % 4) % 4;
        int dataSize = (w * 3 + rowPad) * hgt;
        using var fs = new FileStream(path, FileMode.Create);
        using var bw = new BinaryWriter(fs);
        bw.Write((ushort)0x4D42);
        bw.Write(54 + dataSize);
        bw.Write(0); bw.Write(54);
        bw.Write(40); bw.Write(w); bw.Write(hgt);
        bw.Write((ushort)1); bw.Write((ushort)24);
        bw.Write(0); bw.Write(dataSize);
        bw.Write(2835); bw.Write(2835); bw.Write(0); bw.Write(0);
        var pad = new byte[rowPad];
        for (int j = 0; j < hgt; j++)
        {
            bw.Write(bgr, j * w * 3, w * 3);
            if (rowPad > 0) bw.Write(pad);
        }
    }
}
