using System;
using System.IO;

// Прогон НОВОЙ меры стыка на настоящей выгрузке terrain.bin.
// Код SampleGrid и обоих замеров скопирован из FarBackground.cs дословно.
class Program
{
    const float MetresPerUnit = 10f;
    const int TransitionCells = 8;

    static float SampleGrid(float[] h, int n, float half, float step, float wx, float wz)
    {
        float gx = (wx + half) / step, gz = (wz + half) / step;
        int i0 = Math.Clamp((int)MathF.Floor(gx), 0, n - 1);
        int j0 = Math.Clamp((int)MathF.Floor(gz), 0, n - 1);
        float tx = Math.Clamp(gx - i0, 0f, 1f), tz = Math.Clamp(gz - j0, 0f, 1f);
        int s = n + 1;
        float a = h[j0 * s + i0], b = h[j0 * s + i0 + 1];
        float c = h[(j0 + 1) * s + i0], d = h[(j0 + 1) * s + i0 + 1];
        return (a * (1 - tx) + b * tx) * (1 - tz) + (c * (1 - tx) + d * tx) * tz;
    }

    static void Main(string[] argv)
    {
        using var f = new BinaryReader(File.OpenRead(argv[0]));
        if (new string(f.ReadChars(4)) != "CBTR") throw new Exception("не тот файл");
        int ver = f.ReadInt32(), count = f.ReadInt32();
        var H = new float[count][]; var Half = new float[count]; var Step = new float[count];
        int n2 = 0;
        for (int r = 0; r < count; r++)
        {
            int ring = f.ReadInt32(), side = f.ReadInt32();
            float cell = f.ReadSingle(), lift = f.ReadSingle();
            var h = new float[side * side];
            for (int k = 0; k < h.Length; k++) h[k] = f.ReadSingle();
            for (int k = 0; k < h.Length; k++) f.ReadSingle();
            if (ver >= 2) f.ReadBytes(h.Length);
            n2 = side - 1;
            H[ring] = h; Step[ring] = cell; Half[ring] = n2 * cell * 0.5f;
        }

        float worstGapM = 0f, worstRampDeg = 0f;
        for (int ring = 0; ring + 1 < count; ring++)
        {
            float gapMax = 0f, rampMax = 0f;
            for (int t = 0; t <= n2; t++)
            for (int e = 0; e < 4; e++)
            {
                int gi = e == 0 || e == 1 ? t : (e == 2 ? 0 : n2);
                int gj = e == 0 ? 0 : (e == 1 ? n2 : t);
                float wx = -Half[ring] + gi * Step[ring], wz = -Half[ring] + gj * Step[ring];
                float gap = MathF.Abs(H[ring][gj * (n2 + 1) + gi]
                    - SampleGrid(H[ring + 1], n2, Half[ring + 1], Step[ring + 1], wx, wz))
                    * MetresPerUnit;
                if (gap > gapMax) gapMax = gap;
            }
            float band = TransitionCells * Step[ring];
            for (int t = TransitionCells; t <= n2 - TransitionCells; t++)
            for (int e = 0; e < 4; e++)
            {
                int gi = e == 0 || e == 1 ? t : (e == 2 ? TransitionCells : n2 - TransitionCells);
                int gj = e == 0 ? TransitionCells : (e == 1 ? n2 - TransitionCells : t);
                float wx = -Half[ring] + gi * Step[ring], wz = -Half[ring] + gj * Step[ring];
                float diff = MathF.Abs(H[ring][gj * (n2 + 1) + gi]
                    - SampleGrid(H[ring + 1], n2, Half[ring + 1], Step[ring + 1], wx, wz));
                float deg = MathF.Atan(diff / band) * 180f / MathF.PI;
                if (deg > rampMax) rampMax = deg;
            }
            Console.WriteLine($"стык {ring}/{ring + 1}: расхождение {gapMax:F2} м, пандус {rampMax:F1}°");
            if (gapMax > worstGapM) worstGapM = gapMax;
            if (rampMax > worstRampDeg) worstRampDeg = rampMax;
        }
        Console.WriteLine();
        Console.WriteLine($"в отчёт уйдёт: worstSeamM {worstGapM:F1}, worstRampDeg {worstRampDeg:F1}");
        Console.WriteLine($"старая мера на этих же данных писала: worstSeamM 124");
    }
}
