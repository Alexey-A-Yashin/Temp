#!/bin/sh
# Разворачивает исходники проекта в каталоги src/ трёх стендов.
#
# Стенды собираются НЕ из каталога проекта напрямую, а из копий: так видно, что
# именно проверялось, и случайная правка стенда не уходит в игру.
#
# Запускать из распакованного каталога стенда, передав путь к каталогу проекта:
#     sh подготовить.sh ~/Godot/ColoringBook
#
# Слой Domain + Infrastructure/Generation от Godot не зависит; Plants зависит и
# потому выбрасывается.
set -e
if [ -z "$1" ]; then echo "укажите путь к каталогу проекта"; exit 1; fi
P="$1/scripts"
if [ ! -d "$P" ]; then echo "не нахожу $P"; exit 1; fi

prep() {
    d="$1"; shift
    rm -rf "$d/src"; mkdir -p "$d/src"
    cp -r "$P/Domain" "$d/src/"
    cp -r "$P/Infrastructure/Generation" "$d/src/"
    rm -rf "$d/src/Generation/Plants"
    for f in "$@"; do cp "$f" "$d/src/"; done
    echo "готов $d"
}

prep gentest
prep cstest

# godotcheck дополнительно берёт файлы презентационного слоя: они зависят от
# Godot и проверяются только по заглушкам.
prep godotcheck \
    "$P/Presentation/Level/FarBackground.cs" \
    "$P/Presentation/Level/TerrainReport.cs" \
    "$P/Presentation/Level/SeasonColorMapper.cs" \
    "$P/Presentation/Level/TerrainGradient.cs" \
    "$P/Presentation/Diagnostics/SessionLog.cs"

cat > godotcheck/src/LevelView3DStub.cs <<'STUB'
namespace ColoringBook.Presentation.Level;

/// <summary>
/// Заглушка LevelView3D — только то, к чему обращается FarBackground.
/// Настоящий файл около 5000 строк и тянет за собой весь Presentation.
///
/// NewTerrainPreview обязано остаться ПОЛЕМ, а не const: с const компилятор
/// сворачивает ветки и объявляет код за ними недостижимым (CS0162, CS8602).
/// Стенд должен ловить эту ошибку, а не порождать её сам.
/// </summary>
public static class LevelView3D
{
    public static bool NewTerrainPreview = true;
    public static string BuildStamp = "стенд";
}
STUB
echo "все три стенда готовы: dotnet build в любом из них"
