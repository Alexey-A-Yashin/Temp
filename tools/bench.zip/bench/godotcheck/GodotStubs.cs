// Заглушки типов Godot для проверки правил языка без движка.
//
// Полной сборки они не дают — только компиляцию того, что не обращается к
// настоящему движку. Но именно на правилах языка я и спотыкаюсь: ref-параметр в
// локальной функции (CS1628), неоднозначное имя (CS0104).
//
// ЗДЕСЬ ОБЯЗАТЕЛЬНО ДОЛЖНЫ БЫТЬ ИМЕНА, СОВПАДАЮЩИЕ С System. У Godot есть свои
// Environment, Timer, Range, Signal и другие; при `using Godot;` простое имя
// становится неоднозначным, и сборка падает. Без этих заглушек пробник такую
// ошибку не воспроизводит — так у меня и прошёл CS0104 на Environment.NewLine.
using System;

namespace Godot
{
    // ---- имена, конфликтующие с System ----

    /// <summary>Окружение сцены: небо, туман, тонирование. Конфликтует с
    /// System.Environment.</summary>
    public sealed class Environment { }

    /// <summary>Узел-таймер. Конфликтует с System.Threading.Timer.</summary>
    public sealed class Timer { }

    /// <summary>Диапазон значений. Конфликтует с System.Range.</summary>
    public sealed class Range { }

    // ---- обиходные типы ----

    public static class GD
    {
        public static void Print(string s) => Console.WriteLine(s);
        public static void PushWarning(string s) => Console.Error.WriteLine(s);
        public static void PushError(string s) => Console.Error.WriteLine(s);
    }

    public struct Vector2
    {
        public float X, Y;
        public Vector2(float x, float y) { X = x; Y = y; }
    }

    public struct Vector3
    {
        public float X, Y, Z;
        public Vector3(float x, float y, float z) { X = x; Y = y; Z = z; }
        public static Vector3 Up => new(0, 1, 0);
        public float LengthSquared() => X * X + Y * Y + Z * Z;
        public Vector3 Normalized() => this;
        public Vector3 Cross(Vector3 o) => this;
        public static Vector3 operator -(Vector3 a, Vector3 b) => a;
        public static Vector3 operator +(Vector3 a, Vector3 b) => a;
        public static Vector3 operator -(Vector3 a) => a;
        public static Vector3 operator *(Vector3 a, float k) => a;
        public static Vector3 operator /(Vector3 a, float k) => a;
    }

    public struct Color
    {
        public float R, G, B, A;
        public Color(float r, float g, float b, float a = 1f) { R = r; G = g; B = b; A = a; }
        public Color Lerp(Color o, float t) => this;
    }

    /// <summary>Заглушки математики и готовых цветов — понадобились, когда на
    /// стенд поехали SeasonColorMapper и TerrainGradient.</summary>
    public static class Mathf
    {
        public static float Clamp(float v, float lo, float hi) => System.Math.Clamp(v, lo, hi);
        public static int Clamp(int v, int lo, int hi) => System.Math.Clamp(v, lo, hi);
        public static float Lerp(float a, float b, float t) => a + (b - a) * t;
        public static float Abs(float v) => System.MathF.Abs(v);
        public static float Min(float a, float b) => System.MathF.Min(a, b);
        public static float Max(float a, float b) => System.MathF.Max(a, b);
        public static float Pow(float a, float b) => System.MathF.Pow(a, b);
        public static float Sqrt(float v) => System.MathF.Sqrt(v);
        public static float Floor(float v) => System.MathF.Floor(v);
        public static float Round(float v) => System.MathF.Round(v);
        public static int RoundToInt(float v) => (int)System.MathF.Round(v);
    }
    public static class Colors
    {
        public static Color White => new(1f, 1f, 1f);
        public static Color Black => new(0f, 0f, 0f);
        public static Color Gray => new(0.5f, 0.5f, 0.5f);
        public static Color Magenta => new(1f, 0f, 1f);
    }

    /// <summary>Заглушки картинок — добавлены, когда на стенд поехал
    /// TerrainGradient.</summary>
    public class Image
    {
        public enum Format { Rgba8, Rgb8 }
        public static Image CreateEmpty(int w, int h, bool mipmaps, Format f) => new();
        public void SetPixel(int x, int y, Color c) { }
    }
    public class Texture2D { }
    public class ImageTexture : Texture2D
    {
        public static ImageTexture CreateFromImage(Image img) => new();
        public void Update(Image img) { }
    }

    public class Node
    {
        public string Name = "";
        public void AddChild(Node n) { }
        public void QueueFree() { }
    }
    public class Node3D : Node { }
    public class Camera3D : Node3D { }

    public class Mesh
    {
        public enum ArrayType { Vertex, Normal, Color, Index, Max }
        public enum PrimitiveType { Points, Lines, Triangles }
    }
    public class ArrayMesh : Mesh
    {
        public void AddSurfaceFromArrays(PrimitiveType t, Collections.Array a) { }
    }

    public class BaseMaterial3D
    {
        public enum TransparencyEnum { Disabled, Alpha }
        public enum CullModeEnum { Back, Front, Disabled }
        public enum SpecularModeEnum { SchlickGgx, Disabled }
    }
    public class StandardMaterial3D : BaseMaterial3D
    {
        public Color AlbedoColor;
        public TransparencyEnum Transparency;
        public CullModeEnum CullMode;
        public SpecularModeEnum SpecularMode;
        public float Roughness, Metallic;
        public bool VertexColorUseAsAlbedo;
    }

    public class GeometryInstance3D : Node3D
    {
        public enum ShadowCastingSetting { Off, On }
        public ShadowCastingSetting CastShadow;
        public BaseMaterial3D? MaterialOverride;
    }
    public class MeshInstance3D : GeometryInstance3D
    {
        public Mesh? Mesh;
    }
}

namespace Godot.Collections
{
    /// <summary>Заглушка Godot.Collections.Array. Индексатор по int и Resize —
    /// без них сборка массивов поверхности не воспроизводится.</summary>
    public class Array
    {
        private readonly System.Collections.Generic.Dictionary<int, object?> _v = new();
        public void Resize(int n) { }
        public object? this[int i] { get => _v.TryGetValue(i, out var o) ? o : null; set => _v[i] = value!; }
    }

    public class Array<T>
    {
        private readonly System.Collections.Generic.List<T> _v = new();
        public void Resize(int n) { }
        public void Add(T x) => _v.Add(x);
        public T this[int i] { get => _v[i]; set => _v[i] = value; }
    }
}
