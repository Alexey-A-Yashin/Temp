using System;
using System.IO;
using System.Text;
using Godot;

// Место для проверки конструкций, которые уходят в Presentation или Bootstrap.
// Полной сборки заглушки не дают, но правила языка проверяют — а спотыкаюсь я
// именно на них.
class Probe
{
    static void Main()
    {
        // Пример: неоднозначное имя. Раскомментировать, чтобы убедиться, что
        // стенд ловит CS0104 — у Godot есть свой Environment.
        // string bad = "строка" + Environment.NewLine;

        string good = "строка" + System.Environment.NewLine;
        File.WriteAllText("/tmp/probe.txt", good, Encoding.UTF8);
        GD.Print("стенд работает");
    }
}
