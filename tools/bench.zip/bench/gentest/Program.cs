using System;
using System.Collections.Generic;
using System.IO;
using ColoringBook.Infrastructure.Generation.Mapgen;
using ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

// МАСКИ НАПРАВЛЕНИЙ вместо восьми соседей (Galin и др., 2010).
//
// На восьми соседях траверс поперёк склона возможен только под 45° к линии
// падения — серпантину нужен куда более пологий угол, и он не выражается.
// Маска берёт все ПРИМИТИВНЫЕ смещения в радиусе R: (1,2), (2,3), (1,3)...
// При R=3 это 32 направления вместо восьми, шаг по углу около 11° вместо 45°.
//
// Длинный шаг проверяется ПО ВСЕЙ ДЛИНЕ: иначе трасса перепрыгнет промоину.
class Program
{
    const float CellM=60f;
    static int S; static float[] H,Frac,Slope; static float CellW=CellM/10f;
    const float ShrubFloor=0.44f,SnowFloor=0.63f,ScreeSlope=38f;
    const float UpLim=12f,UpShort=20f,DownLim=30f;
    static (int dx,int dy)[] Mask;
    static float[] Flow;
    static int HUBS; static float SEP;

    static (int,int)[] BuildMask(int R)
    {
        var l=new List<(int,int)>();
        for(int dy=-R;dy<=R;dy++) for(int dx=-R;dx<=R;dx++)
        {
            if(dx==0&&dy==0) continue;
            if(Math.Max(Math.Abs(dx),Math.Abs(dy))>R) continue;
            int g=Gcd(Math.Abs(dx),Math.Abs(dy));
            if(g!=1) continue;                       // только примитивные — без повторов направлений
            l.Add((dx,dy));
        }
        return l.ToArray();
        static int Gcd(int a,int b){while(b!=0){(a,b)=(b,a%b);}return a==0?1:a;}
    }

    static bool Rocky(int k)=>Frac[k]>SnowFloor||Slope[k]>ScreeSlope;

    /// <summary>Стоимость шага. Отрицательная — шаг запрещён.</summary>
    static double Cost(int a,int b,bool preferBand)
    {
        int ax=a%S,ay=a/S,bx=b%S,by=b/S;
        int dx=bx-ax, dy=by-ay;
        int steps=Math.Max(Math.Abs(dx),Math.Abs(dy));
        double dist=Math.Sqrt((double)dx*dx+(double)dy*dy)*CellM;
        double dz=(H[b]-H[a])*10;
        double deg=Math.Atan(Math.Abs(dz)/dist)*180/Math.PI;
        if (dz>0 ? deg>UpShort : deg>DownLim) return -1;
        // проверка по всей длине шага + срезка/подсыпка под ровную нить
        double cut=0;
        for(int t=1;t<steps;t++)
        {
            double f=(double)t/steps;
            int ix=(int)Math.Round(ax+dx*f), iy=(int)Math.Round(ay+dy*f);
            int m=iy*S+ix;
            if(Rocky(m)) return -1;
            double line=H[a]+(H[b]-H[a])*f;
            cut+=Math.Abs(H[m]-line)*10;
        }
        if(Rocky(b)) return -1;
        double w=1;
        if (dz>0 && deg>UpLim) w += (deg-UpLim)*0.15;
        if (preferBand && !(Frac[b]>=ShrubFloor&&Frac[b]<=SnowFloor)) w += 2.5;
        // срезка дорога: трасса врезается в склон, но не роет туннель
        double cutAvg = steps>1 ? cut/(steps-1) : 0;
        if (cutAvg>12) return -1;
        return dist*w + cutAvg*20;
    }

    static double[] Dijkstra(int src,bool preferBand,int[] prev)
    {
        var dist=new double[S*S]; Array.Fill(dist,double.MaxValue);
        Array.Fill(prev,-1); dist[src]=0;
        var pq=new PriorityQueue<int,double>(); pq.Enqueue(src,0);
        while(pq.TryDequeue(out int c,out double d))
        {
            if(d>dist[c]+1e-9) continue;
            int i=c%S,j=c/S;
            foreach(var (dx,dy) in Mask)
            {
                int x=i+dx,y=j+dy;
                if(x<3||y<3||x>=S-3||y>=S-3) continue;
                int nb=y*S+x;
                double w=Cost(c,nb,preferBand); if(w<0) continue;
                if(d+w<dist[nb]-1e-9){dist[nb]=d+w;prev[nb]=c;pq.Enqueue(nb,d+w);}
            }
        }
        return dist;
    }

    static List<int> Trace(int[] prev,int to)
    { var p=new List<int>(); for(int c=to;c>=0;c=prev[c]) p.Add(c); p.Reverse(); return p; }

    static double Length(List<int> p)
    { double L=0; for(int k=1;k<p.Count;k++){int a=p[k-1],b=p[k];
        double dx=(a%S-b%S)*CellM,dy=(a/S-b/S)*CellM,dz=(H[a]-H[b])*10;
        L+=Math.Sqrt(dx*dx+dy*dy+dz*dz);} return L; }

    static void Main()
    {
        float km=float.Parse(Environment.GetEnvironmentVariable("KM")??"20",
            System.Globalization.CultureInfo.InvariantCulture);
        int R=int.Parse(Environment.GetEnvironmentVariable("R")??"3");
        Mask=BuildMask(R);
        HUBS=int.Parse(Environment.GetEnvironmentVariable("HUBS")??"14");
        SEP=float.Parse(Environment.GetEnvironmentVariable("SEP")??"1500",
            System.Globalization.CultureInfo.InvariantCulture);
        S=(int)(km*1000/CellM)+1;
        Console.WriteLine($"маска радиуса {R}: {Mask.Length} направлений, шаг по углу ~{360.0/Mask.Length:F0}°");
        Console.WriteLine("сид             сеть маршрутов");
        foreach(int seed in new[]{-410752382})
        {
            var noise=new SimplexNoise(seed);
            H=new float[S*S];
            for(int j=0;j<S;j++) for(int i=0;i<S;i++)
                H[j*S+i]=RidgedMountains.LayeredHeight(noise,(-S/2f+i)*CellW*10f/1000f,
                                                             (-S/2f+j)*CellW*10f/1000f)/10f;
            RidgedMountains.ThermalErosion(H,S,CellW,33f,25);
            Flow=new float[H.Length];
            RidgedMountains.HydraulicErosion(H,S,CellW,8,0.12f,Flow);
            float lo=1e9f,hi=-1e9f; foreach(var v in H){if(v<lo)lo=v;if(v>hi)hi=v;}
            Frac=new float[H.Length]; Slope=new float[H.Length];
            for(int j=0;j<S;j++) for(int i=0;i<S;i++)
            {
                int k=j*S+i; Frac[k]=(H[k]-lo)/(hi-lo);
                int im=Math.Max(i-1,0),ip=Math.Min(i+1,S-1),jm=Math.Max(j-1,0),jp=Math.Min(j+1,S-1);
                float gx=(H[j*S+ip]-H[j*S+im])/((ip-im)*CellW);
                float gz=(H[jp*S+i]-H[jm*S+i])/((jp-jm)*CellW);
                Slope[k]=MathF.Atan(MathF.Sqrt(gx*gx+gz*gz))*180f/MathF.PI;
            }
            // концы трассы двойным обходом внутри полосы
            // ---- УЗЛЫ СЕТИ ----
            //
            // «Гора диктует маршрут»: узлы берутся у местности, а не назначаются.
            // Толщина полосы в окне 11x11 показывает, где склон широк и по нему
            // есть чем ехать; локальные максимумы толщины, разнесённые на 1.5 км,
            // и есть естественные опоры трассы.
            var thick=new int[H.Length];
            for(int j2=6;j2<S-6;j2++) for(int i2=6;i2<S-6;i2++)
            {
                int k=j2*S+i2;
                if(Rocky(k)||Frac[k]<ShrubFloor||Frac[k]>SnowFloor) continue;
                int c=0;
                for(int b=-5;b<=5;b++) for(int a=-5;a<=5;a++)
                {
                    int m=(j2+b)*S+(i2+a);
                    if(!Rocky(m)&&Frac[m]>=ShrubFloor&&Frac[m]<=SnowFloor) c++;
                }
                thick[k]=c;
            }
            // ---- ПЕРЕВАЛЫ И СЕДЛОВИНЫ ----
            //
            // Седловина — точка, вокруг которой более высокие соседи образуют ДВА
            // и более отдельных участка кольца: с двух сторон гора, с двух других
            // спуск в разные долины. Это классическая дискретная проверка, и она
            // же ловит ровно то, что нужно велосипедисту, — место, где хребет
            // можно перевалить.
            //
            // Берём только те, что лежат в поясах выше леса: перевал по осыпи нам
            // не нужен, а перевал в лесу — это уже не перевал.
            var saddles=new List<int>();
            {
                var ring=new (int,int)[]{(1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1)};
                for(int j2=2;j2<S-2;j2++) for(int i2=2;i2<S-2;i2++)
                {
                    int k=j2*S+i2;
                    if(Rocky(k)) continue;
                    if(Frac[k]<ShrubFloor-0.08f||Frac[k]>SnowFloor) continue;
                    var higher=new bool[8];
                    for(int t=0;t<8;t++)
                        higher[t]=H[(j2+ring[t].Item2)*S+(i2+ring[t].Item1)]>H[k];
                    int runs=0;
                    for(int t=0;t<8;t++) if(higher[t]&&!higher[(t+7)%8]) runs++;
                    if(runs>=2) saddles.Add(k);
                }
            }
            // ---- ОПОРЫ РАЗДАЮТСЯ ПО ТЕРРИТОРИИ, А НЕ ПО ТОЛЩИНЕ ----
            //
            // Жадный выбор по толщине полосы кучкует опоры там, где склон широк,
            // и сеть садится в один угол: размах выходил 34-49% квадратов.
            // Теперь территория делится на клетки SEP x SEP, и в каждой берётся
            // лучшее место полосы, если оно там есть. Гора по-прежнему диктует —
            // но диктует в каждом углу, а не только в самом удобном.
            int minSep=(int)(SEP/CellM);
            var hubs=new List<int>();
            {
                int gq=(S+minSep-1)/minSep;
                var bestIn=new int[gq*gq]; Array.Fill(bestIn,-1);
                for(int k=0;k<H.Length;k++)
                {
                    if(thick[k]<=10) continue;
                    int c=(k/S/minSep)*gq+(k%S/minSep);
                    if(bestIn[c]<0||thick[k]>thick[bestIn[c]]) bestIn[c]=k;
                }
                foreach(int k in bestIn) if(k>=0) hubs.Add(k);
            }
            int thickHubs=hubs.Count;
            // Перевалов берём до половины от числа склоновых опор: они ценны как
            // узлы, но сами по себе трассы не делают.
            saddles.Sort((a,b)=>Frac[a].CompareTo(Frac[b]));   // низкие перемычки ценнее
            int passHubsAdded=0;
            foreach(int k in saddles)
            {
                if(passHubsAdded>=Math.Max(4,thickHubs/2)) break;
                bool ok=true;
                foreach(int q in hubs)
                {
                    int dx=k%S-q%S, dy=k/S-q/S;
                    if(dx*dx+dy*dy<(minSep/2)*(minSep/2)){ok=false;break;}
                }
                if(ok){hubs.Add(k);passHubsAdded++;}
            }
            int passHubs=hubs.Count-thickHubs;
            if(hubs.Count<3){Console.WriteLine($"{seed,12}: опор мало ({hubs.Count})");continue;}

            // ---- РЁБРА: каждый узел к трём ближайшим ----
            var paths=new List<List<int>>();
            var edgeSet=new HashSet<(int,int)>();
            double netLen=0; int inBandN=0, totalN=0;
            for(int a=0;a<hubs.Count;a++)
            {
                var order3=new List<int>();
                for(int b=0;b<hubs.Count;b++) if(b!=a) order3.Add(b);
                order3.Sort((x,y)=>{
                    long dx1=hubs[x]%S-hubs[a]%S, dy1=hubs[x]/S-hubs[a]/S;
                    long dx2=hubs[y]%S-hubs[a]%S, dy2=hubs[y]/S-hubs[a]/S;
                    return (dx1*dx1+dy1*dy1).CompareTo(dx2*dx2+dy2*dy2);});
                var pvA=new int[H.Length]; var dA2=Dijkstra(hubs[a],true,pvA);
                for(int t=0;t<3&&t<order3.Count;t++)
                {
                    int b=order3[t];
                    var key=(Math.Min(a,b),Math.Max(a,b));
                    if(edgeSet.Contains(key)) continue;
                    if(dA2[hubs[b]]==double.MaxValue) continue;
                    var p=Trace(pvA,hubs[b]);
                    double L2=Length(p);
                    // прямое расстояние: если объезд вчетверо длиннее, ребра нет
                    int dx3=hubs[b]%S-hubs[a]%S, dy3=hubs[b]/S-hubs[a]/S;
                    double straight=Math.Sqrt((double)dx3*dx3+(double)dy3*dy3)*CellM;
                    if(L2>straight*4) continue;
                    edgeSet.Add(key); paths.Add(p); netLen+=L2;
                    foreach(int k in p){totalN++; if(Frac[k]>=ShrubFloor&&Frac[k]<=SnowFloor) inBandN++;}
                }
            }
            // ---- ПЕРЕГОНЫ ПО ДОЛИНЕ ----
            //
            // Сеть по полосе распадается на куски: горы стоят порознь, и по
            // среднему уровню с одной на другую не перебраться. Велосипедист в
            // таком случае спускается и едет долиной до следующей горы — здесь
            // это ребро без предпочтения полосы, то есть по тому, что позволяет
            // местность.
            var par0=new int[hubs.Count]; for(int k=0;k<par0.Length;k++) par0[k]=k;
            int Find0(int x){while(par0[x]!=x){par0[x]=par0[par0[x]];x=par0[x];}return x;}
            foreach(var (u,v) in edgeSet){int a4=Find0(u),b4=Find0(v); if(a4!=b4) par0[a4]=b4;}
            int valleyLinks=0; double valleyLen=0;
            for(int guard=0; guard<hubs.Count; guard++)
            {
                var comps=new HashSet<int>(); for(int k=0;k<hubs.Count;k++) comps.Add(Find0(k));
                if(comps.Count<=1) break;
                int bestA=-1,bestB=-1; double bestD=double.MaxValue; List<int> bestP=null;
                for(int a3=0;a3<hubs.Count;a3++)
                {
                    var pvV=new int[H.Length]; var dV=Dijkstra(hubs[a3],false,pvV);
                    for(int b3=0;b3<hubs.Count;b3++)
                    {
                        if(Find0(a3)==Find0(b3)) continue;
                        if(dV[hubs[b3]]>=bestD) continue;
                        bestD=dV[hubs[b3]]; bestA=a3; bestB=b3; bestP=Trace(pvV,hubs[b3]);
                    }
                }
                if(bestP==null) break;
                par0[Find0(bestA)]=Find0(bestB);
                edgeSet.Add((Math.Min(bestA,bestB),Math.Max(bestA,bestB)));
                paths.Add(bestP); valleyLinks++;
                double L3=Length(bestP); valleyLen+=L3; netLen+=L3;
                foreach(int k in bestP){totalN++; if(Frac[k]>=ShrubFloor&&Frac[k]<=SnowFloor) inBandN++;}
            }

            // независимые кольца сети: E - V + C
            var par=new int[hubs.Count]; for(int k=0;k<par.Length;k++) par[k]=k;
            int Find(int x){while(par[x]!=x){par[x]=par[par[x]];x=par[x];}return x;}
            foreach(var (u,v) in edgeSet){int a2=Find(u),b2=Find(v); if(a2!=b2) par[a2]=b2;}
            var roots=new HashSet<int>(); for(int k=0;k<par.Length;k++) roots.Add(Find(k));
            int cyc=edgeSet.Count-hubs.Count+roots.Count;
            // ---- БРОДЫ ----
            // Пересечение маршрута с водотоком. Поток берём у водной эрозии и
            // отсекаем по верхнему проценту — это и есть постоянные русла.
            var fs=(float[])Flow.Clone(); Array.Sort(fs);
            float wcut=fs[(int)(fs.Length*0.99f)];
            var fordSet=new HashSet<int>();
            foreach(var p in paths) foreach(int k in p) if(Flow[k]>=wcut) fordSet.Add(k);
            // соседние клетки — один брод, а не десять
            int fords=0; var fseen=new HashSet<int>();
            foreach(int k in fordSet)
            {
                bool near=false;
                foreach(int q in fseen)
                { int dx=k%S-q%S,dy=k/S-q/S; if(dx*dx+dy*dy<25){near=true;break;} }
                if(!near){fseen.Add(k);fords++;}
            }

            // ---- ОБРЕЗКА ТУПИКОВ ----
            // Ветка, висящая на одном узле, никуда не ведёт. Тупики законны, но в
            // сеть не идут: убираем листья, пока они есть.
            var deg=new int[hubs.Count];
            var alive=new HashSet<(int,int)>(edgeSet);
            bool changed=true;
            while(changed)
            {
                changed=false;
                Array.Clear(deg,0,deg.Length);
                foreach(var (u,v) in alive){deg[u]++;deg[v]++;}
                foreach(var e in new List<(int,int)>(alive))
                    if(deg[e.Item1]<=1||deg[e.Item2]<=1){alive.Remove(e);changed=true;}
            }
            int coreEdges=alive.Count;

            // ---- ОХВАТ ТЕРРИТОРИИ ----
            // Доля проезжей земли, лежащей ближе километра от маршрута.
            var dist=new int[H.Length]; Array.Fill(dist,int.MaxValue);
            var q2=new Queue<int>();
            foreach(var p in paths) foreach(int k in p) if(dist[k]!=0){dist[k]=0;q2.Enqueue(k);}
            int lim=(int)(1000/CellM);
            while(q2.Count>0)
            {
                int c=q2.Dequeue(); if(dist[c]>=lim) continue;
                int i3=c%S,j3=c/S;
                for(int t=0;t<8;t++)
                {
                    int x=i3+new[]{1,1,0,-1,-1,-1,0,1}[t], y=j3+new[]{0,1,1,1,0,-1,-1,-1}[t];
                    if(x<0||y<0||x>=S||y>=S) continue;
                    int nb=y*S+x; if(Rocky(nb)||dist[nb]<=dist[c]+1) continue;
                    dist[nb]=dist[c]+1; q2.Enqueue(nb);
                }
            }
            // Охват считаем ДВАЖДЫ: по всей непроезжей-исключённой земле и только
            // по той, куда игрок вообще может добраться от сети. Второе честнее:
            // до недостижимых углов маршрут и не должен доходить.
            var reach=new bool[H.Length]; var q3=new Queue<int>();
            foreach(var p in paths) foreach(int k in p) if(!reach[k]){reach[k]=true;q3.Enqueue(k);}
            while(q3.Count>0)
            {
                int c=q3.Dequeue(); int i3=c%S,j3=c/S;
                foreach(var (dx,dy) in Mask)
                {
                    int x=i3+dx,y=j3+dy;
                    if(x<3||y<3||x>=S-3||y>=S-3) continue;
                    int nb=y*S+x;
                    if(!reach[nb]&&Cost(c,nb,false)>=0){reach[nb]=true;q3.Enqueue(nb);}
                }
            }
            // ---- РАЗМАХ СЕТИ ПО ТЕРРИТОРИИ ----
            //
            // Плотность троп и размах сети — разные вещи. Делим территорию на
            // квадраты 2x2 км и считаем, в скольких из тех, где вообще есть
            // проезжая земля, побывал маршрут. Это отвечает на вопрос «сеть
            // раскинута по территории или сидит в одном углу».
            int qcell=(int)(2000/CellM);
            int qn=(S+qcell-1)/qcell;
            var qHasLand=new bool[qn*qn]; var qHasRoute=new bool[qn*qn];
            for(int k=0;k<H.Length;k++)
                if(!Rocky(k)) qHasLand[(k/S/qcell)*qn+(k%S/qcell)]=true;
            foreach(var p in paths) foreach(int k in p)
                qHasRoute[(k/S/qcell)*qn+(k%S/qcell)]=true;
            int qLand=0,qRoute=0;
            for(int k=0;k<qn*qn;k++){ if(qHasLand[k]){qLand++; if(qHasRoute[k]) qRoute++;} }

            int ridable=0, covered=0, reachable=0, coveredR=0;
            for(int k=0;k<H.Length;k++)
            {
                if(Rocky(k)) continue;
                ridable++; if(dist[k]<=lim) covered++;
                if(reach[k]){reachable++; if(dist[k]<=lim) coveredR++;}
            }

            Console.WriteLine($"{seed,12}   опор {hubs.Count,2} (склон {thickHubs}, перевалов {passHubs}), "
                + $"рёбер {edgeSet.Count,2}, без тупиков {coreEdges,2}, бродов {fords,2}, "
                + $"вблизи троп {100.0*coveredR/Math.Max(reachable,1),3:F0}%, квадратов 2км с маршрутом {100.0*qRoute/Math.Max(qLand,1),3:F0}% | "
                + $"сеть {netLen/1000,5:F1} км, в полосе {100.0*inBandN/Math.Max(totalN,1),3:F0}%, колец {cyc,2}"
                + $" | перегонов долиной {valleyLinks}, {valleyLen/1000:F1} км");
            if(seed==-410752382)
            {
                using var bw=new BinaryWriter(File.Create("/home/claude/work/net.bin"));
                bw.Write(S); bw.Write(CellM);
                foreach(var v in H) bw.Write(v);
                foreach(var v in Frac) bw.Write(v);
                bw.Write(hubs.Count); foreach(var v in hubs) bw.Write(v);
                bw.Write(paths.Count);
                foreach(var p in paths){bw.Write(p.Count); foreach(var v in p) bw.Write(v);}
            }
        }
    }
}
