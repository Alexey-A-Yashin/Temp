using System;
using System.IO;
using ColoringBook.Infrastructure.Generation.Mapgen;
using ColoringBook.Infrastructure.Generation.Mapgen.Algorithms;

// ТОЧНАЯ КОПИЯ ПОСТРОЕНИЯ КОЛЕЦ ИЗ FarBackground.Build, БЕЗ GODOT.
//
// Нужна затем, чтобы подбирать что угодно, не гоняя игру, — но пользоваться ею
// можно только после сверки с настоящей выгрузкой. Порядок действий здесь
// повторяет FarBackground дословно, включая порядок обхода колец от грубого к
// мелкому и переходную полосу последней.
public static class Ringgen
{
    public const int Rings = 5, RingResolution = 120, DrainageSide = 241;
    public const float StepM = 30f, MetresPerUnit = 10f;
    const int ErosionIterations = 25, WaterIterations = 8, TransitionCells = 8;
    const float WaterStrength = 0.12f;

    public static float OuterExtent =>
        RingResolution * (StepM / MetresPerUnit) * (1 << (Rings - 1));

    public static float SampleWorld(SimplexNoise noise, float wx, float wz)
        => RidgedMountains.LayeredHeight(noise, wx * MetresPerUnit / 1000f,
                                         wz * MetresPerUnit / 1000f) / MetresPerUnit;

    public static float SampleGrid(float[] h, int n, float half, float step, float wx, float wz)
    {
        float gx = (wx + half) / step, gz = (wz + half) / step;
        int i0 = Math.Clamp((int)MathF.Floor(gx), 0, n - 1);
        int j0 = Math.Clamp((int)MathF.Floor(gz), 0, n - 1);
        float tx = Math.Clamp(gx - i0, 0f, 1f), tz = Math.Clamp(gz - j0, 0f, 1f);
        int s = n + 1;
        float a = h[j0 * s + i0], b = h[j0 * s + i0 + 1];
        float c = h[(j0 + 1) * s + i0], d = h[(j0 + 1) * s + i0 + 1];
        return (a * (1 - tx) + b * tx) * (1 - tz) + (c * (1 - tx) + d * tx) * tz;
    }

    static void Blend(float[] h, int n, float half, float step,
                      float[] oh, float ohalf, float ostep, int on)
    {
        int side = n + 1;
        for (int j = 0; j <= n; j++)
        for (int i = 0; i <= n; i++)
        {
            int edge = Math.Min(Math.Min(i, n - i), Math.Min(j, n - j));
            if (edge >= TransitionCells) continue;
            float w = edge / (float)TransitionCells;
            w = w * w * (3f - 2f * w);
            h[j * side + i] = SampleGrid(oh, on, ohalf, ostep,
                -half + i * step, -half + j * step) * (1f - w) + h[j * side + i] * w;
        }
    }

    public sealed class Ring
    {
        public int Index; public float Step, Half, Lift;
        public float[] H = Array.Empty<float>(), Flow = Array.Empty<float>();
    }

    /// <summary>Строит все кольца тем же порядком, что игра.</summary>
    public static Ring[] Build(int seed, float lift, out float[] drainage)
    {
        float outer = OuterExtent;
        drainage = RidgedMountains.BuildDrainage(DrainageSide, outer, seed);
        var noise = new SimplexNoise(seed);
        var built = new Ring[Rings];
        int n = RingResolution;
        for (int ring = Rings - 1; ring >= 0; ring--)
        {
            float stepW = StepM * MathF.Pow(2f, ring) / MetresPerUnit;
            float half = RingResolution * stepW * 0.5f;
            var h = new float[(n + 1) * (n + 1)];
            for (int j = 0; j <= n; j++)
            for (int i = 0; i <= n; i++)
                h[j * (n + 1) + i] = SampleWorld(noise, -half + i * stepW, -half + j * stepW) + lift;
            RidgedMountains.ThermalErosion(h, n + 1, stepW, 33f, ErosionIterations);
            var flow = new float[h.Length];
            RidgedMountains.HydraulicErosion(h, n + 1, stepW, WaterIterations, WaterStrength, flow);
            RidgedMountains.CarveChannels(h, n + 1, half, drainage, DrainageSide, outer);
            if (ring + 1 < Rings)
                Blend(h, n, half, stepW, built[ring + 1].H, built[ring + 1].Half,
                      built[ring + 1].Step, RingResolution);
            built[ring] = new Ring { Index = ring, Step = stepW, Half = half, Lift = lift, H = h, Flow = flow };
        }
        return built;
    }

    /// <summary>Чтение настоящей выгрузки игры — для сверки.</summary>
    public static Ring[] ReadDump(string path, out byte[][] biome)
    {
        using var f = new BinaryReader(File.OpenRead(path));
        if (new string(f.ReadChars(4)) != "CBTR") throw new Exception("не тот файл");
        int ver = f.ReadInt32(), count = f.ReadInt32();
        var outp = new Ring[count]; biome = new byte[count][];
        for (int r = 0; r < count; r++)
        {
            int ring = f.ReadInt32(), side = f.ReadInt32();
            float cell = f.ReadSingle(), lift = f.ReadSingle();
            var h = new float[side * side];
            for (int k = 0; k < h.Length; k++) h[k] = f.ReadSingle();
            var fl = new float[side * side];
            for (int k = 0; k < fl.Length; k++) fl[k] = f.ReadSingle();
            biome[ring] = ver >= 2 ? f.ReadBytes(side * side) : new byte[side * side];
            outp[ring] = new Ring { Index = ring, Step = cell, Half = (side - 1) * cell * 0.5f,
                                    Lift = lift, H = h, Flow = fl };
        }
        return outp;
    }
}
